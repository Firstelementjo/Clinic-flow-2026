import { Inject, Injectable, Logger, OnModuleDestroy, forwardRef } from '@nestjs/common';
import { Queue } from 'bullmq';
import IORedis from 'ioredis';
import { getConfig } from '@firstelement/config';
import {
  DEFAULT_JOB_OPTIONS,
  QueueName,
  type InboundJob,
  type OutboundJob,
} from '@firstelement/messaging';
import { resolveAIEligibility } from '@firstelement/messaging';
import { AIOrchestratorProvider, EscalationEngineProvider } from '../ai/ai.providers';
import { PrismaService } from '../common/prisma.service';
import { DomainEventBus } from '../events/domain-event-bus';
import { InboundPipelineProvider, OutboundDispatcherProvider } from './messaging.providers';

/**
 * The API's side of the queue (plan §11): accept the work, hand it off,
 * return. Nothing here waits on message processing, and later slices add
 * AI generation behind the same boundary without changing callers.
 *
 * `QUEUE_DRIVER=inline` runs the same job functions in-process. It exists
 * so the mock pipeline is exercisable on a machine without Redis, and
 * configuration rejects it in production — inline work dies with the
 * process, which is exactly what durable queues are for.
 */
@Injectable()
export class MessageQueueService implements OnModuleDestroy {
  private readonly logger = new Logger(MessageQueueService.name);
  private readonly driver = getConfig().QUEUE_DRIVER;
  private connection?: IORedis;
  private readonly queues = new Map<QueueName, Queue>();

  constructor(
    private readonly inbound: InboundPipelineProvider,
    private readonly outbound: OutboundDispatcherProvider,
    private readonly prisma: PrismaService,
    private readonly events: DomainEventBus,
    @Inject(forwardRef(() => AIOrchestratorProvider))
    private readonly orchestrator: AIOrchestratorProvider,
    @Inject(forwardRef(() => EscalationEngineProvider))
    private readonly escalation: EscalationEngineProvider,
  ) {}

  async enqueueInbound(job: InboundJob): Promise<void> {
    if (this.driver === 'inline') {
      const result = await this.inbound.process(job);
      this.logger.debug({ message: 'Inline inbound processing', result: result.status });
      if (result.status === 'processed') {
        // Score first: an explicit request for a person should hand over
        // before the agent spends a model call answering.
        await this.escalation.scoreTurn({
          organizationId: job.organizationId,
          projectId: job.projectId,
          conversationId: result.conversationId,
          messageId: result.messageId,
        });
        await this.runAITurnInline(job, result.conversationId, result.messageId);
      }
      return;
    }

    await this.queue(QueueName.INCOMING_MESSAGE).add('inbound', job, {
      ...DEFAULT_JOB_OPTIONS,
      // Second layer of idempotency: BullMQ drops a job whose id it has
      // already seen, so a provider retrying the same webhook does not
      // even reach the database (plan §8).
      jobId: `${job.projectId}:${job.channel}:${job.message.externalMessageId}`,
    });
  }

  async enqueueOutbound(job: OutboundJob): Promise<void> {
    if (this.driver === 'inline') {
      const result = await this.outbound.dispatch(job);
      if (result.status === 'failed') {
        this.logger.warn({ message: 'Inline outbound send failed', reason: result.reason });
      }
      return;
    }

    await this.queue(QueueName.OUTBOUND_SEND).add('outbound', job, {
      ...DEFAULT_JOB_OPTIONS,
      jobId: `send:${job.messageId}`,
    });
  }

  /**
   * Development-only path. In production the worker owns AI turns — an
   * HTTP process has no business sitting inside a 30-second model call.
   */
  private async runAITurnInline(
    job: InboundJob,
    conversationId: string,
    messageId: string,
  ): Promise<void> {
    const eligibility = await resolveAIEligibility(this.prisma.client, {
      organizationId: job.organizationId,
      projectId: job.projectId,
      conversationId,
    });
    if (!eligibility.eligible) return;

    const result = await this.orchestrator.run({
      organizationId: job.organizationId,
      projectId: job.projectId,
      conversationId,
      messageId,
    });

    if (result.status === 'replied') {
      await this.enqueueOutbound({
        organizationId: job.organizationId,
        projectId: job.projectId,
        conversationId,
        messageId: result.messageId,
      });
      return;
    }

    if (result.status === 'escalated' || result.status === 'failed') {
      await this.escalation.escalateDirectly({
        organizationId: job.organizationId,
        projectId: job.projectId,
        conversationId,
        reason: result.reason,
        trigger: result.status === 'failed' ? 'AI_FAILURE' : 'EXPLICIT_REQUEST',
      });
    }
  }

  private queue(name: QueueName): Queue {
    this.connection ??= new IORedis(getConfig().REDIS_URL, { maxRetriesPerRequest: null });

    let queue = this.queues.get(name);
    if (!queue) {
      queue = new Queue(name, { connection: this.connection });
      this.queues.set(name, queue);
    }
    return queue;
  }

  async onModuleDestroy(): Promise<void> {
    await Promise.all([...this.queues.values()].map((queue) => queue.close()));
    await this.connection?.quit();
  }
}
