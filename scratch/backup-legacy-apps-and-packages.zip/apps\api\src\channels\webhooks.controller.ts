import {
  Body,
  Controller,
  Get,
  HttpCode,
  Logger,
  NotFoundException,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
  Req,
} from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { getConfig } from '@firstelement/config';
import { resolveVerificationChallenge } from '@firstelement/connectors';
import { loadConnectionById } from '@firstelement/messaging';
import { ChannelType, ErrorCode } from '@firstelement/shared';
import { Public } from '../auth/decorators';
import { PrismaService } from '../common/prisma.service';
import { ConnectorRegistryProvider } from '../messaging/messaging.providers';
import { MessageQueueService } from '../messaging/message-queue.service';
import { ChannelsService } from './channels.service';
import type { RawBodyRequest } from './webhook.types';

/**
 * Public webhook endpoints for the real channels (plan §8).
 *
 * These are the only unauthenticated write paths in the API, so the
 * defences are worth stating:
 *
 * - **Signature or shared secret on every request.** Meta signs the body
 *   with the app secret; Telegram sends a secret token header. A request
 *   that fails verification is rejected before anything is parsed for
 *   meaning, and is never queued.
 * - **The connection id in the URL is not authorization.** It selects
 *   which credentials to verify against; the signature is what proves the
 *   caller is the platform.
 * - **Rate limited**, because an unauthenticated endpoint that enqueues
 *   work is a free amplifier otherwise.
 * - **Always 200 on a verified request**, even when processing fails.
 *   Meta and Telegram retry aggressively on non-2xx and eventually
 *   disable a failing webhook; durability belongs to the queue, not to
 *   the HTTP response.
 */
@Controller('webhooks')
export class WebhooksController {
  private readonly logger = new Logger(WebhooksController.name);
  private readonly encryptionKey = getConfig().ENCRYPTION_KEY;

  constructor(
    private readonly prisma: PrismaService,
    private readonly channels: ChannelsService,
    private readonly registry: ConnectorRegistryProvider,
    private readonly queue: MessageQueueService,
  ) {}

  /**
   * Meta's GET handshake when a webhook URL is registered. Echoes the
   * challenge only when the verify token matches, compared in constant
   * time.
   */
  @Get('meta/:connectionId')
  @Public()
  @Throttle({ default: { limit: 30, ttl: 60_000 } })
  async verify(
    @Param('connectionId', ParseUUIDPipe) connectionId: string,
    @Query('hub.mode') mode?: string,
    @Query('hub.verify_token') token?: string,
    @Query('hub.challenge') challenge?: string,
  ): Promise<string> {
    const connection = await loadConnectionById(this.prisma.client, this.encryptionKey, connectionId);
    const expected = connection?.credentials?.verifyToken;

    const result =
      typeof expected === 'string'
        ? resolveVerificationChallenge({ mode, token, challenge, expectedToken: expected })
        : null;

    if (result === null) {
      // Same 404 whether the connection is unknown or the token is wrong:
      // a probe should not learn which connection ids exist.
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Not found' });
    }

    return result;
  }

  @Post('meta/:connectionId')
  @Public()
  @HttpCode(200)
  @Throttle({ default: { limit: 600, ttl: 60_000 } })
  async meta(
    @Param('connectionId', ParseUUIDPipe) connectionId: string,
    @Req() request: RawBodyRequest,
    @Body() body: unknown,
  ): Promise<{ received: boolean }> {
    return this.handle(connectionId, request, body, [
      ChannelType.WHATSAPP,
      ChannelType.INSTAGRAM,
      ChannelType.MESSENGER,
    ]);
  }

  @Post('telegram/:connectionId')
  @Public()
  @HttpCode(200)
  @Throttle({ default: { limit: 600, ttl: 60_000 } })
  async telegram(
    @Param('connectionId', ParseUUIDPipe) connectionId: string,
    @Req() request: RawBodyRequest,
    @Body() body: unknown,
  ): Promise<{ received: boolean }> {
    return this.handle(connectionId, request, body, [ChannelType.TELEGRAM]);
  }

  private async handle(
    connectionId: string,
    request: RawBodyRequest,
    body: unknown,
    allowed: ChannelType[],
  ): Promise<{ received: boolean }> {
    const connection = await loadConnectionById(
      this.prisma.client,
      this.encryptionKey,
      connectionId,
      (error) =>
        this.logger.error({
          message: 'Could not decrypt channel credentials — has ENCRYPTION_KEY changed?',
          connectionId,
          error: error instanceof Error ? error.message : String(error),
        }),
    );

    if (!connection || !connection.isEnabled || !allowed.includes(connection.channel)) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Not found' });
    }

    const connector = this.registry.get(connection);

    const verified = await connector.verifyWebhook({
      rawBody: request.rawBody ?? Buffer.from(JSON.stringify(body ?? {}), 'utf8'),
      headers: request.headers as Record<string, string | undefined>,
    });

    if (!verified) {
      // Recorded on the connection so a misconfigured app secret shows up
      // on the channel panel rather than as silence.
      await this.channels.recordError(connection.id, 'Webhook signature verification failed');
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Not found' });
    }

    try {
      const messages = await connector.receiveWebhook(body);

      for (const message of messages) {
        await this.queue.enqueueInbound({
          organizationId: connection.organizationId,
          projectId: connection.projectId,
          connectionId: connection.id,
          channel: connection.channel,
          message,
        });
      }

      if (messages.length > 0) await this.channels.markInbound(connection.id);
    } catch (error) {
      // Still 200: the platform retrying the same broken payload does not
      // help, and a run of non-2xx responses gets the webhook disabled.
      this.logger.error({
        message: 'Webhook processing failed after verification',
        connectionId,
        error: error instanceof Error ? error.message : String(error),
      });
      await this.channels.recordError(
        connection.id,
        error instanceof Error ? error.message : 'Webhook processing failed',
      );
    }

    return { received: true };
  }
}
