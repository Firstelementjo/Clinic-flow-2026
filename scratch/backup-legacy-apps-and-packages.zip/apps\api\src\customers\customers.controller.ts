import { Body, Controller, Get, Param, ParseUUIDPipe, Patch, Query, Req } from '@nestjs/common';
import type { Request } from 'express';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import { paginationSchema, updateCustomerSchema, type UpdateCustomerInput } from '@firstelement/shared';
import { z } from 'zod';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { CustomersService } from './customers.service';

const listQuerySchema = paginationSchema.extend({ projectId: z.string().uuid().optional() });

@Controller('customers')
export class CustomersController {
  constructor(private readonly customers: CustomersService) {}

  @Get()
  @RequirePermissions(Permission.CUSTOMER_READ)
  list(@Tenant() ctx: TenantContext, @Query() query: unknown) {
    const { projectId, search, cursor, limit } = listQuerySchema.parse(query);
    return this.customers.list(ctx, { projectId, search, cursor, limit });
  }

  @Get(':customerId')
  @RequirePermissions(Permission.CUSTOMER_READ)
  getOne(
    @Tenant() ctx: TenantContext,
    @Param('customerId', ParseUUIDPipe) customerId: string,
  ) {
    return this.customers.getById(ctx, customerId);
  }

  @Get('cx/:cxId')
  @RequirePermissions(Permission.CUSTOMER_READ)
  getByCxId(@Tenant() ctx: TenantContext, @Param('cxId') cxId: string) {
    return this.customers.getByCxId(ctx, cxId);
  }

  @Patch(':customerId')
  @RequirePermissions(Permission.CUSTOMER_UPDATE)
  update(
    @Tenant() ctx: TenantContext,
    @Param('customerId', ParseUUIDPipe) customerId: string,
    @Body(zodBody(updateCustomerSchema)) body: UpdateCustomerInput,
    @Req() request: Request,
  ) {
    return this.customers.update(ctx, customerId, body, request.ip);
  }
}
