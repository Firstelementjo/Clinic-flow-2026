import { describe, expect, it } from 'vitest';
import {
  SecretBoxError,
  decryptJson,
  decryptSecret,
  encryptJson,
  encryptSecret,
  secretsMatch,
} from './secret-box';

const KEY = 'a'.repeat(64);
const OTHER_KEY = 'b'.repeat(64);

describe('encryptSecret / decryptSecret', () => {
  it('round-trips a value', () => {
    const envelope = encryptSecret('EAAG...meta-access-token', KEY);
    expect(decryptSecret(envelope, KEY)).toBe('EAAG...meta-access-token');
  });

  it('never leaves the plaintext in the envelope', () => {
    const envelope = encryptSecret('super-secret-token', KEY);
    expect(envelope).not.toContain('super-secret-token');
  });

  it('produces a different ciphertext each time, so equal tokens are not detectable', () => {
    expect(encryptSecret('same', KEY)).not.toBe(encryptSecret('same', KEY));
  });

  it('carries a version prefix so the key can be rotated later', () => {
    expect(encryptSecret('x', KEY).startsWith('v1.')).toBe(true);
  });

  it('refuses a key that is not 32 bytes of hex', () => {
    expect(() => encryptSecret('x', 'too-short')).toThrowError(SecretBoxError);
  });

  it('fails on the wrong key rather than returning garbage', () => {
    const envelope = encryptSecret('token', KEY);
    expect(() => decryptSecret(envelope, OTHER_KEY)).toThrowError(SecretBoxError);
  });

  it('detects tampering — the whole point of authenticated encryption', () => {
    // A blob edited in the database must fail loudly, not decrypt into
    // plausible nonsense that then gets sent to Meta as a token.
    const envelope = encryptSecret('token', KEY);
    const parts = envelope.split('.');
    const flipped = Buffer.from(parts[3]!, 'base64url');
    flipped[0] = flipped[0]! ^ 0xff;
    const tampered = [parts[0], parts[1], parts[2], flipped.toString('base64url')].join('.');

    expect(() => decryptSecret(tampered, KEY)).toThrowError(SecretBoxError);
  });

  it('rejects an envelope with an unknown shape', () => {
    expect(() => decryptSecret('not-an-envelope', KEY)).toThrowError(SecretBoxError);
    expect(() => decryptSecret('v2.a.b.c', KEY)).toThrowError(SecretBoxError);
  });

  it('handles non-ASCII secrets', () => {
    const envelope = encryptSecret('رمز-سري', KEY);
    expect(decryptSecret(envelope, KEY)).toBe('رمز-سري');
  });
});

describe('credential bundles', () => {
  it('round-trips a whole credential object', () => {
    const credentials = { accessToken: 'EAAG', phoneNumberId: '123', appSecret: 'shh' };
    const envelope = encryptJson(credentials, KEY);

    expect(envelope).not.toContain('EAAG');
    expect(decryptJson(envelope, KEY)).toEqual(credentials);
  });
});

describe('secretsMatch', () => {
  it('matches identical secrets', () => {
    expect(secretsMatch('token', 'token')).toBe(true);
  });

  it('rejects different secrets and different lengths', () => {
    expect(secretsMatch('token', 'other')).toBe(false);
    expect(secretsMatch('token', 'token-longer')).toBe(false);
  });

  it('rejects an empty candidate against a real secret', () => {
    expect(secretsMatch('', 'token')).toBe(false);
  });
});
