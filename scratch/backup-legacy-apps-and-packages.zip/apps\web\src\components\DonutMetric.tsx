/**
 * A circular donut gauge for displaying a percentage metric.
 * Pure SVG, no external dependencies.
 */
export function DonutMetric({
  label,
  value,
  color = 'var(--fe-agent)',
}: {
  label: string;
  value: number | null;
  /** CSS colour for the filled arc. */
  color?: string;
}) {
  const pct = Math.min(100, Math.max(0, value ?? 0));
  const r = 36;
  const circumference = 2 * Math.PI * r;
  const offset = circumference - (pct / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative">
        <svg width="96" height="96" viewBox="0 0 96 96" className="-rotate-90">
          {/* Background track */}
          <circle
            cx="48"
            cy="48"
            r={r}
            fill="none"
            stroke="var(--fe-mist-deep)"
            strokeWidth="8"
          />
          {/* Filled arc */}
          <circle
            cx="48"
            cy="48"
            r={r}
            fill="none"
            stroke={color}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className="transition-[stroke-dashoffset] duration-700 ease-out"
          />
        </svg>
        {/* Value sits in the centre of the ring */}
        <span className="absolute inset-0 flex items-center justify-center fe-mono text-lg font-semibold text-ink" dir="ltr">
          {value === null ? '—' : `${pct}%`}
        </span>
      </div>
      <span className="fe-eyebrow text-center text-xs">{label}</span>
    </div>
  );
}
