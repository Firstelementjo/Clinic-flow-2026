import { Injectable } from '@nestjs/common';
import { accessibleProjectsScope, projectScope, type TenantContext } from '@firstelement/database';
import { PrismaService } from '../common/prisma.service';

export interface AnalyticsSummary {
  window: { from: string; to: string; days: number };
  conversations: {
    total: number;
    open: number;
    resolved: number;
    escalated: number;
    /** Share resolved without ever reaching a human, 0–100. */
    aiResolutionRate: number;
    escalationRate: number;
  };
  responsiveness: {
    /** Minutes from the customer's first message to the first human reply. */
    medianFirstResponseMinutes: number | null;
    medianResolutionMinutes: number | null;
    /**
     * Average handling time (V1.2 §22): first response → resolution, the
     * stretch an agent actually worked the case. Deliberately not
     * created→resolved, which would count the time a conversation sat in
     * the queue overnight as handling.
     */
    averageHandlingMinutes: number | null;
  };
  /**
   * Satisfaction from the case resolution record (V1.2 §14).
   *
   * **Agent-reported, not customer-reported.** Nothing in this build asks
   * the customer directly; the agent records whether the customer seemed
   * satisfied. Treat these as an internal quality signal rather than a
   * survey result — see docs/analytics.md.
   */
  satisfaction: {
    /** Share of rated cases marked satisfied, 0–100. */
    csat: number | null;
    /** Share marked not satisfied, 0–100. */
    dsat: number | null;
    /** How many resolutions carried a satisfaction answer at all. */
    rated: number;
    casesResolved: number;
    /** Resolved as a share of all cases with a recorded outcome. */
    resolveRate: number | null;
  };
  ai: {
    runs: number;
    failedRuns: number;
    escalatedRuns: number;
    medianLatencyMs: number | null;
    inputTokens: number;
    outputTokens: number;
    estimatedCostUsd: number;
  };
  channels: { channel: string; conversations: number }[];
  knowledgeGaps: { query: string; occurrences: number }[];
  workload: { employee: string; active: number; capacity: number }[];
}

const DEFAULT_WINDOW_DAYS = 30;

/**
 * Analytics (plan §29/§69).
 *
 * Computed on read rather than from a rollup table. At the volumes a
 * single project produces this is a handful of indexed aggregates, and it
 * has the property that matters while the product is young: the numbers
 * cannot silently disagree with the rows they come from. When a project
 * outgrows it, the honest fix is a materialized rollup on the
 * analytics-rollup queue that already exists — not a cache bolted on here.
 *
 * Every query is tenant-scoped through the same helpers as the rest of
 * the API. An organization-wide view is the union of the caller's
 * accessible projects, never "all rows in the table".
 */
export interface EmployeeAnalyticsSummary {
  csat: number | null;
  dsat: number | null;
  resolveRate: number | null;
  casesResolved: number;
  averageHandlingMinutes: number | null;
  medianFirstResponseMinutes: number | null;
}

@Injectable()
export class AnalyticsService {
  constructor(private readonly prisma: PrismaService) {}

  async employeeSummary(
    ctx: TenantContext,
    employeeId: string,
    options: { days?: number } = {},
  ): Promise<EmployeeAnalyticsSummary> {
    const days = Math.min(Math.max(options.days ?? 30, 1), 365);
    const from = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const scope = accessibleProjectsScope(ctx);

    // Find the user for this employee
    const employee = await this.prisma.client.employee.findFirst({
      where: { id: employeeId, organizationId: ctx.organizationId },
      select: { userId: true },
    });
    if (!employee) {
      return { csat: null, dsat: null, resolveRate: null, casesResolved: 0, averageHandlingMinutes: null, medianFirstResponseMinutes: null };
    }

    // Conversations assigned to this employee
    const conversations = await this.prisma.client.conversation.findMany({
      where: { ...scope, assignedEmployeeId: employee.userId, createdAt: { gte: from } },
      select: {
        id: true,
        status: true,
        createdAt: true,
        firstResponseAt: true,
        resolvedAt: true,
      },
    });

    // Case resolutions for this employee's conversations
    const conversationIds = conversations.map((c) => c.id);
    const resolutions = conversationIds.length > 0
      ? await this.prisma.client.caseResolution.findMany({
          where: { conversationId: { in: conversationIds }, createdAt: { gte: from } },
          select: { outcome: true, customerSatisfied: true },
        })
      : [];

    const rated = resolutions.filter((r) => r.customerSatisfied !== null);
    const satisfied = rated.filter((r) => r.customerSatisfied === true).length;
    const casesResolved = resolutions.filter((r) => r.outcome === 'RESOLVED').length;

    const firstResponseMinutes = conversations
      .filter((c) => c.firstResponseAt)
      .map((c) => minutesBetween(c.createdAt, c.firstResponseAt!));

    const handlingMinutes = conversations
      .filter((c) => c.firstResponseAt && c.resolvedAt)
      .map((c) => minutesBetween(c.firstResponseAt!, c.resolvedAt!))
      .filter((m) => m >= 0);

    return {
      csat: rated.length === 0 ? null : percentage(satisfied, rated.length),
      dsat: rated.length === 0 ? null : percentage(rated.length - satisfied, rated.length),
      resolveRate: resolutions.length === 0 ? null : percentage(casesResolved, resolutions.length),
      casesResolved,
      averageHandlingMinutes: mean(handlingMinutes),
      medianFirstResponseMinutes: median(firstResponseMinutes),
    };
  }

  /**
   * Paginated audit-log browsing.
   *
   * <p>This lives in the service rather than the controller for the reason
   * `plan.md` §0.4 gives: authorization must not live only in a controller. The
   * route takes `projectId` from the **query string**, so `PermissionsGuard`
   * supplies no project scope for it (`can()` only checks the project boundary
   * when a project id is handed to it), and the previous inline
   * `where: { organizationId, ...(projectId ? { projectId } : {}) }` in the
   * controller therefore let any `AUDIT_LOG_READ` holder page through the audit
   * log of any project in their organization — actor names, emails and metadata.
   *
   * <p>A supplied `projectId` now goes through `projectScope`, which refuses a
   * project the caller does not hold membership of and renders as a 404 that is
   * indistinguishable from a nonexistent one. With no `projectId`, the scope is
   * the caller's reachable projects rather than the whole organization.
   */
  async auditLogs(
    ctx: TenantContext,
    options: { action?: string; projectId?: string; cursor?: string; limit?: number } = {},
  ) {
    const limit = options.limit ?? 50;

    const scope = options.projectId
      ? projectScope(ctx, options.projectId)
      : accessibleProjectsScope(ctx);

    const rows = await this.prisma.client.auditLog.findMany({
      where: {
        ...scope,
        ...(options.action ? { action: options.action } : {}),
      },
      select: {
        id: true,
        action: true,
        actorType: true,
        resourceType: true,
        resourceId: true,
        projectId: true,
        metadata: true,
        createdAt: true,
        actor: { select: { fullName: true, email: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: limit + 1,
      ...(options.cursor ? { cursor: { id: options.cursor }, skip: 1 } : {}),
    });

    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;

    return {
      items: page.map((row) => ({
        id: row.id,
        action: row.action,
        actorType: row.actorType,
        actorName: row.actor?.fullName ?? null,
        resourceType: row.resourceType,
        resourceId: row.resourceId,
        projectId: row.projectId,
        metadata: row.metadata as Record<string, unknown>,
        createdAt: row.createdAt.toISOString(),
      })),
      nextCursor: hasMore ? (page[page.length - 1]?.id ?? null) : null,
    };
  }

  async summary(
    ctx: TenantContext,
    options: { projectId?: string; days?: number } = {},
  ): Promise<AnalyticsSummary> {
    const days = Math.min(Math.max(options.days ?? DEFAULT_WINDOW_DAYS, 1), 365);
    const from = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const to = new Date();

    const scope = options.projectId
      ? projectScope(ctx, options.projectId)
      : accessibleProjectsScope(ctx);

    const [conversations, escalations, aiRuns, usage, gaps, employees, resolutions] = await Promise.all([
      this.prisma.client.conversation.findMany({
        where: { ...scope, createdAt: { gte: from } },
        select: {
          id: true,
          status: true,
          channel: true,
          createdAt: true,
          firstResponseAt: true,
          resolvedAt: true,
          _count: { select: { escalations: true } },
        },
      }),
      this.prisma.client.escalation.count({ where: { ...scope, createdAt: { gte: from } } }),
      this.prisma.client.aIRun.findMany({
        where: { ...scope, startedAt: { gte: from } },
        select: { status: true, decision: true, latencyMs: true },
      }),
      this.prisma.client.aIUsage.aggregate({
        where: { ...scope, createdAt: { gte: from } },
        _sum: { inputTokens: true, outputTokens: true, estimatedCost: true },
      }),
      this.prisma.client.knowledgeGap.groupBy({
        by: ['query'],
        where: { ...scope, createdAt: { gte: from } },
        _count: { query: true },
        orderBy: { _count: { query: 'desc' } },
        take: 10,
      }),
      this.prisma.client.employee.findMany({
        where: { organizationId: ctx.organizationId },
        select: {
          activeConversationCount: true,
          maxConcurrentConversations: true,
          user: { select: { fullName: true } },
        },
        orderBy: { activeConversationCount: 'desc' },
        take: 10,
      }),
      // The V1.2 §14 resolution records — the source for CSAT/DSAT,
      // resolve rate and cases resolved.
      this.prisma.client.caseResolution.findMany({
        where: { ...scope, createdAt: { gte: from } },
        select: { outcome: true, customerSatisfied: true },
      }),
    ]);

    const total = conversations.length;
    const resolved = conversations.filter((c) => c.status === 'RESOLVED').length;
    const escalatedConversations = conversations.filter((c) => c._count.escalations > 0).length;

    // "AI resolved it" means resolved without ever escalating — not
    // "the AI sent a message", which would flatter the number badly.
    const aiResolved = conversations.filter(
      (c) => c.status === 'RESOLVED' && c._count.escalations === 0,
    ).length;

    const firstResponseMinutes = conversations
      .filter((c) => c.firstResponseAt)
      .map((c) => minutesBetween(c.createdAt, c.firstResponseAt!));

    const resolutionMinutes = conversations
      .filter((c) => c.resolvedAt)
      .map((c) => minutesBetween(c.createdAt, c.resolvedAt!));

    // Handling time is first response → resolution: the stretch an agent
    // actually worked. Counting from creation would bill a conversation
    // that waited overnight in the queue as handling time.
    const handlingMinutes = conversations
      .filter((c) => c.firstResponseAt && c.resolvedAt)
      .map((c) => minutesBetween(c.firstResponseAt!, c.resolvedAt!))
      .filter((minutes) => minutes >= 0);

    const rated = resolutions.filter((r) => r.customerSatisfied !== null);
    const satisfied = rated.filter((r) => r.customerSatisfied === true).length;
    const casesResolved = resolutions.filter((r) => r.outcome === 'RESOLVED').length;

    const latencies = aiRuns
      .map((run) => run.latencyMs)
      .filter((value): value is number => typeof value === 'number');

    const byChannel = new Map<string, number>();
    for (const conversation of conversations) {
      byChannel.set(conversation.channel, (byChannel.get(conversation.channel) ?? 0) + 1);
    }

    return {
      window: { from: from.toISOString(), to: to.toISOString(), days },
      conversations: {
        total,
        open: conversations.filter((c) => c.status === 'OPEN' || c.status === 'PENDING').length,
        resolved,
        escalated: escalations,
        aiResolutionRate: percentage(aiResolved, total),
        escalationRate: percentage(escalatedConversations, total),
      },
      responsiveness: {
        // Median, not mean: one conversation left open over a weekend
        // drags an average into uselessness.
        medianFirstResponseMinutes: median(firstResponseMinutes),
        medianResolutionMinutes: median(resolutionMinutes),
        averageHandlingMinutes: mean(handlingMinutes),
      },
      satisfaction: {
        // Null rather than zero when nothing was rated: "no data" and
        // "everyone was unhappy" must not render identically.
        csat: rated.length === 0 ? null : percentage(satisfied, rated.length),
        dsat: rated.length === 0 ? null : percentage(rated.length - satisfied, rated.length),
        rated: rated.length,
        casesResolved,
        resolveRate: resolutions.length === 0 ? null : percentage(casesResolved, resolutions.length),
      },
      ai: {
        runs: aiRuns.length,
        failedRuns: aiRuns.filter((run) => run.status === 'FAILED').length,
        escalatedRuns: aiRuns.filter((run) => run.decision === 'ESCALATE').length,
        medianLatencyMs: median(latencies),
        inputTokens: usage._sum.inputTokens ?? 0,
        outputTokens: usage._sum.outputTokens ?? 0,
        estimatedCostUsd: Number((usage._sum.estimatedCost ?? 0).toFixed(4)),
      },
      channels: [...byChannel.entries()]
        .map(([channel, count]) => ({ channel, conversations: count }))
        .sort((a, b) => b.conversations - a.conversations),
      // The backlog of what the knowledge base is missing, most asked first.
      knowledgeGaps: gaps.map((gap) => ({
        query: gap.query.slice(0, 120),
        occurrences: gap._count.query,
      })),
      workload: employees.map((employee) => ({
        employee: employee.user.fullName,
        active: employee.activeConversationCount,
        capacity: employee.maxConcurrentConversations,
      })),
    };
  }
}

function minutesBetween(start: Date, end: Date): number {
  return Math.max(0, (end.getTime() - start.getTime()) / 60_000);
}

function mean(values: number[]): number | null {
  if (values.length === 0) return null;
  const total = values.reduce((sum, value) => sum + value, 0);
  return Number((total / values.length).toFixed(1));
}

function median(values: number[]): number | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  const value =
    sorted.length % 2 === 0 ? (sorted[middle - 1]! + sorted[middle]!) / 2 : sorted[middle]!;
  return Number(value.toFixed(1));
}

function percentage(part: number, whole: number): number {
  if (whole === 0) return 0;
  return Number(((part / whole) * 100).toFixed(1));
}
