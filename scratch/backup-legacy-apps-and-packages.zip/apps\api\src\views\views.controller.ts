import { Body, Controller, Delete, Get, Param, ParseEnumPipe, ParseUUIDPipe, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { CrmObjectType, type CreateViewInput, type UpdateViewInput } from '@firstelement/shared';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import { AuthGuard } from '../auth/auth.guard';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { zodBody } from '../common/zod-validation.pipe';
import { createViewSchema, updateViewSchema } from '@firstelement/shared';
import { ViewsService } from './views.service';

/**
 * Saved views are a per-workspace configuration, so they ride the generic
 * `objects/:objectType/views` shape from the spec rather than a table of
 * their own on each CRM controller.
 */
@Controller()
@UseGuards(AuthGuard)
export class ViewsController {
  constructor(private readonly views: ViewsService) {}

  @Get('objects/:objectType/views')
  @RequirePermissions(Permission.VIEW_READ)
  list(
    @Tenant() ctx: TenantContext,
    @Param('objectType', new ParseEnumPipe(CrmObjectType)) objectType: string,
    @Query() query: { projectId: string },
  ) {
    return this.views.list(ctx, objectType, query.projectId);
  }

  @Post('objects/:objectType/views')
  @RequirePermissions(Permission.VIEW_MANAGE)
  create(
    @Tenant() ctx: TenantContext,
    @Param('objectType', new ParseEnumPipe(CrmObjectType)) objectType: string,
    @Query() query: { projectId: string },
    @Body(zodBody(createViewSchema)) body: CreateViewInput,
  ) {
    return this.views.create(ctx, objectType, query.projectId, body);
  }

  @Patch('views/:id')
  @RequirePermissions(Permission.VIEW_MANAGE)
  update(
    @Tenant() ctx: TenantContext,
    @Param('id', ParseUUIDPipe) id: string,
    @Body(zodBody(updateViewSchema)) body: UpdateViewInput,
  ) {
    return this.views.update(ctx, id, body);
  }

  @Delete('views/:id')
  @RequirePermissions(Permission.VIEW_MANAGE)
  remove(@Tenant() ctx: TenantContext, @Param('id', ParseUUIDPipe) id: string) {
    return this.views.remove(ctx, id);
  }
}