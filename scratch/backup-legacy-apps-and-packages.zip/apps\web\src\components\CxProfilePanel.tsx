import { Spinner, StatusChip, useDirection } from '@firstelement/ui';
import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import { useT, type StringKey } from '../lib/i18n';
import type { CustomerDetail } from '../lib/customers';
import { useSession } from '../lib/session';
import type { SessionUser } from '@firstelement/shared';

/**
 * Slide-over panel that shows a CX profile when clicking a CX ID.
 * Contact details (phone/email) are visible to admins only.
 * Past tickets show dates, agent name, and status.
 */
export function CxProfilePanel({
  customerId,
  onClose,
}: {
  customerId: string;
  onClose: () => void;
}) {
  const t = useT();
  const { locale } = useDirection();
  const session = useSession();
  const isAdmin = (session.data as SessionUser | null)?.role === 'ADMIN';

  const customer = useQuery({
    queryKey: ['customer', customerId],
    queryFn: () => api.get<CustomerDetail>(`/customers/${customerId}`),
  });

  if (customer.isPending) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner label={t('common.loading')} />
      </div>
    );
  }

  if (customer.isError || !customer.data) {
    return (
      <p className="p-4 text-sm text-slate">{t('common.error')}</p>
    );
  }

  const data = customer.data;

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <header className="flex shrink-0 items-center gap-3 border-b border-hairline px-4 py-3">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-ink">{data.cxId}</p>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="rounded px-1.5 text-xs text-slate hover:bg-mist hover:text-ink"
        >
          ✕
        </button>
      </header>

      <div className="min-h-0 flex-1 overflow-y-auto">
        {/* Contact details — admin only */}
        {isAdmin && (data.primaryPhone || data.primaryEmail) && (
          <div className="border-b border-hairline px-4 py-3">
            <p className="fe-eyebrow mb-1.5">{t('customer.contactDetails')}</p>
            <dl className="flex flex-col gap-1 text-xs">
              {data.primaryPhone && (
                <div className="flex items-center gap-2">
                  <dt className="text-slate-soft">{t('customer.phone')}:</dt>
                  <dd className="fe-mono text-ink" dir="ltr">{data.primaryPhone}</dd>
                </div>
              )}
              {data.primaryEmail && (
                <div className="flex items-center gap-2">
                  <dt className="text-slate-soft">{t('customer.email')}:</dt>
                  <dd className="fe-mono text-ink" dir="ltr">{data.primaryEmail}</dd>
                </div>
              )}
            </dl>
          </div>
        )}

        {/* First/last seen */}
        <div className="grid grid-cols-2 gap-2 border-b border-hairline px-4 py-3 text-xs">
          <div>
            <dt className="fe-eyebrow">{t('customer.firstSeen')}</dt>
            <dd className="fe-mono text-slate" dir="ltr">
              {formatDate(data.firstSeenAt, locale)}
            </dd>
          </div>
          <div>
            <dt className="fe-eyebrow">{t('customer.lastSeen')}</dt>
            <dd className="fe-mono text-slate" dir="ltr">
              {formatDate(data.lastSeenAt, locale)}
            </dd>
          </div>
        </div>

        {/* Total tickets */}
        <div className="border-b border-hairline px-4 py-3">
          <p className="fe-eyebrow mb-1">{t('customer.ticketHistory')}</p>
          <p className="text-xs text-slate">
            {data.conversations.length} {t('customer.totalTickets')}
          </p>
        </div>

        {/* Ticket list */}
        <ul className="divide-y divide-hairline">
          {data.conversations.map((conversation) => (
            <li key={conversation.id} className="px-4 py-2.5">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-ink">
                  {conversation.ticketNumber}
                </span>
                <StatusChip
                  tone={
                    conversation.status === 'OPEN'
                      ? 'human'
                      : conversation.status === 'CLOSED'
                        ? 'neutral'
                        : 'ai'
                  }
                >
                  {t(`status.${conversation.status}` as StringKey)}
                </StatusChip>
              </div>
              <div className="mt-1 flex items-center gap-3 text-xs text-slate">
                <span className="fe-eyebrow">{conversation.channel}</span>
                {conversation.assignedAgent && (
                  <span>{t('customer.agent')}: {conversation.assignedAgent}</span>
                )}
                <span className="fe-mono ms-auto" dir="ltr">
                  {formatDate(conversation.createdAt, locale)}
                </span>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
