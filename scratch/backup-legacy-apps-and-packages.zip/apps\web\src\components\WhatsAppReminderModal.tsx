import { useState } from 'react';
import {
  Calendar,
  Check,
  CheckCheck,
  Clock,
  MapPin,
  MessageCircle,
  Phone,
  ShieldCheck,
  Stethoscope,
  X,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { Spinner, useDirection } from '@firstelement/ui';
import { usePatientReminderAction } from '../lib/reminders';

interface WhatsAppReminderModalProps {
  appointment: {
    id: string;
    title: string;
    patientName?: string | null;
    patientPhone?: string | null;
    doctorName?: string | null;
    service?: string | null;
    appointmentDate: string;
    status: string;
  } | null;
  onClose: () => void;
}

export function WhatsAppReminderModal({ appointment, onClose }: WhatsAppReminderModalProps) {
  const dir = useDirection();
  const respondMutation = usePatientReminderAction();
  const [patientResponse, setPatientResponse] = useState<string | null>(null);

  if (!appointment) return null;

  const apptDate = new Date(appointment.appointmentDate);
  const formattedDate = apptDate.toLocaleDateString(dir.locale === 'ar' ? 'ar-SA' : 'en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  });
  const formattedTime = apptDate.toLocaleTimeString(dir.locale === 'ar' ? 'ar-SA' : 'en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const handleAction = (action: 'CONFIRM' | 'RESCHEDULE' | 'CANCEL') => {
    respondMutation.mutate(
      {
        appointmentId: appointment.id,
        action,
      },
      {
        onSuccess: () => {
          if (action === 'CONFIRM') {
            setPatientResponse(
              dir.locale === 'ar'
                ? 'شكراً لك! تم تأكيد حضورك بنجاح. ننتظرك في الموعد.'
                : 'Thank you! Your attendance is confirmed. See you then!',
            );
          } else if (action === 'RESCHEDULE') {
            setPatientResponse(
              dir.locale === 'ar'
                ? 'تم استلام طلبك لتغيير الموعد. سيتواصل معك المساعد الذكي بالخيارات المتاحة.'
                : 'Reschedule request received! Our AI agent will send you available slots.',
            );
          } else {
            setPatientResponse(
              dir.locale === 'ar'
                ? 'تم إلغاء الموعد بناءً على طلبك. تم فتح الوقت لمرضى آخرين.'
                : 'Appointment cancelled per your request. The slot has been released.',
            );
          }
        },
      },
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-md rounded-3xl bg-[#121b22] text-white shadow-2xl border border-white/10 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Phone Speaker & Camera Notch */}
        <div className="flex justify-center pt-2 pb-1 bg-[#1f2c34]">
          <div className="h-1.5 w-16 rounded-full bg-white/20" />
        </div>

        {/* WhatsApp Mobile Top Bar */}
        <div className="flex items-center justify-between bg-[#1f2c34] px-4 py-2.5 border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="h-10 w-10 rounded-full bg-[#00a884] flex items-center justify-center font-bold text-white shadow-sm">
                CF
              </div>
              <span className="absolute bottom-0 end-0 h-3 w-3 rounded-full bg-[#25D366] border-2 border-[#1f2c34]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-sm text-white">Clinic Flow Care</span>
                <ShieldCheck className="h-4 w-4 text-[#00a884]" />
              </div>
              <p className="text-[11px] text-[#8696a0]">Official Clinic WhatsApp</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-1.5 text-[#8696a0] hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* WhatsApp Chat Body */}
        <div className="p-4 space-y-3 bg-[#0b141a] min-h-[380px] flex flex-col justify-end text-xs">
          {/* Encryption Notice */}
          <div className="mx-auto rounded-lg bg-[#182229] px-3 py-1.5 text-[10px] text-[#8696a0] text-center max-w-[90%] shadow-xs">
            Messages and calls are end-to-end encrypted. No one outside of this chat can read them.
          </div>

          {/* Date separator */}
          <div className="flex justify-center">
            <span className="rounded-md bg-[#182229] px-2 py-0.5 text-[10px] text-[#8696a0]">
              TODAY
            </span>
          </div>

          {/* Automated Interactive Reminder Message Bubble */}
          <div className="flex flex-col items-start max-w-[95%]">
            <div className="rounded-2xl rounded-tl-xs bg-[#202c33] text-[#e9edef] p-3.5 shadow-sm space-y-2.5 border border-white/5">
              {/* Reminder Title Header */}
              <div className="flex items-center gap-2 text-[#00a884] font-bold text-xs">
                <MessageCircle className="h-4 w-4 shrink-0" />
                <span>
                  {dir.locale === 'ar' ? 'تذكير بموعد العيادة القادم' : 'Upcoming Clinic Appointment Reminder'}
                </span>
              </div>

              {/* Greeting */}
              <p className="text-xs text-[#d1d7db]">
                {dir.locale === 'ar'
                  ? `عزيزنا/عزيزتنا ${appointment.patientName || 'المريض'}،`
                  : `Dear ${appointment.patientName || 'Patient'},`}
              </p>

              <p className="text-xs text-[#d1d7db] leading-relaxed">
                {dir.locale === 'ar'
                  ? `نود تذكيرك بموعدك الطبي القادم لدى عياداتنا. يرجى تأكيد الحضور بضغطة زر أدناه لتثبيت وقت الطبيب:`
                  : `This is a friendly reminder of your upcoming medical consultation. Please confirm your attendance below to secure the doctor's schedule:`}
              </p>

              {/* Appointment Highlight Box */}
              <div className="rounded-xl bg-[#111b21] p-3 space-y-1.5 border border-white/5 font-mono text-[11px]">
                <div className="flex items-center gap-2 text-[#00a884]">
                  <Stethoscope className="h-3.5 w-3.5 shrink-0" />
                  <span className="font-semibold text-white">
                    {appointment.doctorName || 'Doctor Sarah Al-Ahmad'}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[#8696a0]">
                  <Calendar className="h-3.5 w-3.5 shrink-0" />
                  <span>{formattedDate}</span>
                </div>
                <div className="flex items-center gap-2 text-[#8696a0]">
                  <Clock className="h-3.5 w-3.5 shrink-0" />
                  <span>{formattedTime}</span>
                </div>
                <div className="flex items-center gap-2 text-[#8696a0]">
                  <MapPin className="h-3.5 w-3.5 shrink-0" />
                  <span>Medical Tower, Floor 4, Suite 402</span>
                </div>
              </div>

              {/* 3 WhatsApp 1-Click Interactive Buttons */}
              <div className="pt-2 border-t border-white/10 space-y-1.5">
                <p className="text-[10px] text-[#8696a0] font-semibold">
                  {dir.locale === 'ar' ? 'الرجاء الضغط على خيارك أدناه:' : 'Select an option below:'}
                </p>

                <div className="flex flex-col gap-1.5">
                  <button
                    type="button"
                    disabled={respondMutation.isPending}
                    onClick={() => handleAction('CONFIRM')}
                    className="w-full flex items-center justify-center gap-2 rounded-xl bg-[#00a884] text-white py-2 text-xs font-bold hover:bg-[#008f6f] active:scale-[0.98] transition-all shadow-xs"
                  >
                    <Check className="h-4 w-4" />
                    <span>{dir.locale === 'ar' ? 'تأكيد الحضور' : 'Confirm Attendance'}</span>
                  </button>

                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      disabled={respondMutation.isPending}
                      onClick={() => handleAction('RESCHEDULE')}
                      className="flex items-center justify-center gap-1.5 rounded-xl bg-[#2a3942] text-[#e9edef] py-2 text-[11px] font-semibold hover:bg-[#32444f] transition-all"
                    >
                      <RefreshCw className="h-3 w-3 text-amber-400" />
                      <span>{dir.locale === 'ar' ? 'طلب تغيير الموعد' : 'Reschedule'}</span>
                    </button>

                    <button
                      type="button"
                      disabled={respondMutation.isPending}
                      onClick={() => handleAction('CANCEL')}
                      className="flex items-center justify-center gap-1.5 rounded-xl bg-[#2a3942] text-[#f15c6d] py-2 text-[11px] font-semibold hover:bg-[#32444f] transition-all"
                    >
                      <X className="h-3 w-3" />
                      <span>{dir.locale === 'ar' ? 'إلغاء الموعد' : 'Cancel'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Timestamp & double blue ticks */}
              <div className="flex items-center justify-end gap-1 text-[10px] text-[#8696a0] pt-1">
                <span>{formattedTime}</span>
                <CheckCheck className="h-3.5 w-3.5 text-[#53bdeb]" />
              </div>
            </div>
          </div>

          {/* Patient Interactive Reaction / Live Confirmation Message */}
          {patientResponse && (
            <div className="flex flex-col items-end max-w-[90%] ms-auto animate-in slide-in-from-bottom-2 duration-200">
              <div className="rounded-2xl rounded-tr-xs bg-[#005c4b] text-[#e9edef] p-3 shadow-sm border border-white/5 space-y-1">
                <p className="text-xs font-medium leading-relaxed">{patientResponse}</p>
                <div className="flex items-center justify-end gap-1 text-[10px] text-white/70">
                  <span>Just now</span>
                  <CheckCheck className="h-3.5 w-3.5 text-[#53bdeb]" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info note */}
        <div className="bg-[#1f2c34] p-3 text-center border-t border-white/5 text-[11px] text-[#8696a0]">
          Click any button above to test the real-time status update in Clinic Flow.
        </div>
      </div>
    </div>
  );
}
