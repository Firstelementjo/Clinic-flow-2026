import { Module } from '@nestjs/common';
import { RoutingController } from './routing.controller';
import { RoutingService } from './routing.service';
import { RoutingEngineProvider } from './routing.providers';
import { AgentStatusService } from './agent-status.service';

@Module({
  controllers: [RoutingController],
  providers: [RoutingService, RoutingEngineProvider, AgentStatusService],
  exports: [RoutingService, RoutingEngineProvider, AgentStatusService],
})
export class RoutingModule {}
