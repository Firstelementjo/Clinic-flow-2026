import { useNavigate } from 'react-router-dom';
import { StatusChip, StatusRail, useDirection, type StatusTone } from '@firstelement/ui';
import type { ConversationSummary } from '@firstelement/shared';
import { formatListStamp } from '../lib/format';
import { useT, type StringKey } from '../lib/i18n';
import { navigateToCxProfile, navigateToTicket } from '../lib/navigate-cx';
import { useCloseConversation } from '../lib/inbox';

export function toneFor(conversation: ConversationSummary): StatusTone {
  if (conversation.priority === 'URGENT') return 'escalated';
  return conversation.mode === 'AI' ? 'ai' : 'human';
}

export function ConversationList({
  conversations,
  selectedId,
  onSelect,
  showCloseButton = true,
}: {
  conversations: ConversationSummary[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  showCloseButton?: boolean;
}) {
  const t = useT();
  const { locale } = useDirection();
  const navigate = useNavigate();
  const closeMutation = useCloseConversation();

  return (
    <ul className="divide-y divide-hairline">
      {conversations.map((conversation) => {
        const isSelected = conversation.id === selectedId;
        const canClose = showCloseButton && conversation.status !== 'RESOLVED' && conversation.status !== 'CLOSED';
        return (
          <li key={conversation.id} className="relative group">
            <StatusRail tone={toneFor(conversation)} />
            <div
              role="button"
              tabIndex={0}
              onClick={() => onSelect(conversation.id)}
              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onSelect(conversation.id); }}
              aria-current={isSelected || undefined}
              className={[
                'conv',
                isSelected ? 'on' : '',
              ].join(' ')}
            >
              <div className="av">
                {conversation.customer.displayName.slice(0, 2).toUpperCase()}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <b>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigateToTicket(conversation.ticketNumber, navigate, conversation.customer.cxId);
                      }}
                      className="underline-offset-2 hover:underline hover:text-[var(--fe-ink)]"
                    >
                      {conversation.customer.displayName || conversation.ticketNumber}
                    </button>
                  </b>
                  <span className="sub fe-mono ml-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigateToCxProfile(conversation.customer.cxId, navigate);
                      }}
                      className="underline-offset-2 hover:underline hover:text-[var(--fe-ink)]"
                    >
                      {conversation.customer.cxId}
                    </button>
                  </span>
                  <span className="sub fe-mono ms-auto" dir="ltr">
                    {formatListStamp(conversation.lastMessageAt, locale)}
                  </span>
                </div>
                <div className="sub mt-1" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {conversation.lastMessagePreview ?? '—'}
                </div>

                <div className="mt-2 flex flex-wrap items-center gap-1">
                  <StatusChip tone={conversation.mode === 'AI' ? 'ai' : 'human'}>
                    {t(`mode.${conversation.mode}` as StringKey)}
                  </StatusChip>
                  <span className="fe-eyebrow text-[var(--fe-slate)] ml-1 mr-1">{conversation.channel}</span>
                  {conversation.status === 'RESOLVED' && (
                    <StatusChip tone="neutral">{t('status.RESOLVED')}</StatusChip>
                  )}
                  {(conversation.priority === 'HIGH' || conversation.priority === 'URGENT') && (
                    <StatusChip tone="warn">
                      {t(`priority.${conversation.priority}` as StringKey)}
                    </StatusChip>
                  )}
                  {!conversation.assignedEmployee && conversation.mode === 'HUMAN' && (
                    <StatusChip tone="blue">{t('thread.unassigned')}</StatusChip>
                  )}
                </div>
              </div>
            </div>

            {canClose && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  closeMutation.mutate(conversation.id);
                }}
                title={t('inbox.close')}
                aria-label={t('inbox.close')}
                className="absolute end-2 top-2 z-10 flex h-6 w-6 shrink-0 items-center justify-center rounded border border-hairline bg-surface text-slate-soft hover:border-red-300 hover:bg-red-50 hover:text-red-600"
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            )}
          </li>
        );
      })}
    </ul>
  );
}
