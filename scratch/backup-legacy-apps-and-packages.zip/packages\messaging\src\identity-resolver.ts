import type { PrismaClient } from '@firstelement/database';
import { DomainEventType, type DomainEventPublisher } from '@firstelement/events';
import type { ChannelType, Locale } from '@firstelement/shared';
import { generateCxId, nextCxSequence } from '@firstelement/shared';

export interface InboundIdentity {
  organizationId: string;
  projectId: string;
  platform: ChannelType;
  externalId: string;
  displayName?: string | null;
  /** Verified signals only — a phone the platform vouches for, not typed text. */
  phone?: string | null;
  email?: string | null;
  locale?: Locale;
  rawProfile?: Record<string, unknown>;
}

export interface ResolvedCustomer {
  customerId: string;
  identityId: string;
  created: boolean;
  /**
   * Customers that look like the same person but were matched on a weak
   * signal. Never merged automatically — surfaced for a human to confirm
   * (plan §7).
   */
  possibleMatches: { customerId: string; displayName: string; reason: 'NAME' }[];
}

/**
 * Turns an external handle into a customer (plan §7).
 *
 * Framework-neutral on purpose: the API resolves identities when a dev or
 * admin acts, and the worker resolves them on every inbound message. One
 * implementation, two callers — the alternative is two subtly different
 * definitions of who a customer is.
 *
 * The rule that shapes this: a new handle is not automatically a new
 * person, and a similar name is not automatically the same person. Only
 * signals the platform verifies — phone number, email — are strong enough
 * to link a new handle to an existing customer without asking.
 */
export class IdentityResolver {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: DomainEventPublisher,
  ) {}

  async resolve(input: InboundIdentity): Promise<ResolvedCustomer> {
    const existing = await this.prisma.customerIdentity.findUnique({
      where: {
        projectId_platform_externalId: {
          projectId: input.projectId,
          platform: input.platform,
          externalId: input.externalId,
        },
      },
      select: { id: true, customerId: true },
    });

    if (existing) {
      await this.prisma.customer.update({
        where: { id: existing.customerId },
        data: { lastSeenAt: new Date() },
      });
      return {
        customerId: existing.customerId,
        identityId: existing.id,
        created: false,
        possibleMatches: [],
      };
    }

    const verifiedMatch = await this.findVerifiedMatch(input);
    if (verifiedMatch) {
      const identity = await this.attachIdentity(input, verifiedMatch, true);
      return {
        customerId: verifiedMatch,
        identityId: identity.id,
        created: false,
        possibleMatches: [],
      };
    }

    const possibleMatches = await this.findWeakMatches(input);
    const cxSeq = await nextCxSequence(this.prisma);
    const cxId = generateCxId(cxSeq);
    const customer = await this.prisma.customer.create({
      data: {
        organizationId: input.organizationId,
        projectId: input.projectId,
        cxId,
        displayName: input.displayName?.trim() || this.fallbackName(input),
        primaryEmail: input.email ?? null,
        primaryPhone: input.phone ?? null,
        locale: input.locale ?? 'ar',
        externalIds: { [input.platform]: input.externalId },
      },
      select: { id: true },
    });

    const identity = await this.attachIdentity(
      input,
      customer.id,
      Boolean(input.phone || input.email),
    );

    this.events.publish({
      type: DomainEventType.CUSTOMER_CREATED,
      organizationId: input.organizationId,
      projectId: input.projectId,
      aggregateId: customer.id,
      aggregateType: 'Customer',
      payload: { channel: input.platform, externalId: input.externalId },
      occurredAt: new Date(),
    });

    return { customerId: customer.id, identityId: identity.id, created: true, possibleMatches };
  }

  /** Phone and email are the only signals strong enough to link without asking. */
  private async findVerifiedMatch(input: InboundIdentity): Promise<string | null> {
    if (!input.phone && !input.email) return null;

    const match = await this.prisma.customer.findFirst({
      where: {
        organizationId: input.organizationId,
        projectId: input.projectId,
        OR: [
          ...(input.phone ? [{ primaryPhone: input.phone }] : []),
          ...(input.email ? [{ primaryEmail: input.email }] : []),
        ],
      },
      select: { id: true },
      orderBy: { lastSeenAt: 'desc' },
    });

    return match?.id ?? null;
  }

  /** Name-only overlap. Reported, never acted on. */
  private async findWeakMatches(
    input: InboundIdentity,
  ): Promise<{ customerId: string; displayName: string; reason: 'NAME' }[]> {
    const name = input.displayName?.trim();
    if (!name || name.length < 3) return [];

    const candidates = await this.prisma.customer.findMany({
      where: {
        organizationId: input.organizationId,
        projectId: input.projectId,
        displayName: { equals: name, mode: 'insensitive' },
      },
      select: { id: true, displayName: true },
      take: 5,
    });

    return candidates.map((c) => ({
      customerId: c.id,
      displayName: c.displayName,
      reason: 'NAME' as const,
    }));
  }

  private async attachIdentity(
    input: InboundIdentity,
    customerId: string,
    isVerified: boolean,
  ): Promise<{ id: string }> {
    return this.prisma.customerIdentity.create({
      data: {
        organizationId: input.organizationId,
        projectId: input.projectId,
        customerId,
        platform: input.platform,
        externalId: input.externalId,
        displayName: input.displayName ?? null,
        isVerified,
        rawProfile: (input.rawProfile ?? {}) as object,
      },
      select: { id: true },
    });
  }

  private fallbackName(input: InboundIdentity): string {
    // Show the handle rather than "Unknown": an operator can act on a
    // phone number, and cannot act on a placeholder.
    return input.phone ?? `${input.platform} ${input.externalId.slice(-6)}`;
  }
}
