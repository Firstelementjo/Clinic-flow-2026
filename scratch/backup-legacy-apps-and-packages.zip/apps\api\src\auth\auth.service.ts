import { Injectable, UnauthorizedException } from '@nestjs/common';
import { burnPasswordComparison, verifyPassword } from '@firstelement/auth';
import { AuditAction, ErrorCode, type LoginInput, type SessionUser } from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';
import { SessionService, type IssuedSession } from './session.service';

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly sessions: SessionService,
    private readonly audit: AuditService,
  ) {}

  async login(
    input: LoginInput,
    meta: { userAgent?: string; ipAddress?: string },
  ): Promise<{ session: IssuedSession; user: SessionUser }> {
    const user = await this.prisma.client.user.findUnique({
      where: { email: input.email },
      include: { organization: { select: { isActive: true } } },
    });

    if (!user || !user.isActive || !user.organization.isActive) {
      // Spend the same time as a real comparison so the response time does
      // not distinguish "no such account" from "wrong password".
      await burnPasswordComparison();
      throw this.invalidCredentials();
    }

    if (!(await verifyPassword(input.password, user.passwordHash))) {
      await this.audit.record({
        organizationId: user.organizationId,
        actorUserId: user.id,
        action: AuditAction.USER_LOGIN_FAILED,
        resourceType: 'User',
        resourceId: user.id,
        ipAddress: meta.ipAddress,
      });
      throw this.invalidCredentials();
    }

    const session = await this.sessions.issue({
      userId: user.id,
      organizationId: user.organizationId,
      userAgent: meta.userAgent,
      ipAddress: meta.ipAddress,
    });

    await this.prisma.client.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    await this.audit.record({
      organizationId: user.organizationId,
      actorUserId: user.id,
      action: AuditAction.USER_LOGGED_IN,
      resourceType: 'User',
      resourceId: user.id,
      ipAddress: meta.ipAddress,
    });

    const resolved = await this.sessions.resolve(session.token);
    if (!resolved) throw this.invalidCredentials();

    return { session, user: resolved.user };
  }

  async logout(sessionId: string, user: SessionUser, ipAddress?: string): Promise<void> {
    await this.sessions.revoke(sessionId);
    await this.audit.record({
      organizationId: user.organizationId,
      actorUserId: user.id,
      action: AuditAction.USER_LOGGED_OUT,
      resourceType: 'Session',
      resourceId: sessionId,
      ipAddress,
    });
  }

  private invalidCredentials(): UnauthorizedException {
    return new UnauthorizedException({
      code: ErrorCode.INVALID_CREDENTIALS,
      message: 'Invalid email or password',
    });
  }
}
