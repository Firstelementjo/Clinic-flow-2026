import type { TenantContext } from '@firstelement/database';

export interface ClinicDoctor {
  id: string;
  name: string;
  specialty: string;
  department?: string | null;
  workingDays: number[]; // 0=Sunday, 1=Monday, ..., 6=Saturday
  startHour: string; // "09:00"
  endHour: string; // "17:00"
  slotDuration: number; // in minutes
  isActive: boolean;
}

export interface ClinicProcedure {
  id: string;
  name: string;
  specialty: string;
  durationMinutes: number;
  bufferMinutes: number;
  price?: number | null;
  isActive: boolean;
}

export interface ClinicAppointment {
  id: string;
  organizationId: string;
  projectId: string;
  customerId?: string | null;
  doctorId?: string | null;
  procedureId?: string | null;
  title: string;
  patientName?: string | null;
  patientPhone?: string | null;
  patientEmail?: string | null;
  appointmentDate: Date;
  durationMinutes: number;
  status: string;
  service?: string | null;
  doctorName?: string | null;
  notes?: string | null;
}

/**
 * The appointment fields a caller supplies. `organizationId` and `projectId` are
 * declared optional and are **not** taken from the request: the adapter resolves
 * the tenant from the context and the project through a membership check, so a
 * caller-supplied value can neither of them.
 */
export interface CreateClinicAppointmentInput {
  projectId?: string;
  customerId?: string;
  doctorId?: string;
  procedureId?: string;
  title: string;
  patientName?: string;
  patientPhone?: string;
  patientEmail?: string;
  appointmentDate: Date;
  durationMinutes: number;
  service?: string;
  doctorName?: string;
  notes?: string;
  isAiProposed?: boolean;
  aiProposalReason?: string;
  ticketNumber?: string;
  ticketDate?: Date;
  createdById?: string;
}

/**
 * The clinic system, as the rest of the application sees it.
 *
 * <p>Every method takes the caller's {@link TenantContext} first. That is the
 * point of the change: a clinic adapter that resolves rows by bare id, or that
 * accepts a bare `organizationId`/`projectId` from its caller, cannot enforce a
 * tenant boundary on its own — and `plan.md` §0.4 requires the boundary to live in
 * the service or adapter, not the controller. With the context in the signature,
 * scoping is the adapter's job and an unscoped call is not expressible.
 */
export interface ClinicSystemAdapter {
  getDoctors(ctx: TenantContext, requestedProjectId?: string): Promise<ClinicDoctor[]>;
  getDoctorById(ctx: TenantContext, doctorId: string): Promise<ClinicDoctor | null>;
  getProcedures(ctx: TenantContext, requestedProjectId?: string): Promise<ClinicProcedure[]>;
  getProcedureById(ctx: TenantContext, procedureId: string): Promise<ClinicProcedure | null>;
  getDoctorSchedule(
    ctx: TenantContext,
    doctorId: string,
    date: Date,
  ): Promise<{ isWorkingDay: boolean; startHour: string; endHour: string } | null>;
  getExistingAppointments(
    ctx: TenantContext,
    doctorId: string,
    date: Date,
  ): Promise<ClinicAppointment[]>;
  createAppointment(ctx: TenantContext, input: CreateClinicAppointmentInput): Promise<ClinicAppointment>;
  rescheduleAppointment(
    ctx: TenantContext,
    appointmentId: string,
    newDate: Date,
  ): Promise<ClinicAppointment>;
  cancelAppointment(
    ctx: TenantContext,
    appointmentId: string,
    reason?: string,
  ): Promise<boolean>;
}
