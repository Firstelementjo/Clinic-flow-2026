import { createHash } from 'node:crypto';
import {
  EMBEDDING_DIMENSIONS,
  l2Normalize,
  type EmbeddingProvider,
} from './types';

/**
 * Deterministic local embeddings (no API key, no network).
 *
 * This is not a random-vector stub. It hashes tokens into dimensions —
 * essentially a hashed bag of words — so texts that share vocabulary
 * genuinely land near each other under cosine distance. That makes
 * retrieval testable end to end in development and in CI: a query about
 * refunds actually pulls the refund document rather than whatever row
 * happened to sort first.
 *
 * It is lexical, not semantic: it will not connect "reimbursement" to
 * "refund". Production uses a real provider; this keeps the pipeline
 * honest everywhere else.
 */
export class MockEmbeddingProvider implements EmbeddingProvider {
  readonly name = 'mock';
  readonly model = 'hashed-bag-of-words';
  readonly dimensions = EMBEDDING_DIMENSIONS;

  async embed(texts: string[]): Promise<number[][]> {
    return texts.map((text) => this.embedOne(text));
  }

  private embedOne(text: string): number[] {
    const vector = new Array<number>(this.dimensions).fill(0);
    const tokens = tokenize(text);

    for (const token of tokens) {
      // Two hashes per token: one picks the dimension, one picks the sign,
      // which keeps unrelated tokens from piling up in the same direction.
      const dimension = hashToInt(token) % this.dimensions;
      const sign = hashToInt(`sign:${token}`) % 2 === 0 ? 1 : -1;
      vector[dimension] = (vector[dimension] ?? 0) + sign;
    }

    // Empty or punctuation-only text: a fixed non-zero vector, so it can
    // still be stored and compared instead of producing NaN scores.
    if (tokens.length === 0) vector[0] = 1;

    return l2Normalize(vector);
  }
}

/**
 * Words that carry no topic. A question is mostly these — "how long does
 * a refund take" is four stopwords and two content words — and leaving
 * them in dilutes the vector until a genuinely matching document scores
 * below the retrieval floor.
 */
const STOPWORDS = new Set([
  'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'do', 'does', 'did', 'how',
  'what', 'when', 'where', 'why', 'who', 'which', 'to', 'of', 'in', 'on', 'for', 'and',
  'or', 'my', 'me', 'i', 'you', 'your', 'it', 'this', 'that', 'can', 'will', 'would',
  'should', 'long', 'much', 'many', 'please', 'am',
  // Arabic equivalents.
  'في', 'من', 'إلى', 'على', 'عن', 'هل', 'ما', 'ماذا', 'كيف', 'متى', 'أين', 'هذا', 'هذه',
  'الذي', 'التي', 'و', 'أو', 'كم', 'لي', 'أنا', 'أنت', 'هو', 'هي',
]);

function tokenize(text: string): string[] {
  const raw =
    text
      .toLowerCase()
      // Keep Arabic script alongside Latin: this product's primary
      // language would otherwise tokenize to nothing.
      .match(/[\p{L}\p{N}]+/gu) ?? [];

  const tokens = raw.filter((token) => !STOPWORDS.has(token)).map(stem);

  // A query made entirely of stopwords still needs to embed as something.
  return tokens.length > 0 ? tokens : raw;
}

/**
 * Crude suffix stripping so "refund"/"refunds" and "take"/"takes" land in
 * the same dimension. Not linguistics — just enough that a question and
 * the sentence answering it are not accidental strangers.
 */
function stem(token: string): string {
  if (token.length <= 3) return token;
  for (const suffix of ['ing', 'ed', 'es', 's']) {
    if (token.length > suffix.length + 2 && token.endsWith(suffix)) {
      return token.slice(0, -suffix.length);
    }
  }
  return token;
}

function hashToInt(value: string): number {
  const digest = createHash('sha256').update(value).digest();
  return digest.readUInt32BE(0);
}
