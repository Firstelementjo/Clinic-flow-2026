import { useEffect, useId, useState, type FormEvent, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react';
import { X } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@firstelement/ui';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';

export interface CreateRecordDrawerProps {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  submitLabel: string;
  isSubmitting: boolean;
  canSubmit?: boolean;
  onSubmit: (e: FormEvent) => void;
  children: ReactNode;
}

const fieldInputCls =
  'h-9 w-full rounded border border-hairline bg-surface px-3 text-sm text-ink placeholder:text-slate-soft transition-colors focus:border-signal focus:outline-none';

const fieldSelectCls =
  'h-9 w-full rounded border border-hairline bg-surface px-3 text-sm text-ink transition-colors hover:border-slate-soft focus:border-signal focus:outline-none';

/**
 * Right-hand create form drawer. Always mounted so the open/close slide
 * animates; the wrapper flips `visibility` so closed content is inert.
 * Anchored to the physical right edge — in an RTL app the nav rail sits on
 * the right, and the user asked for the pane "on the right of the window".
 */
export function CreateRecordDrawer({
  open,
  onClose,
  title,
  description,
  submitLabel,
  isSubmitting,
  canSubmit = true,
  onSubmit,
  children,
}: CreateRecordDrawerProps) {
  const t = useT();
  const titleId = useId();

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [open, onClose]);

  return (
    <div className={`fixed inset-0 z-40 ${open ? 'visible' : 'invisible'}`} aria-hidden={!open}>
      <div
        className={`absolute inset-0 bg-ink/40 transition-opacity duration-200 ${open ? 'opacity-100' : 'opacity-0'}`}
        onClick={onClose}
      />
      <aside
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className={`fixed inset-y-0 right-0 flex w-full max-w-xl flex-col bg-surface shadow-pop transition-transform duration-300 ease-out ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <header className="flex items-start justify-between gap-4 border-b border-hairline px-5 py-4">
          <div className="min-w-0">
            <h2 id={titleId} className="fe-display truncate text-lg text-ink">
              {title}
            </h2>
            {description && <p className="mt-1 text-xs text-slate">{description}</p>}
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            aria-label={t('common.cancel')}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md text-slate-soft transition-colors hover:bg-mist hover:text-ink disabled:opacity-50"
          >
            <X aria-hidden="true" className="h-4 w-4" />
          </button>
        </header>

        <form onSubmit={onSubmit} className="flex min-h-0 flex-1 flex-col">
          <div className="flex-1 space-y-7 overflow-y-auto px-5 py-5">{children}</div>
          <footer className="flex items-center justify-end gap-2 border-t border-hairline px-5 py-3">
            <Button type="button" variant="ghost" onClick={onClose} disabled={isSubmitting}>
              {t('common.cancel')}
            </Button>
            <Button type="submit" variant="primary" loading={isSubmitting} disabled={!canSubmit}>
              {submitLabel}
            </Button>
          </footer>
        </form>
      </aside>
    </div>
  );
}

/** A titled group of fields; short fields share two columns, long ones span. */
export function FormSection({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="space-y-3">
      <h3 className="fe-eyebrow">{title}</h3>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">{children}</div>
    </section>
  );
}

function FieldShell({
  label,
  required,
  className,
  children,
}: {
  label: string;
  required?: boolean;
  className?: string;
  children: ReactNode;
}) {
  return (
    <div className={`flex flex-col gap-1.5 ${className ?? ''}`}>
      <label className="text-xs font-medium text-ink-soft">
        {label}
        {required && <span className="ms-1 text-danger">*</span>}
      </label>
      {children}
    </div>
  );
}

export interface TextFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'label' | 'size'> {
  label: string;
  required?: boolean;
  /** Full-width row in the two-column section grid (long text). */
  wide?: boolean;
}

export function TextField({ label, required, wide, className, ...rest }: TextFieldProps) {
  return (
    <FieldShell label={label} required={required} className={wide ? 'sm:col-span-2' : undefined}>
      <input {...rest} className={`${fieldInputCls} ${className ?? ''}`} />
    </FieldShell>
  );
}

export interface SelectOption {
  value: string;
  label: string;
}

export interface SelectFieldProps extends Omit<SelectHTMLAttributes<HTMLSelectElement>, 'label'> {
  label: string;
  required?: boolean;
  options: readonly SelectOption[];
  /** Renders an empty "unset" choice as the first option. */
  placeholder?: string;
  wide?: boolean;
}

export function SelectField({ label, required, options, placeholder, wide, className, ...rest }: SelectFieldProps) {
  return (
    <FieldShell label={label} required={required} className={wide ? 'sm:col-span-2' : undefined}>
      <select {...rest} className={`${fieldSelectCls} ${className ?? ''}`}>
        {placeholder !== undefined && <option value="">{placeholder}</option>}
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </FieldShell>
  );
}

export interface TextAreaFieldProps extends Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, 'label'> {
  label: string;
  required?: boolean;
  wide?: boolean;
}

export function TextAreaField({ label, required, wide, className, ...rest }: TextAreaFieldProps) {
  return (
    <FieldShell label={label} required={required} className={wide ? 'sm:col-span-2' : undefined}>
      <textarea {...rest} className={`${fieldInputCls} min-h-[7rem] resize-y py-2 ${className ?? ''}`} />
    </FieldShell>
  );
}

export function TagsField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string[];
  onChange: (tags: string[]) => void;
  placeholder?: string;
}) {
  const [text, setText] = useState('');

  const addTag = () => {
    const tag = text.trim();
    if (!tag || value.includes(tag)) {
      setText('');
      return;
    }
    onChange([...value, tag]);
    setText('');
  };

  const removeTag = (tag: string) => onChange(value.filter((x) => x !== tag));

  return (
    <FieldShell label={label} className="sm:col-span-2">
      <div className="flex flex-wrap items-center gap-1.5 rounded border border-hairline bg-surface px-2 py-1.5 transition-colors focus-within:border-signal">
        {value.map((tag) => (
          <span key={tag} className="inline-flex items-center gap-1 rounded bg-mist px-2 py-0.5 text-xs text-ink">
            {tag}
            <button
              type="button"
              onClick={() => removeTag(tag)}
              aria-label={`${label}: ${tag}`}
              className="text-slate-soft transition-colors hover:text-ink"
            >
              <X aria-hidden="true" className="h-3 w-3" />
            </button>
          </span>
        ))}
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onBlur={addTag}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              addTag();
            }
            if (e.key === 'Backspace' && !text && value.length > 0) {
              const last = value[value.length - 1];
              if (last) removeTag(last);
            }
          }}
          placeholder={placeholder}
          aria-label={label}
          className="h-7 min-w-[8rem] flex-1 border-none bg-transparent px-1 text-sm text-ink outline-none placeholder:text-slate-soft"
        />
      </div>
    </FieldShell>
  );
}

/** Employee picker sourced from /employees/routing — same list Team uses. */
export interface EmployeeView {
  userId: string;
  fullName: string;
}

export function useEmployees() {
  return useQuery<EmployeeView[]>({
    queryKey: ['employees', 'routing'],
    queryFn: () => api.get('/employees/routing'),
    staleTime: 5 * 60 * 1000,
  });
}

const COMPANY_TYPES = ['Customer', 'Partner', 'Vendor', 'Competitor', 'Prospect', 'Other'] as const;

const COMPANY_TYPE_LABEL: Record<(typeof COMPANY_TYPES)[number], StringKey> = {
  Customer: 'form.companyType.Customer',
  Partner: 'form.companyType.Partner',
  Vendor: 'form.companyType.Vendor',
  Competitor: 'form.companyType.Competitor',
  Prospect: 'form.companyType.Prospect',
  Other: 'form.companyType.Other',
};

const SIZES = ['1-10', '11-50', '51-200', '201-500', '500+'] as const;

const ACCOUNT_STATUSES = ['Active', 'Inactive', 'Prospect'] as const;

const ACCOUNT_STATUS_LABEL: Record<(typeof ACCOUNT_STATUSES)[number], StringKey> = {
  Active: 'form.accountStatus.Active',
  Inactive: 'form.accountStatus.Inactive',
  Prospect: 'form.accountStatus.Prospect',
};

const LEAD_SOURCES = ['Referral', 'Website', 'LinkedIn', 'Campaign', 'Inbound', 'Outbound', 'Event', 'Other'] as const;

const LEAD_SOURCE_LABEL: Record<(typeof LEAD_SOURCES)[number], StringKey> = {
  Referral: 'form.leadSource.Referral',
  Website: 'form.leadSource.Website',
  LinkedIn: 'form.leadSource.LinkedIn',
  Campaign: 'form.leadSource.Campaign',
  Inbound: 'form.leadSource.Inbound',
  Outbound: 'form.leadSource.Outbound',
  Event: 'form.leadSource.Event',
  Other: 'form.leadSource.Other',
};

const PRIORITIES = ['low', 'medium', 'high', 'urgent'] as const;

const PRIORITY_LABEL: Record<(typeof PRIORITIES)[number], StringKey> = {
  low: 'form.priority.low',
  medium: 'form.priority.medium',
  high: 'form.priority.high',
  urgent: 'form.priority.urgent',
};

const CURRENCIES = ['USD', 'JOD', 'EUR', 'AED', 'SAR'] as const;

/** Common option sets, translated per-locale for the create forms. */
export function useFormOptions() {
  const t = useT();

  const mapLabel = <const T extends string>(values: readonly T[], label: Record<T, StringKey>) =>
    values.map((value) => ({ value, label: t(label[value]) }));

  return {
    companyTypes: mapLabel(COMPANY_TYPES, COMPANY_TYPE_LABEL),
    sizes: SIZES.map((size) => ({ value: size, label: size })),
    accountStatuses: mapLabel(ACCOUNT_STATUSES, ACCOUNT_STATUS_LABEL),
    leadSources: mapLabel(LEAD_SOURCES, LEAD_SOURCE_LABEL),
    priorities: mapLabel(PRIORITIES, PRIORITY_LABEL),
    currencies: CURRENCIES.map((currency) => ({ value: currency, label: currency })),
  };
}

/** Common free-text "dropdowns" with suggested values (spec calls them dropdowns). */
export const INDUSTRY_SUGGESTIONS = [
  'تكنولوجيا',
  'رعاية صحية',
  'تمويل',
  'تصنيع',
  'تجزئة',
  'تعليم',
  'إنشاءات',
  'لوجستيات',
  'طاقة',
  'عقارات',
  'Agriculture',
  'Technology',
  'Healthcare',
  'Finance',
  'Manufacturing',
  'Retail',
  'Education',
  'Construction',
  'Logistics',
  'Energy',
  'Real Estate',
];

export const COUNTRY_SUGGESTIONS = [
  'الأردن',
  'السعودية',
  'الإمارات',
  'مصر',
  'قطر',
  'الكويت',
  'Jordan',
  'Saudi Arabia',
  'United Arab Emirates',
  'Egypt',
  'Qatar',
  'Kuwait',
  'United States',
  'United Kingdom',
];

export function textOrUndefined(value: string): string | undefined {
  const trimmed = value.trim();
  return trimmed ? trimmed : undefined;
}

export function numberOrUndefined(value: string): number | undefined {
  const trimmed = value.trim();
  if (!trimmed) return undefined;
  const parsed = Number(trimmed);
  return Number.isFinite(parsed) ? parsed : undefined;
}