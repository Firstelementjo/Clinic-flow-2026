import { Queue, Worker, type Processor } from 'bullmq';
import IORedis from 'ioredis';
import { getConfig } from '@firstelement/config';
import { DEFAULT_JOB_OPTIONS, QueueName } from '@firstelement/messaging';

export { DEFAULT_JOB_OPTIONS, QueueName } from '@firstelement/messaging';

export function createRedisConnection(): IORedis {
  const client = new IORedis(getConfig().REDIS_URL, {
    // BullMQ requires this: a blocking command must not be aborted by the
    // client's own retry limit.
    maxRetriesPerRequest: null,
  });
  client.on('error', (err) => {
    // Log transient Redis connection issues without crashing the process
    console.warn('[redis] connection warning:', err.message);
  });
  return client;
}

export function createQueue(name: QueueName, connection: IORedis): Queue {
  return new Queue(name, { connection, defaultJobOptions: DEFAULT_JOB_OPTIONS });
}

export function createWorker<T>(
  name: QueueName,
  connection: IORedis,
  processor: Processor<T>,
  concurrency = 5,
): Worker<T> {
  const worker = new Worker<T>(name, processor, { connection, concurrency });
  worker.on('error', (err) => {
    console.warn(`[worker:${name}] warning:`, err.message);
  });
  return worker;
}
