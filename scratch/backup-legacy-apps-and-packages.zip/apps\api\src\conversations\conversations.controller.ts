import { Body, Controller, Get, Param, ParseUUIDPipe, Patch, Post, Query, Req } from '@nestjs/common';
import type { Request } from 'express';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import {
  assignConversationSchema,
  inboxQuerySchema,
  sendMessageSchema,
  updateConversationSchema,
  type AssignConversationInput,
  type SendMessageInput,
  type UpdateConversationInput,
} from '@firstelement/shared';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { ConversationsService } from './conversations.service';

@Controller('conversations')
export class ConversationsController {
  constructor(private readonly conversations: ConversationsService) {}

  @Get()
  @RequirePermissions(Permission.CONVERSATION_READ)
  inbox(@Tenant() ctx: TenantContext, @Query() query: unknown) {
    return this.conversations.inbox(ctx, inboxQuerySchema.parse(query));
  }

  @Get(':conversationId')
  @RequirePermissions(Permission.CONVERSATION_READ)
  getOne(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
  ) {
    return this.conversations.getById(ctx, conversationId);
  }

  @Post(':conversationId/messages')
  @RequirePermissions(Permission.CONVERSATION_REPLY)
  reply(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Body(zodBody(sendMessageSchema)) body: SendMessageInput,
    @Req() request: Request,
  ) {
    return this.conversations.reply(ctx, conversationId, body, request.ip);
  }

  @Patch(':conversationId/assignment')
  @RequirePermissions(Permission.CONVERSATION_ASSIGN)
  assign(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Body(zodBody(assignConversationSchema)) body: AssignConversationInput,
    @Req() request: Request,
  ) {
    return this.conversations.assign(ctx, conversationId, body, request.ip);
  }

  @Patch(':conversationId')
  @RequirePermissions(Permission.CONVERSATION_RESOLVE)
  update(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Body(zodBody(updateConversationSchema)) body: UpdateConversationInput,
    @Req() request: Request,
  ) {
    return this.conversations.update(ctx, conversationId, body, request.ip);
  }

  @Patch(':conversationId/close')
  @RequirePermissions(Permission.CONVERSATION_RESOLVE)
  close(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Req() request: Request,
  ) {
    return this.conversations.closeAndUnassign(ctx, conversationId, request.ip);
  }
}
