/**
 * Demo/seed data (plan §15).
 *
 * Idempotent: safe to re-run against an existing dev database. Everything
 * it creates hangs off one clearly-labelled demo organization so it can
 * never be confused with production data — and this script is never wired
 * into an application code path.
 */
import { hashPassword } from '@firstelement/auth';
import { getPrismaClient, disconnectPrisma } from './client';
import { generateTicketNumber, generateCxId } from '@firstelement/shared';

const DEMO_ORG_SLUG = 'firstelement-demo';
const DEMO_PASSWORD = 'DemoPassword123!';

async function main(): Promise<void> {
  if (process.env.NODE_ENV === 'production') {
    throw new Error('Refusing to seed demo data in production.');
  }

  const prisma = getPrismaClient();
  const passwordHash = await hashPassword(DEMO_PASSWORD);

  const organization = await prisma.organization.upsert({
    where: { slug: DEMO_ORG_SLUG },
    update: {},
    create: {
      name: 'FirstElement Demo',
      slug: DEMO_ORG_SLUG,
      defaultLocale: 'ar',
      timezone: 'Asia/Riyadh',
    },
  });

  const projects = await Promise.all(
    [
      { slug: 'retail-support', name: 'دعم التجزئة', description: 'Retail customer support' },
      { slug: 'fintech-support', name: 'دعم المدفوعات', description: 'Payments support desk' },
    ].map((p) =>
      prisma.project.upsert({
        where: { organizationId_slug: { organizationId: organization.id, slug: p.slug } },
        update: {},
        create: { ...p, organizationId: organization.id },
      }),
    ),
  );

  const admin = await prisma.user.upsert({
    where: { email: 'admin@firstelement.dev' },
    update: {},
    create: {
      organizationId: organization.id,
      email: 'admin@firstelement.dev',
      fullName: 'Layla Al-Mansour',
      passwordHash,
      role: 'ADMIN',
      locale: 'ar',
    },
  });

  const employeeSpecs = [
    { email: 'omar@firstelement.dev', fullName: 'Omar Haddad', department: 'Billing' },
    { email: 'sara@firstelement.dev', fullName: 'Sara Nasser', department: 'Technical' },
    { email: 'yousef@firstelement.dev', fullName: 'Yousef Karim', department: 'Retention' },
  ];

  const employees = [];
  for (const spec of employeeSpecs) {
    const user = await prisma.user.upsert({
      where: { email: spec.email },
      update: {},
      create: {
        organizationId: organization.id,
        email: spec.email,
        fullName: spec.fullName,
        passwordHash,
        role: 'EMPLOYEE',
        locale: 'ar',
      },
    });

    await prisma.employee.upsert({
      where: { userId: user.id },
      update: {},
      create: {
        organizationId: organization.id,
        userId: user.id,
        department: spec.department,
        availabilityStatus: 'ONLINE',
        maxConcurrentConversations: 5,
      },
    });

    employees.push(user);
  }

  // Admins are members of every project in their organization; employees
  // are deliberately given partial coverage so the tenant-isolation tests
  // have a real negative case to assert against.
  const memberships: { userId: string; projectId: string }[] = [
    ...projects.map((project) => ({ userId: admin.id, projectId: project.id })),
    { userId: employees[0]!.id, projectId: projects[0]!.id },
    { userId: employees[1]!.id, projectId: projects[0]!.id },
    { userId: employees[2]!.id, projectId: projects[1]!.id },
  ];

  for (const membership of memberships) {
    await prisma.projectMembership.upsert({
      where: {
        projectId_userId: { projectId: membership.projectId, userId: membership.userId },
      },
      update: {},
      create: { ...membership, organizationId: organization.id },
    });
  }

  // Every demo project gets the mock channel enabled so the dev inbound
  // simulator works immediately after seeding (plan §13).
  for (const project of projects) {
    await prisma.channelConnection.upsert({
      where: { projectId_channel: { projectId: project.id, channel: 'MOCK' } },
      update: {},
      create: {
        organizationId: organization.id,
        projectId: project.id,
        channel: 'MOCK',
        displayName: 'Mock channel (development)',
        status: 'CONNECTED',
      },
    });
  }

  // A live agent on the first demo project, using the mock provider so the
  // AI path is demonstrable without any API key. It is deliberately
  // conservative: with an empty knowledge base it asks or hands over
  // rather than inventing answers.
  const clinicTools = [
    'get_doctors',
    'get_procedures',
    'get_procedure_duration',
    'check_availability',
    'find_available_slots',
    'create_appointment',
    'reschedule_appointment',
    'cancel_appointment',
    'search_knowledge_base',
    'get_customer',
    'get_business_hours',
    'request_human',
    'resolve_conversation',
  ];

  const clinicSystemPrompt =
    'أنت وكيل خدمة عملاء عيادة تدفق (Clinic Flow). ' +
    'مهمتك مساعدة المرضى في الاستفسار عن الأطباء، وحجز المواعيد وتعديلها أو إلغائها بدقة. ' +
    'قواعد العمل الصارمة: ' +
    '1. لا تخمن أبداً المواعيد المتاحة أو مدة الإجراءات. استخدم دائماً الأدوات المخصصة: ' +
    '   - get_doctors لمعرفة قائمة وتخصص وساعات عمل الأطباء. ' +
    '   - get_procedures و get_procedure_duration لمعرفة مدة كل فحص وسعره. ' +
    '   - check_availability أو find_available_slots للتحقق من الأوقات المتاحة بدون أي تعارض. ' +
    '   - create_appointment لحجز الموعد وتأكيده للمريض بعد الاتفاق. ' +
    '   - reschedule_appointment لتعديل الموعد عند طلب المريض. ' +
    '   - cancel_appointment لإلغاء الموعد. ' +
    '2. إذا كان الموعد المطلوب مشغولاً أو خارج دوام الطبيب، اقترح المواعيد البديلة أو الأطباء البدلاء المعادة من الأداة. ' +
    '3. كن محترفاً ومتعاوناً ودقيقاً دائماً باللغة العربية أو الإنجليزية.';

  const firstProject = projects[0]!;
  let agent = await prisma.aIAgent.findFirst({
    where: { projectId: firstProject.id },
    select: { id: true, activeVersionId: true },
  });

  if (!agent) {
    agent = await prisma.aIAgent.create({
      data: {
        organizationId: organization.id,
        projectId: firstProject.id,
        name: 'وكيل حجز مواعيد العيادة (Clinic Flow Agent)',
        isEnabled: true,
      },
      select: { id: true, activeVersionId: true },
    });

    const version = await prisma.aIAgentVersion.create({
      data: {
        organizationId: organization.id,
        projectId: firstProject.id,
        agentId: agent.id,
        version: 1,
        systemInstructions: clinicSystemPrompt,
        tone: 'محترف ومتعاطف',
        provider: 'MOCK',
        enabledTools: clinicTools,
      },
      select: { id: true },
    });

    await prisma.aIAgent.update({
      where: { id: agent.id },
      data: { activeVersionId: version.id },
    });
  } else if (agent.activeVersionId) {
    await prisma.aIAgentVersion.update({
      where: { id: agent.activeVersionId },
      data: {
        systemInstructions: clinicSystemPrompt,
        enabledTools: clinicTools,
      },
    });
  }

  await seedConversations({
    organizationId: organization.id,
    projectId: projects[0]!.id,
    assignedEmployeeUserId: employees[0]!.id,
  });

  console.log('Seeded demo organization:', organization.slug);
  console.log('  Admin    : admin@firstelement.dev');
  console.log('  Employees:', employeeSpecs.map((e) => e.email).join(', '));
  console.log('  Password :', DEMO_PASSWORD);
}

/**
 * A spread of conversations that exercises the states an operator has to
 * tell apart at a glance (plan §15): AI-handled, human-handled, unassigned,
 * and one already resolved. Scores and escalations arrive with slice 6.
 */
async function seedConversations(params: {
  organizationId: string;
  projectId: string;
  assignedEmployeeUserId: string;
}): Promise<void> {
  const prisma = getPrismaClient();
  const { organizationId, projectId } = params;

  const existing = await prisma.conversation.count({ where: { projectId } });
  if (existing > 0) return;

  const employee = await prisma.employee.findUnique({
    where: { userId: params.assignedEmployeeUserId },
    select: { id: true },
  });

  const scenarios = [
    {
      customer: { displayName: 'نورة السالم', phone: '+966500000001', platform: 'WHATSAPP' as const },
      channel: 'WHATSAPP' as const,
      mode: 'AI' as const,
      status: 'OPEN' as const,
      priority: 'NORMAL' as const,
      assigned: false,
      messages: [
        { direction: 'INBOUND' as const, author: 'CUSTOMER' as const, body: 'متى يصل طلبي رقم 4471؟' },
        {
          direction: 'OUTBOUND' as const,
          author: 'AI' as const,
          body: 'طلبك رقم 4471 خرج من المستودع أمس ويصل خلال يومي عمل.',
        },
      ],
    },
    {
      customer: { displayName: 'Karim Fadel', phone: '+9627900000002', platform: 'TELEGRAM' as const },
      channel: 'TELEGRAM' as const,
      mode: 'HUMAN' as const,
      status: 'OPEN' as const,
      priority: 'HIGH' as const,
      assigned: true,
      messages: [
        { direction: 'INBOUND' as const, author: 'CUSTOMER' as const, body: 'I was charged twice for the same order.' },
        {
          direction: 'OUTBOUND' as const,
          author: 'EMPLOYEE' as const,
          body: 'I can see both charges. I am reversing the duplicate now — it clears in 3 business days.',
        },
      ],
    },
    {
      customer: { displayName: 'ريم الحارثي', phone: '+966500000003', platform: 'INSTAGRAM' as const },
      channel: 'INSTAGRAM' as const,
      mode: 'HUMAN' as const,
      status: 'RESOLVED' as const,
      priority: 'NORMAL' as const,
      assigned: true,
      messages: [
        { direction: 'INBOUND' as const, author: 'CUSTOMER' as const, body: 'هل يمكنني تبديل المقاس؟' },
        { direction: 'OUTBOUND' as const, author: 'EMPLOYEE' as const, body: 'تم تسجيل طلب التبديل، وسيصلك رابط الشحن.' },
      ],
    },
  ];

  for (const [index, scenario] of scenarios.entries()) {
    const cxId = generateCxId(index);
    const customer = await prisma.customer.create({
      data: {
        organizationId,
        projectId,
        cxId,
        displayName: scenario.customer.displayName,
        primaryPhone: scenario.customer.phone,
        externalIds: { [scenario.customer.platform]: `demo-${index}` },
        identities: {
          create: {
            organizationId,
            projectId,
            platform: scenario.customer.platform,
            externalId: `demo-${index}`,
            displayName: scenario.customer.displayName,
            isVerified: true,
          },
        },
      },
      select: { id: true },
    });

    const base = Date.now() - (scenarios.length - index) * 3_600_000;

    await prisma.conversation.create({
      data: {
        organizationId,
        projectId,
        customerId: customer.id,
        channel: scenario.channel,
        status: scenario.status,
        mode: scenario.mode,
        priority: scenario.priority,
        ticketNumber: generateTicketNumber(new Date(base), index + 1),
        assignedEmployeeId: scenario.assigned ? (employee?.id ?? null) : null,
        messageCount: scenario.messages.length,
        lastMessageAt: new Date(base + scenario.messages.length * 60_000),
        resolvedAt: scenario.status === 'RESOLVED' ? new Date(base + 600_000) : null,
        messages: {
          create: scenario.messages.map((message, i) => ({
            organizationId,
            projectId,
            channel: scenario.channel,
            direction: message.direction,
            authorType: message.author,
            authorUserId: message.author === 'EMPLOYEE' ? params.assignedEmployeeUserId : null,
            body: message.body,
            sentAt: new Date(base + i * 60_000),
          })),
        },
        events: {
          create: [
            {
              organizationId,
              projectId,
              type: 'CONVERSATION_CREATED',
              actorType: 'SYSTEM',
              payload: { channel: scenario.channel },
              occurredAt: new Date(base),
            },
          ],
        },
      },
    });
  }
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(() => disconnectPrisma());
