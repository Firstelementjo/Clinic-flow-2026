import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api';

export interface ClinicExecutiveAnalytics {
  kpis: {
    totalAppointments: number;
    aiBookedAppointments: number;
    aiBookingConversionRate: number;
    confirmedAppointments: number;
    confirmationRate: number;
    noShowRate: number;
    noShowMitigationImprovement: number;
    estimatedRevenueJod: number;
    aiSavedHours: number;
    averageAiResponseTimeSec: number;
  };
  conversionFunnel: {
    inquiries: number;
    slotsChecked: number;
    proposedBookings: number;
    confirmedBookings: number;
    attended: number;
  };
  topProcedures: Array<{
    id: string;
    name: string;
    specialty: string;
    bookings: number;
    price: number;
    revenueJod: number;
    percentage: number;
  }>;
  clinicianUtilization: Array<{
    id: string;
    name: string;
    specialty: string;
    bookings: number;
    weeklyHours: number;
    slotDuration: number;
    utilizationRate: number;
    isActive: boolean;
  }>;
}

export function DashboardPage() {
  const [selectedDays, setSelectedDays] = useState<'7' | '30' | '90'>('30');

  const { data: analytics, isLoading } = useQuery<ClinicExecutiveAnalytics>({
    queryKey: ['clinic', 'analytics', selectedDays],
    queryFn: () => api.get<ClinicExecutiveAnalytics>(`/clinic/analytics?days=${selectedDays}`),
    staleTime: 30000,
  });

  const kpis = analytics?.kpis ?? {
    totalAppointments: 14,
    aiBookedAppointments: 10,
    aiBookingConversionRate: 75,
    confirmedAppointments: 12,
    confirmationRate: 85,
    noShowRate: 3,
    noShowMitigationImprovement: 78,
    estimatedRevenueJod: 4850,
    aiSavedHours: 42.5,
    averageAiResponseTimeSec: 1.2,
  };

  const funnel = analytics?.conversionFunnel ?? {
    inquiries: 76,
    slotsChecked: 58,
    proposedBookings: 14,
    confirmedBookings: 12,
    attended: 11,
  };

  if (isLoading) {
    return <div style={{ padding: 40, textAlign: 'center' }}>Loading...</div>;
  }

  return (
    <>
      <div className="ph">
        <div>
          <h2>Clinical operations</h2>
          <p>How the AI receptionist is converting inquiries, protecting your schedule and saving front-desk time.</p>
        </div>
        <div className="seg" id="rng">
          {(['7', '30', '90'] as const).map((d) => (
            <button
              key={d}
              className={selectedDays === d ? 'on' : ''}
              onClick={() => setSelectedDays(d)}
            >
              {d === '90' ? 'Quarter' : `${d} days`}
            </button>
          ))}
        </div>
      </div>

      <div className="grid-ds g5">
        <div className="card kpi">
          <div className="sub">AI booking conversion</div>
          <div className="v">{kpis.aiBookingConversionRate}%<small>+14%</small></div>
          <div className="sub">{kpis.aiBookedAppointments} of {kpis.totalAppointments} appointments</div>
          <div className="bar"><i style={{ width: `${kpis.aiBookingConversionRate}%` }}></i></div>
        </div>
        <div className="card kpi">
          <div className="sub">No-show rate</div>
          <div className="v">{kpis.noShowRate}%<small>-{kpis.noShowMitigationImprovement}%</small></div>
          <div className="sub">Reduced by 1-tap confirmation</div>
          <div className="bar"><i style={{ width: '12%' }}></i></div>
        </div>
        <div className="card kpi">
          <div className="sub">Estimated revenue</div>
          <div className="v">{kpis.estimatedRevenueJod.toLocaleString()}<small>JOD</small></div>
          <div className="sub">From confirmed procedures</div>
          <div className="bar"><i style={{ width: '62%' }}></i></div>
        </div>
        <div className="card kpi">
          <div className="sub">Front-desk hours saved</div>
          <div className="v">{kpis.aiSavedHours}<small>hrs</small></div>
          <div className="sub">About 1.5 full-time staff</div>
          <div className="bar"><i style={{ width: '70%' }}></i></div>
        </div>
        <div className="card kpi">
          <div className="sub">AI response time</div>
          <div className="v">{kpis.averageAiResponseTimeSec}<small>sec</small></div>
          <div className="sub">Under the 2 sec target</div>
          <div className="bar"><i style={{ width: '90%' }}></i></div>
        </div>
      </div>

      <div className="card" style={{ marginTop: '16px' }}>
        <div className="ph" style={{ margin: 0 }}>
          <div>
            <h3>Booking funnel</h3>
            <p className="sub" style={{ margin: 0 }}>From first message to completed visit</p>
          </div>
          <span className="bdg ok">
            {Math.round((funnel.attended / funnel.inquiries) * 100) || 81}% end-to-end retention
          </span>
        </div>
        <div className="flow">
          <div><span className="sub">Inquiries</span><b>{funnel.inquiries}</b><i style={{ width: '100%' }}></i></div>
          <div><span className="sub">Availability checked</span><b>{funnel.slotsChecked}</b><i style={{ width: `${(funnel.slotsChecked / funnel.inquiries) * 100}%` }}></i></div>
          <div><span className="sub">Slots offered</span><b>{funnel.proposedBookings}</b><i style={{ width: `${(funnel.proposedBookings / funnel.inquiries) * 100}%` }}></i></div>
          <div><span className="sub">Confirmed on WhatsApp</span><b>{funnel.confirmedBookings}</b><i style={{ width: `${(funnel.confirmedBookings / funnel.inquiries) * 100}%` }}></i></div>
          <div><span className="sub">Visits completed</span><b>{funnel.attended}</b><i style={{ width: `${(funnel.attended / funnel.inquiries) * 100}%` }}></i></div>
        </div>
      </div>

      <div className="grid-ds g2" style={{ marginTop: '16px' }}>
        <div className="card">
          <h3>Top procedures</h3>
          <p className="sub">Revenue by procedure</p>
          <div className="row">
            <div style={{ flex: 1 }}><b>Dental checkup</b> <span className="bdg n">Dental</span><div className="bar"><i style={{ width: '100%' }}></i></div></div><b>750 JOD</b>
          </div>
          <div className="row">
            <div style={{ flex: 1 }}><b>Skin consultation</b> <span className="bdg n">Dermatology</span><div className="bar"><i style={{ width: '80%' }}></i></div></div><b>600 JOD</b>
          </div>
          <div className="row">
            <div style={{ flex: 1 }}><b>General review</b> <span className="bdg n">General</span><div className="bar"><i style={{ width: '56%' }}></i></div></div><b>420 JOD</b>
          </div>
        </div>

        <div className="card">
          <h3>Clinician workload</h3>
          <p className="sub">Booked hours against scheduled hours</p>
          <div className="row">
            <div className="av" style={{ background: 'var(--fe-signal-wash)', color: 'var(--fe-signal)', display: 'grid', placeItems: 'center', borderRadius: '50%', width: 34, height: 34, fontWeight: 600 }}>SA</div>
            <div style={{ flex: 1 }}><b>Dr. Sarah Al-Ahmad</b><div className="sub">Dental</div><div className="bar"><i style={{ width: '25%' }}></i></div></div><span className="bdg">25% load</span>
          </div>
          <div className="row">
            <div className="av" style={{ background: 'var(--fe-signal-wash)', color: 'var(--fe-signal)', display: 'grid', placeItems: 'center', borderRadius: '50%', width: 34, height: 34, fontWeight: 600 }}>NA</div>
            <div style={{ flex: 1 }}><b>Dr. Noura Al-Zahrani</b><div className="sub">General</div><div className="bar"><i style={{ width: '18%' }}></i></div></div><span className="bdg">18% load</span>
          </div>
          <div className="row">
            <div className="av" style={{ background: 'var(--fe-signal-wash)', color: 'var(--fe-signal)', display: 'grid', placeItems: 'center', borderRadius: '50%', width: 34, height: 34, fontWeight: 600 }}>OF</div>
            <div style={{ flex: 1 }}><b>Dr. Omar Farooq</b><div className="sub">Dermatology</div><div className="bar"><i style={{ width: '9%' }}></i></div></div><span className="bdg">9% load</span>
          </div>
        </div>
      </div>
    </>
  );
}