import { useState, type FormEvent, useEffect, useMemo } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Calendar, Clock, Ticket, UserCheck, AlertCircle } from 'lucide-react';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import { useCustomers, type CustomerListRow } from '../lib/customers';
import {
  CreateRecordDrawer,
  FormSection,
  TextField,
  SelectField,
  TextAreaField,
  TagsField,
  useFormOptions,
  useEmployees,
  textOrUndefined,
  numberOrUndefined,
} from './CreateRecordDrawer';

const followUpsKey = ['leads'] as const;

export const FOLLOW_UP_STATUSES = ['New', 'Contacted', 'Scheduled', 'Converted', 'Disqualified'] as const;

export const FOLLOW_UP_STATUS_LABEL: Record<(typeof FOLLOW_UP_STATUSES)[number], StringKey> = {
  New: 'followUps.statuses.New',
  Contacted: 'followUps.statuses.Contacted',
  Scheduled: 'followUps.statuses.Scheduled',
  Converted: 'followUps.statuses.Completed',
  Disqualified: 'followUps.statuses.Cancelled',
};

export interface FollowUpRow {
  id: string;
  name: string;
  company: string | null;
  source: string | null;
  status: string;
  jobTitle: string | null;
  email: string | null;
  phone: string | null;
  customerId: string | null;
  ticketNumber: string | null;
  ticketDate: string | null;
  followUpDate: string | null;
  priority: string | null;
  leadScore: number | null;
  estimatedValue: number | null;
  customer?: {
    id: string;
    cxId: string;
    displayName: string;
    primaryEmail: string | null;
    primaryPhone: string | null;
  } | null;
  createdById: string | null;
  createdBy: { id: string; fullName: string } | null;
  ownerId: string | null;
  tags?: string[];
  notes?: string | null;
  createdAt: string;
}

export interface CreateFollowUpDrawerProps {
  open: boolean;
  onClose: () => void;
  initialCustomerId?: string | null;
  initialTicketNumber?: string | null;
  initialTicketDate?: string | null;
}

export function CreateFollowUpDrawer({
  open,
  onClose,
  initialCustomerId,
  initialTicketNumber,
  initialTicketDate,
}: CreateFollowUpDrawerProps) {
  const t = useT();
  const qc = useQueryClient();
  const opts = useFormOptions();
  const customersQuery = useCustomers('');
  const employeesQuery = useEmployees();

  const ownerOptions = (employeesQuery.data ?? []).map((employee) => ({
    value: employee.userId,
    label: employee.fullName,
  }));

  const customerList = customersQuery.data?.items ?? [];

  const customerOptions = useMemo(() => {
    return customerList.map((c) => ({
      value: c.id,
      label: `${c.displayName} (${c.cxId})${c.latestTicket ? ` · Ticket ${c.latestTicket.ticketNumber}` : ''}`,
    }));
  }, [customerList]);

  const [form, setForm] = useState({
    name: '',
    customerId: initialCustomerId ?? '',
    ticketNumber: initialTicketNumber ?? '',
    ticketDate: initialTicketDate ?? '',
    followUpDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
    company: '',
    jobTitle: '',
    email: '',
    phone: '',
    source: '',
    status: 'New',
    priority: 'high',
    ownerId: '',
    notes: '',
    tags: [] as string[],
  });

  // When initial customer/ticket changes, populate form
  useEffect(() => {
    if (initialCustomerId) {
      const match = customerList.find((c) => c.id === initialCustomerId);
      setForm((prev) => ({
        ...prev,
        customerId: initialCustomerId,
        name: prev.name || (match ? `Follow-up with ${match.displayName}` : ''),
        ticketNumber: initialTicketNumber ?? match?.latestTicket?.ticketNumber ?? '',
        ticketDate: initialTicketDate ?? match?.latestTicket?.createdAt ?? '',
        email: prev.email || match?.primaryEmail || '',
        phone: prev.phone || match?.primaryPhone || '',
      }));
    }
  }, [initialCustomerId, initialTicketNumber, initialTicketDate, customerList]);

  // Handle selecting a person from People section
  const handleCustomerSelect = (customerId: string) => {
    const selected = customerList.find((c) => c.id === customerId);
    setForm((prev) => {
      const ticketNum = selected?.latestTicket?.ticketNumber ?? prev.ticketNumber;
      const ticketDt = selected?.latestTicket?.createdAt ?? prev.ticketDate;
      return {
        ...prev,
        customerId,
        name: prev.name || (selected ? `Follow-up with ${selected.displayName}` : ''),
        email: selected?.primaryEmail || prev.email,
        phone: selected?.primaryPhone || prev.phone,
        ticketNumber: ticketNum,
        ticketDate: ticketDt,
      };
    });
  };

  const set = (field: string) => (e: { target: { value: string } }) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const reset = () => {
    setForm({
      name: '',
      customerId: '',
      ticketNumber: '',
      ticketDate: '',
      followUpDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
      company: '',
      jobTitle: '',
      email: '',
      phone: '',
      source: '',
      status: 'New',
      priority: 'high',
      ownerId: '',
      notes: '',
      tags: [],
    });
  };

  const create = useMutation({
    mutationFn: () =>
      api.post<FollowUpRow>('/follow-ups', {
        name: form.name.trim(),
        customerId: form.customerId || undefined,
        ticketNumber: form.ticketNumber || undefined,
        ticketDate: form.ticketDate || undefined,
        followUpDate: form.followUpDate || undefined,
        company: textOrUndefined(form.company),
        jobTitle: textOrUndefined(form.jobTitle),
        email: textOrUndefined(form.email),
        phone: textOrUndefined(form.phone),
        source: form.source || undefined,
        status: form.status || 'New',
        priority: form.priority || undefined,
        ownerId: form.ownerId || undefined,
        tags: form.tags,
        notes: textOrUndefined(form.notes),
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: followUpsKey });
      void qc.invalidateQueries({ queryKey: ['customers'] });
      reset();
      onClose();
    },
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (form.name.trim()) create.mutate();
  };

  const close = () => {
    reset();
    onClose();
  };

  const statusOptions = FOLLOW_UP_STATUSES.map((status) => ({
    value: status,
    label: t(FOLLOW_UP_STATUS_LABEL[status] ?? 'followUps.statuses.New'),
  }));

  // Calculate ticket measurement (elapsed time)
  const ticketAgeDisplay = useMemo(() => {
    if (!form.ticketDate) return null;
    const diffMs = Date.now() - new Date(form.ticketDate).getTime();
    if (diffMs < 0) return 'Just now';
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h elapsed`;
    return `${hours}h elapsed`;
  }, [form.ticketDate]);

  return (
    <CreateRecordDrawer
      open={open}
      onClose={close}
      title={t('followUps.form.title')}
      description={t('followUps.form.about')}
      submitLabel={t('followUps.form.save')}
      isSubmitting={create.isPending}
      canSubmit={Boolean(form.name.trim())}
      onSubmit={onSubmit}
    >
      {/* Connected Person & Ticket Section */}
      <FormSection title={t('followUps.form.sectionPerson')}>
        <div className="space-y-3">
          <SelectField
            label={t('followUps.form.fieldPerson')}
            placeholder={t('followUps.form.selectPersonPlaceholder')}
            options={customerOptions}
            value={form.customerId}
            onChange={(e) => handleCustomerSelect(e.target.value)}
          />

          {/* Ticket Information & Measurement */}
          <div className="rounded-lg border border-hairline bg-surface-raised p-3 text-xs">
            <div className="flex items-center justify-between font-medium text-ink mb-1.5">
              <span className="flex items-center gap-1.5 text-signal">
                <Ticket className="h-3.5 w-3.5" />
                {t('followUps.form.ticketDetails')}
              </span>
              {ticketAgeDisplay && (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 font-mono text-[11px]">
                  <Clock className="h-3 w-3" />
                  {ticketAgeDisplay}
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2 mt-2">
              <TextField
                label={t('followUps.form.ticketNumber')}
                placeholder="e.g. TCK-1042"
                value={form.ticketNumber}
                onChange={set('ticketNumber')}
              />
              <TextField
                label={t('followUps.form.ticketDate')}
                type="date"
                value={form.ticketDate ? form.ticketDate.slice(0, 10) : ''}
                onChange={set('ticketDate')}
              />
            </div>
          </div>
        </div>
      </FormSection>

      <FormSection title={t('followUps.form.sectionFollowUp')}>
        <TextField
          label={t('followUps.form.fieldName')}
          required
          autoFocus
          placeholder="e.g. Call customer about invoice clarification"
          value={form.name}
          onChange={set('name')}
        />
        <div className="grid grid-cols-2 gap-2">
          <TextField
            label={t('followUps.form.fieldDate')}
            type="date"
            value={form.followUpDate}
            onChange={set('followUpDate')}
          />
          <SelectField
            label={t('followUps.form.fieldPriority')}
            options={[
              { value: 'urgent', label: 'Urgent (Within 4h)' },
              { value: 'high', label: 'High (Same day)' },
              { value: 'medium', label: 'Medium' },
              { value: 'low', label: 'Low' },
            ]}
            value={form.priority}
            onChange={set('priority')}
          />
        </div>
        <SelectField
          label={t('followUps.form.fieldStatus')}
          options={statusOptions}
          value={form.status}
          onChange={set('status')}
        />
      </FormSection>

      <FormSection title={t('followUps.form.sectionContact')}>
        <TextField label={t('form.field.email')} type="email" dir="ltr" value={form.email} onChange={set('email')} />
        <TextField label={t('form.field.phone')} dir="ltr" placeholder="+" value={form.phone} onChange={set('phone')} />
      </FormSection>

      <FormSection title={t('form.section.crm')}>
        <SelectField label={t('form.field.assignee')} placeholder="—" options={ownerOptions} value={form.ownerId} onChange={set('ownerId')} />
        <TagsField label={t('form.field.tags')} value={form.tags} onChange={(tags) => setForm((prev) => ({ ...prev, tags }))} placeholder={t('form.field.tagsAdd')} />
        <TextAreaField label={t('form.field.notes')} wide value={form.notes} onChange={set('notes')} />
      </FormSection>
    </CreateRecordDrawer>
  );
}
