import { Controller, Get } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { Public } from '../auth/decorators';

@Controller('health')
export class HealthController {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Liveness/readiness probe. Reports which dependency is unhealthy but
   * never why in detail — connection strings and driver errors stay in the
   * logs, not in an unauthenticated response body.
   */
  @Public()
  @Get()
  async health(): Promise<{ status: 'ok' | 'degraded'; checks: Record<string, 'up' | 'down'> }> {
    const checks: Record<string, 'up' | 'down'> = { database: 'down' };

    try {
      await this.prisma.client.$queryRaw`SELECT 1`;
      checks.database = 'up';
    } catch {
      checks.database = 'down';
    }

    const status = Object.values(checks).every((c) => c === 'up') ? 'ok' : 'degraded';
    return { status, checks };
  }
}
