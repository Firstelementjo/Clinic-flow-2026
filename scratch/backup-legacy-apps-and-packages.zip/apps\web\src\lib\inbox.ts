import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type {
  AssignConversationInput,
  ConversationDetail,
  ConversationSummary,
  InboxFilter,
  SendMessageInput,
  UpdateConversationInput,
} from '@firstelement/shared';
import { api } from './api';

interface InboxPage {
  items: ConversationSummary[];
  nextCursor: string | null;
}

export function useInbox(params: { filter: InboxFilter; search?: string; projectId?: string }) {
  const query = new URLSearchParams({ filter: params.filter });
  if (params.search) query.set('search', params.search);
  if (params.projectId) query.set('projectId', params.projectId);

  return useQuery({
    queryKey: ['inbox', params.filter, params.search ?? '', params.projectId ?? ''],
    queryFn: () => api.get<InboxPage>(`/conversations?${query.toString()}`),
    // The queue moves while you read it. Slice 9 replaces polling with the
    // realtime channel; until then a slow poll keeps the list honest
    // without hammering the API.
    refetchInterval: 20_000,
  });
}

export function useConversation(conversationId: string | null) {
  return useQuery({
    queryKey: ['conversation', conversationId],
    queryFn: () => api.get<ConversationDetail>(`/conversations/${conversationId}`),
    enabled: Boolean(conversationId),
  });
}

/** Every mutation refreshes both the thread and the list it is sorted in. */
function useConversationMutation<TInput>(
  conversationId: string,
  send: (input: TInput) => Promise<ConversationDetail>,
) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: send,
    onSuccess: (detail) => {
      queryClient.setQueryData(['conversation', conversationId], detail);
      void queryClient.invalidateQueries({ queryKey: ['inbox'] });
    },
  });
}

export function useReply(conversationId: string) {
  return useConversationMutation<SendMessageInput>(conversationId, (input) =>
    api.post<ConversationDetail>(`/conversations/${conversationId}/messages`, input),
  );
}

export function useAssign(conversationId: string) {
  return useConversationMutation<AssignConversationInput>(conversationId, (input) =>
    api.patch<ConversationDetail>(`/conversations/${conversationId}/assignment`, input),
  );
}

export function useUpdateConversation(conversationId: string) {
  return useConversationMutation<UpdateConversationInput>(conversationId, (input) =>
    api.patch<ConversationDetail>(`/conversations/${conversationId}`, input),
  );
}

export function useCloseConversation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (conversationId: string) =>
      api.patch<ConversationDetail>(`/conversations/${conversationId}/close`, {}),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['inbox'] });
    },
  });
}
