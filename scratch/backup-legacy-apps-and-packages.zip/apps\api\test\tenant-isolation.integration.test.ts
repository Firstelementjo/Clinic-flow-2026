/**
 * Tenant-isolation proof (plan §6: required before slice 2 is done).
 *
 * This drives the real services against a real PostgreSQL database — the
 * queries under test are the ones the controllers call. Services are
 * constructed directly rather than through the Nest container so the suite
 * needs no decorator metadata and no HTTP listener; the guards that sit in
 * front of them are covered separately by the policy unit tests.
 *
 * Requires a database. Set DATABASE_URL and run migrations first:
 *   docker compose up -d postgres
 *   yarn db:push
 * Without a reachable database the suite skips loudly rather than passing
 * silently — a green run that proved nothing would be worse than a skip.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { getPrismaClient, disconnectPrisma, TenantAccessError, type TenantContext } from '@firstelement/database';
import { hashPassword } from '@firstelement/auth';
import { InboxFilter } from '@firstelement/shared';
import { AuditService } from '../src/audit/audit.service';
import { PrismaService } from '../src/common/prisma.service';
import { ProjectsService } from '../src/projects/projects.service';
import { EmployeesService } from '../src/employees/employees.service';
import { SessionService } from '../src/auth/session.service';
import { DomainEventBus } from '../src/events/domain-event-bus';
import { ConversationsService } from '../src/conversations/conversations.service';
import { CustomersService } from '../src/customers/customers.service';
import { IdentityResolutionService } from '../src/customers/identity-resolution.service';
import type { MessageQueueService } from '../src/messaging/message-queue.service';

const prisma = getPrismaClient();

async function databaseReachable(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return true;
  } catch {
    return false;
  }
}

const hasDatabase = await databaseReachable();

describe.skipIf(!hasDatabase)('cross-project isolation', () => {
  const suffix = Date.now().toString(36);
  const prismaService = { client: prisma } as PrismaService;
  const audit = new AuditService(prismaService);
  const sessions = new SessionService(prismaService);
  const projects = new ProjectsService(prismaService, audit);
  const employees = new EmployeesService(prismaService, audit, sessions);
  // Collect published events instead of wiring the real emitter: the
  // timeline subscriber is exercised by its own path, and these tests are
  // about which rows a caller can reach.
  const published: { type: string }[] = [];
  const eventBus = { publish: (event: { type: string }) => published.push(event) } as DomainEventBus;
  // Delivery is a separate stage with its own tests; here it is a spy, so
  // an isolation failure cannot hide behind a queue error.
  const enqueued: unknown[] = [];
  const queue = {
    enqueueInbound: async (job: unknown) => void enqueued.push(job),
    enqueueOutbound: async (job: unknown) => void enqueued.push(job),
  } as unknown as MessageQueueService;
  const conversations = new ConversationsService(prismaService, audit, eventBus, queue);
  const customers = new CustomersService(prismaService, audit);
  const identities = new IdentityResolutionService(prismaService, eventBus);

  let orgId: string;
  let otherOrgId: string;
  let projectA: string;
  let projectB: string;
  let projectOther: string;
  let employeeCtx: TenantContext;
  let adminCtx: TenantContext;
  let otherOrgAdminCtx: TenantContext;
  let conversationA: { conversationId: string; customerId: string };
  let conversationB: { conversationId: string; customerId: string };
  let conversationOther: { conversationId: string; customerId: string };

  beforeAll(async () => {
    const passwordHash = await hashPassword('IsolationTest123!');

    const org = await prisma.organization.create({
      data: { name: `Isolation ${suffix}`, slug: `isolation-${suffix}` },
    });
    const otherOrg = await prisma.organization.create({
      data: { name: `Rival ${suffix}`, slug: `rival-${suffix}` },
    });
    orgId = org.id;
    otherOrgId = otherOrg.id;

    const [a, b, other] = await Promise.all([
      prisma.project.create({ data: { organizationId: org.id, name: 'A', slug: 'a' } }),
      prisma.project.create({ data: { organizationId: org.id, name: 'B', slug: 'b' } }),
      prisma.project.create({ data: { organizationId: otherOrg.id, name: 'X', slug: 'x' } }),
    ]);
    projectA = a.id;
    projectB = b.id;
    projectOther = other.id;

    const employee = await prisma.user.create({
      data: {
        organizationId: org.id,
        email: `employee-${suffix}@isolation.test`,
        fullName: 'Employee A',
        passwordHash,
        role: 'EMPLOYEE',
      },
    });
    await prisma.projectMembership.create({
      data: { organizationId: org.id, projectId: projectA, userId: employee.id },
    });

    employeeCtx = {
      organizationId: org.id,
      userId: employee.id,
      role: 'EMPLOYEE',
      projectIds: [projectA],
    };
    adminCtx = {
      organizationId: org.id,
      userId: employee.id,
      role: 'ADMIN',
      projectIds: [projectA, projectB],
    };
    otherOrgAdminCtx = {
      organizationId: otherOrg.id,
      userId: 'irrelevant',
      role: 'ADMIN',
      projectIds: [projectOther],
    };

    // One conversation in each project, so every read path has something
    // it must not return.
    conversationA = await createConversation(org.id, projectA, 'Customer A');
    conversationB = await createConversation(org.id, projectB, 'Customer B');
    conversationOther = await createConversation(otherOrg.id, projectOther, 'Customer X');

    await prisma.conversation.update({
      where: { id: conversationA.conversationId },
      data: { lastReplierUserId: employeeCtx.userId },
    });
  });

  async function createConversation(
    organizationId: string,
    projectId: string,
    displayName: string,
  ): Promise<{ conversationId: string; customerId: string }> {
    const cxIdSuffix = Date.now().toString().slice(-4) + Math.floor(Math.random() * 1000);
    const customer = await prisma.customer.create({
      data: { organizationId, projectId, displayName, cxId: `#${cxIdSuffix}`.substring(0, 9) },
      select: { id: true },
    });
    const conversation = await prisma.conversation.create({
      data: {
        organizationId,
        projectId,
        customerId: customer.id,
        channel: 'MOCK',
        messageCount: 1,
        ticketNumber: `#0817TST${cxIdSuffix.slice(-4)}`,
        messages: {
          create: {
            organizationId,
            projectId,
            channel: 'MOCK',
            direction: 'INBOUND',
            authorType: 'CUSTOMER',
            body: 'secret content',
          },
        },
      },
      select: { id: true },
    });
    return { conversationId: conversation.id, customerId: customer.id };
  }

  afterAll(async () => {
    if (!hasDatabase) return;
    await prisma.organization.deleteMany({ where: { id: { in: [orgId, otherOrgId] } } });
    await disconnectPrisma();
  });

  it('lists only the projects the employee belongs to', async () => {
    const visible = await projects.list(employeeCtx);
    expect(visible.map((p) => p.id)).toEqual([projectA]);
  });

  it('refuses to read a sibling project in the same organization', async () => {
    await expect(projects.getById(employeeCtx, projectB)).rejects.toThrowError(TenantAccessError);
  });

  it('refuses to read a project in another organization', async () => {
    await expect(projects.getById(adminCtx, projectOther)).rejects.toThrowError(TenantAccessError);
  });

  it('refuses to write to a project outside the caller membership', async () => {
    await expect(projects.update(employeeCtx, projectB, { name: 'hijacked' })).rejects.toThrowError(
      TenantAccessError,
    );
    const untouched = await prisma.project.findUniqueOrThrow({ where: { id: projectB } });
    expect(untouched.name).toBe('B');
  });

  it("does not leak another organization's projects even to its own admin's list", async () => {
    const visible = await projects.list(otherOrgAdminCtx);
    expect(visible.map((p) => p.id)).toEqual([projectOther]);
  });

  it('drops project ids from another tenant when creating an employee', async () => {
    const created = await employees.create(adminCtx, {
      email: `imported-${suffix}@isolation.test`,
      fullName: 'Imported Person',
      password: 'IsolationTest123!',
      role: 'EMPLOYEE',
      locale: 'ar',
      // projectOther belongs to a different organization and must be ignored.
      projectIds: [projectA, projectOther],
    });

    expect(created.memberships.map((m) => m.projectId)).toEqual([projectA]);
  });

  it('scopes employee listings to the caller organization', async () => {
    const visible = await employees.list(adminCtx);
    expect(visible.length).toBeGreaterThan(0);
    const ids = visible.map((u) => u.id);
    const foreign = await prisma.user.findMany({
      where: { organizationId: otherOrgId },
      select: { id: true },
    });
    for (const user of foreign) {
      expect(ids).not.toContain(user.id);
    }
  });

  it('shows an employee only the conversations in their own project', async () => {
    const inbox = await conversations.inbox(employeeCtx, {
      filter: InboxFilter.ASSIGNED_TO_ME,
      limit: 50,
    });
    const ids = inbox.items.map((item) => item.id);
    expect(ids).toContain(conversationA.conversationId);
    expect(ids).not.toContain(conversationB.conversationId);
    expect(ids).not.toContain(conversationOther.conversationId);
  });

  it('refuses to open a conversation from a sibling project', async () => {
    await expect(
      conversations.getById(employeeCtx, conversationB.conversationId),
    ).rejects.toThrowError(/not found/i);
  });

  it("refuses to open another organization's conversation", async () => {
    await expect(conversations.getById(adminCtx, conversationOther.conversationId)).rejects.toThrowError(
      /not found/i,
    );
  });

  it('refuses to post a reply into a conversation outside the caller reach', async () => {
    await expect(
      conversations.reply(employeeCtx, conversationB.conversationId, { body: 'injected' }),
    ).rejects.toThrowError(/not found/i);

    const messages = await prisma.message.count({
      where: { conversationId: conversationB.conversationId },
    });
    expect(messages).toBe(1);
  });

  it('refuses to assign or resolve a conversation outside the caller reach', async () => {
    await expect(
      conversations.assign(employeeCtx, conversationB.conversationId, { employeeId: null }),
    ).rejects.toThrowError(/not found/i);
    await expect(
      conversations.update(employeeCtx, conversationB.conversationId, { status: 'RESOLVED' }),
    ).rejects.toThrowError(/not found/i);
  });

  it('scopes customer reads and search to accessible projects', async () => {
    const listed = await customers.list(employeeCtx, { limit: 50 });
    const ids = listed.items.map((item) => item.id);
    expect(ids).toContain(conversationA.customerId);
    expect(ids).not.toContain(conversationB.customerId);

    await expect(customers.getById(employeeCtx, conversationB.customerId)).rejects.toThrowError(
      /not found/i,
    );
  });

  it('keeps identity resolution inside one project', async () => {
    const externalId = `handle-${suffix}`;

    const first = await identities.resolve({
      organizationId: orgId,
      projectId: projectA,
      platform: 'WHATSAPP',
      externalId,
      displayName: 'Shared Handle',
      phone: '+966500000999',
    });
    expect(first.created).toBe(true);

    // Same handle, same project: the same customer, not a duplicate.
    const again = await identities.resolve({
      organizationId: orgId,
      projectId: projectA,
      platform: 'WHATSAPP',
      externalId,
    });
    expect(again.created).toBe(false);
    expect(again.customerId).toBe(first.customerId);

    // Same handle in a different project is a different person: business
    // knowledge and consent are project-scoped (plan §20.4).
    const elsewhere = await identities.resolve({
      organizationId: orgId,
      projectId: projectB,
      platform: 'WHATSAPP',
      externalId,
    });
    expect(elsewhere.created).toBe(true);
    expect(elsewhere.customerId).not.toBe(first.customerId);
  });

  it('links a new handle on a verified phone but only reports a name match', async () => {
    const phone = `+9665000${suffix.slice(-5)}`;

    const original = await identities.resolve({
      organizationId: orgId,
      projectId: projectA,
      platform: 'WHATSAPP',
      externalId: `verified-${suffix}`,
      displayName: 'Mona Verified',
      phone,
    });

    // Verified signal: linked without asking.
    const linked = await identities.resolve({
      organizationId: orgId,
      projectId: projectA,
      platform: 'INSTAGRAM',
      externalId: `verified-ig-${suffix}`,
      displayName: 'Mona Verified',
      phone,
    });
    expect(linked.created).toBe(false);
    expect(linked.customerId).toBe(original.customerId);

    // Name alone: a new customer plus a flagged possible match, never a merge.
    const weak = await identities.resolve({
      organizationId: orgId,
      projectId: projectA,
      platform: 'TELEGRAM',
      externalId: `weak-${suffix}`,
      displayName: 'Mona Verified',
    });
    expect(weak.created).toBe(true);
    expect(weak.customerId).not.toBe(original.customerId);
    expect(weak.possibleMatches.map((m) => m.customerId)).toContain(original.customerId);
  });
});

describe.skipIf(hasDatabase)('cross-project isolation (skipped)', () => {
  it('needs a database — see the file header for setup', () => {
    expect(hasDatabase).toBe(false);
  });
});
