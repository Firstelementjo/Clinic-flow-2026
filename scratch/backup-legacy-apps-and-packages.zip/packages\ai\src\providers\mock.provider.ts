import {
  estimateTokens,
  type AIProvider,
  type ChatMessage,
  type CompletionRequest,
  type CompletionResult,
} from './types';

/**
 * Deterministic local model (no API key, no network).
 *
 * It exists so the whole AI path — orchestration, tracing, tool calls,
 * escalation, the transparency panel — is demonstrable and testable
 * without a provider account, and so CI exercises the same code path
 * production uses.
 *
 * It is rule-based, and deliberately conservative in the same directions a
 * real agent must be: it answers only from retrieved context, asks for
 * clarification when it has none, and hands over the moment a customer
 * asks for a person. It does not paraphrase or invent, so a test asserting
 * "the agent did not make up a policy" means something.
 */
export class MockAIProvider implements AIProvider {
  readonly kind = 'MOCK' as const;
  readonly defaultModel = 'mock-rules-v1';

  async generate(request: CompletionRequest): Promise<CompletionResult> {
    const lastUser = [...request.messages].reverse().find((message) => message.role === 'user');
    const question = lastUser?.content ?? '';
    const context = extractContext(request.messages);
    const toolResults = request.messages.filter((message) => message.role === 'tool');

    // Explicit human request wins over everything else (plan §10).
    if (wantsHuman(question) && canCall(request, 'request_human')) {
      return this.reply({
        text: 'سأحوّلك إلى أحد زملائي الآن.',
        toolCalls: [
          {
            id: 'call_request_human',
            name: 'request_human',
            arguments: { reason: 'Customer explicitly asked for a person' },
          },
        ],
        finishReason: 'tool_calls',
        request,
      });
    }

    // Nothing retrieved yet and the knowledge tool is available: look
    // before answering, which is the behaviour being tested.
    if (!context && toolResults.length === 0 && canCall(request, 'search_knowledge_base')) {
      return this.reply({
        text: '',
        toolCalls: [
          {
            id: 'call_search_kb',
            name: 'search_knowledge_base',
            arguments: { query: question.slice(0, 200) },
          },
        ],
        finishReason: 'tool_calls',
        request,
      });
    }

    if (!context) {
      // No knowledge to answer from. Ask rather than invent (plan §9).
      return this.reply({
        text: 'لم أجد هذه المعلومة في قاعدة معرفة المشروع. هل يمكنك توضيح طلبك أكثر؟',
        toolCalls: [],
        finishReason: 'stop',
        request,
      });
    }

    // Answer strictly from the retrieved text: the first two lines of the
    // highest-scoring chunk, quoted rather than rewritten.
    const answer = context.split('\n').filter(Boolean).slice(0, 2).join(' ');
    return this.reply({
      text: answer,
      toolCalls: [],
      finishReason: 'stop',
      request,
    });
  }

  private reply(params: {
    text: string;
    toolCalls: CompletionResult['toolCalls'];
    finishReason: CompletionResult['finishReason'];
    request: CompletionRequest;
  }): CompletionResult {
    const inputTokens = params.request.messages.reduce(
      (total, message) => total + estimateTokens(message.content),
      0,
    );

    return {
      text: params.text,
      toolCalls: params.toolCalls,
      usage: { inputTokens, outputTokens: estimateTokens(params.text) },
      model: params.request.model ?? this.defaultModel,
      finishReason: params.finishReason,
    };
  }
}

const HUMAN_REQUEST_PATTERNS = [
  /\b(human|agent|person|representative|supervisor|manager)\b/i,
  /(موظف|إنسان|شخص|مسؤول|مشرف|بشري)/,
];

function wantsHuman(text: string): boolean {
  const asking = /\b(talk|speak|connect|transfer)\b|(أريد|كلمني|حوّلني|تحويل)/i.test(text);
  return asking && HUMAN_REQUEST_PATTERNS.some((pattern) => pattern.test(text));
}

/**
 * Reads the retrieved-knowledge block the orchestrator supplies. Anything
 * outside it is conversation, not knowledge, and is never treated as a
 * source of business policy.
 */
function extractContext(messages: ChatMessage[]): string | null {
  // Match per message rather than across a joined blob: concatenating
  // first lets an opening delimiter in one message pair with a closing one
  // in another, which is how the security policy briefly got mistaken for
  // retrieved knowledge.
  for (const message of messages) {
    if (message.role !== 'system') continue;

    const match = message.content.match(/<knowledge>([\s\S]*?)<\/knowledge>/);
    const inner = match?.[1]?.trim();
    if (inner) return inner;
  }

  // Tool results are JSON envelopes, not prose. Answering with the
  // envelope would put `{"results":[],"found":false}` in front of a
  // customer — so the payload is parsed, and an empty result set is
  // treated as "no knowledge" rather than as content.
  const retrieved: string[] = [];

  for (const message of messages) {
    if (message.role !== 'tool' || message.toolName !== 'search_knowledge_base') continue;

    try {
      const payload = JSON.parse(message.content) as {
        found?: boolean;
        results?: { content?: string }[];
      };
      if (payload.found === false) continue;

      for (const result of payload.results ?? []) {
        if (result.content) retrieved.push(result.content);
      }
    } catch {
      // Not JSON — ignore rather than quoting it at the customer.
      continue;
    }
  }

  return retrieved.length > 0 ? retrieved.join('\n') : null;
}

function canCall(request: CompletionRequest, tool: string): boolean {
  return (request.tools ?? []).some((definition) => definition.name === tool);
}
