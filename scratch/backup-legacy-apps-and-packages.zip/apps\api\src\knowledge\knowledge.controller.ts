import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
  Req,
  UploadedFile as UploadedFileParam,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import type { Request } from 'express';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import { MAX_UPLOAD_BYTES } from '@firstelement/knowledge-base';
import {
  ErrorCode,
  createKnowledgeBaseSchema,
  createTextDocumentSchema,
  retrievalPreviewSchema,
  type CreateKnowledgeBaseInput,
  type CreateTextDocumentInput,
  type RetrievalPreviewInput,
} from '@firstelement/shared';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { KnowledgeService, type UploadedFile } from './knowledge.service';

@Controller('projects/:projectId/knowledge')
export class KnowledgeController {
  constructor(private readonly knowledge: KnowledgeService) {}

  @Get('bases')
  @RequirePermissions(Permission.KNOWLEDGE_READ)
  listBases(@Tenant() ctx: TenantContext, @Param('projectId', ParseUUIDPipe) projectId: string) {
    return this.knowledge.listBases(ctx, projectId);
  }

  @Post('bases')
  @RequirePermissions(Permission.KNOWLEDGE_MANAGE)
  createBase(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Body(zodBody(createKnowledgeBaseSchema)) body: CreateKnowledgeBaseInput,
  ) {
    return this.knowledge.createBase(ctx, projectId, body);
  }

  @Get('documents')
  @RequirePermissions(Permission.KNOWLEDGE_READ)
  listDocuments(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Query('knowledgeBaseId') knowledgeBaseId?: string,
  ) {
    return this.knowledge.listDocuments(ctx, projectId, knowledgeBaseId);
  }

  @Post('bases/:knowledgeBaseId/documents')
  @RequirePermissions(Permission.KNOWLEDGE_MANAGE)
  // Memory storage with a hard size limit: the file is hashed and handed
  // to the storage driver immediately, and multer never writes a
  // client-named file to disk.
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: MAX_UPLOAD_BYTES, files: 1 } }))
  upload(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('knowledgeBaseId', ParseUUIDPipe) knowledgeBaseId: string,
    @UploadedFileParam() file: UploadedFile | undefined,
    @Req() request: Request,
  ) {
    if (!file) {
      throw new BadRequestException({
        code: ErrorCode.VALIDATION_FAILED,
        message: 'No file was uploaded',
      });
    }
    return this.knowledge.uploadDocument(ctx, projectId, knowledgeBaseId, file, request.ip);
  }

  @Post('bases/:knowledgeBaseId/text')
  @RequirePermissions(Permission.KNOWLEDGE_MANAGE)
  createText(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('knowledgeBaseId', ParseUUIDPipe) knowledgeBaseId: string,
    @Body(zodBody(createTextDocumentSchema)) body: CreateTextDocumentInput,
  ) {
    return this.knowledge.createTextDocument(ctx, projectId, knowledgeBaseId, body);
  }

  @Post('documents/:documentId/reprocess')
  @RequirePermissions(Permission.KNOWLEDGE_MANAGE)
  reprocess(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('documentId', ParseUUIDPipe) documentId: string,
  ) {
    return this.knowledge.reprocessDocument(ctx, projectId, documentId);
  }

  @Delete('documents/:documentId')
  @RequirePermissions(Permission.KNOWLEDGE_MANAGE)
  @HttpCode(204)
  remove(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('documentId', ParseUUIDPipe) documentId: string,
  ) {
    return this.knowledge.deleteDocument(ctx, projectId, documentId);
  }

  /** What the agent would retrieve for a question, with scores. */
  @Post('search')
  @RequirePermissions(Permission.KNOWLEDGE_READ)
  @HttpCode(200)
  search(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Body(zodBody(retrievalPreviewSchema)) body: RetrievalPreviewInput,
  ) {
    return this.knowledge.previewRetrieval(ctx, projectId, body);
  }
}
