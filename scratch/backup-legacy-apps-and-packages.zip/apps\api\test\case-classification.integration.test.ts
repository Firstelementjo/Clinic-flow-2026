/**
 * Case classification, solution lookup and case state (V1.2 §12–§15).
 *
 * The guarantee worth an integration test is §13's: a case in one project
 * must never surface another project's solution. That is a database-level
 * claim, so it is checked against a real database.
 *
 * Requires PostgreSQL with pgvector. Skips loudly without one.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { MockEmbeddingProvider } from '@firstelement/ai';
import { disconnectPrisma, getPrismaClient } from '@firstelement/database';
import {
  DocumentIngestionPipeline,
  KnowledgeRetriever,
  type StorageDriver,
} from '@firstelement/knowledge-base';

const prisma = getPrismaClient();

async function ready(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1 FROM case_classification_questions LIMIT 1`;
    return true;
  } catch {
    return false;
  }
}

const hasDatabase = await ready();

class MemoryStorage implements StorageDriver {
  private readonly files = new Map<string, Buffer>();
  async put(key: string, data: Buffer): Promise<void> {
    this.files.set(key, data);
  }
  async get(key: string): Promise<Buffer> {
    const file = this.files.get(key);
    if (!file) throw new Error(`Missing ${key}`);
    return file;
  }
  async delete(key: string): Promise<void> {
    this.files.delete(key);
  }
}

describe.skipIf(!hasDatabase)('case classification', () => {
  const suffix = Date.now().toString(36);
  const storage = new MemoryStorage();
  const embeddings = new MockEmbeddingProvider();
  const ingestion = new DocumentIngestionPipeline(prisma, storage, embeddings);
  const retriever = new KnowledgeRetriever(prisma, embeddings);

  let organizationId: string;
  let projectA: string;
  let projectB: string;
  let conversationA: string;
  let questionId: string;

  async function ingest(projectId: string, knowledgeBaseId: string, title: string, body: string) {
    const storageKey = `cases/${suffix}/${title}`;
    await storage.put(storageKey, Buffer.from(body, 'utf8'));

    const document = await prisma.document.create({
      data: {
        organizationId,
        projectId,
        knowledgeBaseId,
        title,
        sourceType: 'TEXT',
        storageKey,
        mimeType: 'text/plain',
        status: 'UPLOADED',
      },
      select: { id: true },
    });

    await ingestion.process(document.id);
    return document.id;
  }

  beforeAll(async () => {
    const organization = await prisma.organization.create({
      data: { name: `Cases ${suffix}`, slug: `cases-${suffix}` },
    });
    organizationId = organization.id;

    const [a, b] = await Promise.all([
      prisma.project.create({ data: { organizationId, name: 'A', slug: `case-a-${suffix}` } }),
      prisma.project.create({ data: { organizationId, name: 'B', slug: `case-b-${suffix}` } }),
    ]);
    projectA = a.id;
    projectB = b.id;

    const [baseA, baseB] = await Promise.all([
      prisma.knowledgeBase.create({ data: { organizationId, projectId: projectA, name: 'KB' } }),
      prisma.knowledgeBase.create({ data: { organizationId, projectId: projectB, name: 'KB' } }),
    ]);

    await ingest(
      projectA,
      baseA.id,
      'project-a-refunds.txt',
      'Refund handling for project A. Issue a refund within three business days.',
    );
    await ingest(
      projectB,
      baseB.id,
      'project-b-refunds.txt',
      'Refund handling for project B. Refunds require a manager and take thirty days.',
    );

    const question = await prisma.caseClassificationQuestion.create({
      data: {
        organizationId,
        projectId: projectA,
        position: 1,
        promptAr: 'ما نوع المشكلة؟',
        promptEn: 'What kind of issue is this?',
        options: [
          { value: 'refund', labelAr: 'استرجاع', labelEn: 'Refund handling' },
          { value: 'delivery', labelAr: 'توصيل', labelEn: 'Delivery' },
        ],
      },
      select: { id: true },
    });
    questionId = question.id;

    const customer = await prisma.customer.create({
      data: { organizationId, projectId: projectA, displayName: 'Case customer', cxId: '#33TEST01' },
      select: { id: true },
    });

    const conversation = await prisma.conversation.create({
      data: {
        organizationId,
        projectId: projectA,
        customerId: customer.id,
        channel: 'MOCK',
        mode: 'HUMAN',
        ticketNumber: '#0817TEST001',
      },
      select: { id: true },
    });
    conversationA = conversation.id;
  }, 120_000);

  afterAll(async () => {
    if (!hasDatabase) return;
    await prisma.organization.delete({ where: { id: organizationId } });
    await disconnectPrisma();
  });

  it('stores questions as configurable data rather than code', async () => {
    const questions = await prisma.caseClassificationQuestion.findMany({
      where: { projectId: projectA },
    });

    expect(questions).toHaveLength(1);
    expect(questions[0]!.promptAr).toBe('ما نوع المشكلة؟');
    expect(Array.isArray(questions[0]!.options)).toBe(true);
  });

  it('finds a solution in the case own project knowledge base', async () => {
    const result = await retriever.retrieve({
      organizationId,
      projectId: projectA,
      query: 'Refund handling',
      limit: 3,
      minScore: 0,
    });

    expect(result.chunks.length).toBeGreaterThan(0);
    // The §13 requirement: project A's case never sees project B's answer.
    for (const chunk of result.chunks) {
      expect(chunk.documentTitle).not.toBe('project-b-refunds.txt');
    }
  });

  it('records answers against the conversation', async () => {
    await prisma.conversationClassification.create({
      data: {
        organizationId,
        projectId: projectA,
        conversationId: conversationA,
        answers: [{ questionId, value: 'refund' }],
      },
    });

    const stored = await prisma.conversationClassification.findUniqueOrThrow({
      where: { conversationId: conversationA },
    });

    expect(stored.answers).toEqual([{ questionId, value: 'refund' }]);
  });

  it('captures the resolution that CSAT is computed from', async () => {
    await prisma.caseResolution.create({
      data: {
        organizationId,
        projectId: projectA,
        conversationId: conversationA,
        customerIssue: 'Refund not received',
        agentAction: 'Reissued the refund',
        usedKnowledgeBase: true,
        customerAccepted: true,
        customerSatisfied: true,
        outcome: 'RESOLVED',
      },
    });

    const resolution = await prisma.caseResolution.findUniqueOrThrow({
      where: { conversationId: conversationA },
    });

    expect(resolution.outcome).toBe('RESOLVED');
    expect(resolution.customerSatisfied).toBe(true);
  });

  it('closes and reopens the case, keeping the state on the conversation', async () => {
    await prisma.conversation.update({
      where: { id: conversationA },
      data: { status: 'CLOSED', closedAt: new Date() },
    });
    expect((await prisma.conversation.findUniqueOrThrow({ where: { id: conversationA } })).status).toBe(
      'CLOSED',
    );

    await prisma.conversation.update({
      where: { id: conversationA },
      data: { status: 'OPEN', closedAt: null, resolvedAt: null },
    });

    const reopened = await prisma.conversation.findUniqueOrThrow({ where: { id: conversationA } });
    expect(reopened.status).toBe('OPEN');
    expect(reopened.closedAt).toBeNull();
    // The resolution record survives a reopen — it is the history of what
    // happened, not a field on the current state.
    expect(await prisma.caseResolution.findUnique({ where: { conversationId: conversationA } })).not.toBeNull();
  });
});

describe.skipIf(hasDatabase)('case classification (skipped)', () => {
  it('needs PostgreSQL — see docs/testing.md', () => {
    expect(hasDatabase).toBe(false);
  });
});
