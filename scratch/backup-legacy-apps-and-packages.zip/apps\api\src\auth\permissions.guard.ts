import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { Request } from 'express';
import { assertCan, type Permission, type PolicyActor } from '@firstelement/auth';
import { PERMISSIONS_KEY } from './decorators';

/**
 * Enforces `@RequirePermissions(...)` server-side (plan §5).
 *
 * <h2>What this guard does and does not check</h2>
 *
 * <p>It evaluates each required permission against the caller's role, and it
 * additionally enforces the **project** boundary — but <em>only</em> when the
 * route carries a {@code :projectId} <em>path parameter</em>. That is the whole of
 * the project check here:
 *
 * <pre>{@code
 * const projectId = request.params?.projectId;
 * assertCan(actor, permission, projectId ? { projectId } : {});
 * }</pre>
 *
 * <p>An earlier version of this comment claimed that "a handler therefore cannot
 * forget to scope itself". <b>That was wrong, and it was load-bearing.</b> For a
 * route that names the project in the <em>query string</em> or the <em>request
 * body</em> — {@code GET /notes?projectId=…}, {@code GET /tasks?projectId=…},
 * {@code POST /tasks} with {@code projectId} in the body — {@code request.params}
 * has no {@code projectId}, so {@code assertCan} receives {@code {}} and
 * {@code can()} skips its project check entirely (it is
 * {@code if (resource.projectId && …)}). The handler is then the only remaining
 * layer, and the handler must scope itself with {@code projectScope} /
 * {@code accessibleProjectsScope} / {@code canAccessProject} from
 * {@code @firstelement/database}.
 *
 * <p>The clinic module is the clearest case: none of its routes carry a
 * {@code :projectId} param, so <em>every</em> clinic route depends entirely on
 * {@code LocalClinicAdapter} and {@code ClinicService} for scoping.
 *
 * <h2>Runtime behaviour is deliberately unchanged</h2>
 *
 * <p>Only this comment was corrected. Widening the guard to also read
 * {@code query.projectId} would change the meaning of every existing route at
 * once, and that is a security-owner decision, not a comment fix.
 *
 * <p>Denials raise {@link PermissionDeniedError}, which the exception filter turns
 * into a 404 so project existence does not leak across tenants.
 */
@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<Permission[]>(PERMISSIONS_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!required?.length) return true;

    const request = context.switchToHttp().getRequest<Request>();
    const user = request.sessionUser;
    if (!user) return false;

    const actor: PolicyActor = {
      userId: user.id,
      organizationId: user.organizationId,
      role: user.role,
      projectIds: user.projectIds,
    };

    const projectId = (request.params as Record<string, string | undefined>)?.projectId;

    for (const permission of required) {
      assertCan(actor, permission, projectId ? { projectId } : {});
    }

    return true;
  }
}
