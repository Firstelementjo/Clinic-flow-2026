import { Injectable } from '@nestjs/common';
import { getConfig } from '@firstelement/config';
import { ConnectorRegistry } from '@firstelement/connectors';
import { InboundMessagePipeline, OutboundDispatcher } from '@firstelement/messaging';
import { PrismaService } from '../common/prisma.service';
import { DomainEventBus } from '../events/domain-event-bus';

/**
 * Nest wrappers over the framework-neutral messaging classes.
 *
 * The logic lives in `@firstelement/messaging` because the worker runs the
 * same pipeline without Nest. These wrappers exist only so the API can
 * inject them.
 */

@Injectable()
export class ConnectorRegistryProvider extends ConnectorRegistry {}

@Injectable()
export class InboundPipelineProvider extends InboundMessagePipeline {
  constructor(prisma: PrismaService, events: DomainEventBus) {
    super(prisma.client, events);
  }
}

@Injectable()
export class OutboundDispatcherProvider extends OutboundDispatcher {
  constructor(prisma: PrismaService, registry: ConnectorRegistryProvider) {
    super(prisma.client, registry, getConfig().ENCRYPTION_KEY);
  }
}
