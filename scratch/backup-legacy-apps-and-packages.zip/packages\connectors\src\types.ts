import type { ChannelType } from '@firstelement/shared';

/**
 * The connector contract (plan §8).
 *
 * Everything above this layer — CRM, AI, routing — sees only the
 * normalized shapes here. A WhatsApp payload, an Instagram payload and a
 * Telegram update never travel further than the adapter that produced
 * them, which is what keeps external platforms adapters rather than
 * business logic (plan §20.5).
 */

export interface NormalizedAttachment {
  type: 'image' | 'video' | 'audio' | 'document' | 'sticker' | 'location' | 'unknown';
  url?: string;
  mimeType?: string;
  fileName?: string;
  sizeBytes?: number;
}

export interface NormalizedIncomingMessage {
  channel: ChannelType;
  /** The provider's message id. Drives idempotency — see plan §8. */
  externalMessageId: string;
  /** The sender's handle on this platform. */
  externalUserId: string;
  externalConversationId?: string;
  displayName?: string;
  /** Only signals the platform itself vouches for. */
  phone?: string;
  email?: string;
  text: string;
  attachments: NormalizedAttachment[];
  sentAt: Date;
  /** Kept for debugging and for identity resolution's raw profile. */
  raw: Record<string, unknown>;
}

export interface OutgoingMessage {
  externalUserId: string;
  externalConversationId?: string;
  text: string;
  /** Correlates the send with the persisted message row. */
  messageId: string;
}

export interface OutgoingMediaMessage extends OutgoingMessage {
  attachment: NormalizedAttachment;
}

export interface SendResult {
  ok: boolean;
  externalMessageId?: string;
  /** Present when ok is false. Surfaced on the message row, not swallowed. */
  error?: string;
  /** True when a retry could plausibly succeed (timeouts, 5xx, rate limits). */
  retryable?: boolean;
}

export interface ExternalConversation {
  externalUserId: string;
  externalConversationId?: string;
}

/**
 * What a channel can actually do (plan §8).
 *
 * The four supported platforms are not interchangeable: session-message
 * windows, media support, read receipts and length limits all differ. The
 * UI and the outbound path ask before acting instead of assuming parity,
 * and degrade with a clear message when something is unsupported.
 */
export interface ConnectorCapabilities {
  channel: ChannelType;
  sendText: boolean;
  sendMedia: boolean;
  markAsRead: boolean;
  editMessage: boolean;
  deleteMessage: boolean;
  /** e.g. WhatsApp's 24-hour customer-service window. null = no limit. */
  sessionWindowHours: number | null;
  /** Outside the session window, only pre-approved templates may be sent. */
  requiresTemplateOutsideSession: boolean;
  maxTextLength: number;
  supportedAttachmentTypes: NormalizedAttachment['type'][];
  verifiesWebhookSignature: boolean;
}

export interface MessagingConnector {
  readonly channel: ChannelType;
  /** Identifies the ChannelConnection row this instance was built from. */
  readonly connectionId: string;

  capabilities(): ConnectorCapabilities;
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  verifyWebhook(request: unknown): Promise<boolean>;
  receiveWebhook(payload: unknown): Promise<NormalizedIncomingMessage[]>;
  sendText(message: OutgoingMessage): Promise<SendResult>;
  sendMedia?(message: OutgoingMediaMessage): Promise<SendResult>;
  markAsRead?(conversation: ExternalConversation): Promise<void>;
}

export class UnsupportedCapabilityError extends Error {
  readonly code = 'UNSUPPORTED_CAPABILITY' as const;

  constructor(
    readonly channel: ChannelType,
    readonly capability: keyof ConnectorCapabilities,
  ) {
    super(`${channel} does not support ${String(capability)}`);
    this.name = 'UnsupportedCapabilityError';
  }
}

/**
 * Guard used before an outbound action. Returns the reason rather than
 * throwing when the caller wants to degrade gracefully instead of failing.
 */
export function checkOutboundText(
  capabilities: ConnectorCapabilities,
  text: string,
): { ok: true } | { ok: false; reason: string } {
  if (!capabilities.sendText) {
    return { ok: false, reason: `${capabilities.channel} cannot send text messages` };
  }
  if (text.length > capabilities.maxTextLength) {
    return {
      ok: false,
      reason: `Message is ${text.length} characters; ${capabilities.channel} allows ${capabilities.maxTextLength}`,
    };
  }
  return { ok: true };
}
