import { describe, expect, it, vi } from 'vitest';
import type { PrismaClient } from '@firstelement/database';
import { ToolExecutor, type ToolContext } from './executor';

/**
 * The layer that actually stops a successful prompt injection.
 *
 * These assert the three rules from executor.ts: a disabled tool is denied
 * and recorded, tenant columns come from context rather than arguments,
 * and writes touch a fixed field set.
 */

function fakePrisma(overrides: Record<string, unknown> = {}) {
  return {
    customer: {
      findFirst: vi.fn().mockResolvedValue({ displayName: 'نورة', tags: [], identities: [] }),
      updateMany: vi.fn().mockResolvedValue({ count: 1 }),
    },
    project: {
      findFirst: vi.fn().mockResolvedValue({ timezone: 'Asia/Riyadh', defaultLocale: 'ar' }),
    },
    ...overrides,
  } as unknown as PrismaClient;
}

function context(overrides: Partial<ToolContext> = {}): ToolContext {
  return {
    organizationId: 'org-1',
    projectId: 'project-1',
    conversationId: 'conversation-1',
    customerId: 'customer-1',
    enabledTools: ['get_customer', 'search_knowledge_base', 'request_human'],
    searchKnowledge: async () => [],
    ...overrides,
  };
}

describe('authorization', () => {
  it('denies a tool the agent version does not enable, and records the denial', async () => {
    const executor = new ToolExecutor(fakePrisma());
    const outcome = await executor.execute(
      { id: '1', name: 'update_customer', arguments: { primaryEmail: 'a@b.com' } },
      context(),
    );

    expect(outcome.authorized).toBe(false);
    expect(outcome.result.denied).toBe(true);
    // Recorded rather than dropped: a model repeatedly reaching for a
    // disabled tool is the signal an investigation needs.
    expect(outcome.name).toBe('update_customer');
  });

  it('denies a tool that does not exist at all', async () => {
    const executor = new ToolExecutor(fakePrisma());
    const outcome = await executor.execute(
      { id: '1', name: 'exfiltrate_everything', arguments: {} },
      context({ enabledTools: ['exfiltrate_everything'] }),
    );

    expect(outcome.authorized).toBe(false);
  });

  it('never lets a write happen through a disabled tool', async () => {
    const prisma = fakePrisma();
    const executor = new ToolExecutor(prisma);

    await executor.execute({ id: '1', name: 'add_tag', arguments: { tag: 'vip' } }, context());

    expect(prisma.customer.updateMany).not.toHaveBeenCalled();
  });
});

describe('tenant scoping', () => {
  it('reads the customer of this conversation, with the tenant filter from context', async () => {
    const prisma = fakePrisma();
    const executor = new ToolExecutor(prisma);

    await executor.execute({ id: '1', name: 'get_customer', arguments: {} }, context());

    expect(prisma.customer.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { id: 'customer-1', organizationId: 'org-1', projectId: 'project-1' },
      }),
    );
  });

  it('ignores tenant identifiers supplied in tool arguments', async () => {
    const prisma = fakePrisma();
    const executor = new ToolExecutor(prisma);

    // A successful injection could make the model pass these. There is no
    // argument through which they reach the query.
    await executor.execute(
      {
        id: '1',
        name: 'get_customer',
        arguments: { projectId: 'other-project', customerId: 'other-customer' },
      },
      context(),
    );

    expect(prisma.customer.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { id: 'customer-1', organizationId: 'org-1', projectId: 'project-1' },
      }),
    );
  });
});

describe('write tools', () => {
  const enabled = ['update_customer', 'add_tag'];

  it('updates only the whitelisted contact fields', async () => {
    const prisma = fakePrisma();
    const executor = new ToolExecutor(prisma);

    await executor.execute(
      {
        id: '1',
        name: 'update_customer',
        arguments: {
          primaryEmail: 'Customer@Example.com',
          tags: ['vip'],
          projectId: 'other-project',
          notes: 'injected',
        },
      },
      context({ enabledTools: enabled }),
    );

    expect(prisma.customer.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({ data: { primaryEmail: 'customer@example.com' } }),
    );
  });

  it('rejects a malformed email instead of writing it', async () => {
    const prisma = fakePrisma();
    const executor = new ToolExecutor(prisma);

    const outcome = await executor.execute(
      { id: '1', name: 'update_customer', arguments: { primaryEmail: 'not-an-email' } },
      context({ enabledTools: enabled }),
    );

    expect(outcome.result.updated).toBe(false);
    expect(prisma.customer.updateMany).not.toHaveBeenCalled();
  });

  it('does not duplicate an existing tag', async () => {
    const prisma = fakePrisma({
      customer: {
        findFirst: vi.fn().mockResolvedValue({ tags: ['vip'] }),
        updateMany: vi.fn(),
      },
    });
    const executor = new ToolExecutor(prisma);

    const outcome = await executor.execute(
      { id: '1', name: 'add_tag', arguments: { tag: 'vip' } },
      context({ enabledTools: enabled }),
    );

    expect(outcome.result.added).toBe(false);
    expect(prisma.customer.updateMany).not.toHaveBeenCalled();
  });
});

describe('knowledge and handover', () => {
  it('tells the model plainly when the knowledge base has nothing', async () => {
    const executor = new ToolExecutor(fakePrisma());
    const outcome = await executor.execute(
      { id: '1', name: 'search_knowledge_base', arguments: { query: 'refunds' } },
      context(),
    );

    expect(outcome.result.found).toBe(false);
    expect(outcome.result.results).toEqual([]);
  });

  it('flags a human handover for the orchestrator rather than changing mode itself', async () => {
    const executor = new ToolExecutor(fakePrisma());
    const outcome = await executor.execute(
      { id: '1', name: 'request_human', arguments: { reason: 'Customer asked for a person' } },
      context(),
    );

    expect(outcome.requestsHuman).toBe(true);
    expect(outcome.result.acknowledged).toBe(true);
  });

  it('reports an unbacked tool honestly instead of inventing data', async () => {
    const executor = new ToolExecutor(fakePrisma());
    const outcome = await executor.execute(
      { id: '1', name: 'get_customer_orders', arguments: { limit: 5 } },
      context({ enabledTools: ['get_customer_orders'] }),
    );

    expect(outcome.result.available).toBe(false);
    expect(String(outcome.result.reason)).toContain('not connected');
  });
});
