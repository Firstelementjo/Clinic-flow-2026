import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useEffect, useRef, useState } from 'react';
import {
  Bot,
  CalendarClock,
  CalendarDays,
  ChevronDown,
  Inbox,
  Languages,
  LayoutDashboard,
  LogOut,
  Moon,
  Settings,
  SquareCheck,
  StickyNote,
  Sun,
  Stethoscope,
  UserCog,
  Users,
  type LucideIcon,
} from 'lucide-react';
import { StatusChip } from '@firstelement/ui';
import type { SessionUser } from '@firstelement/shared';
import { useT, type StringKey } from '../lib/i18n';
import { useLocale } from '../lib/locale';
import { useTheme } from '../lib/theme';
import { useLogout } from '../lib/session';
import { NotificationBell } from '../components/NotificationBell';
import { AgentStatusControl } from '../components/AgentStatusControl';
import { FloatingInboxProvider } from '../components/FloatingInbox';

const NAV: { to: string; key: StringKey; icon: LucideIcon }[] = [
  { to: '/app/dashboard', key: 'nav.dashboard', icon: LayoutDashboard },
  { to: '/app/inbox', key: 'nav.inbox', icon: Inbox },
  { to: '/app/appointments', key: 'nav.appointments', icon: CalendarDays },
  { to: '/app/doctors', key: 'nav.doctors', icon: Stethoscope },
  { to: '/app/ai-receptionist', key: 'nav.aiReceptionist', icon: Bot },
  { to: '/app/people', key: 'nav.people', icon: Users },
  { to: '/app/follow-ups', key: 'nav.followUps', icon: CalendarClock },
  { to: '/app/tasks', key: 'nav.tasks', icon: SquareCheck },
  { to: '/app/notes', key: 'nav.notes', icon: StickyNote },
  { to: '/app/team', key: 'nav.team', icon: UserCog },
];

function HeaderControls() {
  const { theme, toggle } = useTheme();
  const { locale, setLocale } = useLocale();

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={toggle}
        className="flex items-center justify-center h-8 w-8 rounded-lg border border-[var(--fe-hairline)] bg-[var(--fe-surface)] text-[var(--fe-slate)] hover:text-[var(--fe-ink)] hover:border-[var(--fe-signal)] transition-colors"
        title="Toggle Theme"
      >
        {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
      </button>
      <button
        onClick={() => setLocale(locale === 'en' ? 'ar' : 'en')}
        className="flex items-center justify-center h-8 w-8 rounded-lg border border-[var(--fe-hairline)] bg-[var(--fe-surface)] text-[var(--fe-slate)] hover:text-[var(--fe-ink)] hover:border-[var(--fe-signal)] transition-colors font-medium text-xs"
        title="Change Language"
      >
        {locale === 'en' ? 'ع' : 'EN'}
      </button>
    </div>
  );
}

const SHORTCUTS: { key: string; to: string; labelKey: StringKey; icon: LucideIcon }[] = [
  { key: 'd', to: '/app/dashboard', labelKey: 'nav.dashboard', icon: LayoutDashboard },
  { key: 'a', to: '/app/appointments', labelKey: 'nav.appointments', icon: CalendarDays },
  { key: 'p', to: '/app/people', labelKey: 'nav.people', icon: Users },
  { key: 'f', to: '/app/follow-ups', labelKey: 'nav.followUps', icon: CalendarClock },
  { key: 't', to: '/app/tasks', labelKey: 'nav.tasks', icon: SquareCheck },
  { key: 'n', to: '/app/notes', labelKey: 'nav.notes', icon: StickyNote },
];

const CREATE_SHORTCUTS: { key: string; to: string; label: string; icon: LucideIcon }[] = [
  { key: 'a', to: '/app/appointments?new=1', label: 'Book new Appointment', icon: CalendarDays },
  { key: 'f', to: '/app/follow-ups?new=1', label: 'Make new Follow-up', icon: CalendarClock },
  { key: 't', to: '/app/tasks?new=1', label: 'Make new Task', icon: SquareCheck },
  { key: 'n', to: '/app/notes?new=1', label: 'Make new Note', icon: StickyNote },
];

export function AppShell({ user }: { user: SessionUser }) {
  const t = useT();
  const logout = useLogout();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [pending, setPending] = useState<'g' | 'n' | null>(null);

  const current = NAV.find(
    (item) => pathname === item.to || pathname.startsWith(`${item.to}/`),
  );

  // G then <letter> → Go to, N then <letter> → Make new
  useEffect(() => {
    let timer: number | undefined;
    const isTypingTarget = () => {
      const el = document.activeElement as HTMLElement | null;
      if (!el) return false;
      const tag = el.tagName;
      return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el.isContentEditable;
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (isTypingTarget()) return;
      const k = e.key.toLowerCase();
      if (!pending) {
        if (k === 'g' || k === 'n') {
          e.preventDefault();
          setPending(k as 'g' | 'n');
          window.clearTimeout(timer);
          timer = window.setTimeout(() => setPending(null), 2000);
        }
        return;
      }
      window.clearTimeout(timer);
      const prev = pending;
      setPending(null);
      if (k === 'escape') return;
      if (k === 'g' || k === 'n') {
        setPending(k as 'g' | 'n');
        timer = window.setTimeout(() => setPending(null), 2000);
        return;
      }
      if (prev === 'g') {
        const hit = SHORTCUTS.find((s) => s.key === k);
        if (hit) {
          e.preventDefault();
          navigate(hit.to);
        }
      } else if (prev === 'n') {
        const hit = CREATE_SHORTCUTS.find((s) => s.key === k);
        if (hit) {
          e.preventDefault();
          navigate(hit.to);
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.clearTimeout(timer);
    };
  }, [pending, navigate]);

  return (
    <FloatingInboxProvider>
      <div className="flex min-h-full bg-[var(--fe-mist)]">
        {/* Dark wayfinding rail. The queue lives on the light surface to its
            side, so colour splits navigation (dark) from work (light). */}
        <aside className="flex w-60 shrink-0 flex-col border-0 bg-[var(--fe-surface)] border-e border-[var(--fe-hairline)] z-10">
          <div className="flex h-16 shrink-0 items-center border-b border-[var(--fe-hairline)] brand">
            <div className="logo">FE</div>
            Clinic Flow
          </div>

          <nav className="flex flex-1 flex-col gap-1 overflow-y-auto px-3 py-4">
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  [
                    'flex items-center gap-3 rounded-lg px-2.5 py-2.5 text-sm transition-colors',
                    isActive
                      ? 'bg-[var(--fe-signal-wash)] text-[var(--fe-signal)] font-semibold shadow-[inset_3px_0_0_var(--fe-signal)] rtl:shadow-[inset_-3px_0_0_var(--fe-signal)]'
                      : 'text-[var(--fe-slate)] hover:bg-[var(--fe-surf2)] hover:text-[var(--fe-ink)]',
                  ].join(' ')
                }
              >
                <item.icon aria-hidden="true" className="h-4 w-4 shrink-0" strokeWidth={1.75} />
                {t(item.key)}
              </NavLink>
            ))}
          </nav>

          <div className="border-t border-[var(--fe-hairline)] p-3">
            <div className="flex items-center gap-3 py-1">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[var(--fe-agent-wash)] text-[var(--fe-agent)] text-xs font-semibold">
                {user.fullName
                  .split(' ')
                  .map((n) => n[0])
                  .slice(0, 2)
                  .join('')}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-[var(--fe-ink)]">{user.fullName}</p>
                <StatusChip className="mt-1" tone={user.role === 'ADMIN' ? 'human' : 'neutral'}>
                  {t(`common.role.${user.role}` as StringKey)}
                </StatusChip>
              </div>
            </div>

            <div className="mt-1 border-t border-hairline pt-2">
              <button
                type="button"
                disabled={logout.isPending}
                onClick={() => logout.mutate()}
                className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-xs font-medium text-nav-muted transition-colors hover:bg-danger-wash hover:text-danger disabled:cursor-not-allowed disabled:opacity-55"
              >
                {logout.isPending ? (
                  <span className="fe-spinner" aria-hidden="true" />
                ) : (
                  <LogOut aria-hidden="true" className="h-4 w-4" />
                )}
                {t('nav.signOut')}
              </button>
            </div>
          </div>
        </aside>

        {/* Light working surface. */}
        <div className="flex min-w-0 flex-1 flex-col relative z-0">
          <header className="flex h-16 shrink-0 items-center gap-4 border-b border-[var(--fe-hairline)] bg-[var(--fe-surface)] px-6">
            {current ? (
              <h1 className="fe-display truncate text-xl font-bold text-[var(--fe-ink)]">{t(current.key)}</h1>
            ) : null}
            <div className="ms-auto flex items-center gap-3">
              <HeaderControls />
              <NotificationBell />
            </div>
          </header>

          <main className="flex-1 overflow-y-auto px-6 py-6 scroll-smooth">
            <div className="w-full">
              <Outlet />
            </div>
          </main>
        </div>
      </div>

      {/* G / N shortcut overlays */}
      {pending && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={() => setPending(null)}>
          <div
            className="w-full max-w-[420px] rounded-xl border border-white/10 bg-[#0e1015] p-2 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-label="Shortcuts"
          >
            {(pending === 'g' ? SHORTCUTS : CREATE_SHORTCUTS).map((s) => (
              <div
                key={s.key}
                className="flex items-center justify-between gap-4 rounded-lg px-3 py-2.5 transition-colors hover:bg-white/[0.06]"
              >
                <span className="flex items-center gap-3 text-sm text-white">
                  <span className="flex h-7 w-7 items-center justify-center rounded-md bg-white/[0.08] text-white">
                    <s.icon aria-hidden="true" className="h-4 w-4" />
                  </span>
                  {'labelKey' in s ? `Go to ${t((s as typeof SHORTCUTS[number]).labelKey)}` : (s as typeof CREATE_SHORTCUTS[number]).label}
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="flex h-6 min-w-6 items-center justify-center rounded-md border border-white/15 bg-white/[0.08] px-1.5 text-xs font-medium text-white">
                    {pending.toUpperCase()}
                  </span>
                  <span className="text-xs text-white/40">then</span>
                  <span className="flex h-6 min-w-6 items-center justify-center rounded-md border border-white/15 bg-white/[0.08] px-1.5 text-xs font-medium text-white">
                    {s.key.toUpperCase()}
                  </span>
                </span>
              </div>
            ))}
            <p className="px-3 pb-1 pt-2 text-center text-xs text-white/40">Press second key or Esc to close</p>
          </div>
        </div>
      )}
    </FloatingInboxProvider>
  );
}
