import {
  EMBEDDING_DIMENSIONS,
  EmbeddingProviderError,
  assertEmbeddingShape,
  l2Normalize,
  type EmbeddingProvider,
} from './types';

interface OpenAIEmbeddingResponse {
  data: { index: number; embedding: number[] }[];
}

/**
 * OpenAI embeddings via the REST API — no SDK, because the surface used
 * here is one endpoint and a vendor SDK would be the widest dependency in
 * the tree for it.
 *
 * `text-embedding-3-small` at 1536 dimensions matches the pgvector column
 * exactly; changing the model means changing the column and re-embedding
 * every chunk, so the dimension is asserted rather than assumed.
 */
export class OpenAIEmbeddingProvider implements EmbeddingProvider {
  readonly name = 'openai';
  readonly dimensions = EMBEDDING_DIMENSIONS;

  constructor(
    private readonly apiKey: string,
    readonly model = 'text-embedding-3-small',
    private readonly baseUrl = 'https://api.openai.com/v1',
    private readonly timeoutMs = 30_000,
  ) {}

  async embed(texts: string[]): Promise<number[][]> {
    if (texts.length === 0) return [];

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await fetch(`${this.baseUrl}/embeddings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: this.model,
          input: texts,
          dimensions: this.dimensions,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const body = await response.text().catch(() => '');
        throw new EmbeddingProviderError(
          this.name,
          `OpenAI embeddings failed (${response.status}): ${body.slice(0, 200)}`,
          // 4xx other than rate limiting will fail identically on retry.
          response.status === 429 || response.status >= 500,
        );
      }

      const payload = (await response.json()) as OpenAIEmbeddingResponse;
      // The API does not guarantee response order matches input order.
      const ordered = [...payload.data].sort((a, b) => a.index - b.index);
      const vectors = ordered.map((item) => l2Normalize(item.embedding));

      assertEmbeddingShape(this.name, vectors, texts.length, this.dimensions);
      return vectors;
    } catch (error) {
      if (error instanceof EmbeddingProviderError) throw error;
      if (error instanceof Error && error.name === 'AbortError') {
        throw new EmbeddingProviderError(this.name, 'OpenAI embeddings timed out', true);
      }
      throw new EmbeddingProviderError(
        this.name,
        error instanceof Error ? error.message : String(error),
        true,
      );
    } finally {
      clearTimeout(timeout);
    }
  }
}
