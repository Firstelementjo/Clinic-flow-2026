import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import {
  accessibleProjectsScope,
  projectScope,
  type TenantContext,
} from '@firstelement/database';
import { DomainEventType } from '@firstelement/events';
import { recountActiveConversations } from '@firstelement/routing';
import {
  AuditAction,
  ConversationStatus,
  ErrorCode,
  MessageAuthorType,
  MessageDirection,
  type AssignConversationInput,
  type ConversationDetail,
  type ConversationSummary,
  type InboxQuery,
  type SendMessageInput,
  type UpdateConversationInput,
} from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';
import { DomainEventBus } from '../events/domain-event-bus';
import { MessageQueueService } from '../messaging/message-queue.service';
import { buildInboxWhere } from './inbox-filter';

const SUMMARY_SELECT = {
  id: true,
  projectId: true,
  ticketNumber: true,
  channel: true,
  status: true,
  mode: true,
  priority: true,
  subject: true,
  messageCount: true,
  lastMessageAt: true,
  project: { select: { name: true } },
  customer: { select: { id: true, cxId: true, displayName: true } },
  assignedEmployee: { select: { id: true, user: { select: { fullName: true } } } },
  messages: {
    select: { body: true },
    orderBy: { sentAt: 'desc' },
    take: 1,
  },
} as const;

@Injectable()
export class ConversationsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: DomainEventBus,
    private readonly queue: MessageQueueService,
  ) {}

  async inbox(
    ctx: TenantContext,
    query: InboxQuery,
  ): Promise<{ items: ConversationSummary[]; nextCursor: string | null }> {
    const scope = query.projectId
      ? projectScope(ctx, query.projectId)
      : accessibleProjectsScope(ctx);

    const rows = await this.prisma.client.conversation.findMany({
      where: {
        ...scope,
        ...buildInboxWhere({
          filter: query.filter,
          userId: ctx.userId,
          channel: query.channel,
          search: query.search,
        }),
      },
      select: SUMMARY_SELECT,
      orderBy: [{ lastMessageAt: 'desc' }, { id: 'desc' }],
      take: query.limit + 1,
      ...(query.cursor ? { cursor: { id: query.cursor }, skip: 1 } : {}),
    });

    const hasMore = rows.length > query.limit;
    const page = hasMore ? rows.slice(0, query.limit) : rows;

    return {
      items: page.map((row) => this.toSummary(row)),
      nextCursor: hasMore ? (page[page.length - 1]?.id ?? null) : null,
    };
  }

  async getById(ctx: TenantContext, conversationId: string): Promise<ConversationDetail> {
    const conversation = await this.prisma.client.conversation.findFirst({
      where: { id: conversationId, ...accessibleProjectsScope(ctx) },
      select: {
        ...SUMMARY_SELECT,
        messages: {
          select: {
            id: true,
            direction: true,
            authorType: true,
            body: true,
            deliveryStatus: true,
            failureReason: true,
            sentAt: true,
            author: { select: { fullName: true } },
          },
          orderBy: { sentAt: 'asc' },
          take: 300,
        },
        events: {
          select: {
            id: true,
            type: true,
            actorType: true,
            actorUserId: true,
            payload: true,
            occurredAt: true,
          },
          orderBy: { occurredAt: 'asc' },
          take: 300,
        },
      },
    });

    if (!conversation) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Conversation not found' });
    }

    const messages = conversation.messages;
    const lastMessage = messages[messages.length - 1];

    return {
      ...this.toSummary({ ...conversation, messages: lastMessage ? [{ body: lastMessage.body }] : [] }),
      messages: messages.map((message) => ({
        id: message.id,
        direction: message.direction,
        authorType: message.authorType,
        authorName: message.author?.fullName ?? null,
        body: message.body,
        deliveryStatus: message.deliveryStatus,
        failureReason: message.failureReason,
        sentAt: message.sentAt.toISOString(),
      })),
      events: conversation.events.map((event) => ({
        id: event.id,
        type: event.type,
        actorType: event.actorType,
        actorName: null,
        payload: (event.payload ?? {}) as Record<string, unknown>,
        occurredAt: event.occurredAt.toISOString(),
      })),
    };
  }

  /**
   * An employee's reply.
   *
   * The message row and the conversation counters move together in one
   * transaction — a thread that shows a reply but whose `lastMessageAt`
   * did not move sorts to the bottom of the inbox and is effectively lost.
   *
   * The row is written first and queued for delivery second: a send that
   * succeeds while the write fails would leave the customer holding a
   * reply the CRM has no record of. The message therefore starts PENDING
   * and the dispatcher moves it to SENT or FAILED.
   */
  async reply(
    ctx: TenantContext,
    conversationId: string,
    input: SendMessageInput,
    ipAddress?: string,
  ) {
    const conversation = await this.loadForWrite(ctx, conversationId);

    const now = new Date();
    const message = await this.prisma.client.$transaction(async (tx) => {
      const created = await tx.message.create({
        data: {
          organizationId: ctx.organizationId,
          projectId: conversation.projectId,
          conversationId,
          channel: conversation.channel,
          direction: MessageDirection.OUTBOUND,
          authorType: MessageAuthorType.EMPLOYEE,
          authorUserId: ctx.userId,
          body: input.body,
          deliveryStatus: 'PENDING',
          sentAt: now,
        },
        select: { id: true, sentAt: true },
      });

      await tx.conversation.update({
        where: { id: conversationId },
        data: {
          lastMessageAt: now,
          messageCount: { increment: 1 },
          lastReplierUserId: ctx.userId,
          // First human response time is a metric an ops manager is
          // measured on; capture it at the moment it happens or never.
          firstResponseAt: conversation.firstResponseAt ?? now,
          status:
            conversation.status === ConversationStatus.RESOLVED ||
            conversation.status === ConversationStatus.CLOSED
              ? ConversationStatus.OPEN
              : conversation.status,
        },
      });

      return created;
    });

    // Delivery happens off the request: the agent's UI should not wait on
    // a platform API, and a failed send must be retryable (plan §11).
    await this.queue.enqueueOutbound({
      organizationId: ctx.organizationId,
      projectId: conversation.projectId,
      conversationId,
      messageId: message.id,
    });

    this.events.publish({
      type: DomainEventType.MESSAGE_CREATED,
      organizationId: ctx.organizationId,
      projectId: conversation.projectId,
      aggregateId: message.id,
      aggregateType: 'Message',
      actorUserId: ctx.userId,
      payload: {
        conversationId,
        customerId: conversation.customerId,
        channel: conversation.channel,
        direction: MessageDirection.OUTBOUND,
        authorType: MessageAuthorType.EMPLOYEE,
        bodyLength: input.body.length,
      },
      occurredAt: now,
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId: conversation.projectId,
      actorUserId: ctx.userId,
      action: AuditAction.EMPLOYEE_REPLIED,
      resourceType: 'Conversation',
      resourceId: conversationId,
      metadata: { messageId: message.id },
      ipAddress,
    });

    return this.getById(ctx, conversationId);
  }

  async assign(
    ctx: TenantContext,
    conversationId: string,
    input: AssignConversationInput,
    ipAddress?: string,
  ) {
    const conversation = await this.loadForWrite(ctx, conversationId);

    if (input.employeeId) {
      // An assignee must belong to this organization and this project —
      // an id alone proves neither.
      const eligible = await this.prisma.client.employee.findFirst({
        where: {
          id: input.employeeId,
          organizationId: ctx.organizationId,
          user: { memberships: { some: { projectId: conversation.projectId } } },
        },
        select: {
          id: true,
          activeConversationCount: true,
          maxConcurrentConversations: true,
        },
      });
      if (!eligible) {
        throw new BadRequestException({
          code: ErrorCode.VALIDATION_FAILED,
          message: 'That employee is not a member of this project',
        });
      }

      // Enforce per-agent conversation limit: skip the check if this is
      // a reassignment to the same employee (a no-op from the load
      // perspective) or if the agent still has capacity.
      if (
        input.employeeId !== conversation.assignedEmployeeId &&
        eligible.activeConversationCount >= eligible.maxConcurrentConversations
      ) {
        throw new BadRequestException({
          code: ErrorCode.VALIDATION_FAILED,
          message: 'That agent has reached their conversation limit',
        });
      }
    }

    await this.prisma.client.conversation.update({
      where: { id: conversationId },
      data: { assignedEmployeeId: input.employeeId },
    });

    // Both sides of a manual reassignment need their workload refreshed,
    // or routing will keep believing the previous owner is busy.
    for (const employeeId of [conversation.assignedEmployeeId, input.employeeId]) {
      if (employeeId) await recountActiveConversations(this.prisma.client, employeeId);
    }

    this.events.publish({
      type: DomainEventType.CONVERSATION_ASSIGNED,
      organizationId: ctx.organizationId,
      projectId: conversation.projectId,
      aggregateId: conversationId,
      aggregateType: 'Conversation',
      actorUserId: ctx.userId,
      payload: {
        employeeId: input.employeeId,
        previousEmployeeId: conversation.assignedEmployeeId,
        reason: 'MANUAL',
      },
      occurredAt: new Date(),
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId: conversation.projectId,
      actorUserId: ctx.userId,
      action: AuditAction.EMPLOYEE_ASSIGNED_CONVERSATION,
      resourceType: 'Conversation',
      resourceId: conversationId,
      metadata: { employeeId: input.employeeId },
      ipAddress,
    });

    return this.getById(ctx, conversationId);
  }

  async update(
    ctx: TenantContext,
    conversationId: string,
    input: UpdateConversationInput,
    ipAddress?: string,
  ) {
    const conversation = await this.loadForWrite(ctx, conversationId);
    const now = new Date();
    const isResolving =
      input.status === ConversationStatus.RESOLVED &&
      conversation.status !== ConversationStatus.RESOLVED;

    await this.prisma.client.conversation.update({
      where: { id: conversationId },
      data: {
        ...input,
        ...(isResolving ? { resolvedAt: now } : {}),
        ...(input.status === ConversationStatus.CLOSED ? { closedAt: now } : {}),
      },
    });

    // Workload drives routing, so it must not drift when a conversation
    // moves between active/inactive states. Recounting beats decrementing:
    // a counter that misses one write starves an agent forever (see packages/routing).
    if (conversation.assignedEmployeeId && input.status !== undefined && input.status !== conversation.status) {
      await recountActiveConversations(this.prisma.client, conversation.assignedEmployeeId);
    }

    if (isResolving) {
      this.events.publish({
        type: DomainEventType.CONVERSATION_RESOLVED,
        organizationId: ctx.organizationId,
        projectId: conversation.projectId,
        aggregateId: conversationId,
        aggregateType: 'Conversation',
        actorUserId: ctx.userId,
        payload: { resolvedBy: MessageAuthorType.EMPLOYEE, messageCount: conversation.messageCount },
        occurredAt: now,
      });

      await this.audit.record({
        organizationId: ctx.organizationId,
        projectId: conversation.projectId,
        actorUserId: ctx.userId,
        action: AuditAction.EMPLOYEE_RESOLVED_CONVERSATION,
        resourceType: 'Conversation',
        resourceId: conversationId,
        ipAddress,
      });
    } else {
      this.events.publish({
        type: DomainEventType.CONVERSATION_UPDATED,
        organizationId: ctx.organizationId,
        projectId: conversation.projectId,
        aggregateId: conversationId,
        aggregateType: 'Conversation',
        actorUserId: ctx.userId,
        payload: {
          status: input.status,
          priority: input.priority,
          previousStatus: conversation.status,
        },
        occurredAt: now,
      });
    }

    return this.getById(ctx, conversationId);
  }

  async closeAndUnassign(ctx: TenantContext, conversationId: string, ipAddress?: string) {
    const conversation = await this.loadForWrite(ctx, conversationId);
    const now = new Date();
    const wasAssigned = conversation.assignedEmployeeId;

    await this.prisma.client.conversation.update({
      where: { id: conversationId },
      data: {
        status: 'RESOLVED',
        resolvedAt: now,
        assignedEmployeeId: null,
        lastReplierUserId: ctx.userId,
      },
    });

    if (wasAssigned) {
      await recountActiveConversations(this.prisma.client, wasAssigned);
    }

    this.events.publish({
      type: DomainEventType.CONVERSATION_RESOLVED,
      organizationId: ctx.organizationId,
      projectId: conversation.projectId,
      aggregateId: conversationId,
      aggregateType: 'Conversation',
      actorUserId: ctx.userId,
      payload: { resolvedBy: MessageAuthorType.EMPLOYEE, messageCount: conversation.messageCount },
      occurredAt: now,
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId: conversation.projectId,
      actorUserId: ctx.userId,
      action: AuditAction.EMPLOYEE_RESOLVED_CONVERSATION,
      resourceType: 'Conversation',
      resourceId: conversationId,
      ipAddress,
    });

    return this.getById(ctx, conversationId);
  }

  /**
   * Loads a conversation for mutation and, in the same step, proves the
   * caller may write to its project. Every write path goes through here so
   * none of them can forget.
   */
  private async loadForWrite(ctx: TenantContext, conversationId: string) {
    const conversation = await this.prisma.client.conversation.findFirst({
      where: { id: conversationId, ...accessibleProjectsScope(ctx) },
      select: {
        id: true,
        projectId: true,
        customerId: true,
        channel: true,
        status: true,
        mode: true,
        messageCount: true,
        firstResponseAt: true,
        assignedEmployeeId: true,
      },
    });

    if (!conversation) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Conversation not found' });
    }

    projectScope(ctx, conversation.projectId);
    return conversation;
  }

  private toSummary(row: {
    id: string;
    projectId: string;
    ticketNumber: string;
    channel: ConversationSummary['channel'];
    status: ConversationSummary['status'];
    mode: ConversationSummary['mode'];
    priority: ConversationSummary['priority'];
    subject: string | null;
    messageCount: number;
    lastMessageAt: Date;
    project: { name: string };
    customer: { id: string; cxId: string; displayName: string };
    assignedEmployee: { id: string; user: { fullName: string } } | null;
    messages: { body: string }[];
  }): ConversationSummary {
    const preview = row.messages[0]?.body ?? null;
    return {
      id: row.id,
      projectId: row.projectId,
      projectName: row.project.name,
      ticketNumber: row.ticketNumber,
      channel: row.channel,
      status: row.status,
      mode: row.mode,
      priority: row.priority,
      subject: row.subject,
      customer: row.customer,
      assignedEmployee: row.assignedEmployee
        ? { id: row.assignedEmployee.id, fullName: row.assignedEmployee.user.fullName }
        : null,
      lastMessagePreview: preview && preview.length > 140 ? `${preview.slice(0, 140)}…` : preview,
      messageCount: row.messageCount,
      lastMessageAt: row.lastMessageAt.toISOString(),
    };
  }
}
