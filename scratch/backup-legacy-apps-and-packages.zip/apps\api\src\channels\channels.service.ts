import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { encryptJson } from '@firstelement/auth';
import { getConfig } from '@firstelement/config';
import { ChannelType as ChannelTypeEnum } from '@firstelement/shared';
import { capabilitiesFor } from '@firstelement/connectors';
import { projectScope, type TenantContext } from '@firstelement/database';
import {
  AuditAction,
  ErrorCode,
  type ChannelConnectionView,
  type CreateChannelConnectionInput,
  type UpdateChannelConnectionInput,
} from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';

/** Every channel now has an adapter (slice 8). */
const IMPLEMENTED_CHANNELS: ReadonlySet<string> = new Set([
  ChannelTypeEnum.MOCK,
  ChannelTypeEnum.WHATSAPP,
  ChannelTypeEnum.INSTAGRAM,
  ChannelTypeEnum.MESSENGER,
  ChannelTypeEnum.TELEGRAM,
]);

/**
 * The credential fields each channel needs. Used to validate before
 * storing, so a half-configured channel fails at the form rather than at
 * the first customer message.
 */
const REQUIRED_CREDENTIALS: Record<string, string[]> = {
  [ChannelTypeEnum.WHATSAPP]: ['phoneNumberId', 'accessToken', 'appSecret', 'verifyToken'],
  [ChannelTypeEnum.INSTAGRAM]: ['pageId', 'pageAccessToken', 'appSecret', 'verifyToken'],
  [ChannelTypeEnum.MESSENGER]: ['pageId', 'pageAccessToken', 'appSecret', 'verifyToken'],
  [ChannelTypeEnum.TELEGRAM]: ['botToken', 'webhookSecret'],
  [ChannelTypeEnum.MOCK]: [],
};

/**
 * Channel connections (plan §14: "never shows secrets").
 *
 * Every read goes through `toView`, which is the only mapping from row to
 * response. Credentials and webhook secrets are not selected at all — not
 * selected-and-stripped — so a future field cannot leak by being forgotten
 * in a `select`.
 */
@Injectable()
export class ChannelsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  async list(ctx: TenantContext, projectId: string): Promise<ChannelConnectionView[]> {
    const rows = await this.prisma.client.channelConnection.findMany({
      where: projectScope(ctx, projectId),
      select: this.publicSelect(),
      orderBy: { createdAt: 'asc' },
    });

    return rows.map((row) => this.toView(row));
  }

  async create(
    ctx: TenantContext,
    projectId: string,
    input: CreateChannelConnectionInput,
    ipAddress?: string,
  ): Promise<ChannelConnectionView> {
    const scope = projectScope(ctx, projectId);

    const existing = await this.prisma.client.channelConnection.findUnique({
      where: { projectId_channel: { projectId, channel: input.channel } },
      select: { id: true },
    });
    if (existing) {
      throw new ConflictException({
        code: ErrorCode.CONFLICT,
        message: `This project already has a ${input.channel} connection`,
      });
    }

    const created = await this.prisma.client.channelConnection.create({
      data: {
        ...scope,
        channel: input.channel,
        displayName: input.displayName,
        // The mock channel needs no credentials, so it is usable the
        // moment it is created. Real channels stay DISCONNECTED until
        // slice 8 stores and verifies their credentials.
        status: input.channel === ChannelTypeEnum.MOCK ? 'CONNECTED' : 'DISCONNECTED',
      },
      select: this.publicSelect(),
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CONNECTED_CHANNEL,
      resourceType: 'ChannelConnection',
      resourceId: created.id,
      metadata: { channel: input.channel },
      ipAddress,
    });

    return this.toView(created);
  }

  async update(
    ctx: TenantContext,
    projectId: string,
    connectionId: string,
    input: UpdateChannelConnectionInput,
    ipAddress?: string,
  ): Promise<ChannelConnectionView> {
    const scope = projectScope(ctx, projectId);

    const result = await this.prisma.client.channelConnection.updateMany({
      where: { id: connectionId, ...scope },
      data: input,
    });
    if (result.count === 0) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Channel not found' });
    }

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CONNECTED_CHANNEL,
      resourceType: 'ChannelConnection',
      resourceId: connectionId,
      metadata: { changedFields: Object.keys(input) },
      ipAddress,
    });

    const updated = await this.prisma.client.channelConnection.findFirstOrThrow({
      where: { id: connectionId, ...scope },
      select: this.publicSelect(),
    });
    return this.toView(updated);
  }

  /** Resolves the connection an inbound simulation or send should use. */
  async requireEnabled(ctx: TenantContext, projectId: string, channel: ChannelTypeEnum) {
    const connection = await this.prisma.client.channelConnection.findFirst({
      where: { ...projectScope(ctx, projectId), channel, isEnabled: true },
      select: { id: true, projectId: true, channel: true, isEnabled: true },
    });

    if (!connection) {
      throw new NotFoundException({
        code: ErrorCode.NOT_FOUND,
        message: `This project has no enabled ${channel} connection`,
      });
    }

    return connection;
  }

  /**
   * Stores connector credentials, encrypted.
   *
   * The plaintext exists only inside this method: it is validated, sealed
   * with AES-256-GCM, and written. Nothing reads it back on any response
   * path — `publicSelect` does not include the column at all, so a future
   * field cannot leak by being forgotten in a strip step.
   */
  async setCredentials(
    ctx: TenantContext,
    projectId: string,
    connectionId: string,
    credentials: Record<string, string>,
    ipAddress?: string,
  ): Promise<ChannelConnectionView> {
    const scope = projectScope(ctx, projectId);

    const connection = await this.prisma.client.channelConnection.findFirst({
      where: { id: connectionId, ...scope },
      select: { id: true, channel: true },
    });
    if (!connection) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Channel not found' });
    }

    const required = REQUIRED_CREDENTIALS[connection.channel] ?? [];
    const missing = required.filter((field) => !credentials[field]?.trim());
    if (missing.length > 0) {
      throw new ConflictException({
        code: ErrorCode.VALIDATION_FAILED,
        message: `Missing credentials for ${connection.channel}: ${missing.join(', ')}`,
      });
    }

    const trimmed = Object.fromEntries(
      required.map((field) => [field, credentials[field]!.trim()]),
    );

    await this.prisma.client.channelConnection.update({
      where: { id: connectionId },
      data: {
        credentials: encryptJson(trimmed, getConfig().ENCRYPTION_KEY),
        status: 'CONNECTED',
        lastError: null,
      },
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CONNECTED_CHANNEL,
      resourceType: 'ChannelConnection',
      resourceId: connectionId,
      // Field names only — an audit log must never become a credential store.
      metadata: { channel: connection.channel, fields: required },
      ipAddress,
    });

    const updated = await this.prisma.client.channelConnection.findFirstOrThrow({
      where: { id: connectionId, ...scope },
      select: this.publicSelect(),
    });
    return this.toView(updated);
  }

  /** The URLs an admin registers with Meta or Telegram. */
  webhookUrls(connectionId: string, channel: ChannelTypeEnum): { url: string; verifyUrl?: string } {
    const base = `${getConfig().API_URL}/api/webhooks`;
    if (channel === ChannelTypeEnum.TELEGRAM) {
      return { url: `${base}/telegram/${connectionId}` };
    }
    return { url: `${base}/meta/${connectionId}`, verifyUrl: `${base}/meta/${connectionId}` };
  }

  /** Surfaces a webhook or send failure on the channel panel. */
  async recordError(connectionId: string, message: string): Promise<void> {
    await this.prisma.client.channelConnection
      .update({
        where: { id: connectionId },
        data: { status: 'ERROR', lastError: message.slice(0, 500) },
      })
      .catch(() => undefined);
  }

  async markInbound(connectionId: string): Promise<void> {
    await this.prisma.client.channelConnection.update({
      where: { id: connectionId },
      data: { lastInboundAt: new Date(), status: 'CONNECTED', lastError: null },
    });
  }

  private publicSelect() {
    return {
      id: true,
      channel: true,
      displayName: true,
      isEnabled: true,
      status: true,
      lastError: true,
      lastInboundAt: true,
      lastOutboundAt: true,
      // Presence only. The ciphertext is never read into this process's
      // response path.
      credentials: false,
    } as const;
  }

  private toView(row: {
    id: string;
    channel: ChannelTypeEnum;
    displayName: string | null;
    isEnabled: boolean;
    status: 'DISCONNECTED' | 'CONNECTED' | 'ERROR';
    lastError: string | null;
    lastInboundAt: Date | null;
    lastOutboundAt: Date | null;
  }): ChannelConnectionView {
    const capabilities = capabilitiesFor(row.channel);
    return {
      id: row.id,
      channel: row.channel,
      displayName: row.displayName,
      isEnabled: row.isEnabled,
      status: row.status,
      lastError: row.lastError,
      lastInboundAt: row.lastInboundAt?.toISOString() ?? null,
      lastOutboundAt: row.lastOutboundAt?.toISOString() ?? null,
      hasCredentials: row.channel !== ChannelTypeEnum.MOCK && row.status === 'CONNECTED',
      capabilities: {
        sendText: capabilities.sendText,
        sendMedia: capabilities.sendMedia,
        markAsRead: capabilities.markAsRead,
        sessionWindowHours: capabilities.sessionWindowHours,
        maxTextLength: capabilities.maxTextLength,
        verifiesWebhookSignature: capabilities.verifiesWebhookSignature,
      },
      isImplemented: IMPLEMENTED_CHANNELS.has(row.channel),
    };
  }
}
