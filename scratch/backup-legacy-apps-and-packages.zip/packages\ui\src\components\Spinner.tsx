import './spinner.css';

export function Spinner({ label }: { label?: string }) {
  return (
    <span className="inline-flex items-center gap-2 text-sm text-slate">
      <span className="fe-spinner" aria-hidden="true" />
      {label && <span>{label}</span>}
    </span>
  );
}
