/**
 * Roster audit proof for the LEGACY clinic module (`apps/api/src/clinic/**`).
 *
 * <h2>Why this suite exists</h2>
 *
 * <p>Phase 26 closed a live cross-tenant breach on this surface and then could not
 * answer whether it had been exploited. The reason is in the migration ledger: the most
 * exposed write paths — doctor and procedure create/update/delete — <em>wrote no audit
 * row at all</em>. An application log cannot answer it either, because a <em>successful</em>
 * unauthorized write produces no log line. Deletes were unaudited entirely. The writes
 * that would have shown it left no trace.
 *
 * <p>So this suite asserts the property that was missing, per operation: one row, with
 * the right actor, tenant, resource, id and diff.
 *
 * <h2>What this suite does and does not cover</h2>
 *
 * <p>It drives {@link LocalClinicAdapter} directly, with an in-memory Prisma stand-in.
 * That is the right layer for these claims: the adapter is where the write happens and
 * where the scope check happens, so it is the only layer that can prove "refused, and
 * wrote nothing". Role authorization is a different claim about a different layer and
 * is proved through the real HTTP guards in
 * `backend/crm-core/src/test/legacy-notes-project-scope/clinic-permissions.test.ts`;
 * the adapter holds no permission logic, so a permission assertion here would be
 * asserting fiction.
 *
 * <h2>The database is an in-memory stand-in</h2>
 *
 * <p>As in phases 26 and 33. It proves the adapter's audit behaviour, not Prisma's
 * query translation — the writes here are `create`/`update`/`deleteMany` against a
 * table with no unusual typing, and `metadata` is a `Json` column that serialises the
 * object it is handed. A real-PostgreSQL run against seeded cross-tenant data remains
 * owed for the same reason it was owed there.
 */
import { beforeEach, describe, expect, it } from 'vitest';
import type { TenantContext } from '@firstelement/database';
import { UserRole } from '@firstelement/shared';
import type { PrismaService } from '../src/common/prisma.service';
import { LocalClinicAdapter } from '../src/clinic/local-clinic.adapter';

// ---------------------------------------------------------------------------
// Tenants
// ---------------------------------------------------------------------------

const ORG_1 = 'org-1';
const ORG_2 = 'org-2';
const PROJECT_A = 'project-a';
const PROJECT_B = 'project-b';
const DOCTOR_A = 'doctor-a';
const PROCEDURE_A = 'proc-a';

/** A clinic administrator in org-1, reaching project A. */
const CLINIC_ADMIN: TenantContext = {
  organizationId: ORG_1,
  userId: 'user-admin',
  role: UserRole.ADMIN,
  projectIds: [PROJECT_A],
};

/**
 * A principal of another tenant.
 *
 * <p>Same role and the same power as {@link CLINIC_ADMIN}, so a refusal here can only
 * come from the tenant boundary. This is the shape the 2026-10-08 breach took.
 */
const FOREIGN_ADMIN: TenantContext = {
  organizationId: ORG_2,
  userId: 'user-foreign',
  role: UserRole.ADMIN,
  projectIds: ['project-foreign'],
};

/** Same tenant, a project the caller is not a member of. */
const COLLEAGUE_IN_B: TenantContext = {
  organizationId: ORG_1,
  userId: 'user-colleague',
  role: UserRole.EMPLOYEE,
  projectIds: [PROJECT_B],
};

// ---------------------------------------------------------------------------
// In-memory database
// ---------------------------------------------------------------------------

type Row = { id: string } & Record<string, unknown>;

interface AuditRow extends Row {
  action: string;
  resourceType: string;
  resourceId?: string | null;
  actorUserId?: string | null;
  actorType?: string;
  organizationId: string;
  projectId?: string | null;
  metadata?: Record<string, unknown>;
}

/**
 * Prisma `where` semantics for exactly the operators these adapters emit: scalar
 * equality and `{ in: [...] }`. An unrecognised operator throws rather than being
 * ignored — a matcher that widened a query it did not understand would make every
 * scoping assertion here pass for the wrong reason.
 */
function matches(row: Row, where: Record<string, unknown>): boolean {
  return Object.entries(where).every(([field, expected]) => {
    if (expected === undefined) return true;
    if (expected !== null && typeof expected === 'object') {
      const clause = expected as Record<string, unknown>;
      if ('in' in clause) return (clause['in'] as unknown[]).includes(row[field]);
      throw new Error(`fake prisma: unsupported operator on ${field}`);
    }
    return row[field] === expected;
  });
}

class FakePrisma {
  doctor: Row[] = [];
  procedure: Row[] = [];
  auditLog: AuditRow[] = [];

  /** Every prisma call, so a test can assert a refusal never reached the database. */
  calls: { op: string; table: string }[] = [];

  resetCalls(): void {
    this.calls = [];
  }

  private rows(table: 'doctor' | 'procedure'): Row[] {
    return this[table];
  }

  private delegate(table: 'doctor' | 'procedure') {
    const rows = () => this.rows(table);
    return {
      findFirst: async (args: { where?: Record<string, unknown> }) => {
        this.calls.push({ op: 'findFirst', table });
        if (!args.where) return rows()[0] ? { ...rows()[0] } : null;
        const hit = rows().find((r) => matches(r, args.where as Record<string, unknown>));
        return hit ? { ...hit } : null;
      },
      create: async (args: { data: Row }) => {
        this.calls.push({ op: 'create', table });
        const row: Row = { id: `new-${table}-${rows().length + 1}`, ...args.data };
        this[table] = [...rows(), row];
        return { ...row };
      },
      update: async (args: { where: { id: string }; data: Partial<Row> }) => {
        this.calls.push({ op: 'update', table });
        const row = rows().find((r) => r.id === args.where.id);
        if (!row) throw new Error(`fake prisma: ${table}.update on missing ${args.where.id}`);
        // `undefined` means "not mentioned", which is what Prisma does with it: the
        // column is left alone. `Object.assign` would instead *overwrite* the stored
        // value with `undefined`, so an update naming one field would blank every
        // other column and a before/after diff would report the entire row as changed.
        // Both halves of that are invisible to a caller in production, so the fake has
        // to honour the documented behaviour rather than the JS default. Caught by the
        // first version of this suite.
        for (const [key, value] of Object.entries(args.data)) {
          if (value !== undefined) (row as Record<string, unknown>)[key] = value;
        }
        // A **copy**, not the stored row. Real Prisma re-reads the row, so a caller
        // holding a pre-image is not holding the same object the update mutates. An
        // aliasing fake makes a before/after diff compare a row against itself and
        // report "nothing changed" for every edit — a harness that manufactures a
        // vacuous pass, which is the one failure mode a diff assertion cannot detect
        // about itself. Caught by the first version of this suite.
        return { ...row };
      },
      deleteMany: async (args: { where?: Record<string, unknown> }) => {
        this.calls.push({ op: 'deleteMany', table });
        const hits = args.where ? rows().filter((r) => matches(r, args.where as Record<string, unknown>)) : rows();
        this[table] = rows().filter((r) => !hits.includes(r));
        return { count: hits.length };
      },
    };
  }

  private auditDelegate() {
    return {
      create: async (args: { data: AuditRow }) => {
        this.calls.push({ op: 'create', table: 'auditLog' });
        const row: AuditRow = { id: `audit-${this.auditLog.length + 1}`, ...args.data };
        this.auditLog = [...this.auditLog, row];
        return row;
      },
    };
  }

  get client(): Record<string, unknown> {
    return {
      doctor: this.delegate('doctor'),
      procedure: this.delegate('procedure'),
      auditLog: this.auditDelegate(),
    } as unknown as Record<string, unknown>;
  }

  seed(): void {
    this.doctor = [
      {
        id: DOCTOR_A,
        organizationId: ORG_1,
        projectId: PROJECT_A,
        name: 'Dr. Amina',
        specialty: 'Cardiology',
        department: null,
        email: 'amina@clinic.example',
        phone: '+966500000001',
        workingDays: [0, 1, 2, 3, 4],
        startHour: '09:00',
        endHour: '17:00',
        slotDuration: 30,
        isActive: true,
      },
    ];
    this.procedure = [
      {
        id: PROCEDURE_A,
        organizationId: ORG_1,
        projectId: PROJECT_A,
        name: 'Echo',
        specialty: 'Cardiology',
        durationMinutes: 30,
        bufferMinutes: 0,
        price: 300,
        isActive: true,
      },
    ];
    this.auditLog = [];
    this.calls = [];
  }
}

// ---------------------------------------------------------------------------
// Suite
// ---------------------------------------------------------------------------

/** The audit rows this suite concerns, in order. */
function rosterRows(prisma: FakePrisma): AuditRow[] {
  return prisma.auditLog.filter(
    (r) => r.resourceType === 'DOCTOR' || r.resourceType === 'PROCEDURE',
  );
}

describe('clinic roster audit (apps/api/src/clinic/local-clinic.adapter.ts)', () => {
  let prisma: FakePrisma;
  let adapter: LocalClinicAdapter;

  beforeEach(() => {
    prisma = new FakePrisma();
    prisma.seed();
    adapter = new LocalClinicAdapter({ client: prisma.client } as unknown as PrismaService);
  });

  // -------------------------------------------------------------------------
  // Doctor
  // -------------------------------------------------------------------------

  describe('doctor create', () => {
    it('writes exactly one row naming the actor, tenant, resource and id', async () => {
      const created = await adapter.createDoctor(CLINIC_ADMIN, {
        name: 'Dr. Bilal',
        specialty: 'Dermatology',
        email: 'bilal@clinic.example',
        phone: '+966500000002',
      });

      expect(rosterRows(prisma)).toHaveLength(1);
      const [row] = rosterRows(prisma);
      expect(row.action).toBe('DOCTOR_CREATED');
      expect(row.resourceType).toBe('DOCTOR');
      expect(row.resourceId).toBe(created.id);
      expect(row.actorUserId).toBe(CLINIC_ADMIN.userId);
      expect(row.actorType).toBe('USER');
      expect(row.organizationId).toBe(ORG_1);
      expect(row.projectId).toBe(PROJECT_A);
    });

    it('records the roster as it now stands, so a clinician who did not exist is described', async () => {
      await adapter.createDoctor(CLINIC_ADMIN, {
        name: 'Dr. Bilal',
        specialty: 'Dermatology',
      });

      const after = rosterRows(prisma)[0].metadata?.['after'] as Record<string, unknown>;
      expect(after).toMatchObject({ name: 'Dr. Bilal', specialty: 'Dermatology', slotDuration: 30 });
    });
  });

  describe('doctor update', () => {
    it('writes exactly one row with the before and after of every changed field', async () => {
      await adapter.updateDoctor(CLINIC_ADMIN, DOCTOR_A, {
        name: 'Dr. Amina Renamed',
        slotDuration: 45,
      });

      expect(rosterRows(prisma)).toHaveLength(1);
      const [row] = rosterRows(prisma);
      expect(row.action).toBe('DOCTOR_UPDATED');
      expect(row.resourceId).toBe(DOCTOR_A);
      expect(row.actorUserId).toBe(CLINIC_ADMIN.userId);
      expect(row.organizationId).toBe(ORG_1);

      expect(row.metadata?.['changes']).toEqual([
        { field: 'name', before: 'Dr. Amina', after: 'Dr. Amina Renamed' },
        { field: 'slotDuration', before: 30, after: 45 },
      ]);
      expect(row.metadata?.['noOp']).toBe(false);
    });

    it('distinguishes a real change from a no-op', async () => {
      // Re-sends the values already on the row.
      await adapter.updateDoctor(CLINIC_ADMIN, DOCTOR_A, { name: 'Dr. Amina', slotDuration: 30 });

      const [row] = rosterRows(prisma);
      expect(row.metadata?.['changes']).toEqual([]);
      expect(row.metadata?.['noOp']).toBe(true);
    });

    it('does not report a field the request never mentioned', async () => {
      await adapter.updateDoctor(CLINIC_ADMIN, DOCTOR_A, { specialty: 'Cardiology' });

      const changes = rosterRows(prisma)[0].metadata?.['changes'] as { field: string }[];
      expect(changes.map((c) => c.field)).toEqual([]);
    });
  });

  describe('doctor delete', () => {
    it('writes exactly one row describing what was removed', async () => {
      // The least recoverable action and, until now, the least evidenced: this row is
      // the only surviving description of a clinician who has been deleted.
      await adapter.deleteDoctor(CLINIC_ADMIN, DOCTOR_A);

      expect(rosterRows(prisma)).toHaveLength(1);
      const [row] = rosterRows(prisma);
      expect(row.action).toBe('DOCTOR_DELETED');
      expect(row.resourceType).toBe('DOCTOR');
      expect(row.resourceId).toBe(DOCTOR_A);
      expect(row.actorUserId).toBe(CLINIC_ADMIN.userId);
      expect(row.organizationId).toBe(ORG_1);
      expect(row.projectId).toBe(PROJECT_A);

      expect(row.metadata?.['before']).toMatchObject({
        name: 'Dr. Amina',
        specialty: 'Cardiology',
        startHour: '09:00',
        slotDuration: 30,
      });
    });

    it('removes the row, and records that it was active', async () => {
      await adapter.deleteDoctor(CLINIC_ADMIN, DOCTOR_A);
      expect(prisma.doctor.find((d) => d.id === DOCTOR_A)).toBeUndefined();
      expect(rosterRows(prisma)[0].metadata?.['wasActive']).toBe(true);
    });
  });

  // -------------------------------------------------------------------------
  // Procedure
  // -------------------------------------------------------------------------

  describe('procedure create', () => {
    it('writes exactly one row naming the actor, tenant, resource and id', async () => {
      const created = await adapter.createProcedure(CLINIC_ADMIN, {
        name: 'Stress test',
        specialty: 'Cardiology',
        durationMinutes: 45,
        price: 500,
      });

      expect(rosterRows(prisma)).toHaveLength(1);
      const [row] = rosterRows(prisma);
      expect(row.action).toBe('PROCEDURE_CREATED');
      expect(row.resourceType).toBe('PROCEDURE');
      expect(row.resourceId).toBe(created.id);
      expect(row.actorUserId).toBe(CLINIC_ADMIN.userId);
      expect(row.organizationId).toBe(ORG_1);
      expect(row.metadata?.['after']).toMatchObject({
        name: 'Stress test',
        durationMinutes: 45,
        price: 500,
      });
    });
  });

  describe('procedure update', () => {
    it('writes exactly one row with the before and after of every changed field', async () => {
      await adapter.updateProcedure(CLINIC_ADMIN, PROCEDURE_A, { price: 500, durationMinutes: 45 });

      expect(rosterRows(prisma)).toHaveLength(1);
      const [row] = rosterRows(prisma);
      expect(row.action).toBe('PROCEDURE_UPDATED');
      expect(row.resourceId).toBe(PROCEDURE_A);
      expect(row.metadata?.['changes']).toEqual([
        { field: 'durationMinutes', before: 30, after: 45 },
        { field: 'price', before: 300, after: 500 },
      ]);
      expect(row.metadata?.['noOp']).toBe(false);
    });

    it('distinguishes a real change from a no-op', async () => {
      await adapter.updateProcedure(CLINIC_ADMIN, PROCEDURE_A, { price: 300 });

      const [row] = rosterRows(prisma);
      expect(row.metadata?.['changes']).toEqual([]);
      expect(row.metadata?.['noOp']).toBe(true);
    });
  });

  describe('procedure delete', () => {
    it('writes exactly one row describing what was removed', async () => {
      await adapter.deleteProcedure(CLINIC_ADMIN, PROCEDURE_A);

      expect(rosterRows(prisma)).toHaveLength(1);
      const [row] = rosterRows(prisma);
      expect(row.action).toBe('PROCEDURE_DELETED');
      expect(row.resourceType).toBe('PROCEDURE');
      expect(row.resourceId).toBe(PROCEDURE_A);
      expect(row.actorUserId).toBe(CLINIC_ADMIN.userId);
      expect(row.organizationId).toBe(ORG_1);
      expect(row.metadata?.['before']).toMatchObject({ name: 'Echo', price: 300 });
    });
  });

  // -------------------------------------------------------------------------
  // What must never be written
  // -------------------------------------------------------------------------

  describe('no clinician contact detail is recorded as a value', () => {
    it('records a changed email or phone as a change, not as the number', async () => {
      await adapter.updateDoctor(CLINIC_ADMIN, DOCTOR_A, {
        email: 'attacker@evil.example',
        phone: '+966500000999',
      });

      const [row] = rosterRows(prisma);
      const serialised = JSON.stringify(row.metadata);

      expect(serialised).not.toContain('attacker@evil.example');
      expect(serialised).not.toContain('+966500000999');
      // …and the change itself is still evidenced.
      expect(row.metadata?.['changes']).toEqual(
        expect.arrayContaining([
          { field: 'email', changed: true },
          { field: 'phone', changed: true },
        ]),
      );
    });

    it('does not record the seeded clinician\'s contact details on a delete', async () => {
      await adapter.deleteDoctor(CLINIC_ADMIN, DOCTOR_A);

      const serialised = JSON.stringify(rosterRows(prisma)[0].metadata);
      expect(serialised).not.toContain('amina@clinic.example');
      expect(serialised).not.toContain('+966500000001');
    });

    it('records contact details as presence only on a create', async () => {
      await adapter.createDoctor(CLINIC_ADMIN, {
        name: 'Dr. Bilal',
        specialty: 'Dermatology',
        email: 'bilal@clinic.example',
        phone: '+966500000002',
      });

      const serialised = JSON.stringify(rosterRows(prisma)[0].metadata);
      expect(serialised).not.toContain('bilal@clinic.example');
      expect(serialised).not.toContain('+966500000002');
      expect(rosterRows(prisma)[0].metadata?.['contactProvided']).toEqual({
        email: true,
        phone: true,
      });
    });

    it('writes no patient data, because a roster row carries none', async () => {
      // Structural, not a filter: `doctors` and `procedures` have no patient columns,
      // so there is nothing to redact. Asserted so a future column addition is caught
      // by a human reading a failing test rather than by an incident.
      await adapter.updateDoctor(CLINIC_ADMIN, DOCTOR_A, { name: 'Dr. Amina II' });
      const metadata = rosterRows(prisma)[0].metadata as Record<string, unknown>;
      expect(Object.keys(metadata).sort()).toEqual(['changes', 'noOp']);
    });
  });

  // -------------------------------------------------------------------------
  // A refusal writes nothing — both halves
  // -------------------------------------------------------------------------

  describe('a cross-tenant actor is refused and writes no audit row', () => {
    // Both halves matter, and they fail independently. A refusal that wrote a row
    // would be a new defect: it is not evidence, and the row would carry the acting
    // principal's identity against a resource in a tenant they may not reach.

    it('refuses to update and writes no row', async () => {
      await expect(
        adapter.updateDoctor(FOREIGN_ADMIN, DOCTOR_A, { name: 'HIJACKED' }),
      ).rejects.toThrow();

      expect(rosterRows(prisma)).toHaveLength(0);
      expect(prisma.doctor.find((d) => d.id === DOCTOR_A)?.name).toBe('Dr. Amina');
    });

    it('refuses to delete and writes no row', async () => {
      await expect(adapter.deleteDoctor(FOREIGN_ADMIN, DOCTOR_A)).rejects.toThrow();

      expect(rosterRows(prisma)).toHaveLength(0);
      expect(prisma.doctor.find((d) => d.id === DOCTOR_A)).toBeDefined();
    });

    it('refuses a procedure update and writes no row', async () => {
      await expect(
        adapter.updateProcedure(FOREIGN_ADMIN, PROCEDURE_A, { price: 1 }),
      ).rejects.toThrow();

      expect(rosterRows(prisma)).toHaveLength(0);
      expect(prisma.procedure.find((p) => p.id === PROCEDURE_A)?.price).toBe(300);
    });

    it('refuses a procedure delete and writes no row', async () => {
      await expect(adapter.deleteProcedure(FOREIGN_ADMIN, PROCEDURE_A)).rejects.toThrow();

      expect(rosterRows(prisma)).toHaveLength(0);
      expect(prisma.procedure.find((p) => p.id === PROCEDURE_A)).toBeDefined();
    });

    it('never reaches the database at all, so the refusal precedes the write', async () => {
      prisma.resetCalls();
      await expect(adapter.deleteDoctor(FOREIGN_ADMIN, DOCTOR_A)).rejects.toThrow();

      // Only the scope probe ran. No update, no delete, and above all no audit insert.
      expect(prisma.calls.filter((c) => c.op !== 'findFirst')).toHaveLength(0);
      expect(prisma.calls.some((c) => c.table === 'auditLog')).toBe(false);
    });
  });

  describe('a same-tenant colleague in another project is refused and writes no row', async () => {
    it('update', async () => {
      await expect(
        adapter.updateDoctor(COLLEAGUE_IN_B, DOCTOR_A, { name: 'HIJACKED' }),
      ).rejects.toThrow();
      expect(rosterRows(prisma)).toHaveLength(0);
    });

    it('delete', async () => {
      await expect(adapter.deleteProcedure(COLLEAGUE_IN_B, PROCEDURE_A)).rejects.toThrow();
      expect(rosterRows(prisma)).toHaveLength(0);
    });
  });

  describe('the audited tenant is the row\'s tenant, never a client-supplied one', async () => {
    it('lands a create in the caller\'s own project and audits it there', async () => {
      // A foreign principal creating in their own organization is legitimate — it is
      // not a breach — so the create succeeds and the audit row must agree with the
      // row it describes. That agreement is exactly what `F-cross-tenant-access.sql`
      // tests for, so it has to hold by construction.
      const created = await adapter.createDoctor(FOREIGN_ADMIN, {
        name: 'Our own doctor',
        specialty: 'Cardiology',
      });

      expect(created.organizationId).toBe(ORG_2);
      expect(created.projectId).toBe(FOREIGN_ADMIN.projectIds[0]);
      expect(prisma.doctor.filter((d) => d.organizationId === ORG_1)).toHaveLength(1);

      const [row] = rosterRows(prisma);
      expect(row.organizationId).toBe(ORG_2);
      expect(row.projectId).toBe(FOREIGN_ADMIN.projectIds[0]);
      expect(row.actorUserId).toBe(FOREIGN_ADMIN.userId);
      expect(row.resourceId).toBe(created.id);
    });

    it('refuses a create naming a project the caller cannot reach, and writes no row', async () => {
      // Naming another tenant's project is refused outright, so there is nothing to
      // audit. Asserted because "refused" and "silently landed somewhere" are the two
      // possible behaviours and only one of them is safe.
      await expect(
        adapter.createDoctor(FOREIGN_ADMIN, {
          projectId: PROJECT_A,
          name: 'Planted',
          specialty: 'Cardiology',
        } as never),
      ).rejects.toThrow();

      expect(rosterRows(prisma)).toHaveLength(0);
      expect(prisma.doctor.filter((d) => d.organizationId === ORG_1)).toHaveLength(1);
      expect(prisma.doctor.find((d) => d.name === 'Planted')).toBeUndefined();
    });
  });
});