import { Injectable } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import type { DomainEvent, DomainEventPublisher } from '@firstelement/events';

/**
 * The transport behind `@firstelement/events`.
 *
 * Publishers call `publish`; subscribers use `@OnEvent('conversation.*')`.
 * Delivery is in-process and synchronous-but-detached: a subscriber that
 * throws must not fail the request that published the event, so failures
 * are contained by EventEmitter2 rather than propagating back to the
 * caller. Anything that must not be lost belongs in a BullMQ job, not a
 * subscriber (plan §11).
 */
@Injectable()
export class DomainEventBus implements DomainEventPublisher {
  constructor(private readonly emitter: EventEmitter2) {}

  publish(event: DomainEvent): void {
    this.emitter.emit(event.type, event);
  }
}
