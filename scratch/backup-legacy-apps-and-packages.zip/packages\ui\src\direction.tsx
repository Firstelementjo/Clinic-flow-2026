import { createContext, useContext, useEffect, useMemo, type ReactNode } from 'react';

export type Direction = 'rtl' | 'ltr';
export type UiLocale = 'ar' | 'en';

interface DirectionValue {
  locale: UiLocale;
  direction: Direction;
}

const DirectionContext = createContext<DirectionValue>({ locale: 'ar', direction: 'rtl' });

/**
 * Direction is derived from locale in one place and written to <html>, so
 * layout mirroring happens through CSS logical properties rather than
 * per-component conditionals. Arabic is the default, not the toggle.
 */
export function DirectionProvider({ locale, children }: { locale: UiLocale; children: ReactNode }) {
  const value = useMemo<DirectionValue>(
    () => ({ locale, direction: locale === 'ar' ? 'rtl' : 'ltr' }),
    [locale],
  );

  useEffect(() => {
    document.documentElement.lang = value.locale;
    document.documentElement.dir = value.direction;
  }, [value]);

  return <DirectionContext.Provider value={value}>{children}</DirectionContext.Provider>;
}

export function useDirection(): DirectionValue {
  return useContext(DirectionContext);
}
