import { Injectable } from '@nestjs/common';
import { createEmbeddingProvider, type EmbeddingProvider } from '@firstelement/ai';
import { getConfig } from '@firstelement/config';
import {
  DocumentIngestionPipeline,
  KnowledgeRetriever,
  LocalStorageDriver,
  type StorageDriver,
} from '@firstelement/knowledge-base';
import { PrismaService } from '../common/prisma.service';

/**
 * Nest wiring for the knowledge layer. The logic lives in
 * `@firstelement/knowledge-base` because the worker runs ingestion without
 * Nest; these are the injectable handles.
 */

export const STORAGE_DRIVER = Symbol('STORAGE_DRIVER');
export const EMBEDDING_PROVIDER = Symbol('EMBEDDING_PROVIDER');

export function createStorageDriver(): StorageDriver {
  const config = getConfig();
  if (config.STORAGE_DRIVER === 's3') {
    // Declared in configuration, not implemented here. Failing loudly at
    // boot beats writing uploads to a local disk that a deployment
    // believes is object storage.
    throw new Error('STORAGE_DRIVER=s3 is not implemented in this build');
  }
  return new LocalStorageDriver(config.STORAGE_LOCAL_PATH);
}

/**
 * The provider is resolved once at boot so a misconfiguration (OpenAI
 * selected with no key) surfaces on startup rather than on the first
 * upload, hours later.
 */
@Injectable()
export class EmbeddingProviderHolder {
  readonly provider: EmbeddingProvider = createEmbeddingProvider();
}

@Injectable()
export class StorageDriverHolder {
  readonly driver: StorageDriver = createStorageDriver();
}

@Injectable()
export class KnowledgeRetrieverProvider extends KnowledgeRetriever {
  constructor(prisma: PrismaService, embeddings: EmbeddingProviderHolder) {
    super(prisma.client, embeddings.provider);
  }
}

@Injectable()
export class IngestionPipelineProvider extends DocumentIngestionPipeline {
  constructor(prisma: PrismaService, storage: StorageDriverHolder, embeddings: EmbeddingProviderHolder) {
    super(prisma.client, storage.driver, embeddings.provider);
  }
}
