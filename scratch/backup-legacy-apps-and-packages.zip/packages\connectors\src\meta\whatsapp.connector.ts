import { ChannelType } from '@firstelement/shared';
import { capabilitiesFor } from '../capabilities';
import type {
  ConnectorCapabilities,
  ExternalConversation,
  MessagingConnector,
  NormalizedAttachment,
  NormalizedIncomingMessage,
  OutgoingMessage,
  SendResult,
} from '../types';
import { verifyMetaSignature } from './signature';

export interface WhatsAppCredentials {
  phoneNumberId: string;
  accessToken: string;
  /** App secret — signs webhook payloads. */
  appSecret: string;
  /** Shared string echoed during the GET verification handshake. */
  verifyToken: string;
  apiVersion?: string;
}

export interface WebhookRequest {
  rawBody: Buffer | string;
  headers: Record<string, string | undefined>;
}

/**
 * WhatsApp Business Cloud API (plan §8: official APIs only).
 *
 * Two behaviours worth knowing about, both of which come from the
 * platform rather than from us:
 *
 * - **Status callbacks share the webhook.** Delivery receipts arrive on
 *   the same endpoint as messages, in a `statuses` array. They are not
 *   customer messages and must not become conversation turns.
 * - **The 24-hour window.** Outside it, only approved templates may be
 *   sent. The capability table records this; the outbound path checks it
 *   before attempting a send, so the failure is a clear message rather
 *   than a platform error nobody can read.
 */
export class WhatsAppConnector implements MessagingConnector {
  readonly channel = ChannelType.WHATSAPP;

  constructor(
    readonly connectionId: string,
    private readonly credentials: WhatsAppCredentials,
  ) {}

  capabilities(): ConnectorCapabilities {
    return capabilitiesFor(ChannelType.WHATSAPP);
  }

  async connect(): Promise<void> {}

  async disconnect(): Promise<void> {}

  async verifyWebhook(request: unknown): Promise<boolean> {
    const { rawBody, headers } = request as WebhookRequest;
    return verifyMetaSignature({
      rawBody,
      signatureHeader: headers['x-hub-signature-256'],
      appSecret: this.credentials.appSecret,
    });
  }

  async receiveWebhook(payload: unknown): Promise<NormalizedIncomingMessage[]> {
    const body = payload as MetaWebhookBody;
    const out: NormalizedIncomingMessage[] = [];

    for (const entry of body?.entry ?? []) {
      for (const change of entry.changes ?? []) {
        const value = change.value;
        // Delivery receipts, not conversation turns.
        if (!value?.messages) continue;

        const contacts = new Map(
          (value.contacts ?? []).map((contact) => [contact.wa_id, contact.profile?.name]),
        );

        for (const message of value.messages) {
          out.push({
            channel: ChannelType.WHATSAPP,
            externalMessageId: message.id,
            externalUserId: message.from,
            externalConversationId: message.from,
            displayName: contacts.get(message.from),
            // WhatsApp identifies people by phone number, and the platform
            // vouches for it — a verified signal for identity resolution.
            phone: `+${message.from}`,
            text: extractText(message),
            attachments: extractAttachments(message),
            sentAt: new Date(Number(message.timestamp) * 1000),
            raw: message as unknown as Record<string, unknown>,
          });
        }
      }
    }

    return out;
  }

  async sendText(message: OutgoingMessage): Promise<SendResult> {
    return this.post({
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: message.externalUserId,
      type: 'text',
      text: { preview_url: false, body: message.text },
    });
  }

  async markAsRead(conversation: ExternalConversation): Promise<void> {
    const externalMessageId = conversation.externalConversationId;
    if (!externalMessageId) return;

    await this.post({
      messaging_product: 'whatsapp',
      status: 'read',
      message_id: externalMessageId,
    }).catch(() => undefined);
  }

  private async post(body: Record<string, unknown>): Promise<SendResult> {
    const version = this.credentials.apiVersion ?? 'v21.0';
    const url = `https://graph.facebook.com/${version}/${this.credentials.phoneNumberId}/messages`;

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.credentials.accessToken}`,
        },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(20_000),
      });

      const text = await response.text();

      if (!response.ok) {
        return {
          ok: false,
          error: `WhatsApp send failed (${response.status}): ${text.slice(0, 200)}`,
          // 4xx means the message or credentials are wrong; retrying sends
          // the same broken request and burns the rate limit.
          retryable: response.status === 429 || response.status >= 500,
        };
      }

      const parsed = JSON.parse(text) as { messages?: { id: string }[] };
      return { ok: true, externalMessageId: parsed.messages?.[0]?.id };
    } catch (error) {
      // Network failure or timeout — worth another attempt.
      return {
        ok: false,
        error: error instanceof Error ? error.message : String(error),
        retryable: true,
      };
    }
  }
}

// --- payload shapes (only the fields used) ---------------------------------

interface MetaWebhookBody {
  entry?: {
    changes?: {
      value?: {
        messages?: WhatsAppMessage[];
        contacts?: { wa_id: string; profile?: { name?: string } }[];
        statuses?: unknown[];
      };
    }[];
  }[];
}

interface WhatsAppMessage {
  id: string;
  from: string;
  timestamp: string;
  type: string;
  text?: { body: string };
  image?: { id: string; mime_type?: string; caption?: string };
  document?: { id: string; mime_type?: string; filename?: string; caption?: string };
  audio?: { id: string; mime_type?: string };
  video?: { id: string; mime_type?: string; caption?: string };
  location?: { latitude: number; longitude: number };
  button?: { text: string };
  interactive?: {
    button_reply?: { title: string };
    list_reply?: { title: string };
  };
}

/**
 * Everything becomes text the CRM and the AI can reason about. A media
 * message with no caption still needs *something* — a conversation row
 * reading "[image]" is honest; an empty body looks like a bug.
 */
function extractText(message: WhatsAppMessage): string {
  if (message.text?.body) return message.text.body;
  if (message.button?.text) return message.button.text;
  if (message.interactive?.button_reply?.title) return message.interactive.button_reply.title;
  if (message.interactive?.list_reply?.title) return message.interactive.list_reply.title;
  if (message.image?.caption) return message.image.caption;
  if (message.video?.caption) return message.video.caption;
  if (message.document?.caption) return message.document.caption;
  if (message.location) {
    return `[location ${message.location.latitude}, ${message.location.longitude}]`;
  }
  return `[${message.type}]`;
}

function extractAttachments(message: WhatsAppMessage): NormalizedAttachment[] {
  const attachments: NormalizedAttachment[] = [];

  // Media ids are not URLs: fetching the bytes needs a second authorized
  // call. The id is kept so that step can happen later, on demand.
  if (message.image) {
    attachments.push({ type: 'image', mimeType: message.image.mime_type, url: message.image.id });
  }
  if (message.video) {
    attachments.push({ type: 'video', mimeType: message.video.mime_type, url: message.video.id });
  }
  if (message.audio) {
    attachments.push({ type: 'audio', mimeType: message.audio.mime_type, url: message.audio.id });
  }
  if (message.document) {
    attachments.push({
      type: 'document',
      mimeType: message.document.mime_type,
      fileName: message.document.filename,
      url: message.document.id,
    });
  }
  if (message.location) attachments.push({ type: 'location' });

  return attachments;
}
