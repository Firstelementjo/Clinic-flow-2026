import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  Query,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { Tenant, RequirePermissions } from '../auth/decorators';
import type { TenantContext } from '@firstelement/database';
import { Permission } from '@firstelement/auth';
import { ClinicService, type BookingRequestInput } from './clinic.service';
import { LocalClinicAdapter } from './local-clinic.adapter';
import { AiSimulatorService } from './ai-simulator.service';
import { RemindersService } from './reminders.service';

/**
 * The clinic module.
 *
 * <h2>Tenant and project scope</h2>
 *
 * <p>No route here carries a {@code :projectId} path parameter, so
 * {@code PermissionsGuard} supplies <em>no</em> project scope for any of them and
 * the adapter is the only thing enforcing the boundary. That is deliberate:
 * `plan.md` §0.4 forbids controller-only authorization, so the checks live in
 * `LocalClinicAdapter` and `ClinicService`, which take the caller's
 * {@code TenantContext` as their first argument. Every denial is a 404 that is
 * indistinguishable from the record not existing.
 *
 * <h2>Role authorization</h2>
 *
 * <p>Every non-{@code @Public()} handler below declares the permission it authorizes.
 * The decorator is <em>not</em> the tenant boundary: no clinic route carries a
 * {@code :projectId} path param, so {@code PermissionsGuard} supplies no project
 * scope for any of them, and {@code LocalClinicAdapter} / {@code ClinicService}
 * remain the thing enforcing tenant and project membership. What the decorator adds
 * is the half that was missing: <em>who may</em> read a clinician's contact details,
 * rewrite the roster, or let the AI simulator write to the schedule. Previously any
 * employee of any tenant could do all of it.
 *
 * <h2>The refusal is a 404, and it has to stay one</h2>
 *
 * <p>A {@code PermissionDeniedError} is rendered by the global
 * {@code HttpExceptionFilter} as {@code 404 {code: NOT_FOUND, message: 'Resource not
 * found'}} — the same status and the same body a nonexistent record produces. That is
 * deliberate and it is uniform across this surface: a caller cannot distinguish "you
 * may not" from "not yours" from "does not exist", and so cannot probe for the
 * existence of a row they have no right to know about. A 403 here would reintroduce
 * that oracle on the one surface carrying patient names and phone numbers.
 *
 * <h2>The gap this file used to carry</h2>
 *
 * <p>Until phase 33 this controller declared no permission at all, and `Permission`
 * had no clinic members, so every handler above required only a valid session.
 * Phase 26 reported that rather than papering over it, on the grounds that borrowing
 * an unrelated permission would make the audit record say something untrue. The
 * members now in `packages/auth` are named for what they authorize; see
 * `CLINIC_EMPLOYEE_GRANT` and `CLINIC_ADMIN_ONLY` for who holds each.
 */
@Controller('clinic')
@UseGuards(AuthGuard)
export class ClinicController {
  constructor(
    private readonly clinicService: ClinicService,
    private readonly clinicAdapter: LocalClinicAdapter,
    private readonly aiSimulator: AiSimulatorService,
    private readonly remindersService: RemindersService,
  ) {}

  @Get('doctors')
  @RequirePermissions(Permission.DOCTOR_READ)
  async getDoctors(
    @Tenant() ctx: TenantContext,
    @Query('projectId') projectId?: string,
  ) {
    return this.clinicService.getDoctors(ctx, projectId);
  }

  @Get('doctors/manage')
  @RequirePermissions(Permission.DOCTOR_READ_MANAGEMENT)
  async getAllDoctors(
    @Tenant() ctx: TenantContext,
    @Query('projectId') projectId?: string,
  ) {
    return this.clinicAdapter.getAllDoctors(ctx, projectId);
  }

  @Post('doctors')
  @RequirePermissions(Permission.DOCTOR_CREATE)
  async createDoctor(
    @Tenant() ctx: TenantContext,
    @Body() body: any,
  ) {
    // `...body` first: a request body is untrusted input (the global ValidationPipe
    // only strips undeclared properties from class DTOs, and this is `any`), so it
    // must never be able to overwrite a server-derived tenant or project.
    return this.clinicAdapter.createDoctor(ctx, {
      ...body,
      projectId: ctx.projectIds[0],
    });
  }

  @Patch('doctors/:id')
  @RequirePermissions(Permission.DOCTOR_UPDATE)
  async updateDoctor(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body() body: any,
  ) {
    // The adapter proves the doctor is in a project this caller can reach before
    // it writes; no tenant or project is taken from the body.
    return this.clinicAdapter.updateDoctor(ctx, id, body);
  }

  @Delete('doctors/:id')
  @RequirePermissions(Permission.DOCTOR_DELETE)
  async deleteDoctor(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.clinicAdapter.deleteDoctor(ctx, id);
  }

  @Get('procedures')
  @RequirePermissions(Permission.PROCEDURE_READ)
  async getProcedures(
    @Tenant() ctx: TenantContext,
    @Query('projectId') projectId?: string,
  ) {
    return this.clinicService.getProcedures(ctx, projectId);
  }

  @Get('procedures/manage')
  @RequirePermissions(Permission.PROCEDURE_READ_MANAGEMENT)
  async getAllProcedures(
    @Tenant() ctx: TenantContext,
    @Query('projectId') projectId?: string,
  ) {
    return this.clinicAdapter.getAllProcedures(ctx, projectId);
  }

  @Post('procedures')
  @RequirePermissions(Permission.PROCEDURE_CREATE)
  async createProcedure(
    @Tenant() ctx: TenantContext,
    @Body() body: any,
  ) {
    // `...body` first — see createDoctor: a body must never override the tenant.
    return this.clinicAdapter.createProcedure(ctx, {
      ...body,
      projectId: ctx.projectIds[0],
    });
  }

  @Patch('procedures/:id')
  @RequirePermissions(Permission.PROCEDURE_UPDATE)
  async updateProcedure(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body() body: any,
  ) {
    return this.clinicAdapter.updateProcedure(ctx, id, body);
  }

  @Delete('procedures/:id')
  @RequirePermissions(Permission.PROCEDURE_DELETE)
  async deleteProcedure(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.clinicAdapter.deleteProcedure(ctx, id);
  }

  @Get('procedures/:id/duration')
  @RequirePermissions(Permission.PROCEDURE_READ)
  async getProcedureDuration(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    const duration = await this.clinicService.getProcedureDuration(ctx, id);
    return { procedureId: id, durationMinutes: duration };
  }

  @Get('slots')
  @RequirePermissions(Permission.SCHEDULE_AVAILABILITY_READ)
  async findAvailableSlots(
    @Tenant() ctx: TenantContext,
    @Query('doctorId') doctorId: string,
    @Query('procedureId') procedureId: string,
    @Query('date') date: string,
  ) {
    return this.clinicService.findAvailableSlots(ctx, doctorId, procedureId, date);
  }

  @Get('check-availability')
  @RequirePermissions(Permission.SCHEDULE_AVAILABILITY_READ)
  async checkAvailability(
    @Tenant() ctx: TenantContext,
    @Query('doctorId') doctorId: string,
    @Query('procedureId') procedureId: string,
    @Query('dateTime') dateTime: string,
  ) {
    return this.clinicService.checkAvailability(ctx, doctorId, procedureId, dateTime);
  }

  @Post('appointments')
  @RequirePermissions(Permission.APPOINTMENT_CREATE)
  async createAppointment(
    @Tenant() ctx: TenantContext,
    @Body() body: BookingRequestInput,
  ) {
    return this.clinicService.createAppointment(ctx, body);
  }

  @Patch('appointments/:id/reschedule')
  @RequirePermissions(Permission.APPOINTMENT_RESCHEDULE)
  async rescheduleAppointment(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body('newDate') newDate?: string,
    @Body('newDateTime') newDateTime?: string,
  ) {
    const targetDate = newDate || newDateTime || '';
    return this.clinicService.rescheduleAppointment(ctx, id, targetDate);
  }

  @Post('appointments/:id/cancel')
  @RequirePermissions(Permission.APPOINTMENT_CANCEL)
  async cancelAppointment(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body('reason') reason?: string,
  ) {
    return this.clinicService.cancelAppointment(ctx, id, reason);
  }

  @Post('ai-simulator/chat')
  // Two permissions, and both are load-bearing. The simulator *creates appointments*
  // (plan §5 — AI tools are application-owned, capability-checked and audited, not
  // merely authenticated), so gating it on CLINIC_AI_SIMULATE alone would let a grant
  // book an appointment without the audit record ever saying so.
  @RequirePermissions(Permission.CLINIC_AI_SIMULATE, Permission.APPOINTMENT_CREATE)
  async runAiSimulator(
    @Tenant() ctx: TenantContext,
    @Body() body: any,
  ) {
    return this.aiSimulator.processTurn(ctx, body);
  }

  @Get('reminders')
  @RequirePermissions(Permission.REMINDER_READ)
  async getReminderSummary(@Tenant() ctx: TenantContext) {
    return this.remindersService.getReminderSummary(ctx);
  }

  @Post('reminders/send-batch')
  @RequirePermissions(Permission.REMINDER_SEND)
  async runBatchReminders(@Tenant() ctx: TenantContext) {
    return this.remindersService.runBatchReminders(ctx);
  }

  @Post('reminders/send/:appointmentId')
  @RequirePermissions(Permission.REMINDER_SEND)
  async sendSingleReminder(
    @Tenant() ctx: TenantContext,
    @Param('appointmentId') appointmentId: string,
    @Body('channel') channel?: 'WHATSAPP' | 'SMS',
  ) {
    return this.remindersService.sendReminderForAppointment(ctx, appointmentId, channel);
  }

  @Post('reminders/respond')
  @RequirePermissions(Permission.REMINDER_RECORD_RESPONSE)
  async handlePatientResponse(
    @Tenant() ctx: TenantContext,
    @Body('appointmentId') appointmentId: string,
    @Body('action') action: 'CONFIRM' | 'RESCHEDULE' | 'CANCEL',
    @Body('reason') reason?: string,
  ) {
    // The authenticated path is tenant-scoped. The public path
    // (`POST /public/appointments/:token/respond`) is separate and capability-based.
    return this.remindersService.processPatientResponseForCaller(
      ctx,
      appointmentId,
      action,
      reason,
    );
  }

  @Get('analytics')
  @RequirePermissions(Permission.ANALYTICS_READ_PROJECT)
  async getExecutiveAnalytics(
    @Tenant() ctx: TenantContext,
    @Query('days') days?: string,
  ) {
    return this.clinicService.getExecutiveAnalytics(ctx, days ? Number(days) : 30);
  }
}
