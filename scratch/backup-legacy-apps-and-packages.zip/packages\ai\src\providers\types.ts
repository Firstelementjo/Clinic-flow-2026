/**
 * Chat provider abstraction (plan §9).
 *
 * The CRM must keep working when a provider is down (plan §20.9), and a
 * project must be able to switch models without touching orchestration.
 * So nothing above this file imports a vendor SDK, and every provider
 * reports usage the same way — otherwise per-project AI spend cannot be
 * compared, and cost analytics become guesswork.
 */

export type AIProviderKind =
  | 'MOCK'
  | 'OPENAI'
  | 'ANTHROPIC'
  | 'GEMINI'
  | 'OPENAI_COMPATIBLE'
  | 'LOCAL';

export type ChatRole = 'system' | 'user' | 'assistant' | 'tool';

export interface ChatMessage {
  role: ChatRole;
  content: string;
  /** Present on tool results, matching the call they answer. */
  toolCallId?: string;
  toolName?: string;
}

export interface ToolDefinition {
  name: string;
  description: string;
  /** JSON Schema for the arguments. Providers translate, never widen. */
  parameters: Record<string, unknown>;
}

export interface ToolCallRequest {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

export interface CompletionRequest {
  messages: ChatMessage[];
  tools?: ToolDefinition[];
  temperature: number;
  maxTokens: number;
  model?: string;
}

export interface CompletionUsage {
  inputTokens: number;
  outputTokens: number;
}

export interface CompletionResult {
  text: string;
  toolCalls: ToolCallRequest[];
  usage: CompletionUsage;
  model: string;
  finishReason: 'stop' | 'length' | 'tool_calls' | 'error';
}

export interface AIProvider {
  readonly kind: AIProviderKind;
  readonly defaultModel: string;
  generate(request: CompletionRequest): Promise<CompletionResult>;
}

export class AIProviderError extends Error {
  readonly code = 'PROVIDER_UNAVAILABLE' as const;

  constructor(
    readonly provider: AIProviderKind,
    message: string,
    /** Whether the next provider in the chain should be tried. */
    readonly retryable = true,
    readonly status?: number,
  ) {
    super(message);
    this.name = 'AIProviderError';
  }
}

/**
 * Published rates in USD per million tokens, used for the cost estimate on
 * every run (plan §9). Approximate by nature — they are for showing an
 * admin that one agent version costs eight times another, not for billing.
 */
const PRICES: Record<string, { input: number; output: number }> = {
  'gpt-4o-mini': { input: 0.15, output: 0.6 },
  'gpt-4o': { input: 2.5, output: 10 },
  'claude-haiku-4-5-20251001': { input: 1, output: 5 },
  'claude-sonnet-5': { input: 3, output: 15 },
  'claude-opus-5': { input: 15, output: 75 },
};

export function estimateCostUsd(model: string, usage: CompletionUsage): number {
  const price = PRICES[model];
  if (!price) return 0;
  return (
    (usage.inputTokens / 1_000_000) * price.input +
    (usage.outputTokens / 1_000_000) * price.output
  );
}

/** Fallback when a provider does not report usage (some local runtimes). */
export function estimateTokens(text: string): number {
  return Math.max(1, Math.ceil(text.length / 4));
}
