import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import {
  CalendarClock,
  CalendarPlus,
  Clock,
  Mail,
  MoreHorizontal,
  Phone,
  Send,
  Ticket,
  Type,
  UserRound,
  Users,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { useDirection } from '@firstelement/ui';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import { useCrmViews } from '../lib/views';
import {
  CreateFollowUpDrawer,
  FOLLOW_UP_STATUSES,
  FOLLOW_UP_STATUS_LABEL,
  type FollowUpRow,
} from '../components/follow-up-form';
import {
  ListView,
  ListBadge,
  ListBadgeSelect,
  Menu,
  MenuItem,
  RecordAvatar,
  type BadgeTone,
  type ListColumn,
} from '../components/ListView';

const FOLLOW_UP_STATUS_TONE: Record<(typeof FOLLOW_UP_STATUSES)[number], BadgeTone> = {
  New: 'neutral',
  Contacted: 'warning',
  Scheduled: 'signal',
  Converted: 'agent',
  Disqualified: 'danger',
};

function followUpStatusLabel(status: string, t: (key: StringKey) => string): string {
  const key = (FOLLOW_UP_STATUS_LABEL as Record<string, StringKey>)[status];
  return key ? t(key) : status;
}

const followUpsKey = ['leads'] as const;

function useFollowUps(search: string) {
  const query = new URLSearchParams();
  if (search.trim()) query.set('search', search.trim());
  return useQuery({
    queryKey: ['leads', search.trim()],
    queryFn: () => api.get<FollowUpRow[]>(`/follow-ups?${query.toString()}`),
  });
}

function calculateTicketMeasurement(ticketDateStr: string | null | undefined): {
  elapsedText: string;
  isOverdue: boolean;
  days: number;
} | null {
  if (!ticketDateStr) return null;
  const ticketTime = new Date(ticketDateStr).getTime();
  if (isNaN(ticketTime)) return null;
  const elapsedMs = Date.now() - ticketTime;
  const hours = Math.floor(elapsedMs / (1000 * 60 * 60));
  const days = Math.floor(hours / 24);

  let elapsedText: string;
  if (days > 0) {
    elapsedText = `${days}d ${hours % 24}h`;
  } else if (hours > 0) {
    elapsedText = `${hours}h`;
  } else {
    elapsedText = '<1h';
  }

  return {
    elapsedText,
    isOverdue: days >= 2, // Overdue if ticket is older than 48 hours without completion
    days,
  };
}

export function FollowUpsPage() {
  const t = useT();
  const dir = useDirection();
  const qc = useQueryClient();
  const views = useCrmViews('lead', { noun: t('followUps.title'), defaultSort: 'createdAt' });
  const [createOpen, setCreateOpen] = useState(false);
  const location = useLocation();
  const nav = useNavigate();

  useEffect(() => {
    if (new URLSearchParams(location.search).get('new') === '1') {
      setCreateOpen(true);
      nav(location.pathname, { replace: true });
    }
  }, [location.search, nav]);

  const followUps = useFollowUps(views.search);

  const rows = useMemo(() => {
    const list = [...(followUps.data ?? [])];
    if (views.sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
    else if (views.sort === 'status') list.sort((a, b) => a.status.localeCompare(b.status));
    else if (views.sort === 'ticketDate') {
      list.sort((a, b) => {
        const timeA = a.ticketDate ? new Date(a.ticketDate).getTime() : 0;
        const timeB = b.ticketDate ? new Date(b.ticketDate).getTime() : 0;
        return timeB - timeA;
      });
    } else {
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    return list;
  }, [followUps.data, views.sort]);

  const invalidate = () => void qc.invalidateQueries({ queryKey: followUpsKey });

  const completeFollowUp = useMutation({
    mutationFn: (id: string) => api.patch<FollowUpRow>(`/follow-ups/${id}`, { status: 'Converted' }),
    onSuccess: invalidate,
  });

  const setFollowUpStatus = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      api.patch<FollowUpRow>(`/follow-ups/${id}`, { status }),
    onSuccess: invalidate,
  });

  const removeMany = useMutation({
    mutationFn: async (ids: string[]) => {
      await Promise.all(ids.map((id) => api.delete(`/follow-ups/${id}`)));
    },
    onSuccess: invalidate,
  });

  const statusOptions = FOLLOW_UP_STATUSES.map((s) => ({ value: s, label: followUpStatusLabel(s, t) }));

  const nameCell = (row: FollowUpRow) => (
    <div className="flex min-w-0 max-w-full items-center gap-2 text-start">
      <RecordAvatar name={row.name} />
      <div className="min-w-0">
        <span className="block truncate text-sm font-medium text-ink">{row.name}</span>
        {row.followUpDate && (
          <span className="flex items-center gap-1 text-[11px] text-slate-soft">
            <CalendarClock className="h-3 w-3 text-signal" />
            <span>Due {row.followUpDate.slice(0, 10)}</span>
          </span>
        )}
      </div>
    </div>
  );

  const customerCell = (row: FollowUpRow) => {
    if (row.customer) {
      return (
        <Link
          to={`/app/people?search=${encodeURIComponent(row.customer.displayName)}`}
          className="group inline-flex items-center gap-1.5 truncate text-xs font-medium text-signal hover:underline"
          title={`View ${row.customer.displayName} in People`}
        >
          <Users className="h-3.5 w-3.5 flex-shrink-0 text-slate-soft group-hover:text-signal" />
          <span className="truncate">{row.customer.displayName}</span>
          <span className="font-mono text-[10px] text-slate-soft">({row.customer.cxId})</span>
        </Link>
      );
    }
    return <span className="text-xs text-slate-soft">—</span>;
  };

  const ticketCell = (row: FollowUpRow) => {
    if (!row.ticketNumber && !row.ticketDate) {
      return <span className="text-xs text-slate-soft">—</span>;
    }

    const measurement = calculateTicketMeasurement(row.ticketDate);

    return (
      <div className="min-w-0 space-y-0.5">
        <div className="flex items-center gap-1.5">
          <Ticket className="h-3 w-3 text-slate-soft" />
          <span className="font-mono text-xs font-semibold text-ink">
            {row.ticketNumber || 'Ticket'}
          </span>
        </div>
        {row.ticketDate && (
          <div className="flex items-center gap-1.5 text-[11px]">
            <span className="text-slate-soft">{formatDate(row.ticketDate, dir.locale)}</span>
            {measurement && (
              <span
                className={`inline-flex items-center gap-0.5 px-1 rounded text-[10px] font-mono font-medium ${
                  measurement.isOverdue
                    ? 'bg-danger-wash text-danger'
                    : 'bg-agent-wash text-agent'
                }`}
                title={`Measured time elapsed since ticket was opened: ${measurement.elapsedText}`}
              >
                {measurement.isOverdue ? (
                  <AlertTriangle className="h-2.5 w-2.5" />
                ) : (
                  <Clock className="h-2.5 w-2.5" />
                )}
                {measurement.elapsedText}
              </span>
            )}
          </div>
        )}
      </div>
    );
  };

  const columns: ListColumn<FollowUpRow>[] = [
    { id: 'name', label: 'followUps.col.name', icon: Type, size: 'minmax(12rem, 3fr)', render: nameCell },
    {
      id: 'customer',
      label: 'followUps.col.person',
      icon: Users,
      size: 'minmax(10rem, 2fr)',
      render: customerCell,
    },
    {
      id: 'ticket',
      label: 'followUps.col.ticketAndDate',
      icon: Ticket,
      size: 'minmax(11rem, 2fr)',
      render: ticketCell,
    },
    {
      id: 'status',
      label: 'list.col.status',
      icon: Send,
      size: '8.5rem',
      render: (row) => (
        <ListBadgeSelect
          value={
            (FOLLOW_UP_STATUSES.includes(row.status as (typeof FOLLOW_UP_STATUSES)[number])
              ? row.status
              : 'New') as (typeof FOLLOW_UP_STATUSES)[number]
          }
          options={statusOptions}
          toneFor={(s) => FOLLOW_UP_STATUS_TONE[s]}
          ariaLabel={t('followUps.status')}
          onChange={(status) => setFollowUpStatus.mutate({ id: row.id, status })}
        />
      ),
    },
    {
      id: 'phone',
      label: 'list.col.phones',
      icon: Phone,
      size: 'minmax(8rem, 1.25fr)',
      render: (row) => row.phone || row.customer?.primaryPhone,
    },
    {
      id: 'email',
      label: 'list.col.emails',
      icon: Mail,
      size: 'minmax(9rem, 1.5fr)',
      render: (row) => row.email || row.customer?.primaryEmail,
    },
    {
      id: 'createdBy',
      label: 'list.col.createdBy',
      icon: UserRound,
      size: 'minmax(7rem, 1.25fr)',
      render: (row) => row.createdBy?.fullName ?? null,
    },
    {
      id: 'createdAt',
      label: 'list.col.created',
      icon: CalendarPlus,
      size: '7rem',
      render: (row) => formatDate(row.createdAt, dir.locale),
    },
  ];

  const footerCells = [
    {
      col: 'customer',
      render: (list: FollowUpRow[]) => {
        const withCust = list.filter((l) => Boolean(l.customer || l.customerId)).length;
        return `${withCust} / ${list.length} ${t('followUps.footer.connectedPeople')}`;
      },
    },
    {
      col: 'ticket',
      render: (list: FollowUpRow[]) => {
        const withTicket = list.filter((l) => Boolean(l.ticketDate || l.ticketNumber)).length;
        return `${withTicket} ${t('followUps.footer.measuredTickets')}`;
      },
    },
    {
      col: 'createdAt',
      render: (list: FollowUpRow[]) => {
        if (list.length === 0) return null;
        const stamps = list.map((l) => new Date(l.createdAt).getTime());
        const earliest = formatDate(new Date(Math.min(...stamps)).toISOString(), dir.locale);
        const latest = formatDate(new Date(Math.max(...stamps)).toISOString(), dir.locale);
        return (
          <span className="flex min-w-0 items-center gap-1">
            <ListBadge>{t('list.footer.earliest')}</ListBadge>
            <span className="truncate">{earliest}</span>
            <span className="opacity-60">·</span>
            <ListBadge>{t('list.footer.latest')}</ListBadge>
            <span className="truncate">{latest}</span>
          </span>
        );
      },
    },
  ];

  return (
    <>
      <ListView<FollowUpRow>
        title={t('followUps.title')}
        eyebrow={t('followUps.eyebrow')}
        addLabel={t('followUps.addLabel')}
        onAdd={() => setCreateOpen(true)}
        noun={t('followUps.title')}
        columns={columns}
        rows={rows}
        isPending={followUps.isPending}
        isError={followUps.isError}
        keyOf={(l) => l.id}
        viewSwitcher={views.switcher}
        filterValue={views.search}
        onFilter={views.setSearch}
        sortValue={views.sort}
        onSort={views.setSort}
        sortOptions={[
          { value: 'createdAt', label: t('list.col.created') },
          { value: 'ticketDate', label: t('followUps.col.ticketDate') },
          { value: 'name', label: t('list.col.name') },
          { value: 'status', label: t('list.col.status') },
        ]}
        hiddenColumns={views.hidden}
        onHiddenColumnsChange={views.setHidden}
        onDeleteSelected={(ids) => removeMany.mutate(ids)}
        footerCells={footerCells}
        rowActions={(row) => (
          <Menu
            button={
              <span
                aria-label={t('list.options')}
                role="img"
                className="flex h-6 w-6 items-center justify-center rounded text-slate-soft transition-colors hover:bg-mist hover:text-ink"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreHorizontal className="h-4 w-4" />
              </span>
            }
          >
            <MenuItem
              icon={CheckCircle2}
              label={t('followUps.action.complete')}
              onClick={() => completeFollowUp.mutate(row.id)}
            />
          </Menu>
        )}
      />
      <CreateFollowUpDrawer open={createOpen} onClose={() => setCreateOpen(false)} />
    </>
  );
}
