import { Injectable, Logger } from '@nestjs/common';
import type { AuditAction } from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';

export interface AuditEntry {
  organizationId: string;
  projectId?: string | null;
  actorUserId?: string | null;
  actorType?: 'USER' | 'SYSTEM' | 'AI';
  action: AuditAction;
  resourceType: string;
  resourceId?: string | null;
  metadata?: Record<string, unknown>;
  ipAddress?: string | null;
}

/**
 * Audit trail (plan §12).
 *
 * Writes are best-effort by design: an audit insert failing must not roll
 * back a legitimate business action the user already completed. The failure
 * is logged at error level so it is still visible, rather than swallowed.
 *
 * Never record message bodies or other customer content here — the audit
 * log answers "who did what to which resource", not "what was said".
 */
@Injectable()
export class AuditService {
  private readonly logger = new Logger(AuditService.name);

  constructor(private readonly prisma: PrismaService) {}

  async record(entry: AuditEntry): Promise<void> {
    try {
      await this.prisma.client.auditLog.create({
        data: {
          organizationId: entry.organizationId,
          projectId: entry.projectId ?? null,
          actorUserId: entry.actorUserId ?? null,
          actorType: entry.actorType ?? 'USER',
          action: entry.action,
          resourceType: entry.resourceType,
          resourceId: entry.resourceId ?? null,
          metadata: (entry.metadata ?? {}) as object,
          ipAddress: entry.ipAddress ?? null,
        },
      });
    } catch (error) {
      this.logger.error({
        message: 'Failed to write audit log entry',
        action: entry.action,
        resourceType: entry.resourceType,
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }
}
