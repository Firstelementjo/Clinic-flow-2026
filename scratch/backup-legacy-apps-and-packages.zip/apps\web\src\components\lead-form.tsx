import { useState, type FormEvent } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import {
  CreateRecordDrawer,
  FormSection,
  TextField,
  SelectField,
  TextAreaField,
  TagsField,
  useFormOptions,
  useEmployees,
  INDUSTRY_SUGGESTIONS,
  textOrUndefined,
  numberOrUndefined,
} from './CreateRecordDrawer';

const leadsKey = ['leads'] as const;

const LEAD_STATUSES = ['New', 'Contacted', 'Qualified', 'Converted', 'Disqualified'] as const;

const LEAD_STATUS_LABEL: Record<(typeof LEAD_STATUSES)[number], StringKey> = {
  New: 'leads.statuses.New',
  Contacted: 'leads.statuses.Contacted',
  Qualified: 'leads.statuses.Qualified',
  Converted: 'leads.statuses.Converted',
  Disqualified: 'leads.statuses.Disqualified',
};

interface LeadRow {
  id: string;
  name: string;
  company: string | null;
  source: string | null;
  status: string;
}

interface CreateLeadDrawerProps {
  open: boolean;
  onClose: () => void;
}

const emptyForm = {
  name: '',
  company: '',
  jobTitle: '',
  email: '',
  phone: '',
  source: '',
  status: 'New',
  industry: '',
  leadScore: '',
  estimatedValue: '',
  priority: '',
  ownerId: '',
  notes: '',
} as const;

export function CreateLeadDrawer({ open, onClose }: CreateLeadDrawerProps) {
  const t = useT();
  const qc = useQueryClient();
  const opts = useFormOptions();
  const ownerOptions = (useEmployees().data ?? []).map((employee) => ({
    value: employee.userId,
    label: employee.fullName,
  }));

  const [form, setForm] = useState({ ...emptyForm, tags: [] as string[] });
  const set = (field: keyof typeof emptyForm) => (e: { target: { value: string } }) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const reset = () => setForm({ ...emptyForm, tags: [] });

  const create = useMutation({
    mutationFn: () =>
      api.post<LeadRow>('/leads', {
        name: form.name.trim(),
        company: textOrUndefined(form.company),
        jobTitle: textOrUndefined(form.jobTitle),
        email: textOrUndefined(form.email),
        phone: textOrUndefined(form.phone),
        source: form.source || undefined,
        status: form.status || 'New',
        industry: textOrUndefined(form.industry),
        leadScore: numberOrUndefined(form.leadScore),
        priority: form.priority || undefined,
        estimatedValue: numberOrUndefined(form.estimatedValue),
        ownerId: form.ownerId || undefined,
        tags: form.tags,
        notes: textOrUndefined(form.notes),
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: leadsKey });
      reset();
      onClose();
    },
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (form.name.trim()) create.mutate();
  };

  const close = () => {
    reset();
    onClose();
  };

  const statusOptions = LEAD_STATUSES.map((status) => ({ value: status, label: t(LEAD_STATUS_LABEL[status]) }));

  return (
    <CreateRecordDrawer
      open={open}
      onClose={close}
      title={t('form.lead.title')}
      description={t('form.lead.about')}
      submitLabel={t('form.lead.save')}
      isSubmitting={create.isPending}
      canSubmit={Boolean(form.name.trim())}
      onSubmit={onSubmit}
    >
      <FormSection title={t('form.section.leadInfo')}>
        <TextField label={t('form.field.name')} required autoFocus value={form.name} onChange={set('name')} />
        <TextField label={t('form.field.company')} value={form.company} onChange={set('company')} />
        <TextField label={t('form.field.jobTitle')} value={form.jobTitle} onChange={set('jobTitle')} />
      </FormSection>

      <FormSection title={t('form.section.contactInfo')}>
        <TextField label={t('form.field.email')} type="email" dir="ltr" value={form.email} onChange={set('email')} />
        <TextField label={t('form.field.phone')} dir="ltr" placeholder="+" value={form.phone} onChange={set('phone')} />
      </FormSection>

      <FormSection title={t('form.section.qualification')}>
        <SelectField label={t('form.field.leadSource')} placeholder="—" options={opts.leadSources} value={form.source} onChange={set('source')} />
        <SelectField label={t('form.field.status')} options={statusOptions} value={form.status} onChange={set('status')} />
        <TextField label={t('form.field.leadScore')} type="number" min={0} max={100} value={form.leadScore} onChange={set('leadScore')} />
        <TextField
          label={t('form.field.industry')}
          list="lead-industry-suggestions"
          placeholder="…"
          value={form.industry}
          onChange={set('industry')}
        />
        <TextField label={t('form.field.estimatedValue')} type="number" min={0} value={form.estimatedValue} onChange={set('estimatedValue')} />
        <SelectField label={t('form.field.priority')} placeholder="—" options={opts.priorities} value={form.priority} onChange={set('priority')} />
      </FormSection>

      <FormSection title={t('form.section.crm')}>
        <SelectField label={t('form.field.assignee')} placeholder="—" options={ownerOptions} value={form.ownerId} onChange={set('ownerId')} />
        <TagsField label={t('form.field.tags')} value={form.tags} onChange={(tags) => setForm((prev) => ({ ...prev, tags }))} placeholder={t('form.field.tagsAdd')} />
        <TextAreaField label={t('form.field.notes')} wide value={form.notes} onChange={set('notes')} />
      </FormSection>

      <datalist id="lead-industry-suggestions">
        {INDUSTRY_SUGGESTIONS.map((suggestion) => (
          <option key={suggestion} value={suggestion} />
        ))}
      </datalist>
    </CreateRecordDrawer>
  );
}