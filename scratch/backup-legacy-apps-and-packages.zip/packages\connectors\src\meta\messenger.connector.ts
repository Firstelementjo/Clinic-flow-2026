import { ChannelType } from '@firstelement/shared';
import { capabilitiesFor } from '../capabilities';
import type {
  ConnectorCapabilities,
  ExternalConversation,
  MessagingConnector,
  NormalizedAttachment,
  NormalizedIncomingMessage,
  OutgoingMessage,
  SendResult,
} from '../types';
import { verifyMetaSignature } from './signature';
import type { WebhookRequest } from './whatsapp.connector';

export interface MessengerCredentials {
  /** Page (Messenger) or IG-linked page id. */
  pageId: string;
  pageAccessToken: string;
  appSecret: string;
  verifyToken: string;
  apiVersion?: string;
}

/**
 * Instagram DMs and Facebook Messenger (plan §8).
 *
 * They share the Messenger Platform: the same webhook shape, the same
 * `/me/messages` send, the same page access token. They differ only in
 * capabilities — Instagram caps text far lower — so one implementation
 * takes the channel as a parameter rather than being copied twice.
 *
 * The platform's own quirks that this absorbs:
 *
 * - **Echoes.** Messages *we* send come back on the webhook with
 *   `is_echo: true`. Storing them would double every outbound message in
 *   the thread.
 * - **Deliveries and reads** arrive on the same endpoint and are not
 *   conversation turns.
 * - **Identity is a page-scoped id**, not a phone or email — no verified
 *   signal, so identity resolution will not silently merge these with an
 *   existing customer (plan §7).
 */
export class MessengerConnector implements MessagingConnector {
  constructor(
    readonly channel: typeof ChannelType.INSTAGRAM | typeof ChannelType.MESSENGER,
    readonly connectionId: string,
    private readonly credentials: MessengerCredentials,
  ) {}

  capabilities(): ConnectorCapabilities {
    return capabilitiesFor(this.channel);
  }

  async connect(): Promise<void> {}

  async disconnect(): Promise<void> {}

  async verifyWebhook(request: unknown): Promise<boolean> {
    const { rawBody, headers } = request as WebhookRequest;
    return verifyMetaSignature({
      rawBody,
      signatureHeader: headers['x-hub-signature-256'],
      appSecret: this.credentials.appSecret,
    });
  }

  async receiveWebhook(payload: unknown): Promise<NormalizedIncomingMessage[]> {
    const body = payload as MessengerWebhookBody;
    const out: NormalizedIncomingMessage[] = [];

    for (const entry of body?.entry ?? []) {
      for (const event of entry.messaging ?? []) {
        // Our own outbound message coming back to us.
        if (!event.message || event.message.is_echo) continue;

        const text = event.message.text ?? describeAttachments(event.message.attachments);
        if (!text) continue;

        out.push({
          channel: this.channel,
          externalMessageId: event.message.mid,
          externalUserId: event.sender.id,
          externalConversationId: event.sender.id,
          text,
          attachments: normalizeAttachments(event.message.attachments),
          sentAt: new Date(event.timestamp ?? Date.now()),
          raw: event as unknown as Record<string, unknown>,
        });
      }
    }

    return out;
  }

  async sendText(message: OutgoingMessage): Promise<SendResult> {
    return this.post({
      recipient: { id: message.externalUserId },
      message: { text: message.text },
      messaging_type: 'RESPONSE',
    });
  }

  async markAsRead(conversation: ExternalConversation): Promise<void> {
    await this.post({
      recipient: { id: conversation.externalUserId },
      sender_action: 'mark_seen',
    }).catch(() => undefined);
  }

  private async post(body: Record<string, unknown>): Promise<SendResult> {
    const version = this.credentials.apiVersion ?? 'v21.0';
    const url = `https://graph.facebook.com/${version}/me/messages?access_token=${encodeURIComponent(this.credentials.pageAccessToken)}`;

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(20_000),
      });

      const text = await response.text();

      if (!response.ok) {
        return {
          ok: false,
          error: `${this.channel} send failed (${response.status}): ${text.slice(0, 200)}`,
          retryable: response.status === 429 || response.status >= 500,
        };
      }

      const parsed = JSON.parse(text) as { message_id?: string };
      return { ok: true, externalMessageId: parsed.message_id };
    } catch (error) {
      return {
        ok: false,
        error: error instanceof Error ? error.message : String(error),
        retryable: true,
      };
    }
  }
}

interface MessengerWebhookBody {
  entry?: {
    messaging?: {
      sender: { id: string };
      recipient?: { id: string };
      timestamp?: number;
      message?: {
        mid: string;
        text?: string;
        is_echo?: boolean;
        attachments?: { type: string; payload?: { url?: string } }[];
      };
    }[];
  }[];
}

function normalizeAttachments(
  attachments: { type: string; payload?: { url?: string } }[] | undefined,
): NormalizedAttachment[] {
  return (attachments ?? []).map((attachment) => ({
    type: mapType(attachment.type),
    url: attachment.payload?.url,
  }));
}

function describeAttachments(
  attachments: { type: string; payload?: { url?: string } }[] | undefined,
): string {
  if (!attachments || attachments.length === 0) return '';
  // An attachment-only message still needs a body an agent can read.
  return attachments.map((attachment) => `[${attachment.type}]`).join(' ');
}

function mapType(type: string): NormalizedAttachment['type'] {
  switch (type) {
    case 'image':
    case 'video':
    case 'audio':
    case 'location':
      return type;
    case 'file':
      return 'document';
    default:
      return 'unknown';
  }
}
