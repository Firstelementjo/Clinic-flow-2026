import { Body, Controller, Get, Patch } from '@nestjs/common';
import { Permission } from '@firstelement/auth';
import { organizationScope, type TenantContext } from '@firstelement/database';
import { updateOrganizationSchema, type UpdateOrganizationInput } from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';

/**
 * The organization is always the caller's own — there is no
 * `/organizations/:id` route by design, so there is no id for a client to
 * tamper with (plan §6).
 */
@Controller('organization')
export class OrganizationsController {
  constructor(private readonly prisma: PrismaService) {}

  @Get()
  @RequirePermissions(Permission.ORGANIZATION_READ)
  get(@Tenant() ctx: TenantContext) {
    return this.prisma.client.organization.findUniqueOrThrow({
      where: { id: organizationScope(ctx).organizationId },
      select: {
        id: true,
        name: true,
        slug: true,
        defaultLocale: true,
        timezone: true,
        createdAt: true,
      },
    });
  }

  @Patch()
  @RequirePermissions(Permission.ORGANIZATION_UPDATE)
  update(
    @Tenant() ctx: TenantContext,
    @Body(zodBody(updateOrganizationSchema)) body: UpdateOrganizationInput,
  ) {
    return this.prisma.client.organization.update({
      where: { id: ctx.organizationId },
      data: body,
      select: { id: true, name: true, slug: true, defaultLocale: true, timezone: true },
    });
  }
}
