import { describe, expect, it } from 'vitest';
import { createSessionToken, hashSessionToken, safeEqual, sessionCookieOptions } from './session-token';

describe('session tokens', () => {
  it('never returns the same token twice', () => {
    const tokens = new Set(Array.from({ length: 500 }, () => createSessionToken().token));
    expect(tokens.size).toBe(500);
  });

  it('stores a hash, not the token', () => {
    const { token, tokenHash } = createSessionToken();
    expect(tokenHash).not.toContain(token);
    expect(tokenHash).toMatch(/^[0-9a-f]{64}$/);
    expect(hashSessionToken(token)).toBe(tokenHash);
  });

  it('produces tokens with at least 256 bits of entropy', () => {
    // 32 random bytes, base64url-encoded.
    expect(createSessionToken().token.length).toBeGreaterThanOrEqual(43);
  });
});

describe('safeEqual', () => {
  it('compares equal and unequal values without throwing on length mismatch', () => {
    expect(safeEqual('abc', 'abc')).toBe(true);
    expect(safeEqual('abc', 'abd')).toBe(false);
    expect(safeEqual('abc', 'abcd')).toBe(false);
  });
});

describe('cookie options', () => {
  it('is httpOnly and lax in every environment, and secure in production', () => {
    const dev = sessionCookieOptions({ secure: false, ttlHours: 1 });
    const prod = sessionCookieOptions({ secure: true, ttlHours: 1 });

    expect(dev.httpOnly).toBe(true);
    expect(dev.sameSite).toBe('lax');
    expect(dev.secure).toBe(false);
    expect(prod.secure).toBe(true);
    expect(prod.maxAge).toBe(3_600_000);
  });
});
