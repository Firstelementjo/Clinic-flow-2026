import type { PrismaClient } from '@firstelement/database';
import { createChatProvider } from '../providers/factory';
import { FailoverProvider } from '../providers/failover';
import {
  AIProviderError,
  estimateCostUsd,
  type AIProvider,
  type AIProviderKind,
  type ChatMessage,
  type CompletionResult,
} from '../providers/types';
import { toolDefinitionsFor } from '../tools/definitions';
import { ToolExecutor, type ToolOutcome } from '../tools/executor';
import { buildMemory } from './memory';
import { buildKnowledgeMessage, buildSystemPrompt, detectInjectionSignals } from './prompt';

export interface RetrievedKnowledge {
  chunkId: string;
  documentId: string;
  knowledgeBaseId: string;
  documentTitle: string;
  content: string;
  score: number;
}

/** Injected so this package does not depend on the knowledge package. */
export type KnowledgeSearch = (params: {
  organizationId: string;
  projectId: string;
  knowledgeBaseIds: string[];
  query: string;
  minScore: number;
}) => Promise<RetrievedKnowledge[]>;

export interface AITurnJob {
  organizationId: string;
  projectId: string;
  conversationId: string;
  /** The inbound message being answered. */
  messageId: string;
}

export type AITurnResult =
  | { status: 'replied'; runId: string; messageId: string }
  | { status: 'resolved'; runId: string; messageId: string }
  | { status: 'escalated'; runId: string; reason: string }
  | { status: 'skipped'; reason: string }
  | { status: 'failed'; runId?: string; reason: string };

const MAX_TOOL_ROUNDS = 3;

/**
 * The AI turn (plan §9).
 *
 * ```
 * load agent version → build context → retrieve → run tools → generate
 *   → record run → decide (reply | ask | escalate)
 * ```
 *
 * Every stage writes an `AIRunStep`, and the run records the exact
 * `AIAgentVersion`, provider, model, retrievals, tool calls and token cost
 * behind the answer. That is what makes "why did it say that?" a query
 * rather than an investigation — and the reason an employee inheriting an
 * escalation can see what the agent already tried.
 *
 * What is deliberately *not* recorded: the model's reasoning trace. The
 * trace carries decisions, citations and operational metadata only
 * (plan §48).
 */
export class AIOrchestrator {
  private readonly tools: ToolExecutor;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly searchKnowledge: KnowledgeSearch,
    private readonly providerFactory = createChatProvider,
  ) {
    this.tools = new ToolExecutor(prisma);
  }

  async run(job: AITurnJob): Promise<AITurnResult> {
    const conversation = await this.prisma.conversation.findFirst({
      where: {
        id: job.conversationId,
        organizationId: job.organizationId,
        projectId: job.projectId,
      },
      select: {
        id: true,
        mode: true,
        customerId: true,
        channel: true,
        customer: { select: { displayName: true, locale: true } },
        project: { select: { name: true } },
      },
    });

    if (!conversation) return { status: 'skipped', reason: 'Conversation not found' };

    // First of two mode checks. The second happens inside the transaction
    // that writes the reply, because an employee can take over while this
    // run is in flight (plan §10).
    if (conversation.mode !== 'AI') {
      return { status: 'skipped', reason: 'Conversation is handled by a human' };
    }

    const agent = await this.prisma.aIAgent.findFirst({
      where: {
        projectId: job.projectId,
        organizationId: job.organizationId,
        isEnabled: true,
      },
      select: { id: true, activeVersion: true },
    });

    if (!agent?.activeVersion) {
      return { status: 'skipped', reason: 'No active AI agent for this project' };
    }

    const version = agent.activeVersion;
    const enabledTools = asStringArray(version.enabledTools);
    const knowledgeBaseIds = asStringArray(version.knowledgeBaseIds);

    const run = await this.prisma.aIRun.create({
      data: {
        organizationId: job.organizationId,
        projectId: job.projectId,
        conversationId: job.conversationId,
        agentId: agent.id,
        agentVersionId: version.id,
        triggerMessageId: job.messageId,
        status: 'RUNNING',
        provider: version.provider,
        model: version.model,
      },
      select: { id: true },
    });

    let sequence = 0;
    const step = async (
      kind: 'CONTEXT' | 'RETRIEVAL' | 'TOOL_EXECUTION' | 'GENERATION' | 'EVALUATION' | 'DECISION',
      detail: Record<string, unknown>,
      latencyMs?: number,
      status: 'OK' | 'ERROR' = 'OK',
    ): Promise<void> => {
      sequence += 1;
      await this.prisma.aIRunStep.create({
        data: { runId: run.id, sequence, kind, status, latencyMs, detail: detail as object },
      });
    };

    const startedAt = Date.now();

    try {
      // --- context -------------------------------------------------------
      const history = await this.prisma.message.findMany({
        where: { conversationId: job.conversationId, projectId: job.projectId },
        select: { authorType: true, body: true, sentAt: true },
        orderBy: { sentAt: 'asc' },
        take: 200,
      });

      const memory = buildMemory(history, version.memoryWindow);
      const question = [...history].reverse().find((m) => m.authorType === 'CUSTOMER')?.body ?? '';

      // Telemetry, not a gate — see prompt.ts.
      const injectionSignals = detectInjectionSignals(question);

      await step('CONTEXT', {
        turns: history.length,
        verbatimTurns: memory.messages.length,
        summarizedTurns: memory.summarizedTurns,
        injectionSignals,
      });

      // --- retrieval -----------------------------------------------------
      const retrievalStart = Date.now();
      const retrieved = await this.searchKnowledge({
        organizationId: job.organizationId,
        projectId: job.projectId,
        knowledgeBaseIds,
        query: question,
        minScore: version.minRetrievalScore,
      });

      if (retrieved.length > 0) {
        await this.prisma.aIRunRetrieval.createMany({
          data: retrieved.map((chunk) => ({
            runId: run.id,
            knowledgeBaseId: chunk.knowledgeBaseId,
            documentId: chunk.documentId,
            chunkId: chunk.chunkId,
            documentTitle: chunk.documentTitle,
            score: chunk.score,
            wasUsed: true,
          })),
        });
      }

      await step(
        'RETRIEVAL',
        { retrieved: retrieved.length, topScore: retrieved[0]?.score ?? null },
        Date.now() - retrievalStart,
      );

      // A knowledge gap is recorded whether or not the agent escalates:
      // it is the backlog of what the knowledge base is missing (plan §70).
      if (retrieved.length === 0 && question.trim()) {
        await this.prisma.knowledgeGap.create({
          data: {
            organizationId: job.organizationId,
            projectId: job.projectId,
            conversationId: job.conversationId,
            query: question.slice(0, 1_000),
            bestScore: null,
            retrievedCount: 0,
          },
        });
      }

      // --- generation (with tool rounds) ---------------------------------
      const provider = this.providerFactory({
        provider: version.provider,
        model: version.model,
        failoverChain: asStringArray(version.failoverChain) as AIProviderKind[],
      });

      const messages: ChatMessage[] = [
        {
          role: 'system',
          content: buildSystemPrompt({
            agentInstructions: version.systemInstructions,
            tone: version.tone,
            projectName: conversation.project.name,
            customerName: conversation.customer.displayName,
            locale: conversation.customer.locale,
            knowledge: retrieved.map((chunk) => ({
              title: chunk.documentTitle,
              content: chunk.content,
              score: chunk.score,
            })),
            conversationSummary: memory.summary,
          }),
        },
      ];

      const knowledgeMessage = buildKnowledgeMessage(
        retrieved.map((chunk) => ({
          title: chunk.documentTitle,
          content: chunk.content,
          score: chunk.score,
        })),
      );
      if (knowledgeMessage) messages.push(knowledgeMessage);
      messages.push(...memory.messages);

      const toolDefinitions = toolDefinitionsFor(enabledTools);
      const toolOutcomes: ToolOutcome[] = [];
      let completion: CompletionResult | null = null;
      let toolSequence = 0;

      for (let round = 0; round < MAX_TOOL_ROUNDS; round += 1) {
        const generationStart = Date.now();
        completion = await provider.generate({
          messages,
          tools: toolDefinitions.length > 0 ? toolDefinitions : undefined,
          temperature: version.temperature,
          maxTokens: version.maxTokens,
          model: version.model ?? undefined,
        });

        await step(
          'GENERATION',
          {
            round,
            finishReason: completion.finishReason,
            toolCallsRequested: completion.toolCalls.length,
            failovers:
              provider instanceof FailoverProvider ? provider.failedAttempts().length : 0,
          },
          Date.now() - generationStart,
        );

        if (completion.toolCalls.length === 0) break;

        for (const call of completion.toolCalls) {
          const outcome = await this.tools.execute(call, {
            organizationId: job.organizationId,
            projectId: job.projectId,
            conversationId: job.conversationId,
            customerId: conversation.customerId,
            enabledTools,
            searchKnowledge: async (query) => {
              const results = await this.searchKnowledge({
                organizationId: job.organizationId,
                projectId: job.projectId,
                knowledgeBaseIds,
                query,
                minScore: version.minRetrievalScore,
              });
              return results.map((chunk) => ({
                title: chunk.documentTitle,
                content: chunk.content,
                score: chunk.score,
              }));
            },
          });

          toolSequence += 1;
          toolOutcomes.push(outcome);

          await this.prisma.aIRunToolCall.create({
            data: {
              runId: run.id,
              sequence: toolSequence,
              toolName: outcome.name,
              arguments: outcome.arguments as object,
              result: outcome.result as object,
              authorized: outcome.authorized,
              isError: outcome.isError,
              errorMessage: outcome.errorMessage,
              latencyMs: outcome.latencyMs,
            },
          });

          messages.push({
            role: 'assistant',
            content: `Calling ${outcome.name}`,
          });
          messages.push({
            role: 'tool',
            toolCallId: call.id,
            toolName: outcome.name,
            content: JSON.stringify(outcome.result).slice(0, 8_000),
          });
        }

        await step('TOOL_EXECUTION', {
          round,
          calls: completion.toolCalls.length,
          denied: toolOutcomes.filter((outcome) => !outcome.authorized).length,
        });

        if (toolOutcomes.some((outcome) => outcome.requestsHuman)) break;
      }

      if (!completion) throw new AIProviderError(version.provider, 'No completion produced', false);

      // --- usage ---------------------------------------------------------
      const usedProvider: AIProvider =
        provider instanceof FailoverProvider ? (provider.lastUsed ?? provider) : provider;
      const latencyMs = Date.now() - startedAt;

      await this.prisma.aIUsage.create({
        data: {
          organizationId: job.organizationId,
          projectId: job.projectId,
          runId: run.id,
          provider: usedProvider.kind as AIProviderKind,
          model: completion.model,
          inputTokens: completion.usage.inputTokens,
          outputTokens: completion.usage.outputTokens,
          latencyMs,
          estimatedCost: estimateCostUsd(completion.model, completion.usage),
        },
      });

      // --- decision ------------------------------------------------------
      const humanRequest = toolOutcomes.find((outcome) => outcome.requestsHuman);
      const resolveRequest = toolOutcomes.find((outcome) => outcome.requestsResolve);
      const rawText = completion.text ?? (completion as { content?: string }).content ?? '';
      const answer = rawText.trim();

      if (humanRequest) {
        const reason = String(humanRequest.result.reason ?? 'The agent asked for a person');
        await step('DECISION', { decision: 'ESCALATE', reason });
        await this.finishRun(run.id, {
          status: 'COMPLETED',
          decision: 'ESCALATE',
          decisionReason: reason,
          latencyMs,
          provider: usedProvider.kind as AIProviderKind,
          model: completion.model,
        });
        return { status: 'escalated', runId: run.id, reason };
      }

      if (resolveRequest) {
        const reason = String(resolveRequest.result.reason ?? 'Issue resolved');
        // Write the reply message and resolve the conversation in one transaction
        const resolved = await this.prisma.$transaction(async (tx) => {
          const current = await tx.conversation.findUnique({
            where: { id: job.conversationId },
            select: { mode: true },
          });
          if (current?.mode !== 'AI') return null;

          const message = await tx.message.create({
            data: {
              organizationId: job.organizationId,
              projectId: job.projectId,
              conversationId: job.conversationId,
              channel: conversation.channel,
              direction: 'OUTBOUND',
              authorType: 'AI',
              body: answer || reason,
              deliveryStatus: 'PENDING',
              metadata: { aiRunId: run.id } as object,
            },
            select: { id: true },
          });

          await tx.conversation.update({
            where: { id: job.conversationId },
            data: {
              lastMessageAt: new Date(),
              messageCount: { increment: 1 },
              status: 'RESOLVED',
              resolvedAt: new Date(),
            },
          });

          return message;
        });

        if (!resolved) {
          await step('DECISION', { decision: 'NO_ACTION', reason: 'Human took over mid-run' });
          await this.finishRun(run.id, {
            status: 'ABORTED',
            decision: 'NO_ACTION',
            decisionReason: 'A human took over while this run was in flight',
            latencyMs,
            provider: usedProvider.kind as AIProviderKind,
            model: completion.model,
          });
          return { status: 'skipped', reason: 'Human took over mid-run' };
        }

        await step('DECISION', { decision: 'RESOLVE', reason });
        await this.finishRun(run.id, {
          status: 'COMPLETED',
          decision: 'RESOLVE',
          decisionReason: reason,
          latencyMs,
          provider: usedProvider.kind as AIProviderKind,
          model: completion.model,
          responseMessageId: resolved.id,
        });
        return { status: 'resolved', runId: run.id, messageId: resolved.id };
      }

      if (!answer) {
        await step('DECISION', { decision: 'ESCALATE', reason: 'Model produced no answer' });
        await this.finishRun(run.id, {
          status: 'COMPLETED',
          decision: 'ESCALATE',
          decisionReason: 'The agent produced no answer',
          latencyMs,
          provider: usedProvider.kind as AIProviderKind,
          model: completion.model,
        });
        return { status: 'escalated', runId: run.id, reason: 'Model produced no answer' };
      }

      const decision = retrieved.length === 0 ? 'ASK_CLARIFICATION' : 'REPLY';

      // The mode is re-read inside the same transaction that writes the
      // message. Checking once at the start and trusting it is the race
      // that lets an AI reply land after a human took over (plan §10).
      const written = await this.prisma.$transaction(async (tx) => {
        const current = await tx.conversation.findUnique({
          where: { id: job.conversationId },
          select: { mode: true },
        });
        if (current?.mode !== 'AI') return null;

        const message = await tx.message.create({
          data: {
            organizationId: job.organizationId,
            projectId: job.projectId,
            conversationId: job.conversationId,
            channel: conversation.channel,
            direction: 'OUTBOUND',
            authorType: 'AI',
            body: answer,
            deliveryStatus: 'PENDING',
            metadata: { aiRunId: run.id } as object,
          },
          select: { id: true },
        });

        await tx.conversation.update({
          where: { id: job.conversationId },
          data: { lastMessageAt: new Date(), messageCount: { increment: 1 } },
        });

        return message;
      });

      if (!written) {
        await step('DECISION', { decision: 'NO_ACTION', reason: 'Human took over mid-run' });
        await this.finishRun(run.id, {
          status: 'ABORTED',
          decision: 'NO_ACTION',
          decisionReason: 'A human took over while this run was in flight',
          latencyMs,
          provider: usedProvider.kind as AIProviderKind,
          model: completion.model,
        });
        return { status: 'skipped', reason: 'Human took over mid-run' };
      }

      await step('DECISION', {
        decision,
        citations: retrieved.map((chunk) => chunk.documentTitle),
      });

      await this.finishRun(run.id, {
        status: 'COMPLETED',
        decision,
        decisionReason:
          decision === 'REPLY'
            ? `Answered from ${retrieved.length} knowledge source(s)`
            : 'No matching knowledge; asked the customer to clarify',
        latencyMs,
        provider: usedProvider.kind as AIProviderKind,
        model: completion.model,
        responseMessageId: written.id,
      });

      return { status: 'replied', runId: run.id, messageId: written.id };
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      await step('DECISION', { decision: 'ESCALATE', reason }, undefined, 'ERROR');
      await this.finishRun(run.id, {
        status: 'FAILED',
        decision: 'ESCALATE',
        decisionReason: 'The AI provider failed; handing to a person',
        errorMessage: reason.slice(0, 500),
        latencyMs: Date.now() - startedAt,
      });

      // The CRM never goes down because AI did (plan §20.9): a provider
      // outage becomes a conversation waiting for a human, not a lost one.
      return { status: 'failed', runId: run.id, reason };
    }
  }

  private async finishRun(
    runId: string,
    data: {
      status: 'COMPLETED' | 'FAILED' | 'ABORTED';
      decision: 'REPLY' | 'ASK_CLARIFICATION' | 'ESCALATE' | 'NO_ACTION' | 'RESOLVE';
      decisionReason: string;
      latencyMs: number;
      provider?: AIProviderKind;
      model?: string;
      errorMessage?: string;
      responseMessageId?: string;
    },
  ): Promise<void> {
    await this.prisma.aIRun.update({
      where: { id: runId },
      data: {
        status: data.status,
        decision: data.decision,
        decisionReason: data.decisionReason,
        latencyMs: data.latencyMs,
        errorMessage: data.errorMessage,
        responseMessageId: data.responseMessageId,
        finishedAt: new Date(),
        ...(data.provider ? { provider: data.provider } : {}),
        ...(data.model ? { model: data.model } : {}),
      },
    });
  }
}

function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string') : [];
}
