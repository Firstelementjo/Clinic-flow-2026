import { secretsMatch } from '@firstelement/auth';
import { ChannelType } from '@firstelement/shared';
import { capabilitiesFor } from '../capabilities';
import type {
  ConnectorCapabilities,
  MessagingConnector,
  NormalizedAttachment,
  NormalizedIncomingMessage,
  OutgoingMessage,
  SendResult,
} from '../types';

export interface TelegramCredentials {
  botToken: string;
  /**
   * Sent back by Telegram in `X-Telegram-Bot-Api-Secret-Token`. Telegram
   * does not sign payloads, so this shared token is the whole
   * authentication story — which is why it is compared in constant time
   * and why the webhook must be HTTPS.
   */
  webhookSecret: string;
}

/**
 * Telegram Bot API (plan §8: official API only).
 *
 * Differs from Meta in ways this adapter absorbs: no read receipts, edits
 * and deletes are supported, no session window, and chat ids are numeric
 * rather than opaque strings.
 */
export class TelegramConnector implements MessagingConnector {
  readonly channel = ChannelType.TELEGRAM;

  constructor(
    readonly connectionId: string,
    private readonly credentials: TelegramCredentials,
  ) {}

  capabilities(): ConnectorCapabilities {
    return capabilitiesFor(ChannelType.TELEGRAM);
  }

  async connect(): Promise<void> {}

  async disconnect(): Promise<void> {}

  async verifyWebhook(request: unknown): Promise<boolean> {
    const { headers } = request as { headers: Record<string, string | undefined> };
    const provided = headers['x-telegram-bot-api-secret-token'];
    if (!provided || !this.credentials.webhookSecret) return false;
    return secretsMatch(provided, this.credentials.webhookSecret);
  }

  async receiveWebhook(payload: unknown): Promise<NormalizedIncomingMessage[]> {
    const update = payload as TelegramUpdate;
    // Edited messages arrive as a separate field; treating an edit as a
    // new message would duplicate the turn, so only new ones are taken.
    const message = update?.message;
    if (!message?.chat) return [];

    const text = extractText(message);
    if (!text) return [];

    const from = message.from;
    const displayName = from
      ? [from.first_name, from.last_name].filter(Boolean).join(' ') || from.username
      : undefined;

    return [
      {
        channel: ChannelType.TELEGRAM,
        // Message ids are only unique per chat, so the chat id is part of
        // the identifier the idempotency constraint sees.
        externalMessageId: `${message.chat.id}:${message.message_id}`,
        externalUserId: String(message.chat.id),
        externalConversationId: String(message.chat.id),
        displayName,
        text,
        attachments: extractAttachments(message),
        sentAt: new Date(message.date * 1000),
        raw: message as unknown as Record<string, unknown>,
      },
    ];
  }

  async sendText(message: OutgoingMessage): Promise<SendResult> {
    try {
      const response = await fetch(
        `https://api.telegram.org/bot${this.credentials.botToken}/sendMessage`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: message.externalUserId,
            text: message.text,
          }),
          signal: AbortSignal.timeout(20_000),
        },
      );

      const body = (await response.json()) as {
        ok: boolean;
        description?: string;
        result?: { message_id: number; chat: { id: number } };
      };

      if (!response.ok || !body.ok) {
        return {
          ok: false,
          error: `Telegram send failed (${response.status}): ${body.description ?? 'unknown error'}`,
          retryable: response.status === 429 || response.status >= 500,
        };
      }

      return {
        ok: true,
        externalMessageId: body.result
          ? `${body.result.chat.id}:${body.result.message_id}`
          : undefined,
      };
    } catch (error) {
      return {
        ok: false,
        error: error instanceof Error ? error.message : String(error),
        retryable: true,
      };
    }
  }
}

interface TelegramUpdate {
  update_id?: number;
  message?: TelegramMessage;
  edited_message?: TelegramMessage;
}

interface TelegramMessage {
  message_id: number;
  date: number;
  chat: { id: number; type: string };
  from?: { first_name?: string; last_name?: string; username?: string };
  text?: string;
  caption?: string;
  photo?: { file_id: string }[];
  document?: { file_id: string; file_name?: string; mime_type?: string };
  voice?: { file_id: string; mime_type?: string };
  video?: { file_id: string; mime_type?: string };
  sticker?: { file_id: string; emoji?: string };
  location?: { latitude: number; longitude: number };
}

function extractText(message: TelegramMessage): string {
  if (message.text) return message.text;
  if (message.caption) return message.caption;
  if (message.sticker) return message.sticker.emoji ?? '[sticker]';
  if (message.location) {
    return `[location ${message.location.latitude}, ${message.location.longitude}]`;
  }
  if (message.photo) return '[photo]';
  if (message.voice) return '[voice]';
  if (message.video) return '[video]';
  if (message.document) return `[document ${message.document.file_name ?? ''}]`.trim();
  return '';
}

function extractAttachments(message: TelegramMessage): NormalizedAttachment[] {
  const attachments: NormalizedAttachment[] = [];

  // Telegram sends several sizes of the same photo; the last is largest.
  const photo = message.photo?.[message.photo.length - 1];
  if (photo) attachments.push({ type: 'image', url: photo.file_id });
  if (message.video) attachments.push({ type: 'video', url: message.video.file_id });
  if (message.voice) attachments.push({ type: 'audio', url: message.voice.file_id });
  if (message.sticker) attachments.push({ type: 'sticker', url: message.sticker.file_id });
  if (message.document) {
    attachments.push({
      type: 'document',
      url: message.document.file_id,
      fileName: message.document.file_name,
      mimeType: message.document.mime_type,
    });
  }
  if (message.location) attachments.push({ type: 'location' });

  return attachments;
}
