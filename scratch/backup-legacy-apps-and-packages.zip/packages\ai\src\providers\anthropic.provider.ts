import {
  AIProviderError,
  type AIProvider,
  type ChatMessage,
  type CompletionRequest,
  type CompletionResult,
} from './types';

interface AnthropicResponse {
  content: (
    | { type: 'text'; text: string }
    | { type: 'tool_use'; id: string; name: string; input: Record<string, unknown> }
  )[];
  usage?: { input_tokens: number; output_tokens: number };
  model: string;
  stop_reason: string | null;
}

/**
 * Anthropic Messages API over REST.
 *
 * Two shape differences from OpenAI that this adapter absorbs so the
 * orchestrator never sees them: system instructions are a top-level
 * parameter rather than a message, and tool results are user-role content
 * blocks rather than a distinct role.
 */
export class AnthropicProvider implements AIProvider {
  readonly kind = 'ANTHROPIC' as const;
  readonly defaultModel: string;

  constructor(
    private readonly apiKey: string,
    options: { model?: string; baseUrl?: string; timeoutMs?: number } = {},
  ) {
    this.defaultModel = options.model ?? 'claude-sonnet-5';
    this.baseUrl = options.baseUrl ?? 'https://api.anthropic.com/v1';
    this.timeoutMs = options.timeoutMs ?? 60_000;
  }

  private readonly baseUrl: string;
  private readonly timeoutMs: number;

  async generate(request: CompletionRequest): Promise<CompletionResult> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);
    const model = request.model ?? this.defaultModel;

    const system = request.messages
      .filter((message) => message.role === 'system')
      .map((message) => message.content)
      .join('\n\n');

    try {
      const response = await fetch(`${this.baseUrl}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': this.apiKey,
          'anthropic-version': '2023-06-01',
        },
        signal: controller.signal,
        body: JSON.stringify({
          model,
          system: system || undefined,
          temperature: request.temperature,
          max_tokens: request.maxTokens,
          messages: toAnthropicMessages(request.messages),
          ...(request.tools?.length
            ? {
                tools: request.tools.map((tool) => ({
                  name: tool.name,
                  description: tool.description,
                  input_schema: tool.parameters,
                })),
              }
            : {}),
        }),
      });

      if (!response.ok) {
        const body = await response.text().catch(() => '');
        throw new AIProviderError(
          this.kind,
          `Anthropic request failed (${response.status}): ${body.slice(0, 300)}`,
          response.status === 429 || response.status >= 500,
          response.status,
        );
      }

      const payload = (await response.json()) as AnthropicResponse;

      const text = payload.content
        .filter((block): block is { type: 'text'; text: string } => block.type === 'text')
        .map((block) => block.text)
        .join('');

      const toolCalls = payload.content
        .filter(
          (block): block is { type: 'tool_use'; id: string; name: string; input: Record<string, unknown> } =>
            block.type === 'tool_use',
        )
        .map((block) => ({ id: block.id, name: block.name, arguments: block.input }));

      return {
        text,
        toolCalls,
        usage: {
          inputTokens: payload.usage?.input_tokens ?? 0,
          outputTokens: payload.usage?.output_tokens ?? 0,
        },
        model: payload.model ?? model,
        finishReason:
          payload.stop_reason === 'tool_use'
            ? 'tool_calls'
            : payload.stop_reason === 'max_tokens'
              ? 'length'
              : 'stop',
      };
    } catch (error) {
      if (error instanceof AIProviderError) throw error;
      if (error instanceof Error && error.name === 'AbortError') {
        throw new AIProviderError(this.kind, 'Anthropic request timed out', true);
      }
      throw new AIProviderError(
        this.kind,
        error instanceof Error ? error.message : String(error),
        true,
      );
    } finally {
      clearTimeout(timeout);
    }
  }
}

function toAnthropicMessages(messages: ChatMessage[]): Record<string, unknown>[] {
  const out: Record<string, unknown>[] = [];

  for (const message of messages) {
    if (message.role === 'system') continue;

    if (message.role === 'tool') {
      out.push({
        role: 'user',
        content: [
          {
            type: 'tool_result',
            tool_use_id: message.toolCallId,
            content: message.content,
          },
        ],
      });
      continue;
    }

    out.push({ role: message.role, content: message.content });
  }

  return out;
}
