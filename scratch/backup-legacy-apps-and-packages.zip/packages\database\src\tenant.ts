/**
 * Tenant scoping primitives (plan §6).
 *
 * The rule these enforce: a `projectId` arriving from a client is a
 * *request*, never an authorization. It must be checked against the
 * caller's resolved membership before it reaches a query, and the query
 * must additionally carry `organizationId` so that a bug in membership
 * resolution still cannot cross an organization boundary.
 */

import type { UserRole } from '@firstelement/shared';

export interface TenantContext {
  organizationId: string;
  userId: string;
  /**
   * Typed as the shared `UserRole` rather than as a second, hand-written union
   * of role literals. That duplication was the trap: a third role added to
   * `UserRole` reached the Prisma enum and `packages/auth` while this interface
   * still admitted only two, so every place that builds a `TenantContext` from a
   * session user failed to typecheck. The type is the single source of truth, so
   * the next role cannot be added in three places and forgotten in the fourth.
   */
  role: UserRole;
  /** Resolved server-side from membership (ADMIN: every project in the org). */
  projectIds: readonly string[];
}

export class TenantAccessError extends Error {
  readonly code = 'FORBIDDEN' as const;

  constructor(
    message: string,
    readonly context: { organizationId: string; userId: string; projectId?: string },
  ) {
    super(message);
    this.name = 'TenantAccessError';
  }
}

export function canAccessProject(ctx: TenantContext, projectId: string): boolean {
  return ctx.projectIds.includes(projectId);
}

/**
 * Returns a where-fragment pinned to both tenant columns. Callers spread
 * it into every project-scoped query:
 *
 *   prisma.conversation.findMany({ where: { ...projectScope(ctx, id), status } })
 */
export function projectScope(
  ctx: TenantContext,
  projectId: string,
): { organizationId: string; projectId: string } {
  if (!canAccessProject(ctx, projectId)) {
    throw new TenantAccessError('Project is not accessible to this user', {
      organizationId: ctx.organizationId,
      userId: ctx.userId,
      projectId,
    });
  }
  return { organizationId: ctx.organizationId, projectId };
}

/** Scope for org-level (not project-scoped) tables. */
export function organizationScope(ctx: TenantContext): { organizationId: string } {
  return { organizationId: ctx.organizationId };
}

/**
 * Scope for reads that span "all projects I can see" — the unified inbox,
 * global search, dashboard rollups. Never falls back to an unfiltered
 * query: a user with no memberships must see nothing, not everything.
 */
export function accessibleProjectsScope(ctx: TenantContext): {
  organizationId: string;
  projectId: { in: string[] };
} {
  return {
    organizationId: ctx.organizationId,
    projectId: { in: [...ctx.projectIds] },
  };
}
