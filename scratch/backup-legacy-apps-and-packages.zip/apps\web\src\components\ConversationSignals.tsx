import { useQuery } from '@tanstack/react-query';
import { Sparkline, StatusChip } from '@firstelement/ui';
import type { ConversationScoreView, EscalationView } from '@firstelement/shared';
import { api } from '../lib/api';
import { useT } from '../lib/i18n';

/**
 * The frustration history and, when there is one, the escalation that
 * came out of it.
 *
 * This is the pair an employee needs before reading the thread: how the
 * conversation has been trending, and why it landed on their desk.
 */
export function ConversationSignals({ conversationId }: { conversationId: string }) {
  const t = useT();

  const scores = useQuery({
    queryKey: ['conversation-scores', conversationId],
    queryFn: () => api.get<ConversationScoreView[]>(`/conversations/${conversationId}/scores`),
  });

  const escalations = useQuery({
    queryKey: ['conversation-escalations', conversationId],
    queryFn: () => api.get<EscalationView[]>(`/conversations/${conversationId}/escalations`),
  });

  const points = (scores.data ?? []).map((score) => ({ value: score.frustration }));
  const latest = scores.data?.[scores.data.length - 1];
  const escalation = escalations.data?.[0];

  if (points.length === 0 && !escalation) return null;

  return (
    <div className="flex flex-col gap-2">
      {points.length > 1 && (
        <div className="flex items-center gap-2">
          <span className="fe-eyebrow">{t('signals.frustration')}</span>
          <Sparkline points={points} threshold={70} label={t('signals.frustration')} />
          <span className="fe-mono text-xs text-slate" dir="ltr">
            {latest?.frustration ?? 0}
          </span>
          {latest?.intent && <StatusChip tone="neutral">{latest.intent}</StatusChip>}
        </div>
      )}

      {escalation && (
        <div className="rounded border border-escalation/40 bg-escalation-wash/50 p-2.5">
          <div className="mb-1 flex items-center gap-2">
            <StatusChip tone="escalated">{t('signals.escalated')}</StatusChip>
            <span className="text-xs text-ink-soft">{escalation.reason}</span>
          </div>
          {/* The handover summary: what an employee reads before the thread. */}
          {escalation.summary && (
            <p className="whitespace-pre-wrap text-xs text-slate">{escalation.summary}</p>
          )}
        </div>
      )}
    </div>
  );
}
