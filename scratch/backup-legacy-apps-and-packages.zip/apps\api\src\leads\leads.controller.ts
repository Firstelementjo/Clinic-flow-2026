import { Query, Controller, Get, Post, Patch, Delete, Param, Body, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { Tenant, RequirePermissions } from '../auth/decorators';
import type { TenantContext } from '@firstelement/database';
import { Permission } from '@firstelement/auth';
import { LeadsService } from './leads.service';

@Controller(['leads', 'follow-ups'])
@UseGuards(AuthGuard)
export class LeadsController {
  constructor(private readonly leadsService: LeadsService) {}

  @Get()
  @RequirePermissions(Permission.LEAD_READ)
  async list(
    @Tenant() ctx: TenantContext,
    @Query('projectId') projectId?: string,
    @Query('search') search?: string,
  ) {
    return this.leadsService.list(ctx, projectId, search);
  }

  @Get(':id')
  @RequirePermissions(Permission.LEAD_READ)
  async get(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.leadsService.getById(ctx, id);
  }

  @Post()
  @RequirePermissions(Permission.LEAD_CREATE)
  async create(
    @Tenant() ctx: TenantContext,
    @Body() body: {
      name: string;
      company?: string;
      jobTitle?: string;
      email?: string;
      phone?: string;
      source?: string;
      status?: string;
      industry?: string;
      leadScore?: number;
      priority?: string;
      estimatedValue?: number;
      ownerId?: string;
      customerId?: string;
      ticketNumber?: string;
      ticketDate?: string;
      followUpDate?: string;
      tags?: string[];
      notes?: string;
    },
  ) {
    return this.leadsService.create(ctx, body);
  }

  @Patch(':id')
  @RequirePermissions(Permission.LEAD_UPDATE)
  async update(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body() body: {
      name?: string;
      company?: string;
      jobTitle?: string;
      email?: string;
      phone?: string;
      source?: string;
      status?: string;
      industry?: string;
      leadScore?: number;
      priority?: string;
      estimatedValue?: number;
      ownerId?: string;
      customerId?: string;
      ticketNumber?: string;
      ticketDate?: string;
      followUpDate?: string;
      tags?: string[];
      notes?: string;
    },
  ) {
    return this.leadsService.update(ctx, id, body);
  }

  @Post(':id/convert')
  @RequirePermissions(Permission.LEAD_CONVERT)
  async convertToCustomer(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body('customerName') customerName?: string,
  ) {
    return this.leadsService.convertToCustomer(ctx, id, customerName);
  }

  @Delete(':id')
  @RequirePermissions(Permission.LEAD_DELETE)
  async delete(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.leadsService.delete(ctx, id);
  }
}