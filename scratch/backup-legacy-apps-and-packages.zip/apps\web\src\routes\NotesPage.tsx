import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { CalendarClock, FileText, Link2, MoreHorizontal, Trash2, Type, UserRound } from 'lucide-react';
import { useDirection } from '@firstelement/ui';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import { useSession } from '../lib/session';
import { CreateNoteDrawer } from '../components/notes-form';
import { useCrmViews } from '../lib/views';
import {
  ListView,
  ListBadge,
  Menu,
  MenuItem,
  RecordAvatar,
  type ListColumn,
} from '../components/ListView';

interface ProjectNote {
  id: string;
  projectId: string;
  resourceType: string;
  resourceId: string;
  body: string;
  author: { id: string; fullName: string } | null;
  createdAt: string;
}

const RESOURCE_LABEL: Record<string, StringKey> = {
  ACCOUNT: 'notes.resource.ACCOUNT',
  LEAD: 'notes.resource.LEAD',
  DEAL: 'notes.resource.DEAL',
  TASK: 'notes.resource.TASK',
  CUSTOMER: 'notes.resource.CUSTOMER',
  CONVERSATION: 'notes.resource.CONVERSATION',
};

function firstLine(body: string): string {
  const line = body
    .split('\n')
    .map((part) => part.trim())
    .find(Boolean);
  return line ?? body.trim();
}

export function NotesPage() {
  const t = useT();
  const dir = useDirection();
  const qc = useQueryClient();
  const session = useSession();
  const projectId = session.data?.projectIds?.[0];
  const views = useCrmViews('note', { noun: t('notes.list.title'), defaultSort: 'createdAt' });
  const [createOpen, setCreateOpen] = useState(false);
  const location = useLocation();
  const nav = useNavigate();
  useEffect(() => {
    if (new URLSearchParams(location.search).get('new') === '1') {
      setCreateOpen(true);
      nav(location.pathname, { replace: true });
    }
  }, [location.search, nav]);

  const notes = useQuery({
    queryKey: ['notes', 'project', projectId ?? ''],
    queryFn: () => api.get<ProjectNote[]>(`/notes/project?projectId=${projectId}`),
    enabled: Boolean(projectId),
  });

  const deleteNote = useMutation({
    mutationFn: (id: string) => api.delete(`/notes/${id}?projectId=${projectId}`),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['notes', 'project', projectId ?? ''] }),
  });

  const deleteManyNotes = useMutation({
    mutationFn: async (ids: string[]) => {
      await Promise.all(ids.map((id) => api.delete(`/notes/${id}?projectId=${projectId}`)));
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['notes', 'project', projectId ?? ''] }),
  });

  const titleCell = (note: ProjectNote) => (
    <button type="button" tabIndex={-1} className="flex min-w-0 max-w-full items-center gap-2 text-start">
      <RecordAvatar name={note.body} />
      <span className="truncate text-sm font-medium text-ink">{firstLine(note.body)}</span>
    </button>
  );

  const relationsCell = (note: ProjectNote) => (
    <span className="flex min-w-0 items-center gap-1">
      <ListBadge>{t(RESOURCE_LABEL[note.resourceType] ?? 'list.col.relations')}</ListBadge>
      <span className="fe-mono truncate text-2xs text-slate-soft">{note.resourceId.slice(0, 6)}</span>
    </span>
  );

  const columns: ListColumn<ProjectNote>[] = [
    { id: 'title', label: 'list.col.title', icon: Type, size: 'minmax(11rem, 3fr)', render: titleCell },
    { id: 'relations', label: 'list.col.relations', icon: Link2, size: 'minmax(8rem, 1.5fr)', render: relationsCell },
    {
      id: 'body',
      label: 'list.col.body',
      icon: FileText,
      size: 'minmax(10rem, 2fr)',
      render: (note) => (
        <p className="max-w-full truncate whitespace-nowrap text-xs text-slate" title={note.body}>
          {note.body}
        </p>
      ),
    },
    {
      id: 'author',
      label: 'list.col.createdBy',
      icon: UserRound,
      size: 'minmax(6rem, 1.25fr)',
      render: (note) => note.author?.fullName ?? null,
    },
    {
      id: 'createdAt',
      label: 'list.col.created',
      icon: CalendarClock,
      size: '7rem',
      render: (note) => formatDate(note.createdAt, dir.locale),
    },
  ];

  return (
    <>
      <ListView<ProjectNote>
        title={t('notes.list.title')}
        eyebrow={t('notes.list.eyebrow')}
        addLabel={t('list.newNote')}
        onAdd={() => setCreateOpen(true)}
        noun={t('notes.list.title')}
        objectType="notes"
        columns={columns}
        rows={notes.data}
        isPending={notes.isPending}
        isError={notes.isError}
        keyOf={(n) => n.id}
        viewSwitcher={views.switcher}
        hiddenColumns={views.hidden}
        onHiddenColumnsChange={views.setHidden}
        onDeleteSelected={(ids) => deleteManyNotes.mutate(ids)}
        footerCells={[]}
        rowActions={(note) => (
          <Menu
            button={
              <span
                aria-label={t('list.options')}
                role="img"
                className="flex h-6 w-6 items-center justify-center rounded text-slate-soft transition-colors hover:bg-mist hover:text-ink"
              >
                <MoreHorizontal className="h-4 w-4" />
              </span>
            }
          >
            <MenuItem danger icon={Trash2} label={t('companies.delete')} onClick={() => deleteNote.mutate(note.id)} />
          </Menu>
        )}
      />
      {projectId ? (
        <CreateNoteDrawer open={createOpen} onClose={() => setCreateOpen(false)} projectId={projectId} />
      ) : null}
    </>
  );
}