import { Module } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { ViewsService } from './views.service';
import { ViewsController } from './views.controller';

@Module({
  providers: [ViewsService, PrismaService],
  controllers: [ViewsController],
  exports: [ViewsService],
})
export class ViewsModule {}