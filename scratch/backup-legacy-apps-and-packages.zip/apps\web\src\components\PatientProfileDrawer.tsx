import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  Calendar,
  CalendarClock,
  CalendarDays,
  CheckCircle2,
  Clock,
  ExternalLink,
  Globe,
  Mail,
  MessageCircle,
  MessageSquare,
  Phone,
  Plus,
  ShieldCheck,
  Stethoscope,
  Ticket,
  User,
  X,
  AlertTriangle,
  HeartPulse,
  Activity,
  Shield,
  FileText,
  Pill,
  Droplet,
  Edit3,
  Check,
  Sparkles,
} from 'lucide-react';
import {
  useCustomer,
  useUpdateCustomerMedical,
  type CustomerDetail,
  type PatientMedicalProfile,
} from '../lib/customers';
import { useT } from '../lib/i18n';
import { formatDate } from '../lib/format';
import { NotesSection } from './NotesSection';
import { Spinner, Button, useDirection } from '@firstelement/ui';

export interface PatientProfileDrawerProps {
  customerId: string | null;
  onClose: () => void;
  onBookAppointment?: (customer: CustomerDetail) => void;
  onScheduleFollowUp?: (customer: CustomerDetail) => void;
}

type ProfileTab = 'overview' | 'medical' | 'appointments' | 'followups' | 'conversations' | 'notes';

const PRESET_ALLERGIES = [
  'Penicillin',
  'Latex',
  'Aspirin',
  'Sulfa Drugs',
  'Local Anesthesia',
  'NSAIDs',
  'Iodine',
  'Codeine',
];

const PRESET_CHRONIC = [
  'Type II Diabetes',
  'Hypertension',
  'Asthma',
  'Cardiovascular Disease',
  'Bleeding Disorder',
  'Kidney Disease',
  'Epilepsy',
  'Thyroid Disorder',
];

const INSURANCE_PROVIDERS = [
  'Bupa Arabia',
  'Tawuniya (التعاونية)',
  'Medgulf (ميدغلف)',
  'Cigna Healthcare',
  'Al Rajhi Takaful',
  'Malath Insurance',
  'AXA / GIG Gulf',
  'Self-Pay / Cash',
];

const NETWORK_CLASSES = ['VIP Gold', 'VIP Silver', 'Class A', 'Class B', 'Class C', 'Standard'];

function getInitials(name: string): string {
  if (!name) return 'PT';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
}

function getAvatarColor(name: string): string {
  const colors = [
    'from-teal-600 to-emerald-700',
    'from-blue-600 to-indigo-700',
    'from-cyan-600 to-teal-700',
    'from-emerald-600 to-teal-800',
    'from-sky-600 to-blue-700',
  ];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length]!;
}

export function PatientProfileDrawer({
  customerId,
  onClose,
  onBookAppointment,
  onScheduleFollowUp,
}: PatientProfileDrawerProps) {
  const t = useT();
  const { locale } = useDirection();
  const isAr = locale === 'ar';

  const [activeTab, setActiveTab] = useState<ProfileTab>('overview');
  const [medicalModalOpen, setMedicalModalOpen] = useState(false);

  const customerQuery = useCustomer(customerId || undefined);
  const customer = customerQuery.data;

  if (!customerId) return null;

  const initials = customer ? getInitials(customer.displayName) : 'PT';
  const avatarGradient = customer ? getAvatarColor(customer.displayName) : 'from-teal-600 to-emerald-700';

  const medical = customer?.metadata?.medical as PatientMedicalProfile | undefined;
  const allergies = medical?.allergies || [];
  const chronicConditions = medical?.chronicConditions || [];
  const insurance = medical?.insurance;
  const intake = medical?.intake;
  const bloodType = medical?.bloodType;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-ink/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      <div className="fixed inset-y-0 end-0 flex max-w-full">
        <div className="relative w-screen max-w-2xl bg-surface border-s border-hairline shadow-2xl flex flex-col">
          {/* Top Banner & Header */}
          <div className="relative bg-gradient-to-r from-[#0f5b4c] to-[#15803d] p-6 text-white shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="absolute top-4 end-4 rounded-full bg-white/10 p-1.5 text-white/80 hover:bg-white/20 hover:text-white transition-colors"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>

            {customerQuery.isPending ? (
              <div className="flex h-24 items-center justify-center">
                <Spinner label={t('common.loading')} />
              </div>
            ) : customer ? (
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                {/* Large Profile Avatar */}
                <div
                  className={`h-16 w-16 rounded-2xl bg-gradient-to-br ${avatarGradient} flex items-center justify-center text-white text-xl font-bold font-mono shadow-md border-2 border-white/20 shrink-0`}
                >
                  {initials}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-white tracking-tight truncate">
                      {customer.displayName}
                    </h2>
                    <span className="rounded bg-white/20 px-2 py-0.5 font-mono text-xs font-semibold text-white/90">
                      {customer.cxId}
                    </span>
                    {bloodType && (
                      <span className="inline-flex items-center gap-1 rounded bg-red-500/30 border border-red-300/40 px-2 py-0.5 text-xs font-bold text-white">
                        <Droplet className="h-3 w-3 fill-current text-red-200" />
                        {bloodType}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-white/80 mt-1 flex items-center gap-2">
                    <span>{isAr ? 'الملف الطبي للمريض' : 'Patient Medical Profile'}</span>
                    <span>·</span>
                    <span>{isAr ? 'مسجل منذ' : 'Registered'} {new Date(customer.firstSeenAt).toLocaleDateString()}</span>
                  </p>

                  {/* Top Action Buttons */}
                  <div className="flex flex-wrap items-center gap-2 mt-3">
                    <button
                      type="button"
                      onClick={() => onBookAppointment && onBookAppointment(customer)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-white px-3 py-1.5 text-xs font-semibold text-[#0f5b4c] shadow-xs hover:bg-white/90 transition-colors"
                    >
                      <CalendarDays className="h-3.5 w-3.5" />
                      <span>{t('appointments.new')}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setMedicalModalOpen(true)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-white/30 bg-white/10 px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/20 transition-colors"
                    >
                      <HeartPulse className="h-3.5 w-3.5" />
                      <span>{isAr ? 'تعديل الملف الطبي والتأمين' : 'Edit Medical & Insurance'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onScheduleFollowUp && onScheduleFollowUp(customer)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-white/30 bg-white/10 px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/20 transition-colors"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>{isAr ? 'متابعة' : 'Follow-up'}</span>
                    </button>

                    {customer.conversations.length > 0 && (
                      <Link
                        to={`/app/inbox?conversationId=${customer.conversations[0]?.id}`}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-white/30 bg-white/10 px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/20 transition-colors"
                      >
                        <MessageCircle className="h-3.5 w-3.5" />
                        <span>Chat in Inbox</span>
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          {/* CRITICAL MEDICAL ALERT BANNER (If allergies recorded) */}
          {allergies.length > 0 && (
            <div className="bg-red-500/10 border-b border-red-500/20 px-6 py-3 flex items-start gap-3 text-red-900 dark:text-red-200">
              <AlertTriangle className="h-5 w-5 text-red-600 shrink-0 mt-0.5 animate-pulse" />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-2xs font-extrabold tracking-wider uppercase text-red-700 dark:text-red-400">
                    {isAr ? 'تنبيه حساسية دوائية حرجة' : 'CRITICAL ALLERGY ALERT'}
                  </span>
                  <span className="rounded bg-red-600 px-1.5 py-0.2 text-[10px] font-extrabold text-white">
                    CONTRAINDICATION
                  </span>
                </div>
                <p className="text-xs font-bold text-red-950 dark:text-red-100 mt-0.5">
                  {isAr ? 'يعاني المريض من حساسية تجاه:' : 'Patient has recorded allergy to:'}{' '}
                  <span className="underline">{allergies.join(', ')}</span>
                </p>
                <p className="text-3xs text-red-800/80 dark:text-red-300 mt-0.5">
                  {isAr
                    ? 'يجب على الطبيب المعالج والذكاء الاصطناعي مراجعة المواد قبل وصف المضادات أو استخدام التخدير الموضعي.'
                    : 'Attending clinician must confirm contraindications before prescribing medication or local anesthesia.'}
                </p>
              </div>
            </div>
          )}

          {/* Navigation Tabs */}
          <div className="flex border-b border-hairline bg-surface px-6 overflow-x-auto shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('overview')}
              className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
                activeTab === 'overview'
                  ? 'border-[#0f5b4c] text-[#0f5b4c]'
                  : 'border-transparent text-slate-soft hover:text-ink'
              }`}
            >
              {isAr ? 'نظرة عامة والاتصال' : 'Overview & Contact'}
            </button>

            {/* Dedicated Medical & Insurance Tab */}
            <button
              type="button"
              onClick={() => setActiveTab('medical')}
              className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'medical'
                  ? 'border-[#0f5b4c] text-[#0f5b4c]'
                  : 'border-transparent text-slate-soft hover:text-ink'
              }`}
            >
              <HeartPulse className="h-3.5 w-3.5 text-red-500" />
              <span>{isAr ? 'الملف الطبي والتأمين' : 'Medical & Insurance'}</span>
              {allergies.length > 0 && (
                <span className="rounded-full bg-red-500 text-white px-1.5 py-0.2 text-[10px] font-bold">
                  {allergies.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('appointments')}
              className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'appointments'
                  ? 'border-[#0f5b4c] text-[#0f5b4c]'
                  : 'border-transparent text-slate-soft hover:text-ink'
              }`}
            >
              <span>{t('appointments.title')}</span>
              {customer?.appointments && customer.appointments.length > 0 && (
                <span className="rounded-full bg-[#0f5b4c]/10 text-[#0f5b4c] px-1.5 py-0.2 text-[10px] font-mono">
                  {customer.appointments.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('followups')}
              className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'followups'
                  ? 'border-[#0f5b4c] text-[#0f5b4c]'
                  : 'border-transparent text-slate-soft hover:text-ink'
              }`}
            >
              <span>{isAr ? 'المتابعات والتذاكر' : 'Follow-ups & Tickets'}</span>
              {customer?.leads && customer.leads.length > 0 && (
                <span className="rounded-full bg-signal/10 text-signal px-1.5 py-0.2 text-[10px] font-mono">
                  {customer.leads.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('conversations')}
              className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'conversations'
                  ? 'border-[#0f5b4c] text-[#0f5b4c]'
                  : 'border-transparent text-slate-soft hover:text-ink'
              }`}
            >
              <span>{isAr ? 'المحادثات' : 'Conversations'}</span>
              {customer?.conversations && customer.conversations.length > 0 && (
                <span className="rounded-full bg-slate-soft/10 text-slate px-1.5 py-0.2 text-[10px] font-mono">
                  {customer.conversations.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('notes')}
              className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
                activeTab === 'notes'
                  ? 'border-[#0f5b4c] text-[#0f5b4c]'
                  : 'border-transparent text-slate-soft hover:text-ink'
              }`}
            >
              {isAr ? 'الملاحظات السريرية' : 'Clinical Notes'}
            </button>
          </div>

          {/* Tab Contents */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {customer && (
              <>
                {/* 1. OVERVIEW & CONTACT */}
                {activeTab === 'overview' && (
                  <div className="space-y-6">
                    {/* Quick Medical Summary Cards */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {/* Blood Group */}
                      <div className="rounded-xl border border-hairline bg-surface-raised p-3.5 space-y-1">
                        <span className="text-[11px] font-medium text-slate-soft flex items-center gap-1.5">
                          <Droplet className="h-3.5 w-3.5 text-red-500" />
                          {isAr ? 'فصيلة الدم' : 'Blood Group'}
                        </span>
                        <p className="font-mono text-base font-bold text-ink">
                          {bloodType || (isAr ? 'غير محددة' : 'Not Recorded')}
                        </p>
                      </div>

                      {/* Allergies Count */}
                      <div className="rounded-xl border border-hairline bg-surface-raised p-3.5 space-y-1">
                        <span className="text-[11px] font-medium text-slate-soft flex items-center gap-1.5">
                          <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
                          {isAr ? 'حساسية مسجلة' : 'Known Allergies'}
                        </span>
                        <p className="text-base font-bold text-ink">
                          {allergies.length > 0 ? (
                            <span className="text-red-600 font-bold">{allergies.length} {isAr ? 'حساسيات' : 'Recorded'}</span>
                          ) : (
                            <span className="text-emerald-600 font-medium text-xs">{isAr ? 'لا توجد (NKDA)' : 'None (NKDA)'}</span>
                          )}
                        </p>
                      </div>

                      {/* Insurance Status */}
                      <div className="rounded-xl border border-hairline bg-surface-raised p-3.5 space-y-1">
                        <span className="text-[11px] font-medium text-slate-soft flex items-center gap-1.5">
                          <ShieldCheck className="h-3.5 w-3.5 text-teal-600" />
                          {isAr ? 'التغطية التأمينية' : 'Insurance'}
                        </span>
                        <p className="text-xs font-bold text-ink truncate">
                          {insurance?.provider ? (
                            <span>{insurance.provider} ({insurance.networkClass || 'Active'})</span>
                          ) : (
                            <span className="text-slate-soft font-normal">{isAr ? 'دفع نقدي / شخصي' : 'Self-Pay'}</span>
                          )}
                        </p>
                      </div>
                    </div>

                    {/* Contact Cards */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="rounded-xl border border-hairline bg-surface-raised p-4 space-y-1">
                        <span className="text-[11px] font-medium text-slate-soft flex items-center gap-1.5">
                          <Phone className="h-3.5 w-3.5 text-[#0f5b4c]" />
                          {isAr ? 'رقم الجوال' : 'Phone Number'}
                        </span>
                        <p className="font-mono text-sm font-semibold text-ink">
                          {customer.primaryPhone || '—'}
                        </p>
                        {customer.primaryPhone && (
                          <div className="flex items-center gap-2 pt-1 text-xs">
                            <a
                              href={`tel:${customer.primaryPhone}`}
                              className="text-signal hover:underline"
                            >
                              Call
                            </a>
                            <span className="text-slate-soft">·</span>
                            <a
                              href={`https://wa.me/${customer.primaryPhone.replace(/\D/g, '')}`}
                              target="_blank"
                              rel="noreferrer"
                              className="text-emerald-600 hover:underline"
                            >
                              WhatsApp
                            </a>
                          </div>
                        )}
                      </div>

                      <div className="rounded-xl border border-hairline bg-surface-raised p-4 space-y-1">
                        <span className="text-[11px] font-medium text-slate-soft flex items-center gap-1.5">
                          <Mail className="h-3.5 w-3.5 text-signal" />
                          {isAr ? 'البريد الإلكتروني' : 'Email Address'}
                        </span>
                        <p className="font-mono text-sm font-semibold text-ink truncate">
                          {customer.primaryEmail || '—'}
                        </p>
                        {customer.primaryEmail && (
                          <a
                            href={`mailto:${customer.primaryEmail}`}
                            className="inline-block pt-1 text-xs text-signal hover:underline"
                          >
                            Send Email
                          </a>
                        )}
                      </div>

                      <div className="rounded-xl border border-hairline bg-surface-raised p-4 space-y-1">
                        <span className="text-[11px] font-medium text-slate-soft flex items-center gap-1.5">
                          <Globe className="h-3.5 w-3.5 text-amber-600" />
                          {isAr ? 'اللغة المفضلة' : 'Language Preference'}
                        </span>
                        <p className="text-sm font-semibold text-ink">
                          {customer.locale === 'ar' ? 'العربية (Arabic)' : 'English'}
                        </p>
                      </div>

                      <div className="rounded-xl border border-hairline bg-surface-raised p-4 space-y-1">
                        <span className="text-[11px] font-medium text-slate-soft flex items-center gap-1.5">
                          <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
                          {isAr ? 'القنوات النشطة' : 'Active Channels'}
                        </span>
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {customer.identities.length > 0 ? (
                            customer.identities.map((id) => (
                              <span
                                key={id.id}
                                className="rounded px-2 py-0.5 bg-surface border border-hairline text-xs font-mono font-medium text-ink"
                              >
                                {id.platform}
                              </span>
                            ))
                          ) : (
                            <span className="text-xs text-slate-soft">Web / Clinic Direct</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Next Appointment Alert Card if available */}
                    {customer.appointments && customer.appointments.length > 0 && (
                      <div className="rounded-xl border border-[#b2ded5] bg-[#f0faf7] p-4">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-[#0f5b4c] flex items-center gap-1.5">
                            <Stethoscope className="h-4 w-4" />
                            {isAr ? 'أحدث موعد' : 'Latest Appointment'}
                          </span>
                          <span className="rounded bg-[#0f5b4c] text-white px-2 py-0.5 text-[10px] font-semibold uppercase">
                            {customer.appointments[0]?.status}
                          </span>
                        </div>
                        <p className="text-sm font-bold text-ink mt-2">
                          {customer.appointments[0]?.title}
                        </p>
                        <p className="text-xs text-slate-soft mt-0.5 flex items-center gap-2">
                          <Clock className="h-3.5 w-3.5 text-[#0f5b4c]" />
                          <span>
                            {new Date(customer.appointments[0]?.appointmentDate || '').toLocaleString()}
                          </span>
                          <span>·</span>
                          <span>{customer.appointments[0]?.durationMinutes} min</span>
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* 2. DEDICATED MEDICAL & INSURANCE TAB */}
                {activeTab === 'medical' && (
                  <div className="space-y-6">
                    {/* Header Action inside Tab */}
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-base font-bold text-ink flex items-center gap-2">
                          <HeartPulse className="h-4 w-4 text-red-500" />
                          {isAr ? 'الملف الطبي المعتمد والبيانات السريرية' : 'Clinical Medical Profile & Insurance'}
                        </h3>
                        <p className="text-xs text-slate-soft mt-0.5">
                          {isAr
                            ? 'معلومات الحساسية الدوائية، الأمراض المزمنة، بطاقة التأمين الطبي، واستمارة الفحص الأولي'
                            : 'Patient allergies, chronic conditions, verified insurance policy, and intake history.'}
                        </p>
                      </div>

                      <Button
                        size="sm"
                        onClick={() => setMedicalModalOpen(true)}
                        className="flex items-center gap-1.5 bg-[#0f5b4c] text-white hover:bg-[#0c473b]"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                        {isAr ? 'تعديل البيانات' : 'Update Profile'}
                      </Button>
                    </div>

                    {/* Section 1: Allergies & Adverse Reactions */}
                    <div className="rounded-2xl border border-hairline bg-surface p-4 shadow-sm">
                      <div className="flex items-center justify-between pb-3 border-b border-hairline">
                        <span className="text-xs font-bold uppercase tracking-wider text-red-600 flex items-center gap-1.5">
                          <AlertTriangle className="h-4 w-4" />
                          {isAr ? 'الحساسية الدوائية والمواد (Allergies)' : 'Allergies & Contraindications'}
                        </span>
                        <span className="text-2xs text-slate-soft">
                          {allergies.length} {isAr ? 'مواد مسجلة' : 'allergens'}
                        </span>
                      </div>

                      <div className="mt-3">
                        {allergies.length === 0 ? (
                          <div className="flex items-center gap-2 rounded-xl bg-emerald-500/10 p-3 text-xs text-emerald-800 dark:text-emerald-300">
                            <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                            <span>
                              {isAr
                                ? 'لا توجد حساسية دوائية مسجلة حتى الآن (No Known Drug Allergies - NKDA).'
                                : 'No Known Drug Allergies (NKDA) recorded for this patient.'}
                            </span>
                          </div>
                        ) : (
                          <div className="flex flex-wrap gap-2">
                            {allergies.map((allergy) => (
                              <span
                                key={allergy}
                                className="inline-flex items-center gap-1.5 rounded-xl border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-xs font-bold text-red-800 dark:text-red-300 shadow-2xs"
                              >
                                <AlertTriangle className="h-3.5 w-3.5 text-red-600" />
                                {allergy}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Section 2: Chronic Conditions & Regular Medications */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Chronic Conditions */}
                      <div className="rounded-2xl border border-hairline bg-surface p-4 shadow-sm space-y-3">
                        <span className="text-xs font-bold uppercase tracking-wider text-amber-600 flex items-center gap-1.5">
                          <Activity className="h-4 w-4" />
                          {isAr ? 'الأمراض المزمنة' : 'Chronic Conditions'}
                        </span>

                        {chronicConditions.length === 0 ? (
                          <p className="text-xs text-slate-soft">
                            {isAr ? 'لا توجد أمراض مزمنة مسجلة.' : 'No chronic conditions recorded.'}
                          </p>
                        ) : (
                          <div className="flex flex-wrap gap-1.5">
                            {chronicConditions.map((cond) => (
                              <span
                                key={cond}
                                className="inline-flex items-center gap-1 rounded-lg border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-xs font-semibold text-amber-800 dark:text-amber-300"
                              >
                                <Activity className="h-3 w-3" />
                                {cond}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Regular Medications */}
                      <div className="rounded-2xl border border-hairline bg-surface p-4 shadow-sm space-y-3">
                        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 flex items-center gap-1.5">
                          <Pill className="h-4 w-4" />
                          {isAr ? 'الأدوية الحالية المستمرة' : 'Current Medications'}
                        </span>

                        {medical?.medications && medical.medications.length > 0 ? (
                          <div className="flex flex-wrap gap-1.5">
                            {medical.medications.map((med) => (
                              <span
                                key={med}
                                className="inline-flex items-center gap-1 rounded-lg border border-indigo-500/30 bg-indigo-500/10 px-2.5 py-1 text-xs font-medium text-indigo-800 dark:text-indigo-300"
                              >
                                <Pill className="h-3 w-3" />
                                {med}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <p className="text-xs text-slate-soft">
                            {isAr ? 'لا توجد أدوية دورية مسجلة.' : 'No regular medications recorded.'}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Section 3: Digital Health Insurance Card */}
                    <div className="rounded-2xl border border-hairline bg-surface p-5 shadow-sm space-y-3">
                      <div className="flex items-center justify-between pb-2 border-b border-hairline">
                        <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-300 flex items-center gap-1.5">
                          <Shield className="h-4 w-4" />
                          {isAr ? 'بطاقة التأمين الطبي الرقمية' : 'Digital Health Insurance Card'}
                        </span>
                        <span
                          className={`rounded-full px-2 py-0.5 text-2xs font-extrabold uppercase ${
                            insurance?.status === 'ACTIVE'
                              ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                              : 'bg-slate-500/10 text-slate-soft'
                          }`}
                        >
                          {insurance?.status || (isAr ? 'دفع نقدي' : 'Self-Pay')}
                        </span>
                      </div>

                      {insurance?.provider ? (
                        /* Realistic Health Card Visual Design */
                        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-teal-950 to-emerald-950 p-5 text-white shadow-xl border border-white/10">
                          {/* Background Glow & Watermark */}
                          <div className="absolute -right-8 -bottom-8 h-36 w-36 rounded-full bg-teal-500/10 blur-2xl pointer-events-none" />
                          <Shield className="absolute right-4 bottom-4 h-24 w-24 text-white/5 pointer-events-none" />

                          <div className="relative z-10 flex items-center justify-between">
                            <div>
                              <span className="text-2xs font-mono uppercase tracking-widest text-teal-300">
                                {isAr ? 'شبكة التأمين الطبي' : 'HEALTH INSURANCE NETWORK'}
                              </span>
                              <h4 className="text-lg font-bold tracking-tight text-white mt-0.5">
                                {insurance.provider}
                              </h4>
                            </div>
                            <span className="rounded-lg bg-teal-500/20 border border-teal-400/30 px-2.5 py-1 font-mono text-xs font-bold text-teal-200">
                              {insurance.networkClass || 'VIP Class'}
                            </span>
                          </div>

                          <div className="relative z-10 mt-6 grid grid-cols-2 gap-4 text-xs font-mono">
                            <div>
                              <span className="text-3xs uppercase tracking-wider text-white/60">
                                {isAr ? 'اسم حامل البطاقة' : 'Cardholder'}
                              </span>
                              <p className="font-bold text-white text-sm truncate mt-0.5">
                                {customer.displayName}
                              </p>
                            </div>

                            <div>
                              <span className="text-3xs uppercase tracking-wider text-white/60">
                                {isAr ? 'رقم العضوية' : 'Member ID'}
                              </span>
                              <p className="font-bold text-teal-200 text-sm mt-0.5">
                                {insurance.memberId || '—'}
                              </p>
                            </div>

                            <div>
                              <span className="text-3xs uppercase tracking-wider text-white/60">
                                {isAr ? 'رقم الوثيقة' : 'Policy No.'}
                              </span>
                              <p className="text-white/90 mt-0.5">
                                {insurance.policyNumber || '—'}
                              </p>
                            </div>

                            <div>
                              <span className="text-3xs uppercase tracking-wider text-white/60">
                                {isAr ? 'نسبة التحمل / الصلاحية' : 'Copay & Expiry'}
                              </span>
                              <p className="text-teal-300 font-semibold mt-0.5">
                                {insurance.copayPercentage}% · {insurance.expiryDate || 'Valid'}
                              </p>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="rounded-xl border border-dashed border-hairline p-6 text-center text-xs text-slate-soft">
                          <Shield className="mx-auto h-6 w-6 text-slate-soft/70 mb-1" />
                          <p>{isAr ? 'لا توجد وثيقة تأمين مسجلة. المريض مسجل كدفع نقدي مباشر.' : 'No insurance policy linked. Patient is listed as direct self-pay.'}</p>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => setMedicalModalOpen(true)}
                            className="mt-3 text-xs"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            {isAr ? 'إضافة بطاقة تأمين' : 'Add Insurance Policy'}
                          </Button>
                        </div>
                      )}
                    </div>

                    {/* Section 4: Pre-Visit Clinical Intake History */}
                    <div className="rounded-2xl border border-hairline bg-surface p-4 shadow-sm space-y-3">
                      <div className="flex items-center justify-between pb-2 border-b border-hairline">
                        <span className="text-xs font-bold uppercase tracking-wider text-slate-soft flex items-center gap-1.5">
                          <FileText className="h-4 w-4 text-teal-600" />
                          {isAr ? 'استمارة الفحص الأولي والتاريخ الطبي' : 'Pre-Visit Clinical Intake History'}
                        </span>
                        {intake?.lastIntakeDate && (
                          <span className="text-2xs text-slate-soft">
                            {isAr ? 'تاريخ التحديث:' : 'Updated:'} {intake.lastIntakeDate}
                          </span>
                        )}
                      </div>

                      <div className="space-y-3 text-xs">
                        <div>
                          <span className="font-semibold text-slate-soft text-2xs uppercase">
                            {isAr ? 'الشكوى الرئيسية (Chief Complaint):' : 'Chief Complaint:'}
                          </span>
                          <p className="mt-0.5 text-sm font-medium text-ink bg-surface-muted/40 p-2.5 rounded-xl border border-hairline/60">
                            {intake?.chiefComplaint || (isAr ? 'لم تسجل شكوى رئيسية بعد.' : 'No complaint recorded.')}
                          </p>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="rounded-xl border border-hairline/60 p-2.5">
                            <span className="font-semibold text-slate-soft text-2xs uppercase">
                              {isAr ? 'العمليات السابقة:' : 'Past Surgeries:'}
                            </span>
                            <p className="text-ink mt-0.5 font-medium">
                              {intake?.preExistingSurgeries || (isAr ? 'لا يوجد' : 'None')}
                            </p>
                          </div>

                          <div className="rounded-xl border border-hairline/60 p-2.5">
                            <span className="font-semibold text-slate-soft text-2xs uppercase">
                              {isAr ? 'التدخين:' : 'Smoking:'}
                            </span>
                            <p className="text-ink mt-0.5 font-medium">
                              {intake?.smokingStatus === 'SMOKER'
                                ? (isAr ? 'مدخن' : 'Smoker')
                                : intake?.smokingStatus === 'OCCASIONAL'
                                ? (isAr ? 'بشكل متقطع' : 'Occasional')
                                : (isAr ? 'غير مدخن' : 'Non-Smoker')}
                            </p>
                          </div>
                        </div>

                        {intake?.clinicalNotes && (
                          <div>
                            <span className="font-semibold text-slate-soft text-2xs uppercase">
                              {isAr ? 'ملاحظات الطبيب السريرية وتنبيهات الكادر:' : 'Clinical Alerts & Doctor Notes:'}
                            </span>
                            <p className="mt-1 text-xs text-amber-950 dark:text-amber-200 bg-amber-50/70 dark:bg-amber-950/20 p-2.5 rounded-xl border border-amber-500/20">
                              {intake.clinicalNotes}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. APPOINTMENTS TAB */}
                {activeTab === 'appointments' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-ink">
                        {isAr ? 'سجل المواعيد والزيارات' : 'Appointment History'}
                      </h3>
                      <button
                        type="button"
                        onClick={() => onBookAppointment && onBookAppointment(customer)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-[#0f5b4c] hover:underline"
                      >
                        <Plus className="h-3 w-3" />
                        <span>{t('appointments.new')}</span>
                      </button>
                    </div>

                    {!customer.appointments || customer.appointments.length === 0 ? (
                      <p className="text-xs text-slate-soft">
                        {isAr ? 'لا توجد مواعيد سابقة مسجلة لهذا المريض.' : 'No appointments recorded yet.'}
                      </p>
                    ) : (
                      <div className="space-y-2.5">
                        {customer.appointments.map((a) => (
                          <div
                            key={a.id}
                            className="rounded-xl border border-hairline bg-surface-raised p-4 transition-colors hover:border-[#0f5b4c]/30"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <h4 className="text-sm font-bold text-ink">{a.title}</h4>
                                <p className="text-xs text-slate-soft mt-0.5 flex items-center gap-1.5">
                                  <Stethoscope className="h-3 w-3 text-[#0f5b4c]" />
                                  <span>{a.doctorName || 'Doctor Assigned'}</span>
                                  {a.service && (
                                    <>
                                      <span>·</span>
                                      <span>{a.service}</span>
                                    </>
                                  )}
                                </p>
                              </div>
                              <span className="rounded bg-surface px-2 py-0.5 text-[10px] font-bold uppercase border border-hairline text-ink">
                                {a.status}
                              </span>
                            </div>

                            <div className="mt-3 pt-2 border-t border-hairline flex items-center justify-between text-xs text-slate-soft font-mono">
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3 text-[#0f5b4c]" />
                                {new Date(a.appointmentDate).toLocaleString()}
                              </span>
                              <span>{a.durationMinutes} min</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* 4. FOLLOW-UPS TAB */}
                {activeTab === 'followups' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-ink">Follow-ups & Tickets</h3>
                      <button
                        type="button"
                        onClick={() => onScheduleFollowUp && onScheduleFollowUp(customer)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-[#0f5b4c] hover:underline"
                      >
                        <Plus className="h-3 w-3" />
                        <span>Schedule Follow-up</span>
                      </button>
                    </div>

                    {!customer.leads || customer.leads.length === 0 ? (
                      <p className="text-xs text-slate-soft">No follow-ups recorded yet.</p>
                    ) : (
                      <div className="space-y-2.5">
                        {customer.leads.map((f) => (
                          <div
                            key={f.id}
                            className="rounded-xl border border-hairline bg-surface-raised p-4 transition-colors hover:border-signal/30"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <h4 className="text-sm font-bold text-ink">{f.name}</h4>
                                <div className="flex items-center gap-2 mt-1 text-xs font-mono">
                                  {f.ticketNumber && (
                                    <span className="text-signal font-semibold">
                                      Ticket: {f.ticketNumber}
                                    </span>
                                  )}
                                  {f.ticketDate && (
                                    <span className="text-slate-soft">
                                      · {new Date(f.ticketDate).toLocaleDateString()}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <span className="rounded bg-surface px-2 py-0.5 text-[10px] font-bold uppercase border border-hairline text-ink">
                                {f.status}
                              </span>
                            </div>

                            {f.followUpDate && (
                              <p className="text-xs text-slate-soft mt-2 pt-2 border-t border-hairline flex items-center gap-1.5 font-mono">
                                <CalendarClock className="h-3.5 w-3.5 text-signal" />
                                Scheduled: {new Date(f.followUpDate).toLocaleString()}
                              </p>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* 5. CONVERSATIONS TAB */}
                {activeTab === 'conversations' && (
                  <div className="space-y-3">
                    <h3 className="text-sm font-bold text-ink">Conversations & Inquiries</h3>
                    {customer.conversations.length === 0 ? (
                      <p className="text-xs text-slate-soft">No conversations recorded yet.</p>
                    ) : (
                      customer.conversations.map((conv) => (
                        <div
                          key={conv.id}
                          className="rounded-xl border border-hairline bg-surface-raised p-4 flex items-center justify-between"
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs font-bold text-signal">
                                {conv.ticketNumber}
                              </span>
                              <span className="rounded bg-surface px-1.5 py-0.2 text-[10px] font-mono border border-hairline">
                                {conv.channel}
                              </span>
                              <span className="text-xs text-slate-soft">
                                {conv.messageCount} messages
                              </span>
                            </div>
                            <p className="text-xs text-ink font-medium mt-1">
                              {conv.subject || 'Direct Inquiry'}
                            </p>
                            <p className="text-[11px] text-slate-soft mt-0.5">
                              Last active: {new Date(conv.lastMessageAt).toLocaleString()}
                            </p>
                          </div>

                          <Link
                            to={`/app/inbox?conversationId=${conv.id}`}
                            className="inline-flex items-center gap-1 rounded-lg bg-surface border border-hairline px-3 py-1 text-xs font-semibold text-ink hover:border-signal hover:text-signal transition-colors"
                          >
                            <span>Open</span>
                            <ExternalLink className="h-3 w-3" />
                          </Link>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* 6. CLINICAL NOTES TAB */}
                {activeTab === 'notes' && (
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-ink">Patient Clinical & Team Notes</h3>
                    <NotesSection
                      resourceType="CUSTOMER"
                      resourceId={customer.id}
                      projectId={customer.projectId}
                    />
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* EDIT MEDICAL & INSURANCE MODAL */}
      {customer && (
        <MedicalProfileModal
          open={medicalModalOpen}
          onClose={() => setMedicalModalOpen(false)}
          customer={customer}
        />
      )}
    </div>
  );
}

// -------------------------------------------------------------
// MEDICAL & INSURANCE EDIT MODAL
// -------------------------------------------------------------
function MedicalProfileModal({
  open,
  onClose,
  customer,
}: {
  open: boolean;
  onClose: () => void;
  customer: CustomerDetail;
}) {
  const { locale } = useDirection();
  const isAr = locale === 'ar';

  const updateMutation = useUpdateCustomerMedical();
  const existingMedical = customer?.metadata?.medical as PatientMedicalProfile | undefined;

  const [bloodType, setBloodType] = useState(existingMedical?.bloodType || 'O+');
  const [allergies, setAllergies] = useState<string[]>(existingMedical?.allergies || []);
  const [newAllergyInput, setNewAllergyInput] = useState('');

  const [chronicConditions, setChronicConditions] = useState<string[]>(
    existingMedical?.chronicConditions || [],
  );
  const [newConditionInput, setNewConditionInput] = useState('');

  const [provider, setProvider] = useState(existingMedical?.insurance?.provider || 'Bupa Arabia');
  const [policyNumber, setPolicyNumber] = useState(existingMedical?.insurance?.policyNumber || '');
  const [memberId, setMemberId] = useState(existingMedical?.insurance?.memberId || '');
  const [networkClass, setNetworkClass] = useState(existingMedical?.insurance?.networkClass || 'VIP Gold');
  const [copayPercentage, setCopayPercentage] = useState(
    existingMedical?.insurance?.copayPercentage ?? 10,
  );
  const [expiryDate, setExpiryDate] = useState(existingMedical?.insurance?.expiryDate || '2027-12-31');

  const [chiefComplaint, setChiefComplaint] = useState(existingMedical?.intake?.chiefComplaint || '');
  const [preExistingSurgeries, setPreExistingSurgeries] = useState(
    existingMedical?.intake?.preExistingSurgeries || '',
  );
  const [smokingStatus, setSmokingStatus] = useState<'NON_SMOKER' | 'SMOKER' | 'OCCASIONAL'>(
    existingMedical?.intake?.smokingStatus || 'NON_SMOKER',
  );
  const [clinicalNotes, setClinicalNotes] = useState(existingMedical?.intake?.clinicalNotes || '');

  if (!open) return null;

  const handleToggleAllergy = (a: string) => {
    if (allergies.includes(a)) {
      setAllergies(allergies.filter((item) => item !== a));
    } else {
      setAllergies([...allergies, a]);
    }
  };

  const handleAddCustomAllergy = () => {
    if (newAllergyInput.trim() && !allergies.includes(newAllergyInput.trim())) {
      setAllergies([...allergies, newAllergyInput.trim()]);
      setNewAllergyInput('');
    }
  };

  const handleToggleChronic = (c: string) => {
    if (chronicConditions.includes(c)) {
      setChronicConditions(chronicConditions.filter((item) => item !== c));
    } else {
      setChronicConditions([...chronicConditions, c]);
    }
  };

  const handleAddCustomChronic = () => {
    if (newConditionInput.trim() && !chronicConditions.includes(newConditionInput.trim())) {
      setChronicConditions([...chronicConditions, newConditionInput.trim()]);
      setNewConditionInput('');
    }
  };

  const handleSave = () => {
    const medicalProfile: PatientMedicalProfile = {
      bloodType,
      allergies,
      chronicConditions,
      medications: existingMedical?.medications || [],
      insurance: {
        provider,
        policyNumber,
        memberId,
        networkClass,
        copayPercentage: Number(copayPercentage),
        expiryDate,
        status: 'ACTIVE',
      },
      intake: {
        intakeCompleted: true,
        lastIntakeDate: new Date().toISOString().split('T')[0],
        chiefComplaint,
        preExistingSurgeries,
        smokingStatus,
        clinicalNotes,
      },
    };

    // Also update tags for instant filtering across CRM
    const updatedTags = [
      ...allergies.map((a) => `Allergy: ${a}`),
      provider,
      networkClass,
      ...chronicConditions,
    ].slice(0, 15);

    updateMutation.mutate(
      {
        customerId: customer.id,
        tags: updatedTags,
        medical: medicalProfile,
      },
      {
        onSuccess: () => {
          onClose();
        },
      },
    );
  };

  return (
    <div className="fixed inset-0 z-60 overflow-y-auto bg-ink/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-xl rounded-2xl bg-surface border border-hairline shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-hairline px-6 py-4 bg-surface-raised">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-500/10 text-red-600">
              <HeartPulse className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-ink">
                {isAr ? 'تعديل الملف الطبي والتأمين' : 'Update Clinical & Insurance Data'}
              </h3>
              <p className="text-2xs text-slate-soft">
                {customer.displayName} · {customer.cxId}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-soft hover:bg-surface hover:text-ink transition"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Blood Type */}
          <div>
            <label className="block text-2xs font-bold uppercase tracking-wider text-slate-soft mb-1.5">
              {isAr ? 'فصيلة الدم (Blood Group)' : 'Blood Group'}
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
              {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                <button
                  key={bg}
                  type="button"
                  onClick={() => setBloodType(bg)}
                  className={`rounded-lg py-1.5 text-center text-xs font-bold transition ${
                    bloodType === bg
                      ? 'bg-red-600 text-white shadow-sm'
                      : 'bg-surface border border-hairline text-slate-soft hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {bg}
                </button>
              ))}
            </div>
          </div>

          {/* Allergies Preset Pills */}
          <div>
            <label className="block text-2xs font-bold uppercase tracking-wider text-red-600 mb-1.5 flex items-center gap-1">
              <AlertTriangle className="h-3.5 w-3.5" />
              {isAr ? 'الحساسية الدوائية والمواد (اضغط لتحديد المواد)' : 'Known Allergies (Click to toggle)'}
            </label>
            <div className="flex flex-wrap gap-1.5">
              {PRESET_ALLERGIES.map((a) => {
                const selected = allergies.includes(a);
                return (
                  <button
                    key={a}
                    type="button"
                    onClick={() => handleToggleAllergy(a)}
                    className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition flex items-center gap-1 ${
                      selected
                        ? 'bg-red-600 text-white shadow-xs'
                        : 'bg-surface border border-hairline text-slate-soft hover:bg-red-500/10 hover:text-red-700'
                    }`}
                  >
                    {selected && <Check className="h-3 w-3 stroke-[3]" />}
                    {a}
                  </button>
                );
              })}
            </div>

            {/* Custom Allergy Input */}
            <div className="mt-2 flex items-center gap-2">
              <input
                type="text"
                value={newAllergyInput}
                onChange={(e) => setNewAllergyInput(e.target.value)}
                placeholder={isAr ? 'إضافة حساسية أخرى...' : 'Add another allergy...'}
                className="h-8 flex-1 rounded-lg border border-hairline bg-surface px-3 text-xs text-ink placeholder:text-slate-soft focus:border-red-500 focus:outline-none"
              />
              <Button size="sm" variant="secondary" onClick={handleAddCustomAllergy}>
                {isAr ? 'إضافة' : 'Add'}
              </Button>
            </div>
          </div>

          {/* Chronic Conditions */}
          <div>
            <label className="block text-2xs font-bold uppercase tracking-wider text-amber-600 mb-1.5 flex items-center gap-1">
              <Activity className="h-3.5 w-3.5" />
              {isAr ? 'الأمراض المزمنة وعوامل الخطر' : 'Chronic Conditions & Health Factors'}
            </label>
            <div className="flex flex-wrap gap-1.5">
              {PRESET_CHRONIC.map((c) => {
                const selected = chronicConditions.includes(c);
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => handleToggleChronic(c)}
                    className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition flex items-center gap-1 ${
                      selected
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-surface border border-hairline text-slate-soft hover:bg-amber-500/10 hover:text-amber-800'
                    }`}
                  >
                    {selected && <Check className="h-3 w-3 stroke-[3]" />}
                    {c}
                  </button>
                );
              })}
            </div>

            {/* Custom Condition */}
            <div className="mt-2 flex items-center gap-2">
              <input
                type="text"
                value={newConditionInput}
                onChange={(e) => setNewConditionInput(e.target.value)}
                placeholder={isAr ? 'إضافة حالة مزمنة أخرى...' : 'Add another condition...'}
                className="h-8 flex-1 rounded-lg border border-hairline bg-surface px-3 text-xs text-ink placeholder:text-slate-soft focus:border-amber-500 focus:outline-none"
              />
              <Button size="sm" variant="secondary" onClick={handleAddCustomChronic}>
                {isAr ? 'إضافة' : 'Add'}
              </Button>
            </div>
          </div>

          {/* Insurance Information */}
          <div className="border-t border-hairline pt-4 space-y-3">
            <span className="text-2xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-300 flex items-center gap-1.5">
              <Shield className="h-3.5 w-3.5" />
              {isAr ? 'بيانات التأمين الطبي' : 'Insurance Policy Details'}
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-2xs text-slate-soft block mb-1">
                  {isAr ? 'شركة التأمين' : 'Provider'}
                </label>
                <select
                  value={provider}
                  onChange={(e) => setProvider(e.target.value)}
                  className="h-8.5 w-full rounded-lg border border-hairline bg-surface px-2.5 text-xs text-ink focus:border-signal focus:outline-none"
                >
                  {INSURANCE_PROVIDERS.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-2xs text-slate-soft block mb-1">
                  {isAr ? 'فئة الشبكة' : 'Network Class'}
                </label>
                <select
                  value={networkClass}
                  onChange={(e) => setNetworkClass(e.target.value)}
                  className="h-8.5 w-full rounded-lg border border-hairline bg-surface px-2.5 text-xs text-ink focus:border-signal focus:outline-none"
                >
                  {NETWORK_CLASSES.map((nc) => (
                    <option key={nc} value={nc}>
                      {nc}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-2xs text-slate-soft block mb-1">
                  {isAr ? 'رقم العضوية' : 'Member ID'}
                </label>
                <input
                  type="text"
                  value={memberId}
                  onChange={(e) => setMemberId(e.target.value)}
                  placeholder="BUP-901248"
                  className="h-8.5 w-full rounded-lg border border-hairline bg-surface px-3 text-xs text-ink focus:border-signal focus:outline-none"
                />
              </div>

              <div>
                <label className="text-2xs text-slate-soft block mb-1">
                  {isAr ? 'رقم الوثيقة' : 'Policy Number'}
                </label>
                <input
                  type="text"
                  value={policyNumber}
                  onChange={(e) => setPolicyNumber(e.target.value)}
                  placeholder="BUPA-SA-882194"
                  className="h-8.5 w-full rounded-lg border border-hairline bg-surface px-3 text-xs text-ink focus:border-signal focus:outline-none"
                />
              </div>

              <div>
                <label className="text-2xs text-slate-soft block mb-1">
                  {isAr ? 'نسبة التحمل (Copay %)' : 'Copay (%)'}
                </label>
                <input
                  type="number"
                  value={copayPercentage}
                  onChange={(e) => setCopayPercentage(Number(e.target.value) || 0)}
                  placeholder="10"
                  className="h-8.5 w-full rounded-lg border border-hairline bg-surface px-3 text-xs text-ink focus:border-signal focus:outline-none"
                />
              </div>

              <div>
                <label className="text-2xs text-slate-soft block mb-1">
                  {isAr ? 'تاريخ انتهاء الوثيقة' : 'Expiry Date'}
                </label>
                <input
                  type="date"
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  className="h-8.5 w-full rounded-lg border border-hairline bg-surface px-3 text-xs text-ink focus:border-signal focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Clinical Intake Notes */}
          <div className="border-t border-hairline pt-4 space-y-3">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-soft flex items-center gap-1.5">
              <FileText className="h-3.5 w-3.5 text-teal-600" />
              {isAr ? 'الفحص الأولي والملاحظات السريرية' : 'Pre-Visit Intake Notes'}
            </span>

            <div>
              <label className="text-2xs text-slate-soft block mb-1">
                {isAr ? 'الشكوى الرئيسية (Chief Complaint)' : 'Chief Complaint'}
              </label>
              <input
                type="text"
                value={chiefComplaint}
                onChange={(e) => setChiefComplaint(e.target.value)}
                placeholder="e.g. Sensitivity on upper left molar, routine checkup"
                className="h-8.5 w-full rounded-lg border border-hairline bg-surface px-3 text-xs text-ink focus:border-signal focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-2xs text-slate-soft block mb-1">
                  {isAr ? 'حالة التدخين' : 'Smoking Status'}
                </label>
                <select
                  value={smokingStatus}
                  onChange={(e) => setSmokingStatus(e.target.value as any)}
                  className="h-8.5 w-full rounded-lg border border-hairline bg-surface px-2.5 text-xs text-ink focus:border-signal focus:outline-none"
                >
                  <option value="NON_SMOKER">{isAr ? 'غير مدخن' : 'Non-Smoker'}</option>
                  <option value="SMOKER">{isAr ? 'مدخن' : 'Smoker'}</option>
                  <option value="OCCASIONAL">{isAr ? 'بشكل متقطع' : 'Occasional'}</option>
                </select>
              </div>

              <div>
                <label className="text-2xs text-slate-soft block mb-1">
                  {isAr ? 'العمليات السابقة' : 'Past Surgeries'}
                </label>
                <input
                  type="text"
                  value={preExistingSurgeries}
                  onChange={(e) => setPreExistingSurgeries(e.target.value)}
                  placeholder="e.g. Appendectomy"
                  className="h-8.5 w-full rounded-lg border border-hairline bg-surface px-3 text-xs text-ink focus:border-signal focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-2xs text-slate-soft block mb-1">
                {isAr ? 'ملاحظات وتنبيهات الطبيب السريرية' : 'Clinical Alerts & Doctor Notes'}
              </label>
              <textarea
                rows={2}
                value={clinicalNotes}
                onChange={(e) => setClinicalNotes(e.target.value)}
                placeholder="Special precautions or allergies context..."
                className="w-full rounded-lg border border-hairline bg-surface p-2 text-xs text-ink focus:border-signal focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2.5 border-t border-hairline px-6 py-3.5 bg-surface-raised">
          <Button variant="ghost" onClick={onClose} disabled={updateMutation.isPending}>
            {isAr ? 'إلغاء' : 'Cancel'}
          </Button>
          <Button
            onClick={handleSave}
            loading={updateMutation.isPending}
            className="bg-[#0f5b4c] text-white hover:bg-[#0c473b]"
          >
            {isAr ? 'حفظ البيانات الطبية' : 'Save Medical Data'}
          </Button>
        </div>
      </div>
    </div>
  );
}
