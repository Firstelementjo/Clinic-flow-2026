import { Controller, Get, Param, ParseUUIDPipe, Query } from '@nestjs/common';
import { Permission } from '@firstelement/auth';
import { accessibleProjectsScope, type TenantContext } from '@firstelement/database';
import { PrismaService } from '../common/prisma.service';
import { CurrentUser, RequirePermissions, Tenant } from '../auth/decorators';
import { AnalyticsService } from './analytics.service';
import type { SessionUser } from '@firstelement/shared';

@Controller()
export class AnalyticsController {
  constructor(
    private readonly analytics: AnalyticsService,
    private readonly prisma: PrismaService,
  ) {}

  /** Self-service: any authenticated user can read their own stats. */
  @Get('me/analytics')
  myAnalytics(
    @CurrentUser() user: SessionUser,
    @Query('days') days?: string,
  ) {
    if (!user.employeeId) {
      return { csat: null, dsat: null, resolveRate: null, casesResolved: 0, averageHandlingMinutes: null, medianFirstResponseMinutes: null };
    }
    // Build a minimal TenantContext from the session user
    const ctx: TenantContext = { organizationId: user.organizationId, userId: user.id, role: user.role, projectIds: user.projectIds };
    return this.analytics.employeeSummary(ctx, user.employeeId, { days: days ? Number(days) : undefined });
  }

  /** Organization-wide, but only across projects the caller can access. */
  @Get('analytics/summary')
  @RequirePermissions(Permission.ANALYTICS_READ_ORGANIZATION)
  summary(@Tenant() ctx: TenantContext, @Query('days') days?: string) {
    return this.analytics.summary(ctx, { days: days ? Number(days) : undefined });
  }

  @Get('projects/:projectId/analytics')
  @RequirePermissions(Permission.ANALYTICS_READ_PROJECT)
  projectSummary(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Query('days') days?: string,
  ) {
    return this.analytics.summary(ctx, { projectId, days: days ? Number(days) : undefined });
  }

  @Get('employees/:employeeId/analytics')
  @RequirePermissions(Permission.ANALYTICS_READ_ORGANIZATION)
  employeeSummary(
    @Tenant() ctx: TenantContext,
    @Param('employeeId', ParseUUIDPipe) employeeId: string,
    @Query('days') days?: string,
  ) {
    return this.analytics.employeeSummary(ctx, employeeId, { days: days ? Number(days) : undefined });
  }

  /**
   * Audit log browsing (plan §12).
   *
   * Admin-only, organization-scoped, and read-only — there is no endpoint
   * that edits or deletes an audit row, because an audit trail somebody
   * can quietly rewrite is not one.
   */
  @Get('audit-logs')
  @RequirePermissions(Permission.AUDIT_LOG_READ)
  async auditLogs(
    @Tenant() ctx: TenantContext,
    @Query('action') action?: string,
    @Query('projectId') projectId?: string,
    @Query('cursor') cursor?: string,
  ) {
    // The query lives in the service: the project scope check is authorization, and
    // `plan.md` §0.4 forbids it living in the controller. See AnalyticsService#auditLogs.
    return this.analytics.auditLogs(ctx, { action, projectId, cursor });
  }

  /** Conversations that escalated and nobody owns — the queue to watch. */
  @Get('escalations/unassigned')
  @RequirePermissions(Permission.CONVERSATION_READ)
  async unassigned(@Tenant() ctx: TenantContext) {
    const escalations = await this.prisma.client.escalation.findMany({
      where: { ...accessibleProjectsScope(ctx), status: 'PENDING' },
      select: {
        id: true,
        conversationId: true,
        reason: true,
        summary: true,
        intent: true,
        createdAt: true,
        conversation: { select: { ticketNumber: true, customer: { select: { cxId: true } } } },
      },
      orderBy: { createdAt: 'asc' },
      take: 50,
    });

    return escalations.map((escalation) => ({
      id: escalation.id,
      conversationId: escalation.conversationId,
      ticketNumber: escalation.conversation.ticketNumber,
      cxId: escalation.conversation.customer.cxId,
      reason: escalation.reason,
      summary: escalation.summary,
      intent: escalation.intent,
      createdAt: escalation.createdAt.toISOString(),
    }));
  }
}
