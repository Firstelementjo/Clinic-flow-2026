import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Spinner, useDirection } from '@firstelement/ui';
import {
  CalendarClock,
  CalendarDays,
  Clock,
  LayoutGrid,
  List,
  Mail,
  MessageCircle,
  Phone,
  Plus,
  Search,
  Stethoscope,
  Ticket,
  User,
  Users,
  Eye,
  Droplet,
  AlertTriangle,
  ShieldCheck,
  HeartPulse,
} from 'lucide-react';
import { useT } from '../lib/i18n';
import { formatDate } from '../lib/format';
import { useCustomers, type CustomerListRow, type CustomerDetail } from '../lib/customers';
import { CreateFollowUpDrawer } from '../components/follow-up-form';
import { CreateAppointmentDrawer } from '../components/appointment-form';
import { PatientProfileDrawer } from '../components/PatientProfileDrawer';

function measureTicketAge(dateStr: string | null | undefined): { text: string; tone: 'normal' | 'warn' | 'urgent' } | null {
  if (!dateStr) return null;
  const time = new Date(dateStr).getTime();
  if (isNaN(time)) return null;
  const diffMs = Date.now() - time;
  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  const days = Math.floor(hours / 24);

  if (days >= 2) {
    return { text: `${days}d ${hours % 24}h elapsed`, tone: 'urgent' };
  }
  if (days >= 1) {
    return { text: `${days}d elapsed`, tone: 'warn' };
  }
  if (hours > 0) {
    return { text: `${hours}h elapsed`, tone: 'normal' };
  }
  return { text: '<1h elapsed', tone: 'normal' };
}

function getInitials(name: string): string {
  if (!name) return 'PT';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
}



export function PeoplePage() {
  const t = useT();
  const dir = useDirection();
  const isAr = dir.locale === 'ar';
  const [search, setSearch] = useState('');
  const [medicalFilter, setMedicalFilter] = useState<'ALL' | 'ALLERGIES' | 'INSURED' | 'CHRONIC'>('ALL');

  // Drawers state
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [followUpFor, setFollowUpFor] = useState<{ id: string; ticketNumber?: string | null; ticketDate?: string | null } | null>(null);
  const [appointmentFor, setAppointmentFor] = useState<{ id: string; ticketNumber?: string | null; ticketDate?: string | null } | null>(null);

  const customersQuery = useCustomers(search);
  const customers = customersQuery.data?.items ?? [];



  const filteredCustomers = useMemo(() => {
    return customers.filter((c) => {
      const med = c.metadata?.medical;
      if (medicalFilter === 'ALLERGIES') return med?.allergies && med.allergies.length > 0;
      if (medicalFilter === 'INSURED') return med?.insurance?.provider && med.insurance.provider !== 'Self-Pay / Cash';
      if (medicalFilter === 'CHRONIC') return med?.chronicConditions && med.chronicConditions.length > 0;
      return true;
    });
  }, [customers, medicalFilter]);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-bold text-[var(--fe-ink)]">
              {t('people.title')}
            </h2>
            <span className="rounded-full border border-[var(--fe-hairline)] bg-[var(--fe-surface)] px-2.5 py-0.5 text-xs font-medium text-[var(--fe-slate)]">
              {customers.length} profiles
            </span>
          </div>
          <p className="mt-1 text-sm text-[var(--fe-slate)]">
            Patient directory with medical flags and recent activity.
          </p>
        </div>

        {/* Search Box */}
        <div className="relative w-72">
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or phone"
            className="w-full rounded-lg border border-[var(--fe-hairline)] bg-[var(--fe-surface)] px-4 py-2 text-sm text-[var(--fe-ink)] placeholder:text-[var(--fe-slate)] focus:border-[#0f5b4c] focus:outline-none focus:ring-1 focus:ring-[#0f5b4c]"
          />
        </div>
      </div>

      {/* Quick Medical & Clinical Filters Toolbar */}
      <div className="inline-flex rounded-lg border border-[var(--fe-hairline)] bg-[var(--fe-surface)] p-1">
        <button
          type="button"
          onClick={() => setMedicalFilter('ALL')}
          className={`rounded-md px-4 py-1.5 text-sm font-medium transition-colors ${
            medicalFilter === 'ALL'
              ? 'bg-[#0f5b4c]/10 text-[#0f5b4c] dark:text-[#2dd4bf]'
              : 'text-[var(--fe-slate)] hover:text-[var(--fe-ink)]'
          }`}
        >
          All
        </button>

        <button
          type="button"
          onClick={() => setMedicalFilter('ALLERGIES')}
          className={`rounded-md px-4 py-1.5 text-sm font-medium transition-colors ${
            medicalFilter === 'ALLERGIES'
              ? 'bg-[#0f5b4c]/10 text-[#0f5b4c] dark:text-[#2dd4bf]'
              : 'text-[var(--fe-slate)] hover:text-[var(--fe-ink)]'
          }`}
        >
          High allergy risk
        </button>

        <button
          type="button"
          onClick={() => setMedicalFilter('INSURED')}
          className={`rounded-md px-4 py-1.5 text-sm font-medium transition-colors ${
            medicalFilter === 'INSURED'
              ? 'bg-[#0f5b4c]/10 text-[#0f5b4c] dark:text-[#2dd4bf]'
              : 'text-[var(--fe-slate)] hover:text-[var(--fe-ink)]'
          }`}
        >
          Verified insurance
        </button>

        <button
          type="button"
          onClick={() => setMedicalFilter('CHRONIC')}
          className={`rounded-md px-4 py-1.5 text-sm font-medium transition-colors ${
            medicalFilter === 'CHRONIC'
              ? 'bg-[#0f5b4c]/10 text-[#0f5b4c] dark:text-[#2dd4bf]'
              : 'text-[var(--fe-slate)] hover:text-[var(--fe-ink)]'
          }`}
        >
          Chronic care
        </button>
      </div>

      {/* Main Content Area */}
      {customersQuery.isPending ? (
        <div className="card flex h-64 items-center justify-center">
          <Spinner label={t('common.loading')} />
        </div>
      ) : customersQuery.isError ? (
        <div className="card p-8 text-center text-sm text-[var(--fe-danger)]">
          {t('common.error')}
        </div>
      ) : filteredCustomers.length === 0 ? (
        <div className="card flex flex-col items-center justify-center py-20 text-center">
          <div className="h-12 w-12 rounded-[var(--fe-radius)] bg-[var(--fe-mist)] flex items-center justify-center text-[var(--fe-slate)] mb-3">
            <Users className="h-6 w-6" />
          </div>
          <h3 className="text-base font-bold text-[var(--fe-ink)]">
            {customers.length > 0 ? (isAr ? 'لا توجد نتائج مطابقة للتصفية الطبية' : 'No patients match this medical filter') : t('people.empty.title')}
          </h3>
          <p className="text-xs text-[var(--fe-slate)] mt-1 max-w-sm">
            {customers.length > 0 ? (isAr ? 'جرّب اختيار فلتر آخر أو إعادة التعيين.' : 'Try switching filters or reset to All Profiles.') : t('people.empty.body')}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredCustomers.map((c) => {
            const initials = getInitials(c.displayName);
            const measurement = measureTicketAge(c.latestTicket?.createdAt);
            const latestAppt = c.appointments && c.appointments.length > 0 ? c.appointments[0] : null;
            const med = c.metadata?.medical;

            return (
              <div
                key={c.id}
                className="flex flex-col overflow-hidden rounded-xl border border-[var(--fe-hairline)] bg-[var(--fe-surface)] shadow-sm"
              >
                {/* Profile Card Body */}
                <div className="flex flex-1 flex-col p-5">
                  {/* Avatar & Header row */}
                  <div className="mb-4 flex items-start gap-4">
                    <div
                      className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#0f5b4c]/10 text-sm font-bold text-[#0f5b4c] dark:text-[#2dd4bf]"
                    >
                      {initials}
                    </div>

                    <div className="min-w-0 flex-1">
                      <button
                        type="button"
                        onClick={() => setSelectedCustomerId(c.id)}
                        className="block w-full truncate text-start text-base font-bold text-[var(--fe-ink)] hover:text-[#0f5b4c] dark:hover:text-[#2dd4bf]"
                      >
                        {c.displayName}
                      </button>
                      <p className="mt-0.5 truncate text-sm text-[var(--fe-slate)]">
                        {c.primaryPhone || 'No phone'}
                      </p>
                    </div>
                  </div>

                  {/* Medical Indicators Row */}
                  <div className="mb-5 flex flex-wrap items-center gap-2">
                    {med?.bloodType && (
                      <span className="rounded-full bg-blue-500/10 px-2.5 py-0.5 text-xs font-semibold text-blue-700 dark:text-blue-400">
                        {med.bloodType}
                      </span>
                    )}
                    {med?.allergies && med.allergies.length > 0 && (
                      <span className="rounded-full bg-red-500/10 px-2.5 py-0.5 text-xs font-medium text-red-700 dark:text-red-400">
                        {med.allergies[0]}
                      </span>
                    )}
                    {med?.insurance?.provider && (
                      <span className="rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                        Insured
                      </span>
                    )}
                    {med?.chronicConditions && med.chronicConditions.length > 0 && (
                      <span className="rounded-full bg-orange-500/10 px-2.5 py-0.5 text-xs font-medium text-orange-700 dark:text-orange-400">
                        Chronic care
                      </span>
                    )}
                  </div>

                  {/* Card Bottom Stats & Actions */}
                  <div className="mt-auto flex items-center justify-between gap-4 border-t border-[var(--fe-hairline)] pt-4">
                    <div className="flex-1 min-w-0">
                      {latestAppt ? (
                        <p className="truncate text-xs text-[var(--fe-slate)]">
                          Next: {latestAppt.title}, {new Date(latestAppt.appointmentDate).toLocaleDateString()}
                        </p>
                      ) : (
                        <p className="truncate text-xs text-[var(--fe-slate)]">
                          {c.conversationCount} chats, {c.followUps?.length || 0} follow-up
                        </p>
                      )}
                    </div>

                    <div className="shrink-0">
                      <button
                        type="button"
                        onClick={() => setSelectedCustomerId(c.id)}
                        className="rounded-md border border-[var(--fe-hairline)] bg-[var(--fe-surface)] px-3 py-1.5 text-sm font-medium text-[var(--fe-ink)] hover:bg-[var(--fe-mist)] transition-colors"
                      >
                        Open profile
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ============================================================ */}
      {/* PATIENT 360 PROFILE DRAWER                                   */}
      {/* ============================================================ */}
      <PatientProfileDrawer
        customerId={selectedCustomerId}
        onClose={() => setSelectedCustomerId(null)}
        onBookAppointment={(cust) =>
          setAppointmentFor({
            id: cust.id,
            ticketNumber: cust.conversations[0]?.ticketNumber,
            ticketDate: cust.conversations[0]?.createdAt,
          })
        }
        onScheduleFollowUp={(cust) =>
          setFollowUpFor({
            id: cust.id,
            ticketNumber: cust.conversations[0]?.ticketNumber,
            ticketDate: cust.conversations[0]?.createdAt,
          })
        }
      />

      {/* Connected Follow-up creation drawer */}
      {followUpFor && (
        <CreateFollowUpDrawer
          open={Boolean(followUpFor)}
          onClose={() => setFollowUpFor(null)}
          initialCustomerId={followUpFor.id}
          initialTicketNumber={followUpFor.ticketNumber}
          initialTicketDate={followUpFor.ticketDate}
        />
      )}

      {/* Connected Appointment creation drawer */}
      {appointmentFor && (
        <CreateAppointmentDrawer
          open={Boolean(appointmentFor)}
          onClose={() => setAppointmentFor(null)}
          initialCustomerId={appointmentFor.id}
          initialTicketNumber={appointmentFor.ticketNumber}
          initialTicketDate={appointmentFor.ticketDate}
        />
      )}
    </div>
  );
}