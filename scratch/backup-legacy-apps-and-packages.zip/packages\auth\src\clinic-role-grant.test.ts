/**
 * `CLINIC_STAFF` grant proof (`packages/auth`).
 *
 * <h2>Why this role exists</h2>
 *
 * <p>Phase 33 added 18 clinic permissions and deliberately did not add the role they
 * were shaped for, because `UserRole` is a Prisma enum and a third member is a schema
 * migration plus a matrix change — a ruling for the orchestrator, not a silent edit.
 * Until now the role existed only in prose, so every permission named for it was
 * granted to nobody.
 *
 * <p>This suite states what the role holds, and — the part that matters — what it does
 * not. The separation is the point: before this role, the only way to employ a
 * receptionist was to hand them `EMPLOYEE`, which carries `NOTE_READ`, `CUSTOMER_READ`,
 * `CONVERSATION_READ`, `DEAL_READ`, `TASK_READ` and the rest of the CRM surface. A
 * booking clerk could read every clinical note in the organization. A booking clerk
 * must not read clinical notes they have no case for, and must not administer the
 * roster. `CLINIC_STAFF` is the role that says so.
 */
import { describe, expect, it } from 'vitest';
import { UserRole } from '@firstelement/shared';
import {
  CLINIC_ADMIN_ONLY,
  CLINIC_EMPLOYEE_GRANT,
  CLINIC_STAFF_GRANT,
  Permission,
  ROLE_PERMISSIONS,
  can,
  roleHasPermission,
  type PolicyActor,
} from './policy';

const ORG = 'org-1';
const PROJECT_A = 'project-a';

const actor = (role: UserRole): PolicyActor => ({
  userId: `${role}-1`,
  organizationId: ORG,
  role,
  projectIds: [PROJECT_A],
});

describe('CLINIC_STAFF exists as a role, not a comment', () => {
  it('is a member of the shared role vocabulary', () => {
    expect(UserRole.CLINIC_STAFF).toBe('CLINIC_STAFF');
  });

  it('has a grant in the matrix — the failure this role used to have', () => {
    // Before the enum member and this entry, a permission named for CLINIC_STAFF was
    // granted to nobody. This assertion fails the moment the key goes missing, which
    // is the load-bearing proof the enum addition is not decorative.
    expect(ROLE_PERMISSIONS[UserRole.CLINIC_STAFF]).toBeDefined();
    expect(Array.isArray(ROLE_PERMISSIONS[UserRole.CLINIC_STAFF])).toBe(true);
    expect(ROLE_PERMISSIONS[UserRole.CLINIC_STAFF].length).toBeGreaterThan(0);
  });

  it('is reflected in the schema, the shared mirror and the matrix alike', () => {
    // Three files declare this role. If they ever drift, a principal minted from the
    // database cannot be represented in the matrix and every route is unreachable.
    const everyRole = Object.keys(ROLE_PERMISSIONS).sort();
    expect(everyRole).toEqual(Object.values(UserRole).sort());
  });
});

describe('what CLINIC_STAFF holds', () => {
  it('holds the front desk: book, reschedule, cancel, roster, catalog, slots, reminders', () => {
    for (const permission of [
      Permission.DOCTOR_READ,
      Permission.PROCEDURE_READ,
      Permission.SCHEDULE_AVAILABILITY_READ,
      Permission.APPOINTMENT_CREATE,
      Permission.APPOINTMENT_RESCHEDULE,
      Permission.APPOINTMENT_CANCEL,
      Permission.REMINDER_READ,
      Permission.REMINDER_SEND,
      Permission.REMINDER_RECORD_RESPONSE,
    ] as Permission[]) {
      expect(roleHasPermission(UserRole.CLINIC_STAFF, permission)).toBe(true);
    }
  });

  it('holds exactly the clinic front-desk grant, and nothing else', () => {
    // The whole value of the role is this equality. If a clinic permission is added to
    // the grant without a decision here, this fails naming it.
    expect([...CLINIC_STAFF_GRANT].sort()).toEqual([...CLINIC_EMPLOYEE_GRANT].sort());
  });

  it('holds no permission outside the clinic surface', () => {
    const clinicPermissions = new Set<Permission>([
      ...CLINIC_EMPLOYEE_GRANT,
      ...CLINIC_ADMIN_ONLY,
      Permission.CLINIC_AI_SIMULATE,
      Permission.ANALYTICS_READ_PROJECT,
    ]);
    const outside = CLINIC_STAFF_GRANT.filter((p) => !clinicPermissions.has(p));
    expect(outside).toEqual([]);
  });
});

describe('what CLINIC_STAFF does not hold — the separation', () => {
  it('cannot administer the roster', () => {
    // A booking clerk edits slots. A clinician leaving the practice is a
    // clinic-configuration decision with clinical consequences, and deleting a doctor
    // whose appointments still exist is not self-service.
    for (const permission of [
      Permission.DOCTOR_CREATE,
      Permission.DOCTOR_UPDATE,
      Permission.DOCTOR_DELETE,
      Permission.PROCEDURE_CREATE,
      Permission.PROCEDURE_UPDATE,
      Permission.PROCEDURE_DELETE,
    ]) {
      expect(roleHasPermission(UserRole.CLINIC_STAFF, permission)).toBe(false);
      expect(CLINIC_ADMIN_ONLY).toContain(permission);
    }
  });

  it('cannot read clinician contact details or roster workload', () => {
    expect(roleHasPermission(UserRole.CLINIC_STAFF, Permission.DOCTOR_READ_MANAGEMENT)).toBe(false);
    expect(roleHasPermission(UserRole.CLINIC_STAFF, Permission.PROCEDURE_READ_MANAGEMENT)).toBe(false);
  });

  it('cannot let an unreviewed model write to the clinical schedule', () => {
    expect(roleHasPermission(UserRole.CLINIC_STAFF, Permission.CLINIC_AI_SIMULATE)).toBe(false);
  });

  it('cannot read clinical notes, customers, conversations, deals or tasks', () => {
    // The reason the role exists. Every one of these is held by EMPLOYEE, so before
    // CLINIC_STAFF a receptionist could read all of it.
    const crmReads = [
      Permission.NOTE_READ,
      Permission.CUSTOMER_READ,
      Permission.CONVERSATION_READ,
      Permission.DEAL_READ,
      Permission.TASK_READ,
      Permission.LEAD_READ,
      Permission.KNOWLEDGE_READ,
    ];

    for (const permission of crmReads) {
      expect(roleHasPermission(UserRole.CLINIC_STAFF, permission), `${permission} leaked`).toBe(false);
      // The control: EMPLOYEE really does hold it, so this is a difference in the
      // matrix and not a permission that nobody has.
      expect(roleHasPermission(UserRole.EMPLOYEE, permission)).toBe(true);
    }
  });

  it('is strictly narrower than EMPLOYEE, so nothing it can reach is new reach', () => {
    const staff = new Set(CLINIC_STAFF_GRANT);
    const extra = ROLE_PERMISSIONS[UserRole.EMPLOYEE].filter((p) => !staff.has(p));
    expect(extra.length).toBeGreaterThan(0);
    // Every one of the nine clinic permissions is also an employee permission, so this
    // role can never widen anybody's reach — it only removes.
    for (const permission of CLINIC_STAFF_GRANT) {
      expect(roleHasPermission(UserRole.EMPLOYEE, permission)).toBe(true);
    }
  });
});

describe('the tenant boundary is unaffected by the new role', () => {
  it('books inside its own organization and project', () => {
    expect(
      can(actor(UserRole.CLINIC_STAFF), Permission.APPOINTMENT_CREATE, {
        organizationId: ORG,
        projectId: PROJECT_A,
      }),
    ).toBe(true);
  });

  it('cannot book into another organization', () => {
    expect(
      can(actor(UserRole.CLINIC_STAFF), Permission.APPOINTMENT_CREATE, {
        organizationId: 'org-2',
      }),
    ).toBe(false);
  });

  it('cannot book into a project it is not a member of', () => {
    expect(
      can(actor(UserRole.CLINIC_STAFF), Permission.APPOINTMENT_CREATE, {
        projectId: 'project-elsewhere',
      }),
    ).toBe(false);
  });

  it('is refused on every ADMIN-only permission, everywhere', () => {
    for (const permission of CLINIC_ADMIN_ONLY) {
      for (const organizationId of [ORG, 'org-2']) {
        expect(
          can(actor(UserRole.CLINIC_STAFF), permission, { organizationId }),
          `${permission} allowed`,
        ).toBe(false);
      }
    }
  });
});

describe('ADMIN is unchanged by the addition', () => {
  it('still holds every permission by construction', () => {
    // `ROLE_PERMISSIONS[ADMIN]` is `Object.values(Permission)`, so a new member is
    // included without an explicit grant and cannot be forgotten.
    expect(new Set(ROLE_PERMISSIONS[UserRole.ADMIN])).toEqual(new Set(Object.values(Permission)));
  });

  it('is not narrowed by CLINIC_STAFF existing', () => {
    expect(roleHasPermission(UserRole.ADMIN, Permission.DOCTOR_DELETE)).toBe(true);
    expect(roleHasPermission(UserRole.ADMIN, Permission.CLINIC_AI_SIMULATE)).toBe(true);
  });
});