import { Injectable, NotFoundException } from '@nestjs/common';
import { TOOLS } from '@firstelement/ai';
import { projectScope, type TenantContext } from '@firstelement/database';
import {
  AuditAction,
  ErrorCode,
  type AgentVersionView,
  type AgentView,
  type SaveAgentInput,
} from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';

@Injectable()
export class AgentsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  async get(ctx: TenantContext, projectId: string): Promise<AgentView | null> {
    const agent = await this.prisma.client.aIAgent.findFirst({
      where: projectScope(ctx, projectId),
      select: {
        id: true,
        name: true,
        isEnabled: true,
        activeVersion: true,
        _count: { select: { versions: true } },
      },
    });

    if (!agent) return null;

    return {
      id: agent.id,
      name: agent.name,
      isEnabled: agent.isEnabled,
      activeVersion: agent.activeVersion ? toVersionView(agent.activeVersion) : null,
      versionCount: agent._count.versions,
      availableTools: Object.values(TOOLS).map((tool) => ({
        name: tool.name,
        description: tool.description,
        mutates: tool.mutates,
        isImplemented: tool.isImplemented,
      })),
    };
  }

  async listVersions(ctx: TenantContext, projectId: string): Promise<AgentVersionView[]> {
    const versions = await this.prisma.client.aIAgentVersion.findMany({
      where: projectScope(ctx, projectId),
      orderBy: { version: 'desc' },
      take: 50,
    });
    return versions.map(toVersionView);
  }

  /**
   * Saves agent configuration by creating a new version and pointing the
   * agent at it (plan §9).
   *
   * Never mutates the live version in place. Every `AIRun` references the
   * exact version that produced it, so a regression ("it started refusing
   * refunds on Tuesday") is answerable by diffing two rows instead of
   * guessing what the prompt used to say.
   */
  async save(
    ctx: TenantContext,
    projectId: string,
    input: SaveAgentInput,
    ipAddress?: string,
  ): Promise<AgentView> {
    const scope = projectScope(ctx, projectId);

    // Only tools that exist may be enabled; a typo must not silently
    // become a permission the executor then denies at runtime.
    const enabledTools = input.enabledTools.filter((name) => name in TOOLS);

    const knowledgeBaseIds = await this.filterKnowledgeBases(projectId, input.knowledgeBaseIds);

    const agent = await this.prisma.client.$transaction(async (tx) => {
      const existing = await tx.aIAgent.findFirst({
        where: scope,
        select: { id: true, versions: { select: { version: true }, orderBy: { version: 'desc' }, take: 1 } },
      });

      const agentId =
        existing?.id ??
        (
          await tx.aIAgent.create({
            data: { ...scope, name: input.name, isEnabled: input.isEnabled },
            select: { id: true },
          })
        ).id;

      const nextVersion = (existing?.versions[0]?.version ?? 0) + 1;

      const version = await tx.aIAgentVersion.create({
        data: {
          ...scope,
          agentId,
          version: nextVersion,
          systemInstructions: input.systemInstructions,
          tone: input.tone ?? null,
          provider: input.provider,
          model: input.model ?? null,
          temperature: input.temperature,
          maxTokens: input.maxTokens,
          failoverChain: input.failoverChain,
          enabledTools,
          knowledgeBaseIds,
          minRetrievalScore: input.minRetrievalScore,
          memoryWindow: input.memoryWindow,
          createdByUserId: ctx.userId,
        },
        select: { id: true },
      });

      await tx.aIAgent.update({
        where: { id: agentId },
        data: { name: input.name, isEnabled: input.isEnabled, activeVersionId: version.id },
      });

      return { id: agentId, versionNumber: nextVersion };
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_UPDATED_AI_AGENT,
      resourceType: 'AIAgent',
      resourceId: agent.id,
      metadata: {
        version: agent.versionNumber,
        provider: input.provider,
        isEnabled: input.isEnabled,
        enabledTools,
      },
      ipAddress,
    });

    const saved = await this.get(ctx, projectId);
    if (!saved) throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Agent not found' });
    return saved;
  }

  /** Roll back to an earlier version without retyping it. */
  async activateVersion(
    ctx: TenantContext,
    projectId: string,
    versionId: string,
    ipAddress?: string,
  ): Promise<AgentView> {
    const scope = projectScope(ctx, projectId);

    const version = await this.prisma.client.aIAgentVersion.findFirst({
      where: { id: versionId, ...scope },
      select: { id: true, agentId: true, version: true },
    });
    if (!version) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Agent version not found' });
    }

    await this.prisma.client.aIAgent.update({
      where: { id: version.agentId },
      data: { activeVersionId: version.id },
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_UPDATED_AI_AGENT,
      resourceType: 'AIAgent',
      resourceId: version.agentId,
      metadata: { activatedVersion: version.version },
      ipAddress,
    });

    const saved = await this.get(ctx, projectId);
    if (!saved) throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Agent not found' });
    return saved;
  }

  /** Knowledge bases from another project are dropped, not trusted. */
  private async filterKnowledgeBases(projectId: string, ids: string[]): Promise<string[]> {
    if (ids.length === 0) return [];
    const bases = await this.prisma.client.knowledgeBase.findMany({
      where: { id: { in: ids }, projectId },
      select: { id: true },
    });
    return bases.map((base) => base.id);
  }
}

function toVersionView(version: {
  id: string;
  version: number;
  systemInstructions: string;
  tone: string | null;
  provider: AgentVersionView['provider'];
  model: string | null;
  temperature: number;
  maxTokens: number;
  failoverChain: unknown;
  enabledTools: unknown;
  knowledgeBaseIds: unknown;
  minRetrievalScore: number;
  memoryWindow: number;
  createdAt: Date;
}): AgentVersionView {
  return {
    id: version.id,
    version: version.version,
    systemInstructions: version.systemInstructions,
    tone: version.tone,
    provider: version.provider,
    model: version.model,
    temperature: version.temperature,
    maxTokens: version.maxTokens,
    failoverChain: asArray(version.failoverChain) as AgentVersionView['failoverChain'],
    enabledTools: asArray(version.enabledTools),
    knowledgeBaseIds: asArray(version.knowledgeBaseIds),
    minRetrievalScore: version.minRetrievalScore,
    memoryWindow: version.memoryWindow,
    createdAt: version.createdAt.toISOString(),
  };
}

function asArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string') : [];
}
