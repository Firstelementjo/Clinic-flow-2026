import { useState, type FormEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Check, Search } from 'lucide-react';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import {
  CreateRecordDrawer,
  FormSection,
  SelectField,
  TextField,
  TextAreaField,
} from './CreateRecordDrawer';
import type { NoteRow } from '../lib/notes';

const RESOURCE_TYPES = ['ACCOUNT', 'LEAD', 'DEAL', 'TASK'] as const;

const RESOURCE_TYPE_LABEL: Record<(typeof RESOURCE_TYPES)[number], StringKey> = {
  ACCOUNT: 'notes.resource.ACCOUNT',
  LEAD: 'notes.resource.LEAD',
  DEAL: 'notes.resource.DEAL',
  TASK: 'notes.resource.TASK',
};

const TYPE_API: Record<(typeof RESOURCE_TYPES)[number], { endpoint: string; nameKey: string }> = {
  ACCOUNT: { endpoint: '/accounts', nameKey: 'name' },
  LEAD: { endpoint: '/leads', nameKey: 'name' },
  DEAL: { endpoint: '/deals', nameKey: 'name' },
  TASK: { endpoint: '/tasks', nameKey: 'title' },
};

export function CreateNoteDrawer({ open, onClose, projectId }: { open: boolean; onClose: () => void; projectId: string }) {
  const t = useT();
  const qc = useQueryClient();

  const [resourceType, setResourceType] = useState<(typeof RESOURCE_TYPES)[number]>('ACCOUNT');
  const [resourceId, setResourceId] = useState('');
  const [resourceLabel, setResourceLabel] = useState('');
  const [search, setSearch] = useState('');
  const [body, setBody] = useState('');

  const apiConf = TYPE_API[resourceType];

  const results = useQuery({
    queryKey: ['note-picker', resourceType, search.trim()],
    queryFn: async () => {
      if (!search.trim()) return [];
      const list = await api.get<Record<string, unknown>[]>(
        `${apiConf.endpoint}?search=${encodeURIComponent(search.trim())}`,
      );
      return list
        .map((record) => ({ id: record.id as string, label: String(record[apiConf.nameKey] ?? '') }))
        .filter((record) => record.label)
        .slice(0, 12);
    },
  });

  const create = useMutation({
    mutationFn: () =>
      api.post<NoteRow>('/notes', {
        resourceType,
        resourceId,
        body: body.trim(),
        projectId,
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['notes', 'project', projectId] });
      reset();
      onClose();
    },
  });

  const reset = () => {
    setResourceType('ACCOUNT');
    setResourceId('');
    setResourceLabel('');
    setSearch('');
    setBody('');
  };

  const pickType = (value: string) => {
    setResourceType(value as (typeof RESOURCE_TYPES)[number]);
    setResourceId('');
    setResourceLabel('');
    setSearch('');
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (resourceId && body.trim()) create.mutate();
  };

  const close = () => {
    reset();
    onClose();
  };

  const picked = resourceLabel || (resourceId ? resourceId.slice(0, 8) : '');

  return (
    <CreateRecordDrawer
      open={open}
      onClose={close}
      title={t('form.note.title')}
      description={t('form.note.about')}
      submitLabel={t('form.note.save')}
      isSubmitting={create.isPending}
      canSubmit={Boolean(resourceId) && Boolean(body.trim())}
      onSubmit={onSubmit}
    >
      <FormSection title={t('notes.attachType')}>
        <SelectField
          label={t('notes.attachType')}
          options={RESOURCE_TYPES.map((value) => ({ value, label: t(RESOURCE_TYPE_LABEL[value]) }))}
          value={resourceType}
          onChange={(e) => pickType(e.target.value)}
        />
      </FormSection>

      <FormSection title={t('notes.attachPick')}>
        <p className="-mt-4 text-2xs text-slate-soft">
          {picked ? (
            <span className="flex items-center gap-1 text-xs text-ink">
              <Check aria-hidden="true" className="h-3.5 w-3.5 text-signal" />
              {resourceLabel || resourceId}
            </span>
          ) : (
            t('notes.attachPick')
          )}
        </p>
        <TextField
          label={t('notes.searchPlaceholder')}
          dir="ltr"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setResourceId('');
            setResourceLabel('');
          }}
        />
        {search.trim() ? (
          <div className="max-h-44 overflow-y-auto rounded border border-hairline bg-surface">
            {results.isPending ? (
              <p className="px-2.5 py-2 text-xs text-slate-soft">{t('list.error')}</p>
            ) : results.data && results.data.length > 0 ? (
              <ul>
                {results.data.map((record) => (
                  <li key={record.id}>
                    <button
                      type="button"
                      onClick={() => {
                        setResourceId(record.id);
                        setResourceLabel(record.label);
                      }}
                      className={`flex w-full items-center gap-2 px-2.5 py-2 text-start text-xs transition-colors hover:bg-mist ${
                        resourceId === record.id ? 'bg-signal-wash text-ink' : 'text-slate'
                      }`}
                    >
                      <Search aria-hidden="true" className="h-3.5 w-3.5 shrink-0 text-slate-soft" />
                      <span className="truncate">{record.label}</span>
                      <span className="fe-mono ms-auto shrink-0 text-2xs text-slate-soft">{record.id.slice(0, 6)}</span>
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="px-2.5 py-2 text-xs text-slate-soft">{t('list.empty.title')}</p>
            )}
          </div>
        ) : null}
      </FormSection>

      <FormSection title={t('list.col.body')}>
        <TextAreaField label={t('list.col.body')} wide rows={5} value={body} onChange={(e) => setBody(e.target.value)} />
      </FormSection>
    </CreateRecordDrawer>
  );
}