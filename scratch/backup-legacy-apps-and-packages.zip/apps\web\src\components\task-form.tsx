import { useState, type FormEvent } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import {
  CreateRecordDrawer,
  FormSection,
  TextField,
  SelectField,
  TextAreaField,
  useFormOptions,
  useEmployees,
  textOrUndefined,
} from './CreateRecordDrawer';

const tasksKey = ['tasks'] as const;

const TASK_STATUSES = ['open', 'completed'] as const;

const TASK_STATUS_LABEL: Record<(typeof TASK_STATUSES)[number], StringKey> = {
  open: 'tasks.filter.open',
  completed: 'tasks.filter.completed',
};

interface TaskRow {
  id: string;
  title: string;
  description: string | null;
  priority: string;
  dueDate: string | null;
  status: string;
}

interface CreateTaskDrawerProps {
  open: boolean;
  onClose: () => void;
}

const emptyForm = {
  title: '',
  description: '',
  status: 'open',
  priority: 'medium',
  dueDate: '',
  assignedToId: '',
} as const;

export function CreateTaskDrawer({ open, onClose }: CreateTaskDrawerProps) {
  const t = useT();
  const qc = useQueryClient();
  const opts = useFormOptions();
  const assigneeOptions = (useEmployees().data ?? []).map((employee) => ({
    value: employee.userId,
    label: employee.fullName,
  }));

  const [form, setForm] = useState({ ...emptyForm });
  const set = (field: keyof typeof emptyForm) => (e: { target: { value: string } }) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const reset = () => setForm({ ...emptyForm });

  const create = useMutation({
    mutationFn: () =>
      api.post<TaskRow>('/tasks', {
        title: form.title.trim(),
        description: textOrUndefined(form.description),
        priority: form.priority || 'medium',
        dueDate: form.dueDate || undefined,
        status: form.status || 'open',
        assignedToId: form.assignedToId || undefined,
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: tasksKey });
      reset();
      onClose();
    },
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (form.title.trim()) create.mutate();
  };

  const close = () => {
    reset();
    onClose();
  };

  const statusOptions = TASK_STATUSES.map((status) => ({ value: status, label: t(TASK_STATUS_LABEL[status]) }));

  return (
    <CreateRecordDrawer
      open={open}
      onClose={close}
      title={t('form.task.title')}
      description={t('form.task.about')}
      submitLabel={t('form.task.save')}
      isSubmitting={create.isPending}
      canSubmit={Boolean(form.title.trim())}
      onSubmit={onSubmit}
    >
      <FormSection title={t('form.section.taskInfo')}>
        <TextField label={t('form.field.title')} required autoFocus value={form.title} onChange={set('title')} />
        <SelectField label={t('form.field.status')} options={statusOptions} value={form.status} onChange={set('status')} />
        <SelectField label={t('form.field.priority')} options={opts.priorities} value={form.priority} onChange={set('priority')} />
        <TextField label={t('form.field.dueDate')} type="date" value={form.dueDate} onChange={set('dueDate')} />
      </FormSection>

      <FormSection title={t('form.section.details')}>
        <SelectField label={t('form.field.assignee')} placeholder="—" options={assigneeOptions} value={form.assignedToId} onChange={set('assignedToId')} />
        <TextAreaField label={t('form.field.description')} wide value={form.description} onChange={set('description')} />
      </FormSection>
    </CreateRecordDrawer>
  );
}