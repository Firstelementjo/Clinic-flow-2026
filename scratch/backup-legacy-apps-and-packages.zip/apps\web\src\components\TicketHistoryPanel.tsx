import { useState } from 'react';
import { Spinner, StatusChip, useDirection, type UiLocale } from '@firstelement/ui';
import { useQuery } from '@tanstack/react-query';
import type {
  ChannelType,
  ConversationMode,
  ConversationPriority,
  ConversationStatus,
  MessageView,
} from '@firstelement/shared';
import { api } from '../lib/api';
import { formatDate, formatTime } from '../lib/format';
import { useT, type StringKey } from '../lib/i18n';

interface ConversationSummary {
  id: string;
  ticketNumber: string;
  channel: ChannelType;
  status: ConversationStatus;
  mode: ConversationMode;
  priority: ConversationPriority;
  subject: string | null;
  messageCount: number;
  lastMessageAt: string;
  createdAt: string;
  assignedAgent: string | null;
}

interface ConversationDetail {
  id: string;
  ticketNumber: string;
  channel: ChannelType;
  status: ConversationStatus;
  mode: ConversationMode;
  priority: ConversationPriority;
  projectName: string;
  messageCount: number;
  messages: MessageView[];
}

/**
 * Ticket history panel — shows all past conversations for a customer.
 * Each ticket is expandable to show the full chat messages in a read-only
 * "history" visual style (faded messages, no reply box, warm tint).
 */
export function TicketHistoryPanel({
  customerId: _customerId,
  conversations,
  highlightTicket,
}: {
  customerId: string;
  conversations: ConversationSummary[];
  highlightTicket?: string;
}) {
  const t = useT();
  const { locale } = useDirection();

  // If a specific ticket was requested, auto-expand it
  const highlightConv = highlightTicket
    ? conversations.find((c) => c.ticketNumber === highlightTicket)
    : undefined;
  const [expandedId, setExpandedId] = useState<string | undefined>(highlightConv?.id);

  if (conversations.length === 0) {
    return (
      <div className="p-4">
        <p className="text-sm text-slate">{t('customers.history.empty')}</p>
      </div>
    );
  }

  return (
    <div className="divide-y divide-hairline">
      {conversations.map((conversation) => (
        <TicketRow
          key={conversation.id}
          conversation={conversation}
          isExpanded={expandedId === conversation.id}
          onToggle={() =>
            setExpandedId(expandedId === conversation.id ? undefined : conversation.id)
          }
          locale={locale}
          t={t}
        />
      ))}
    </div>
  );
}

function TicketRow({
  conversation,
  isExpanded,
  onToggle,
  locale,
  t,
}: {
  conversation: ConversationSummary;
  isExpanded: boolean;
  onToggle: () => void;
  locale: UiLocale;
  t: ReturnType<typeof useT>;
}) {
  return (
    <div>
      <button
        type="button"
        onClick={onToggle}
        className="flex w-full items-center gap-3 px-4 py-3 text-start hover:bg-mist/60 transition-colors"
      >
        <span className="text-sm font-medium text-ink">{conversation.ticketNumber}</span>
        <StatusChip
          tone={
            conversation.status === 'OPEN'
              ? 'human'
              : conversation.status === 'CLOSED'
                ? 'neutral'
                : 'ai'
          }
        >
          {t(`status.${conversation.status}` as StringKey)}
        </StatusChip>
        <span className="fe-eyebrow">{conversation.channel}</span>
        {conversation.assignedAgent && (
          <span className="text-xs text-slate">{conversation.assignedAgent}</span>
        )}
        <span className="fe-mono ms-auto text-2xs text-slate-soft" dir="ltr">
          {formatDate(conversation.createdAt, locale)}
        </span>
        <span className="text-xs text-slate-soft">{isExpanded ? '▲' : '▼'}</span>
      </button>

      {isExpanded && <ExpandedTicket conversationId={conversation.id} locale={locale} t={t} />}
    </div>
  );
}

function ExpandedTicket({
  conversationId,
  locale,
  t,
}: {
  conversationId: string;
  locale: UiLocale;
  t: ReturnType<typeof useT>;
}) {
  const conversation = useQuery({
    queryKey: ['conversation', conversationId],
    queryFn: () => api.get<ConversationDetail>(`/conversations/${conversationId}`),
  });

  if (conversation.isPending) {
    return (
      <div className="flex justify-center py-4">
        <Spinner label={t('common.loading')} />
      </div>
    );
  }

  if (conversation.isError || !conversation.data) {
    return (
      <p className="px-4 py-3 text-sm text-slate">{t('common.error')}</p>
    );
  }

  const data = conversation.data;

  return (
    <div className="border-t border-hairline bg-mist/30">
      {/* History banner */}
      <div className="flex items-center gap-2 border-b border-hairline bg-mist/60 px-4 py-2">
        <StatusChip tone="neutral">{t('customers.history.readOnly')}</StatusChip>
        <span className="fe-mono text-xs text-slate-soft" dir="ltr">
          {data.messageCount} {t('thread.messages')}
        </span>
        <span className="fe-eyebrow ms-auto">{data.channel}</span>
      </div>

      {/* Read-only messages — faded for history */}
      <div className="max-h-96 overflow-y-auto px-4 py-3 opacity-75">
        {data.messages.length === 0 ? (
          <p className="py-2 text-center text-xs text-slate">{t('customers.history.noMessages')}</p>
        ) : (
          <ol className="flex flex-col gap-2.5">
            {data.messages.map((message) => (
              <HistoryTurn key={message.id} message={message} locale={locale} t={t} />
            ))}
          </ol>
        )}
      </div>
    </div>
  );
}

function HistoryTurn({
  message,
  locale,
  t,
}: {
  message: MessageView;
  locale: UiLocale;
  t: ReturnType<typeof useT>;
}) {
  const isCustomer = message.authorType === 'CUSTOMER';

  return (
    <li
      className={[
        'max-w-[46rem] rounded border border-hairline border-s-[3px] px-3 py-2',
        isCustomer
          ? 'me-auto border-s-slate-soft bg-surface'
          : message.authorType === 'AI'
            ? 'ms-auto border-s-agent bg-agent-wash/40'
            : 'ms-auto border-s-signal bg-signal-wash/40',
      ].join(' ')}
    >
      <div className="mb-1 flex items-baseline gap-2">
        <span className="fe-eyebrow">
          {message.authorName ?? t(`author.${message.authorType}` as StringKey)}
        </span>
        <span className="fe-mono text-2xs text-slate-soft" dir="ltr">
          {formatTime(message.sentAt, locale)}
        </span>
      </div>
      <p className="whitespace-pre-wrap text-sm text-ink">{message.body}</p>
    </li>
  );
}
