import { Body, Controller, HttpCode, NotFoundException, Post } from '@nestjs/common';
import { ChannelType, ErrorCode, mockIncomingMessageSchema, type MockIncomingMessageInput } from '@firstelement/shared';
import { MockConnector } from '@firstelement/connectors';
import { getConfig } from '@firstelement/config';
import type { TenantContext } from '@firstelement/database';
import { Permission } from '@firstelement/auth';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { ConnectorRegistryProvider } from '../messaging/messaging.providers';
import { MessageQueueService } from '../messaging/message-queue.service';
import { ChannelsService } from './channels.service';

/**
 * The development inbound simulator (plan §13).
 *
 * It drives the *real* pipeline — normalize, resolve identity, find or
 * create the conversation, store idempotently, publish events — so what is
 * exercised in development is the same code path a live WhatsApp webhook
 * will take in slice 8. It is not a shortcut that inserts a row.
 *
 * Two gates, because a message-injection endpoint in production would be
 * a way to impersonate customers: it 404s unless ENABLE_MOCK_CONNECTOR is
 * set (configuration refuses that flag in production), and it still
 * requires a session with access to the target project.
 */
@Controller('dev/mock')
export class MockWebhookController {
  constructor(
    private readonly channels: ChannelsService,
    private readonly registry: ConnectorRegistryProvider,
    private readonly queue: MessageQueueService,
  ) {}

  @Post('incoming-message')
  @RequirePermissions(Permission.CONVERSATION_REPLY)
  @HttpCode(202)
  async incoming(
    @Tenant() ctx: TenantContext,
    @Body(zodBody(mockIncomingMessageSchema)) body: MockIncomingMessageInput,
  ): Promise<{ accepted: number }> {
    if (!getConfig().ENABLE_MOCK_CONNECTOR) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Not found' });
    }

    // projectScope inside this call is what proves the caller may write
    // into the target project — the body's projectId is a request, not an
    // authorization.
    const connection = await this.channels.requireEnabled(ctx, body.projectId, ChannelType.MOCK);
    const connector = this.registry.get(connection) as MockConnector;

    const normalized = await connector.receiveWebhook({
      externalUserId: body.externalUserId,
      text: body.text,
      displayName: body.displayName,
      phone: body.phone,
      email: body.email,
      externalMessageId: body.externalMessageId,
    });

    for (const message of normalized) {
      await this.queue.enqueueInbound({
        organizationId: ctx.organizationId,
        projectId: body.projectId,
        connectionId: connection.id,
        channel: ChannelType.MOCK,
        message,
      });
    }

    await this.channels.markInbound(connection.id);

    return { accepted: normalized.length };
  }
}
