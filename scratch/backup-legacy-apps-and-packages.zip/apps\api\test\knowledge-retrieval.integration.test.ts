/**
 * RAG retrieval against a real pgvector database (plan §6, §9).
 *
 * The guarantee under test cannot be unit-tested: that the project filter
 * runs *before* the similarity search, so one project's documents can
 * never surface in another's answers — not even ranked low.
 *
 * Requires PostgreSQL with pgvector and the migrations applied. Skips
 * loudly without one; see docs/rag.md.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { MockEmbeddingProvider } from '@firstelement/ai';
import { disconnectPrisma, getPrismaClient } from '@firstelement/database';
import {
  DocumentIngestionPipeline,
  KnowledgeRetriever,
  type StorageDriver,
} from '@firstelement/knowledge-base';

const prisma = getPrismaClient();

async function vectorReady(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1 FROM document_chunks LIMIT 1`;
    return true;
  } catch {
    return false;
  }
}

const hasDatabase = await vectorReady();

/** In-memory storage: these tests are about retrieval, not about disks. */
class MemoryStorage implements StorageDriver {
  private readonly files = new Map<string, Buffer>();

  async put(key: string, data: Buffer): Promise<void> {
    this.files.set(key, data);
  }

  async get(key: string): Promise<Buffer> {
    const file = this.files.get(key);
    if (!file) throw new Error(`Missing key ${key}`);
    return file;
  }

  async delete(key: string): Promise<void> {
    this.files.delete(key);
  }
}

describe.skipIf(!hasDatabase)('project-scoped retrieval', () => {
  const suffix = Date.now().toString(36);
  const storage = new MemoryStorage();
  const embeddings = new MockEmbeddingProvider();
  const ingestion = new DocumentIngestionPipeline(prisma, storage, embeddings);
  const retriever = new KnowledgeRetriever(prisma, embeddings);

  let organizationId: string;
  let projectA: string;
  let projectB: string;

  async function ingest(params: {
    projectId: string;
    knowledgeBaseId: string;
    title: string;
    content: string;
  }): Promise<string> {
    const storageKey = `test/${suffix}/${params.title}`;
    await storage.put(storageKey, Buffer.from(params.content, 'utf8'));

    const document = await prisma.document.create({
      data: {
        organizationId,
        projectId: params.projectId,
        knowledgeBaseId: params.knowledgeBaseId,
        title: params.title,
        sourceType: 'TEXT',
        storageKey,
        mimeType: 'text/plain',
        status: 'UPLOADED',
      },
      select: { id: true },
    });

    const result = await ingestion.process(document.id);
    expect(result.status).toBe('READY');
    return document.id;
  }

  beforeAll(async () => {
    const org = await prisma.organization.create({
      data: { name: `RAG ${suffix}`, slug: `rag-${suffix}` },
    });
    organizationId = org.id;

    const [a, b] = await Promise.all([
      prisma.project.create({ data: { organizationId, name: 'A', slug: 'a' } }),
      prisma.project.create({ data: { organizationId, name: 'B', slug: 'b' } }),
    ]);
    projectA = a.id;
    projectB = b.id;

    const [baseA, baseB] = await Promise.all([
      prisma.knowledgeBase.create({ data: { organizationId, projectId: projectA, name: 'Policies' } }),
      prisma.knowledgeBase.create({ data: { organizationId, projectId: projectB, name: 'Policies' } }),
    ]);

    await ingest({
      projectId: projectA,
      knowledgeBaseId: baseA.id,
      title: 'refund-policy.txt',
      content:
        'Refund policy. A refund takes three business days after the return is received.\n\n' +
        'Exchanges are processed in five business days.',
    });

    await ingest({
      projectId: projectA,
      knowledgeBaseId: baseA.id,
      title: 'hours.txt',
      content: 'Our Riyadh office opens at nine in the morning and closes at five.',
    });

    // Same subject, different tenant. This is the document that must never
    // appear in project A's results.
    await ingest({
      projectId: projectB,
      knowledgeBaseId: baseB.id,
      title: 'competitor-refund-policy.txt',
      content: 'Refund policy. A refund takes thirty business days and requires a manager.',
    });
  }, 60_000);

  afterAll(async () => {
    if (!hasDatabase) return;
    await prisma.organization.delete({ where: { id: organizationId } });
    await disconnectPrisma();
  });

  it('indexes a document into chunks with embeddings', async () => {
    const chunks = await prisma.documentChunk.count({ where: { projectId: projectA } });
    expect(chunks).toBeGreaterThan(0);

    const documents = await prisma.document.findMany({
      where: { projectId: projectA },
      select: { status: true, chunkCount: true },
    });
    for (const document of documents) {
      expect(document.status).toBe('READY');
      expect(document.chunkCount).toBeGreaterThan(0);
    }
  });

  it('retrieves the relevant document for a question', async () => {
    const result = await retriever.retrieve({
      organizationId,
      projectId: projectA,
      query: 'how long does a refund take',
    });

    expect(result.chunks.length).toBeGreaterThan(0);
    expect(result.chunks[0]!.documentTitle).toBe('refund-policy.txt');
    expect(result.isGap).toBe(false);
  });

  it('never returns another project chunk, even for an identical topic', async () => {
    const result = await retriever.retrieve({
      organizationId,
      projectId: projectA,
      query: 'refund policy business days',
      limit: 20,
      minScore: 0,
    });

    const foreign = await prisma.documentChunk.findMany({
      where: { projectId: projectB },
      select: { id: true },
    });
    const returnedIds = result.chunks.map((chunk) => chunk.chunkId);

    for (const chunk of foreign) {
      expect(returnedIds).not.toContain(chunk.id);
    }
    for (const chunk of result.chunks) {
      expect(chunk.documentTitle).not.toBe('competitor-refund-policy.txt');
    }
  });

  it('returns nothing for a project with no knowledge rather than falling back', async () => {
    const empty = await prisma.project.create({
      data: { organizationId, name: 'Empty', slug: `empty-${suffix}` },
    });

    const result = await retriever.retrieve({
      organizationId,
      projectId: empty.id,
      query: 'how long does a refund take',
    });

    expect(result.chunks).toHaveLength(0);
    expect(result.isGap).toBe(true);
  });

  it('flags a gap when nothing clears the score floor', async () => {
    const result = await retriever.retrieve({
      organizationId,
      projectId: projectA,
      query: 'kayak rental prices in the fjords',
      minScore: 0.9,
    });

    expect(result.isGap).toBe(true);
    await retriever.recordGap(
      { organizationId, projectId: projectA, query: 'kayak rental prices in the fjords' },
      result,
    );

    const gaps = await prisma.knowledgeGap.findMany({ where: { projectId: projectA } });
    expect(gaps).toHaveLength(1);
    expect(gaps[0]!.query).toContain('kayak');
  });

  it('excludes documents that are not READY', async () => {
    const document = await prisma.document.findFirstOrThrow({
      where: { projectId: projectA, title: 'refund-policy.txt' },
    });
    await prisma.document.update({ where: { id: document.id }, data: { status: 'FAILED' } });

    const result = await retriever.retrieve({
      organizationId,
      projectId: projectA,
      query: 'how long does a refund take',
      minScore: 0,
    });

    expect(result.chunks.every((chunk) => chunk.documentId !== document.id)).toBe(true);
    await prisma.document.update({ where: { id: document.id }, data: { status: 'READY' } });
  });

  it('re-processing replaces chunks instead of duplicating them', async () => {
    const document = await prisma.document.findFirstOrThrow({
      where: { projectId: projectA, title: 'hours.txt' },
    });

    const before = await prisma.documentChunk.count({ where: { documentId: document.id } });
    await ingestion.process(document.id);
    const after = await prisma.documentChunk.count({ where: { documentId: document.id } });

    expect(after).toBe(before);
  });
});

describe.skipIf(hasDatabase)('project-scoped retrieval (skipped)', () => {
  it('needs PostgreSQL with pgvector — see docs/rag.md', () => {
    expect(hasDatabase).toBe(false);
  });
});
