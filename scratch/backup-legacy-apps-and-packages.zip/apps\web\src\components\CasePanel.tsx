import { useEffect, useState, type FormEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button, Panel, Spinner, StatusChip, useDirection } from '@firstelement/ui';
import {
  CaseOutcome,
  type ClassificationQuestionView,
  type ClassificationView,
  type ConversationDetail,
  type ResolutionView,
} from '@firstelement/shared';
import { api } from '../lib/api';
import { useT, type StringKey } from '../lib/i18n';

/**
 * The case workspace beside the conversation (V1.2 §12–§15).
 *
 * Classification → solution → resolution → close, in the order an agent
 * works: understand the issue, find the answer, record what happened, end
 * the case. All of it sits next to the thread so none of it costs a
 * navigation (§21, minimal navigation).
 */
export function CasePanel({ conversation }: { conversation: ConversationDetail }) {
  const t = useT();
  const conversationId = conversation.id;

  const questions = useQuery({
    queryKey: ['classification-questions', conversation.projectId],
    queryFn: () =>
      api.get<ClassificationQuestionView[]>(
        `/projects/${conversation.projectId}/classification-questions`,
      ),
  });

  const classification = useQuery({
    queryKey: ['classification', conversationId],
    queryFn: () => api.get<ClassificationView>(`/conversations/${conversationId}/classification`),
  });

  const enabled = (questions.data ?? []).filter((question) => question.isEnabled);

  return (
    <div className="flex flex-col gap-3 border-t border-hairline p-4">
      <CaseClassification
        conversationId={conversationId}
        questions={enabled}
        classification={classification.data}
        isLoading={questions.isPending || classification.isPending}
      />

      <CaseResolution conversation={conversation} />

      <CaseActions conversation={conversation} />

      {enabled.length === 0 && !questions.isPending && (
        <p className="text-xs text-slate">{t('case.noQuestions')}</p>
      )}
    </div>
  );
}

function CaseClassification({
  conversationId,
  questions,
  classification,
  isLoading,
}: {
  conversationId: string;
  questions: ClassificationQuestionView[];
  classification?: ClassificationView;
  isLoading: boolean;
}) {
  const t = useT();
  const { locale } = useDirection();
  const queryClient = useQueryClient();
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showSolution, setShowSolution] = useState(false);

  // Seed from the server once it arrives, without clobbering edits in
  // progress on a refetch.
  useEffect(() => {
    if (!classification) return;
    setAnswers((current) =>
      Object.keys(current).length > 0
        ? current
        : Object.fromEntries(classification.answers.map((a) => [a.questionId, a.value])),
    );
  }, [classification?.classifiedAt]);

  const save = useMutation({
    mutationFn: () =>
      api.put<ClassificationView>(`/conversations/${conversationId}/classification`, {
        answers: Object.entries(answers).map(([questionId, value]) => ({ questionId, value })),
      }),
    onSuccess: (updated) => {
      queryClient.setQueryData(['classification', conversationId], updated);
      // Opening the solution is the point of answering (§13).
      if (updated.suggestion) setShowSolution(true);
    },
  });

  if (isLoading) return <Spinner label={t('common.loading')} />;
  if (questions.length === 0) return null;

  const suggestion = classification?.suggestion ?? null;

  return (
    <Panel eyebrow={t('case.eyebrow')} title={t('case.classification')}>
      <form
        onSubmit={(event: FormEvent) => {
          event.preventDefault();
          save.mutate();
        }}
        className="flex flex-col gap-4"
      >
        {questions.map((question) => {
          const selected = answers[question.id] ?? '';
          return (
            <div key={question.id} className="flex flex-col gap-1.5">
              <span className="text-xs font-medium text-ink-soft">
                {locale === 'ar' ? question.promptAr : question.promptEn}
                {question.isRequired && <span className="text-escalation"> *</span>}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {question.options.map((option) => {
                  const isActive = selected === option.value;
                  return (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() =>
                        setAnswers({
                          ...answers,
                          [question.id]: isActive ? '' : option.value,
                        })
                      }
                      className={[
                        'rounded-full border px-2.5 py-1 text-xs transition-colors',
                        isActive
                          ? 'border-[var(--fe-agent)] bg-[var(--fe-agent)] text-[var(--fe-surface)]'
                          : 'border-[var(--fe-hairline)] bg-[var(--fe-surface)] text-[var(--fe-ink)] hover:border-[var(--fe-agent)]',
                      ].join(' ')}
                    >
                      {locale === 'ar' ? option.labelAr : option.labelEn}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}

        <div className="flex items-center gap-2">
          <Button type="submit" size="sm" variant="primary" loading={save.isPending}>
            {t('case.classify')}
          </Button>
          {classification?.isComplete && (
            <StatusChip tone="human">{t('case.complete')}</StatusChip>
          )}
        </div>
      </form>

      {suggestion && (
        <div className="mt-3 rounded border border-[var(--fe-hairline)] bg-[var(--fe-mist-deep)] p-2">
          <div className="mb-1 flex items-center gap-2">
            <span className="fe-eyebrow">{t('case.solution')}</span>
            <span className="truncate text-xs text-ink">{suggestion.documentTitle}</span>
            {suggestion.score !== null && (
              <span className="fe-mono ms-auto text-2xs text-slate" dir="ltr">
                {suggestion.score.toFixed(2)}
              </span>
            )}
          </div>

          <Button size="sm" variant="secondary" onClick={() => setShowSolution(!showSolution)}>
            {showSolution ? t('case.hideSolution') : t('case.viewSolution')}
          </Button>

          {showSolution && (
            <p className="mt-2 whitespace-pre-wrap text-xs text-slate">{suggestion.excerpt}</p>
          )}
        </div>
      )}

      {classification && !suggestion && classification.answers.length > 0 && (
        // Saying so beats an empty space: the knowledge base has nothing
        // for this classification, and that is a gap worth filling.
        <p className="mt-2 text-xs text-slate">{t('case.noSolution')}</p>
      )}
    </Panel>
  );
}

function CaseResolution({ conversation }: { conversation: ConversationDetail }) {
  const t = useT();
  const queryClient = useQueryClient();
  const conversationId = conversation.id;
  const [open, setOpen] = useState(false);

  const resolution = useQuery({
    queryKey: ['resolution', conversationId],
    queryFn: () => api.get<ResolutionView | null>(`/conversations/${conversationId}/resolution`),
  });

  const [form, setForm] = useState({
    customerIssue: '',
    agentAction: '',
    usedKnowledgeBase: false,
    customerAccepted: null as boolean | null,
    customerSatisfied: null as boolean | null,
    escalationRequested: false,
    escalatedToSupervisor: false,
    outcome: CaseOutcome.RESOLVED as CaseOutcome,
    notes: '',
  });

  useEffect(() => {
    if (!resolution.data) return;
    setForm({
      customerIssue: resolution.data.customerIssue,
      agentAction: resolution.data.agentAction,
      usedKnowledgeBase: resolution.data.usedKnowledgeBase,
      customerAccepted: resolution.data.customerAccepted ?? null,
      customerSatisfied: resolution.data.customerSatisfied ?? null,
      escalationRequested: resolution.data.escalationRequested,
      escalatedToSupervisor: resolution.data.escalatedToSupervisor,
      outcome: resolution.data.outcome,
      notes: resolution.data.notes ?? '',
    });
  }, [resolution.data?.id]);

  const save = useMutation({
    mutationFn: () =>
      api.put<ResolutionView>(`/conversations/${conversationId}/resolution`, {
        ...form,
        notes: form.notes || null,
      }),
    onSuccess: (saved) => {
      queryClient.setQueryData(['resolution', conversationId], saved);
      void queryClient.invalidateQueries({ queryKey: ['analytics-summary'] });
      setOpen(false);
    },
  });

  return (
    <Panel
      eyebrow={t('case.eyebrow')}
      title={t('case.resolution')}
      actions={
        <Button size="sm" variant="ghost" onClick={() => setOpen(!open)}>
          {open ? t('case.hide') : resolution.data ? t('case.edit') : t('case.record')}
        </Button>
      }
    >
      {!open && resolution.data && (
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <StatusChip
            tone={
              resolution.data.outcome === 'RESOLVED'
                ? 'human'
                : resolution.data.outcome === 'ESCALATED'
                  ? 'escalated'
                  : 'neutral'
            }
          >
            {t(`outcome.${resolution.data.outcome}` as StringKey)}
          </StatusChip>
          {resolution.data.customerSatisfied !== null && (
            <StatusChip tone={resolution.data.customerSatisfied ? 'human' : 'danger'}>
              {resolution.data.customerSatisfied ? t('case.satisfied') : t('case.notSatisfied')}
            </StatusChip>
          )}
          <span className="truncate text-slate">{resolution.data.customerIssue}</span>
        </div>
      )}

      {!open && !resolution.data && <p className="text-xs text-slate">{t('case.notRecorded')}</p>}

      {open && (
        <form
          onSubmit={(event: FormEvent) => {
            event.preventDefault();
            save.mutate();
          }}
          className="flex flex-col gap-2"
        >
          <TextArea
            label={t('case.issue')}
            value={form.customerIssue}
            onChange={(value) => setForm({ ...form, customerIssue: value })}
          />
          <TextArea
            label={t('case.action')}
            value={form.agentAction}
            onChange={(value) => setForm({ ...form, agentAction: value })}
          />

          <Check
            label={t('case.usedKb')}
            checked={form.usedKnowledgeBase}
            onChange={(value) => setForm({ ...form, usedKnowledgeBase: value })}
          />
          <Tri
            label={t('case.accepted')}
            value={form.customerAccepted}
            onChange={(value) => setForm({ ...form, customerAccepted: value })}
          />
          <Tri
            label={t('case.satisfiedQ')}
            value={form.customerSatisfied}
            onChange={(value) => setForm({ ...form, customerSatisfied: value })}
          />
          <Check
            label={t('case.escalationRequested')}
            checked={form.escalationRequested}
            onChange={(value) => setForm({ ...form, escalationRequested: value })}
          />
          <Check
            label={t('case.escalatedToSupervisor')}
            checked={form.escalatedToSupervisor}
            onChange={(value) => setForm({ ...form, escalatedToSupervisor: value })}
          />

          <label className="flex flex-col gap-1">
            <span className="text-xs font-medium text-ink-soft">{t('case.outcome')}</span>
            <select
              value={form.outcome}
              onChange={(e) => setForm({ ...form, outcome: e.target.value as CaseOutcome })}
              className="h-8 rounded border border-[var(--fe-hairline)] bg-[var(--fe-surface)] px-2 text-xs text-[var(--fe-ink)]"
            >
              {Object.values(CaseOutcome).map((outcome) => (
                <option key={outcome} value={outcome}>
                  {t(`outcome.${outcome}` as StringKey)}
                </option>
              ))}
            </select>
          </label>

          <TextArea
            label={t('case.notes')}
            value={form.notes}
            onChange={(value) => setForm({ ...form, notes: value })}
          />

          <div className="flex items-center gap-2">
            <Button
              type="submit"
              size="sm"
              variant="primary"
              loading={save.isPending}
              disabled={!form.customerIssue.trim() || !form.agentAction.trim()}
            >
              {t('case.save')}
            </Button>
            {save.isError && (
              <span className="text-xs text-danger">{(save.error as Error).message}</span>
            )}
          </div>
        </form>
      )}
    </Panel>
  );
}

/** Close and reopen (V1.2 §15). */
function CaseActions({ conversation }: { conversation: ConversationDetail }) {
  const t = useT();
  const queryClient = useQueryClient();
  const isClosed = conversation.status === 'CLOSED';

  const act = useMutation({
    mutationFn: (action: 'close' | 'reopen') =>
      api.post<{ status: string }>(`/conversations/${conversation.id}/${action}`),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['conversation', conversation.id] });
      void queryClient.invalidateQueries({ queryKey: ['inbox'] });
    },
  });

  return (
    <div className="flex items-center gap-2">
      <Button
        size="sm"
        variant={isClosed ? 'secondary' : 'primary'}
        loading={act.isPending}
        onClick={() => act.mutate(isClosed ? 'reopen' : 'close')}
      >
        {isClosed ? t('case.reopen') : t('case.close')}
      </Button>
      {/* Closing without a resolution is refused server-side; showing the
          reason here saves the agent a round trip to find out why. */}
      {act.isError && <span className="text-xs text-danger">{(act.error as Error).message}</span>}
    </div>
  );
}

function TextArea({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-xs font-medium text-[var(--fe-slate)]">{label}</span>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="t"
      />
    </label>
  );
}

function Check({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="flex items-center gap-2 text-xs text-[var(--fe-ink)]">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  );
}

/**
 * Yes / no / not recorded. The third state matters: an unanswered
 * satisfaction question must not count as a dissatisfied customer.
 */
function Tri({
  label,
  value,
  onChange,
}: {
  label: string;
  value: boolean | null;
  onChange: (value: boolean | null) => void;
}) {
  const t = useT();
  return (
    <label className="flex items-center gap-2 text-xs text-[var(--fe-ink)]">
      <span className="flex-1">{label}</span>
      <select
        value={value === null ? '' : value ? 'yes' : 'no'}
        onChange={(e) => onChange(e.target.value === '' ? null : e.target.value === 'yes')}
        className="h-7 rounded border border-[var(--fe-hairline)] bg-[var(--fe-surface)] px-1.5 text-xs"
      >
        <option value="">{t('case.unknown')}</option>
        <option value="yes">{t('common.yes')}</option>
        <option value="no">{t('common.no')}</option>
      </select>
    </label>
  );
}
