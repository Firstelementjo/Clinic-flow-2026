import { Controller, Delete, Get, Patch, Post, Param, Body, UseGuards, Query } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { Tenant, RequirePermissions } from '../auth/decorators';
import type { TenantContext } from '@firstelement/database';
import { Permission } from '@firstelement/auth';
import { AccountsService } from './accounts.service';

@Controller('accounts')
@UseGuards(AuthGuard)
export class AccountsController {
  constructor(private readonly accountsService: AccountsService) {}

  @Get()
  @RequirePermissions(Permission.ACCOUNT_READ)
  async list(
    @Tenant() ctx: TenantContext,
    @Query() query: { search?: string; industry?: string },
  ) {
    return this.accountsService.list(ctx, query.search, query.industry);
  }

  @Get(':id')
  @RequirePermissions(Permission.ACCOUNT_READ)
  async get(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.accountsService.getById(ctx, id);
  }

  @Post()
  @RequirePermissions(Permission.ACCOUNT_CREATE)
  async create(
    @Tenant() ctx: TenantContext,
    @Body() body: {
      name: string;
      companyType?: string;
      industry?: string;
      website?: string;
      size?: string;
      phone?: string;
      email?: string;
      linkedin?: string;
      country?: string;
      city?: string;
      address?: string;
      postalCode?: string;
      description?: string;
      ownerId?: string;
      status?: string;
      leadSource?: string;
      priority?: string;
      tags?: string[];
      notes?: string;
    },
  ) {
    return this.accountsService.create(ctx, body.name, {
      companyType: body.companyType,
      industry: body.industry,
      website: body.website,
      size: body.size,
      phone: body.phone,
      email: body.email,
      linkedin: body.linkedin,
      country: body.country,
      city: body.city,
      address: body.address,
      postalCode: body.postalCode,
      description: body.description,
      ownerId: body.ownerId,
      status: body.status,
      leadSource: body.leadSource,
      priority: body.priority,
      tags: body.tags,
      notes: body.notes,
    });
  }

  @Patch(':id')
  @RequirePermissions(Permission.ACCOUNT_UPDATE)
  async update(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body() body: {
      name?: string;
      companyType?: string;
      industry?: string;
      website?: string;
      size?: string;
      phone?: string;
      email?: string;
      linkedin?: string;
      country?: string;
      city?: string;
      address?: string;
      postalCode?: string;
      description?: string;
      ownerId?: string;
      status?: string;
      leadSource?: string;
      priority?: string;
      tags?: string[];
      notes?: string;
    },
  ) {
    return this.accountsService.update(ctx, id, body);
  }

  @Delete(':id')
  @RequirePermissions(Permission.ACCOUNT_DELETE)
  async delete(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.accountsService.delete(ctx, id);
  }
}