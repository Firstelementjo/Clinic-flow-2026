import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { Request } from 'express';
import { SESSION_COOKIE_NAME } from '@firstelement/auth';
import { ErrorCode } from '@firstelement/shared';
import { IS_PUBLIC_KEY } from './decorators';
import { SessionService } from './session.service';

/**
 * Global authentication guard: routes are authenticated by default and
 * must opt out with `@Public()`. The inverse (opt-in protection) makes a
 * forgotten decorator a silent data leak.
 */
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly sessions: SessionService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    const request = context.switchToHttp().getRequest<Request>();
    const token = request.cookies?.[SESSION_COOKIE_NAME] as string | undefined;

    if (!token) throw this.expired();

    const resolved = await this.sessions.resolve(token);
    if (!resolved) throw this.expired();

    request.sessionUser = resolved.user;
    request.sessionId = resolved.sessionId;
    request.tenant = {
      organizationId: resolved.user.organizationId,
      userId: resolved.user.id,
      role: resolved.user.role,
      projectIds: resolved.user.projectIds,
    };

    return true;
  }

  private expired(): UnauthorizedException {
    return new UnauthorizedException({
      code: ErrorCode.SESSION_EXPIRED,
      message: 'Authentication required',
    });
  }
}
