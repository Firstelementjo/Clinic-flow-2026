import { atom, useAtom } from 'jotai';
import type { UiLocale } from '@firstelement/ui';

const STORAGE_KEY = 'fe.locale';

function initialLocale(): UiLocale {
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored === 'en' || stored === 'ar' ? stored : 'ar';
}

/**
 * Locale is genuine client state (a per-device preference), so it lives in
 * Jotai rather than TanStack Query. It seeds from the user's saved locale
 * on first sign-in and is theirs to override afterwards.
 */
const localeAtom = atom<UiLocale>(initialLocale());

export function useLocale() {
  const [locale, setLocaleState] = useAtom(localeAtom);

  const setLocale = (next: UiLocale) => {
    localStorage.setItem(STORAGE_KEY, next);
    setLocaleState(next);
  };

  return { locale, setLocale, toggle: () => setLocale(locale === 'ar' ? 'en' : 'ar') };
}
