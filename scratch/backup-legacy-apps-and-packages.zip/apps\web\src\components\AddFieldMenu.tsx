import { useEffect, useRef, useState, useMemo } from 'react';
import { createPortal } from 'react-dom';
import {
  Activity,
  Calendar,
  CalendarClock,
  CalendarPlus,
  CalendarX,
  CheckCircle2,
  Clock3,
  DollarSign,
  FileText,
  Image as ImageIcon,
  List,
  Mail,
  MessageSquare,
  Paperclip,
  Settings2,
  Search,
  Trophy,
  Users,
  UserRound,
  Plus,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useT } from '../lib/i18n';

export interface FieldDef {
  id: string;
  label: string;
  icon: LucideIcon;
}

// Registry per CRM object — flat list, no section headers (spec §6)
const REGISTRY: Record<string, FieldDef[]> = {
  // Notes: Last update, Deleted at, Updated by, Attachments, Timeline Activities
  note: [
    { id: 'updatedAt', label: 'Last update', icon: Clock3 },
    { id: 'deletedAt', label: 'Deleted at', icon: CalendarX },
    { id: 'updatedBy', label: 'Updated by', icon: UserRound },
    { id: 'attachments', label: 'Attachments', icon: Paperclip },
    { id: 'timeline', label: 'Timeline Activities', icon: Activity },
  ],
  task: [
    { id: 'updatedAt', label: 'Last update', icon: Clock3 },
    { id: 'deletedAt', label: 'Deleted at', icon: CalendarX },
    { id: 'updatedBy', label: 'Updated by', icon: UserRound },
    { id: 'attachments', label: 'Attachments', icon: Paperclip },
    { id: 'timeline', label: 'Timeline Activities', icon: Activity },
  ],
  opportunity: [
    { id: 'createdAt', label: 'Creation date', icon: CalendarPlus },
    { id: 'updatedAt', label: 'Last update', icon: Clock3 },
    { id: 'deletedAt', label: 'Deleted at', icon: CalendarX },
    { id: 'stage', label: 'Stage', icon: Trophy },
    { id: 'updatedBy', label: 'Updated by', icon: UserRound },
    { id: 'attachments', label: 'Attachments', icon: Paperclip },
    { id: 'calendarEvents', label: 'Calendar events', icon: Calendar },
    { id: 'emails', label: 'Emails', icon: Mail },
    { id: 'notes', label: 'Notes', icon: FileText },
    { id: 'tasks', label: 'Tasks', icon: CheckCircle2 },
    { id: 'timeline', label: 'Timeline Activities', icon: Activity },
    { id: 'owner', label: 'Owner', icon: UserRound },
  ],
  company: [
    { id: 'updatedAt', label: 'Last update', icon: Clock3 },
    { id: 'deletedAt', label: 'Deleted at', icon: CalendarX },
    { id: 'annualRevenue', label: 'Annual Revenue', icon: DollarSign },
    { id: 'updatedBy', label: 'Updated by', icon: UserRound },
    { id: 'attachments', label: 'Attachments', icon: Paperclip },
    { id: 'calendarEvents', label: 'Calendar events', icon: Calendar },
    { id: 'people', label: 'People', icon: Users },
    { id: 'tasks', label: 'Tasks', icon: CheckCircle2 },
    { id: 'notes', label: 'Notes', icon: FileText },
    { id: 'emails', label: 'Emails', icon: Mail },
    { id: 'opportunities', label: 'Opportunities', icon: Trophy },
    { id: 'timeline', label: 'Timeline Activities', icon: Activity },
  ],
  person: [
    { id: 'updatedAt', label: 'Last update', icon: Clock3 },
    { id: 'deletedAt', label: 'Deleted at', icon: CalendarX },
    { id: 'avatar', label: 'Avatar', icon: ImageIcon },
    { id: 'avatarFile', label: 'Avatar File', icon: ImageIcon },
    { id: 'updatedBy', label: 'Updated by', icon: UserRound },
    { id: 'attachments', label: 'Attachments', icon: Paperclip },
    { id: 'calendarEventParticipants', label: 'Calendar Event Participants', icon: Users },
    { id: 'calendarEvents', label: 'Calendar events', icon: Calendar },
    { id: 'lists', label: 'Lists', icon: List },
    { id: 'messageParticipants', label: 'Message Participants', icon: MessageSquare },
    { id: 'emails', label: 'Emails', icon: Mail },
    { id: 'notes', label: 'Notes', icon: FileText },
    { id: 'opportunities', label: 'Opportunities', icon: Trophy },
    { id: 'tasks', label: 'Tasks', icon: CheckCircle2 },
    { id: 'events', label: 'Events', icon: CalendarClock },
  ],
};

// Fallback for unknown objectTypes — show generic set
const GENERIC: FieldDef[] = [
  { id: 'updatedAt', label: 'Last update', icon: Clock3 },
  { id: 'deletedAt', label: 'Deleted at', icon: CalendarX },
  { id: 'updatedBy', label: 'Updated by', icon: UserRound },
];

export function getAvailableFields(objectType: string): FieldDef[] {
  const key = objectType.toLowerCase();
  // Normalize: people -> person, companies -> company, opportunities -> opportunity
  if (key === 'people' || key === 'person') return REGISTRY.person!;
  if (key === 'companies' || key === 'company') return REGISTRY.company!;
  if (key === 'opportunities' || key === 'opportunity') return REGISTRY.opportunity!;
  if (key === 'tasks' || key === 'task') return REGISTRY.task!;
  if (key === 'notes' || key === 'note') return REGISTRY.note!;
  return (REGISTRY[key] as FieldDef[] | undefined) ?? GENERIC;
}

interface AddFieldMenuProps {
  objectType: string;
  /** ids currently displayed as columns (visible) */
  visibleIds: string[];
  onAddField: (fieldId: string) => void;
  onCustomize?: () => void;
}

export function AddFieldMenu({ objectType, visibleIds, onAddField, onCustomize }: AddFieldMenuProps) {
  const t = useT();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const triggerRef = useRef<HTMLButtonElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [anchor, setAnchor] = useState<{ top: number; left: number } | null>(null);

  const visibleSet = useMemo(() => new Set(visibleIds), [visibleIds]);

  const allFields = useMemo(() => getAvailableFields(objectType), [objectType]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return allFields.filter((f) => {
      if (visibleSet.has(f.id)) return false;
      if (!q) return true;
      return f.label.toLowerCase().includes(q);
    });
  }, [allFields, visibleSet, search]);

  useEffect(() => {
    if (!open) {
      setAnchor(null);
      setSearch('');
      return;
    }
    const el = triggerRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    // Position below header, slightly left of + button (spec §1)
    // Align right edge of panel to right edge of trigger + small offset
    const panelWidth = 320;
    let left = r.right - panelWidth + 12; // slightly left of button
    left = Math.max(8, Math.min(left, window.innerWidth - panelWidth - 8));
    setAnchor({ top: r.bottom + 6, left });
    // autofocus search
    setTimeout(() => inputRef.current?.focus(), 30);
  }, [open]);

  const handleAdd = (id: string) => {
    onAddField(id);
    // keep open for adding multiple columns (spec §10)
  };

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        aria-label="Add field"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className="flex h-7 w-7 items-center justify-center rounded border border-hairline bg-surface text-slate-soft transition-colors hover:border-slate-soft hover:text-ink"
      >
        <Plus aria-hidden="true" className="h-4 w-4" />
      </button>

      {open && anchor
        ? createPortal(
            <>
              <button
                type="button"
                aria-hidden="true"
                tabIndex={-1}
                onClick={() => setOpen(false)}
                className="fixed inset-0 z-20 cursor-default"
              />
              <div
                role="menu"
                style={{ top: anchor.top, left: anchor.left, width: 320 }}
                className="fixed z-30 flex max-h-[min(72vh,420px)] flex-col overflow-hidden rounded-xl border border-white/10 bg-[#1a1d23] shadow-[0_16px_40px_rgba(0,0,0,0.5)]"
              >
                {/* Search */}
                <div className="p-2.5">
                  <div className="relative">
                    <Search
                      aria-hidden="true"
                      className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-soft"
                    />
                    <input
                      ref={inputRef}
                      type="search"
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      placeholder={t('list.searchFields' as any) ?? 'Search fields'}
                      className="h-8 w-full rounded-lg border border-white/10 bg-white/[0.06] py-1 pl-8 pr-3 text-xs text-white placeholder:text-slate-soft focus:border-white/20 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Scrollable Field List */}
                <div className="min-h-0 flex-1 overflow-y-auto px-1.5 py-1">
                  {filtered.length === 0 ? (
                    <p className="px-3 py-6 text-center text-xs text-slate-soft">
                      {search.trim() ? 'No fields found' : 'All fields added'}
                    </p>
                  ) : (
                    filtered.map((field) => {
                      const Icon = field.icon;
                      return (
                        <button
                          key={field.id}
                          type="button"
                          role="menuitem"
                          onClick={() => handleAdd(field.id)}
                          className="flex h-10 w-full items-center gap-3 rounded-md px-3 text-start transition-colors hover:bg-white/[0.07] group"
                        >
                          <Icon
                            aria-hidden="true"
                            className="h-[18px] w-[18px] shrink-0 text-slate-soft transition-colors group-hover:text-white"
                          />
                          <span className="truncate text-sm text-[#c8cdd6] transition-colors group-hover:text-white">
                            {field.label}
                          </span>
                        </button>
                      );
                    })
                  )}
                </div>

                {/* Divider + Customize */}
                <div className="border-t border-white/10 p-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setOpen(false);
                      onCustomize?.();
                    }}
                    className="flex h-10 w-full items-center gap-3 rounded-md px-3 text-start transition-colors hover:bg-white/[0.07] group"
                  >
                    <Settings2
                      aria-hidden="true"
                      className="h-[18px] w-[18px] shrink-0 text-slate-soft transition-colors group-hover:text-white"
                    />
                    <span className="truncate text-sm text-[#c8cdd6] transition-colors group-hover:text-white">
                      Customize fields
                    </span>
                  </button>
                </div>
              </div>
            </>,
            document.body,
          )
        : null}
    </>
  );
}
