import type { TurnScores } from './evaluator';

/**
 * Escalation rules (plan §10).
 *
 * Conditions are data, not code: an ops manager changes "escalate at 70"
 * in the UI, and the change takes effect without a deploy. Evaluation is a
 * pure function so the same rule set can be unit-tested, previewed against
 * a past conversation, and explained afterwards.
 */

export const ScoreSignal = {
  FRUSTRATION: 'frustration',
  SENTIMENT: 'sentiment',
  URGENCY: 'urgency',
  RISK: 'risk',
  INTENT_CONFIDENCE: 'intentConfidence',
  AI_CONFIDENCE: 'aiConfidence',
  /** Not a score: how many AI turns have passed without resolution. */
  AI_TURNS_WITHOUT_RESOLUTION: 'aiTurnsWithoutResolution',
  /** 1 when the customer explicitly asked for a person. */
  EXPLICIT_HUMAN_REQUEST: 'explicitHumanRequest',
} as const;
export type ScoreSignal = (typeof ScoreSignal)[keyof typeof ScoreSignal];

export const RuleOperator = {
  GTE: 'gte',
  LTE: 'lte',
  GT: 'gt',
  LT: 'lt',
  EQ: 'eq',
} as const;
export type RuleOperator = (typeof RuleOperator)[keyof typeof RuleOperator];

export interface RuleCondition {
  signal: ScoreSignal;
  operator: RuleOperator;
  value: number;
}

export interface EscalationRuleInput {
  id: string;
  name: string;
  isEnabled: boolean;
  priority: number;
  conditions: RuleCondition[];
  combinator: 'ALL' | 'ANY';
  department?: string | null;
}

export interface RuleFacts extends TurnScores {
  aiTurnsWithoutResolution: number;
  explicitHumanRequest: boolean;
}

export interface RuleMatch {
  rule: EscalationRuleInput;
  /** The conditions that were true, for the escalation reason. */
  matched: RuleCondition[];
}

/**
 * First matching rule wins, by ascending priority.
 *
 * Deterministic ordering matters: two rules can both be true, and an
 * escalation that picks a different one on each run is impossible to
 * reason about or to test.
 */
export function evaluateRules(
  rules: EscalationRuleInput[],
  facts: RuleFacts,
): RuleMatch | null {
  const ordered = [...rules]
    .filter((rule) => rule.isEnabled && rule.conditions.length > 0)
    .sort((a, b) => a.priority - b.priority || a.id.localeCompare(b.id));

  for (const rule of ordered) {
    const matched = rule.conditions.filter((condition) => testCondition(condition, facts));
    const isMatch =
      rule.combinator === 'ANY'
        ? matched.length > 0
        : matched.length === rule.conditions.length;

    if (isMatch) return { rule, matched };
  }

  return null;
}

export function testCondition(condition: RuleCondition, facts: RuleFacts): boolean {
  const actual = readSignal(condition.signal, facts);
  // A signal the evaluator did not produce (aiConfidence on a customer
  // turn) must not silently count as zero and fire an "≤ 30" rule.
  if (actual === null) return false;

  switch (condition.operator) {
    case RuleOperator.GTE:
      return actual >= condition.value;
    case RuleOperator.LTE:
      return actual <= condition.value;
    case RuleOperator.GT:
      return actual > condition.value;
    case RuleOperator.LT:
      return actual < condition.value;
    case RuleOperator.EQ:
      return actual === condition.value;
    default:
      return false;
  }
}

function readSignal(signal: ScoreSignal, facts: RuleFacts): number | null {
  switch (signal) {
    case ScoreSignal.FRUSTRATION:
      return facts.frustration;
    case ScoreSignal.SENTIMENT:
      return facts.sentiment;
    case ScoreSignal.URGENCY:
      return facts.urgency;
    case ScoreSignal.RISK:
      return facts.risk;
    case ScoreSignal.INTENT_CONFIDENCE:
      return facts.intentConfidence;
    case ScoreSignal.AI_CONFIDENCE:
      return facts.aiConfidence;
    case ScoreSignal.AI_TURNS_WITHOUT_RESOLUTION:
      return facts.aiTurnsWithoutResolution;
    case ScoreSignal.EXPLICIT_HUMAN_REQUEST:
      return facts.explicitHumanRequest ? 1 : 0;
    default:
      return null;
  }
}

/**
 * The rules a new project starts with. They encode the plan's own
 * examples (§10) and are fully editable afterwards — defaults, not policy.
 */
export const DEFAULT_ESCALATION_RULES: Omit<EscalationRuleInput, 'id'>[] = [
  {
    name: 'Customer asked for a person',
    isEnabled: true,
    priority: 10,
    combinator: 'ALL',
    conditions: [{ signal: ScoreSignal.EXPLICIT_HUMAN_REQUEST, operator: RuleOperator.EQ, value: 1 }],
  },
  {
    name: 'High risk',
    isEnabled: true,
    priority: 20,
    combinator: 'ALL',
    conditions: [{ signal: ScoreSignal.RISK, operator: RuleOperator.GTE, value: 75 }],
  },
  {
    name: 'Frustration threshold',
    isEnabled: true,
    priority: 30,
    combinator: 'ALL',
    conditions: [{ signal: ScoreSignal.FRUSTRATION, operator: RuleOperator.GTE, value: 70 }],
  },
  {
    name: 'Frustrated and negative',
    isEnabled: true,
    priority: 40,
    combinator: 'ALL',
    conditions: [
      { signal: ScoreSignal.FRUSTRATION, operator: RuleOperator.GTE, value: 50 },
      { signal: ScoreSignal.SENTIMENT, operator: RuleOperator.LTE, value: 25 },
    ],
  },
  {
    name: 'Repeated AI attempts',
    isEnabled: true,
    priority: 50,
    combinator: 'ALL',
    conditions: [
      { signal: ScoreSignal.AI_TURNS_WITHOUT_RESOLUTION, operator: RuleOperator.GTE, value: 4 },
    ],
  },
];

/** Renders a matched rule as the one sentence an employee reads first. */
export function describeMatch(match: RuleMatch): string {
  const parts = match.matched.map(
    (condition) => `${condition.signal} ${symbolFor(condition.operator)} ${condition.value}`,
  );
  return `${match.rule.name} (${parts.join(match.rule.combinator === 'ANY' ? ' or ' : ' and ')})`;
}

function symbolFor(operator: RuleOperator): string {
  switch (operator) {
    case RuleOperator.GTE:
      return '≥';
    case RuleOperator.LTE:
      return '≤';
    case RuleOperator.GT:
      return '>';
    case RuleOperator.LT:
      return '<';
    default:
      return '=';
  }
}
