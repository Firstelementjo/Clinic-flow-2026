import type { ApiErrorBody } from '@firstelement/shared';

/**
 * The one place the browser talks to the API.
 *
 * Auth rides on the httpOnly session cookie — the frontend never holds a
 * token, so there is nothing in JS for an XSS payload to steal.
 */
export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly body: ApiErrorBody,
  ) {
    super(body.message);
    this.name = 'ApiError';
  }

  /** Field-level messages for rendering inline under inputs. */
  get fieldErrors(): Record<string, string[]> {
    return this.body.details ?? {};
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  // FormData must carry the browser's own multipart boundary, so the JSON
  // content type is only applied to non-multipart bodies.
  const isMultipart = init.body instanceof FormData;

  const response = await fetch(`/api${path}`, {
    ...init,
    credentials: 'include',
    headers: {
      ...(isMultipart ? {} : { 'Content-Type': 'application/json' }),
      ...init.headers,
    },
  });

  if (response.status === 204) return undefined as T;

  const payload = await response.json().catch(() => null);

  if (!response.ok) {
    throw new ApiError(
      response.status,
      (payload as ApiErrorBody | null) ?? {
        code: 'INTERNAL',
        message: 'The server did not respond as expected.',
      },
    );
  }

  return payload as T;
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'POST', body: body === undefined ? undefined : JSON.stringify(body) }),
  patch: <T>(path: string, body: unknown) =>
    request<T>(path, { method: 'PATCH', body: JSON.stringify(body) }),
  put: <T>(path: string, body: unknown) =>
    request<T>(path, { method: 'PUT', body: JSON.stringify(body) }),
  delete: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
  /**
   * Multipart upload. The Content-Type header is deliberately omitted so
   * the browser sets it along with the multipart boundary — setting it by
   * hand produces a body the server cannot parse.
   */
  upload: <T>(path: string, body: FormData) =>
    request<T>(path, { method: 'POST', body, headers: {} }),
};
