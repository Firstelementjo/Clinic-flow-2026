/**
 * Shared, minimal control styles for the sales-pipeline pages.
 *
 * These keep the "no raw values" invariant: every class resolves through
 * the design tokens (see packages/ui/tailwind-preset.js). A control has a
 * single hairline border, a 1.75rem hit area and quiet slate labels — the
 * whole page reads as paper, not boxes.
 */

export const controlCls =
  'h-7 rounded border border-hairline bg-surface px-2.5 text-xs text-ink placeholder:text-slate-soft transition-colors focus:border-signal';

export const searchCls =
  'h-8 w-full rounded border border-hairline bg-surface px-3 text-xs text-ink placeholder:text-slate-soft transition-colors focus:border-signal';

export const selectCls =
  'h-6 rounded border border-hairline bg-surface px-1.5 text-xs text-ink transition-colors hover:border-slate-soft focus:border-signal';

export const rowCls =
  'transition-colors hover:bg-mist/40';

/** Quiet action link used inside list rows. */
export const linkCls =
  'text-xs font-medium text-signal transition-colors hover:underline disabled:cursor-not-allowed disabled:opacity-50';