import { useQuery } from '@tanstack/react-query';
import { Panel, Spinner } from '@firstelement/ui';
import { api } from '../lib/api';
import { DonutMetric } from '../components/DonutMetric';
import { SatisfactionDonut } from '../components/SatisfactionDonut';
import { useT } from '../lib/i18n';

interface EmployeeAnalyticsData {
  csat: number | null;
  dsat: number | null;
  resolveRate: number | null;
  casesResolved: number;
  averageHandlingMinutes: number | null;
  medianFirstResponseMinutes: number | null;
}

/**
 * Dashboard for employees (non-admin). Shows personal performance
 * metrics: CSAT, DSAT, AHT, FRT, resolve rate and solved tickets.
 */
export function EmployeeDashboard() {
  const t = useT();

  const stats = useQuery({
    queryKey: ['my-analytics'],
    queryFn: () => api.get<EmployeeAnalyticsData>('/me/analytics?days=30'),
    retry: false,
  });

  return (
    <div className="flex flex-col gap-4">
      <Panel eyebrow={t('analytics.eyebrow')} title={t('analytics.quality')}>
        {stats.isPending ? (
          <Spinner label={t('common.loading')} />
        ) : stats.isError || !stats.data ? (
          <p className="text-sm text-slate">{t('common.error')}</p>
        ) : (
          <>
            <div className="flex flex-wrap items-start justify-center gap-8 py-2">
              <SatisfactionDonut
                csat={stats.data.csat}
                dsat={stats.data.dsat}
              />
              <DonutMetric
                label={t('analytics.resolveRate')}
                value={stats.data.resolveRate}
                color="var(--fe-agent)"
              />
            </div>
            <dl className="grid grid-cols-2 gap-4 pt-4 sm:grid-cols-3 lg:grid-cols-5">
              <Metric
                label={t('analytics.casesResolved')}
                value={stats.data.casesResolved}
              />
              <Metric
                label={t('analytics.aht')}
                value={formatMinutes(stats.data.averageHandlingMinutes, t('analytics.minutes'))}
              />
              <Metric
                label={t('analytics.firstResponse')}
                value={formatMinutes(stats.data.medianFirstResponseMinutes, t('analytics.minutes'))}
              />
            </dl>
          </>
        )}
      </Panel>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string | number }) {
  return (
    <div>
      <dt className="fe-eyebrow">{label}</dt>
      <dd className="fe-mono text-xl text-ink" dir="ltr">
        {value}
      </dd>
    </div>
  );
}

function formatMinutes(minutes: number | null, unit: string): string {
  if (minutes === null) return '—';
  if (minutes < 60) return `${Math.round(minutes)} ${unit}`;
  return `${(minutes / 60).toFixed(1)}h`;
}
