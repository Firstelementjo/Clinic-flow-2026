import {
  AIProviderError,
  type AIProvider,
  type AIProviderKind,
  type CompletionRequest,
  type CompletionResult,
} from './types';

export interface FailoverAttempt {
  provider: AIProviderKind;
  error: string;
}

/**
 * Ordered provider failover (plan §9).
 *
 * The CRM never goes down because AI did (plan §20.9): if the primary is
 * rate-limited or timing out, the next configured provider answers. A
 * non-retryable failure — a bad API key, a rejected request — stops the
 * chain immediately, because failing over on it would just spend a second
 * provider's quota to produce the same error.
 *
 * Which provider actually answered is reported back, so the run trace
 * records the truth rather than the configured intent.
 */
export class FailoverProvider implements AIProvider {
  readonly kind: AIProviderKind;
  readonly defaultModel: string;
  private readonly attempts: FailoverAttempt[] = [];

  constructor(private readonly chain: AIProvider[]) {
    const primary = chain[0];
    if (!primary) throw new Error('FailoverProvider requires at least one provider');
    this.kind = primary.kind;
    this.defaultModel = primary.defaultModel;
  }

  /** Providers tried and failed before the one that answered. */
  failedAttempts(): readonly FailoverAttempt[] {
    return this.attempts;
  }

  /** The provider that answered the last successful call. */
  lastUsed: AIProvider | null = null;

  async generate(request: CompletionRequest): Promise<CompletionResult> {
    this.attempts.length = 0;
    let lastError: unknown;

    for (const provider of this.chain) {
      try {
        const result = await provider.generate(request);
        this.lastUsed = provider;
        return result;
      } catch (error) {
        lastError = error;
        this.attempts.push({
          provider: provider.kind,
          error: error instanceof Error ? error.message : String(error),
        });

        const retryable = error instanceof AIProviderError ? error.retryable : true;
        if (!retryable) break;
      }
    }

    throw lastError instanceof AIProviderError
      ? lastError
      : new AIProviderError(this.kind, `All providers failed: ${String(lastError)}`, true);
  }
}
