import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Bot,
  Calendar,
  CalendarCheck,
  CalendarDays,
  CalendarPlus,
  Check,
  CheckCheck,
  Clock,
  ExternalLink,
  MessageCircle,
  MessageSquare,
  Mic,
  RefreshCw,
  Send,
  Sparkles,
  Stethoscope,
  Terminal,
  Ticket,
  User,
  Users,
  Zap,
} from 'lucide-react';
import { Spinner, useDirection } from '@firstelement/ui';
import { useT } from '../lib/i18n';
import {
  useClinicDoctors,
  useClinicProcedures,
  useSendSimulatorMessage,
  type SimulatorChatMessage,
  type ToolExecutionRecord,
} from '../lib/clinic-ai';

interface PresetPrompt {
  label: string;
  text: string;
  lang: 'en' | 'ar';
}

const PRESET_PROMPTS: PresetPrompt[] = [
  {
    label: 'Book Dental tomorrow 3pm',
    text: 'I want to book an appointment with Dr. Sarah tomorrow at 3:00 PM for teeth cleaning.',
    lang: 'en',
  },
  {
    label: 'حجز كشف أسنان غداً 4 عصراً',
    text: 'مرحباً، أحتاج حجز موعد لفحص الأسنان مع دكتورة سارة غداً الساعة 4 عصراً.',
    lang: 'ar',
  },
  {
    label: 'Check Dr. Ahmed slots Friday',
    text: 'Can you check what slots are available for Dr. Ahmed this Friday?',
    lang: 'en',
  },
  {
    label: 'مواعيد الجلدية المتاحة',
    text: 'ما هي مواعيد استشارة الجلدية المتاحة هذا الأسبوع؟',
    lang: 'ar',
  },
  {
    label: 'Reschedule booking',
    text: 'I would like to reschedule my appointment to next Monday at 2pm.',
    lang: 'en',
  },
];

export function AiReceptionistPage() {
  const t = useT();
  const dir = useDirection();

  const [channel, setChannel] = useState<'whatsapp' | 'web' | 'instagram'>('whatsapp');
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('');
  const [selectedProcedureId, setSelectedProcedureId] = useState<string>('');
  const [patientName, setPatientName] = useState('Sarah Al-Ghamdi');
  const [patientPhone, setPatientPhone] = useState('+966 50 123 4567');

  const [inputMessage, setInputMessage] = useState('');
  const [messages, setMessages] = useState<SimulatorChatMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      content:
        dir.locale === 'ar'
          ? 'مرحباً بك في Clinic Flow!\nأنا المساعد الذكي لمكتب الاستقبال. كيف يمكنني خدمتك اليوم؟ يمكنك سؤالي عن مواعيد الأطباء أو طلب حجز موعد فوراً باللغة العربية أو الإنجليزية.'
          : "Hello and welcome to Clinic Flow!\nI'm your AI Clinic Receptionist. How can I assist you today? You can check doctor availability, ask about procedures, or book an appointment directly in English or Arabic.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [latestTools, setLatestTools] = useState<ToolExecutionRecord[]>([]);
  const [latestIntent, setLatestIntent] = useState<string>('GENERAL_INQUIRY');
  const [latestEntities, setLatestEntities] = useState<Record<string, any>>({});
  const [activeTab, setActiveTab] = useState<'inspector' | 'radar'>('inspector');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const doctorsQuery = useClinicDoctors();
  const proceduresQuery = useClinicProcedures();
  const sendMutation = useSendSimulatorMessage();

  const doctors = doctorsQuery.data || [];
  const procedures = proceduresQuery.data || [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, sendMutation.isPending]);

  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || sendMutation.isPending) return;

    const userMsg: SimulatorChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');

    // Prepare API call
    const history = messages.slice(-6).map((m) => ({
      role: m.role as 'user' | 'assistant',
      content: m.content,
    }));

    sendMutation.mutate(
      {
        message: text,
        conversationHistory: history,
        locale: dir.locale,
        patientName,
        patientPhone,
        preferredDoctorId: selectedDoctorId || undefined,
        preferredProcedureId: selectedProcedureId || undefined,
      },
      {
        onSuccess: (data) => {
          const aiMsg: SimulatorChatMessage = {
            id: `ai-${Date.now()}`,
            role: 'assistant',
            content: data.reply,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            suggestedSlots: data.suggestedSlots,
            createdAppointment: data.createdAppointment,
            ticketNumber: data.ticketNumber,
            toolExecutions: data.toolExecutions,
          };

          setMessages((prev) => [...prev, aiMsg]);
          setLatestTools(data.toolExecutions || []);
          setLatestIntent(data.intent || 'GENERAL_INQUIRY');
          setLatestEntities(data.entities || {});
        },
        onError: (err) => {
          const errorMsg: SimulatorChatMessage = {
            id: `err-${Date.now()}`,
            role: 'assistant',
            content:
              dir.locale === 'ar'
                ? `عذراً، حدث خطأ أثناء معالجة الطلب: ${err.message}`
                : `Sorry, an error occurred while processing your request: ${err.message}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
          setMessages((prev) => [...prev, errorMsg]);
        },
      },
    );
  };

  const handleReset = () => {
    setMessages([
      {
        id: `init-${Date.now()}`,
        role: 'assistant',
        content:
          dir.locale === 'ar'
            ? 'تمت إعادة ضبط المحاكاة. كيف يمكنني خدمتك الآن؟'
            : 'Simulation reset. How can I assist you now?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setLatestTools([]);
    setLatestIntent('GENERAL_INQUIRY');
    setLatestEntities({});
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="ph">
        <div>
          <h2>{dir.locale === 'ar' ? 'مساعد الاستقبال الذكي (محاكاة حية)' : 'AI Receptionist Live Simulator'}</h2>
          <p>
            {dir.locale === 'ar'
              ? 'اختبر كيف يفهم الوكيل الذكي رغبات المرضى، يفحص مواعيد الأطباء المتاحة، وينفذ الحجز مباشرة'
              : 'Test how the AI understands patient booking intent, checks real doctor schedules, and confirms appointments live'}
          </p>
        </div>

        {/* Top Controls */}
        <div className="flex items-center gap-2 ms-auto">
          {/* Simulated Channel Switcher */}
          <div className="seg">
            <button
              type="button"
              onClick={() => setChannel('whatsapp')}
              className={channel === 'whatsapp' ? 'on' : ''}
            >
              WhatsApp
            </button>
            <button
              type="button"
              onClick={() => setChannel('web')}
              className={channel === 'web' ? 'on' : ''}
            >
              Web Chat
            </button>
          </div>

          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 rounded-lg border border-[var(--fe-hairline)] bg-[var(--fe-surface)] px-3 py-1.5 text-xs font-semibold text-[var(--fe-slate)] hover:text-[var(--fe-ink)] hover:border-[var(--fe-ink)] transition-colors shadow-xs"
            title="Reset conversation"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Main Split Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* ============================================================ */}
        {/* LEFT COLUMN: LIVE PATIENT CHAT SIMULATOR (7 cols)            */}
        {/* ============================================================ */}
        <div className="lg:col-span-7 flex flex-col card overflow-hidden h-[740px]">
          {/* WhatsApp / Chat Banner Header */}
          <div className="flex items-center justify-between border-b border-hairline bg-surface-raised px-4 py-3">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="h-9 w-9 rounded-full bg-gradient-to-br from-[#0f5b4c] to-emerald-600 flex items-center justify-center text-white font-bold text-xs shadow-xs">
                  CF
                </div>
                <span className="absolute bottom-0 end-0 h-2.5 w-2.5 rounded-full bg-emerald-500 ring-2 ring-surface" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-ink flex items-center gap-1.5">
                  <span>Clinic Flow AI Receptionist</span>
                  <span className="rounded bg-[#0f5b4c]/10 text-[#0f5b4c] text-[10px] px-1.5 py-0.2 font-mono">
                    Verified Agent
                  </span>
                </h3>
                <p className="text-[11px] text-slate-soft">
                  {channel === 'whatsapp' ? 'WhatsApp Business Channel' : 'Clinic Web Live Chat'} · Fast SLA
                </p>
              </div>
            </div>

            {/* Simulated Patient Info */}
            <div className="hidden sm:flex items-center gap-2 text-xs">
              <User className="h-3.5 w-3.5 text-slate-soft" />
              <span className="font-semibold text-ink">{patientName}</span>
              <span className="text-slate-soft font-mono text-[11px]">({patientPhone})</span>
            </div>
          </div>

          {/* Preset Prompts Bar */}
          <div className="border-b border-hairline bg-mist/40 px-3 py-2 flex items-center gap-1.5 overflow-x-auto text-[11px]">
            <span className="text-slate-soft font-medium shrink-0 flex items-center gap-1">
              <Zap className="h-3 w-3 text-signal" />
              <span>Test Prompts:</span>
            </span>
            {PRESET_PROMPTS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendMessage(p.text)}
                disabled={sendMutation.isPending}
                className="shrink-0 rounded-full border border-hairline bg-surface px-2.5 py-1 text-slate hover:border-[#0f5b4c] hover:text-[#0f5b4c] transition-colors shadow-2xs font-medium"
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Chat Messages Stream */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-dots">
            {messages.map((m) => {
              const isAssistant = m.role === 'assistant';

              return (
                <div
                  key={m.id}
                  className={`flex flex-col ${isAssistant ? 'items-start' : 'items-end'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed shadow-xs ${
                      isAssistant
                        ? 'bg-surface border border-hairline text-ink rounded-tl-sm'
                        : 'bg-[#0f5b4c] text-white rounded-tr-sm'
                    }`}
                  >
                    {/* Message Body */}
                    <div className="whitespace-pre-line">{m.content}</div>

                    {/* Interactive Slot Recommendation Pills */}
                    {isAssistant && m.suggestedSlots && m.suggestedSlots.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-hairline">
                        <p className="text-[10px] font-semibold text-slate-soft mb-1.5">
                          {dir.locale === 'ar' ? 'اختر وقتاً للحجز الفوري:' : 'Click a slot to book immediately:'}
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {m.suggestedSlots.slice(0, 4).map((slot, sIdx) => (
                            <button
                              key={sIdx}
                              type="button"
                              onClick={() =>
                                handleSendMessage(
                                  dir.locale === 'ar'
                                    ? `نعم، أرغب في حجز الموعد الساعة ${slot}`
                                    : `Yes, please book the ${slot} slot for me.`,
                                )
                              }
                              className="rounded-lg border border-[#0f5b4c]/30 bg-[#0f5b4c]/5 hover:bg-[#0f5b4c] hover:text-white px-2.5 py-1 font-mono text-[11px] font-semibold text-[#0f5b4c] transition-colors"
                            >
                              {slot}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Rich Appointment Confirmation Card */}
                    {isAssistant && m.createdAppointment && (
                      <div className="mt-3 rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3 text-start space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="inline-flex items-center gap-1 font-bold text-emerald-700 text-xs">
                            <CalendarCheck className="h-3.5 w-3.5" />
                            <span>Appointment Confirmed</span>
                          </span>
                          <span className="rounded bg-emerald-600 text-white px-1.5 py-0.2 text-[9px] font-mono font-bold uppercase">
                            {m.createdAppointment.status || 'SCHEDULED'}
                          </span>
                        </div>

                        <div className="text-[11px] space-y-1 font-mono text-slate">
                          <p>
                            <span className="text-slate-soft">Doctor: </span>
                            <span className="font-semibold text-ink">
                              {m.createdAppointment.doctorName || 'Assigned Clinician'}
                            </span>
                          </p>
                          <p>
                            <span className="text-slate-soft">Procedure: </span>
                            <span className="font-semibold text-ink">
                              {m.createdAppointment.service || m.createdAppointment.title}
                            </span>
                          </p>
                          <p>
                            <span className="text-slate-soft">When: </span>
                            <span className="font-semibold text-ink">
                              {new Date(m.createdAppointment.appointmentDate).toLocaleString([], {
                                dateStyle: 'medium',
                                timeStyle: 'short',
                              })}
                            </span>
                          </p>
                          {m.ticketNumber && (
                            <p>
                              <span className="text-slate-soft">Ticket: </span>
                              <span className="font-semibold text-signal">{m.ticketNumber}</span>
                            </p>
                          )}
                        </div>

                        <div className="pt-2 border-t border-emerald-500/20 flex items-center justify-end">
                          <Link
                            to="/app/appointments"
                            className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#0f5b4c] hover:underline"
                          >
                            <span>Open in Appointments</span>
                            <ExternalLink className="h-3 w-3" />
                          </Link>
                        </div>
                      </div>
                    )}

                    {/* Timestamp & Delivery Status */}
                    <div
                      className={`flex items-center gap-1 mt-1 text-[10px] ${
                        isAssistant ? 'text-slate-soft justify-start' : 'text-emerald-100 justify-end'
                      }`}
                    >
                      <span>{m.timestamp}</span>
                      {!isAssistant && <CheckCheck className="h-3 w-3 text-emerald-200" />}
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Typing Indicator */}
            {sendMutation.isPending && (
              <div className="flex items-center gap-2 text-xs text-slate-soft">
                <div className="h-6 w-6 rounded-full bg-[#0f5b4c]/10 flex items-center justify-center text-[#0f5b4c]">
                  <Bot className="h-3.5 w-3.5 animate-spin" />
                </div>
                <div className="rounded-xl border border-hairline bg-surface px-3 py-2 text-xs shadow-2xs flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#0f5b4c] animate-bounce" />
                  <span className="h-1.5 w-1.5 rounded-full bg-[#0f5b4c] animate-bounce [animation-delay:0.2s]" />
                  <span className="h-1.5 w-1.5 rounded-full bg-[#0f5b4c] animate-bounce [animation-delay:0.4s]" />
                  <span className="ms-1 text-slate-soft">AI Receptionist is checking schedules & tools...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input Bar */}
          <div className="border-t border-hairline p-3 bg-surface">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <button
                type="button"
                className="h-9 w-9 rounded-lg border border-hairline bg-surface flex items-center justify-center text-slate-soft hover:text-ink transition-colors shrink-0 shadow-2xs"
                title="Voice input simulation"
              >
                <Mic className="h-4 w-4" />
              </button>

              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder={
                  dir.locale === 'ar'
                    ? 'اكتب رسالتك للمساعد الذكي (مثال: احجز موعد أسنان مع د. سارة غداً 3 عصراً)...'
                    : 'Type a message (e.g., Book dental checkup with Dr. Sarah tomorrow at 3pm)...'
                }
                className="flex-1 rounded-xl border border-hairline bg-surface-raised px-4 py-2 text-xs text-ink placeholder:text-slate-soft focus:border-[#0f5b4c] focus:outline-hidden focus:ring-1 focus:ring-[#0f5b4c] shadow-2xs"
              />

              <button
                type="submit"
                disabled={!inputMessage.trim() || sendMutation.isPending}
                className="h-9 px-4 rounded-xl bg-[#0f5b4c] text-white text-xs font-semibold hover:bg-[#0c4a3e] disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-xs flex items-center gap-1.5 shrink-0"
              >
                <span>Send</span>
                <Send className="h-3.5 w-3.5" />
              </button>
            </form>
          </div>
        </div>

        {/* ============================================================ */}
        {/* RIGHT COLUMN: AI BRAIN & REAL-TIME TOOL INSPECTOR (5 cols)   */}
        {/* ============================================================ */}
        <div className="lg:col-span-5 flex flex-col card overflow-hidden h-[740px]">
          {/* Header & Tabs */}
          <div className="border-b border-hairline bg-surface-raised px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="h-4 w-4 text-[#0f5b4c]" />
              <h3 className="text-xs font-bold text-ink">AI Agent Brain & Tool Telemetry</h3>
            </div>

            <div className="seg">
              <button
                type="button"
                onClick={() => setActiveTab('inspector')}
                className={activeTab === 'inspector' ? 'on' : ''}
              >
                Tool Waterfall
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('radar')}
                className={activeTab === 'radar' ? 'on' : ''}
              >
                Clinic Radar
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-xs">
            {/* Intent & Entity Extraction Panel */}
            <div className="rounded-xl border border-hairline bg-surface-raised p-3.5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-soft text-[11px] font-semibold uppercase tracking-wider">
                  Intent Detected
                </span>
                <span
                  className={`rounded-md px-2 py-0.5 text-[11px] font-bold ${
                    latestIntent === 'BOOK_APPOINTMENT'
                      ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                      : latestIntent === 'CHECK_AVAILABILITY'
                      ? 'bg-sky-500/10 text-sky-600 border border-sky-500/20'
                      : 'bg-slate-500/10 text-slate border border-hairline'
                  }`}
                >
                  {latestIntent}
                </span>
              </div>

              {/* Extracted Entities */}
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="rounded-lg border border-hairline bg-surface p-2">
                  <span className="text-slate-soft block text-[10px]">Clinician:</span>
                  <span className="font-semibold text-ink truncate block">
                    {latestEntities.doctorName || 'Auto-detecting...'}
                  </span>
                </div>
                <div className="rounded-lg border border-hairline bg-surface p-2">
                  <span className="text-slate-soft block text-[10px]">Procedure:</span>
                  <span className="font-semibold text-ink truncate block">
                    {latestEntities.procedureName || 'Auto-detecting...'}
                  </span>
                </div>
                <div className="rounded-lg border border-hairline bg-surface p-2">
                  <span className="text-slate-soft block text-[10px]">Target Date:</span>
                  <span className="font-semibold text-ink truncate block">
                    {latestEntities.targetDateStr || 'Today / Tomorrow'}
                  </span>
                </div>
                <div className="rounded-lg border border-hairline bg-surface p-2">
                  <span className="text-slate-soft block text-[10px]">Target Time:</span>
                  <span className="font-semibold text-ink truncate block">
                    {latestEntities.targetTimeStr || 'Flexible / Any'}
                  </span>
                </div>
              </div>
            </div>

            {activeTab === 'inspector' ? (
              /* Tool Execution Waterfall */
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-ink flex items-center gap-1.5">
                    <Sparkles className="h-3.5 w-3.5 text-signal" />
                    <span>Real-time Tool Execution Waterfall</span>
                  </h4>
                  <span className="text-[10px] text-slate-soft">
                    {latestTools.length} tool calls in last turn
                  </span>
                </div>

                {latestTools.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-hairline p-8 text-center text-slate-soft">
                    <Terminal className="h-6 w-6 mx-auto mb-2 text-slate-soft/60" />
                    <p className="font-sans text-xs">
                      Send a message in the chat simulator to see the AI agent call clinic tools in real-time.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {latestTools.map((tool, idx) => (
                      <div
                        key={idx}
                        className="rounded-xl border border-hairline bg-surface p-3 shadow-2xs space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span
                              className={`h-2 w-2 rounded-full ${
                                tool.status === 'SUCCESS'
                                  ? 'bg-emerald-500'
                                  : tool.status === 'WARNING'
                                  ? 'bg-amber-500'
                                  : 'bg-rose-500'
                              }`}
                            />
                            <span className="font-bold text-ink text-xs">{tool.toolName}</span>
                          </div>
                          <span className="rounded bg-surface-raised px-1.5 py-0.2 text-[10px] text-slate-soft font-mono">
                            {tool.executionTimeMs}ms
                          </span>
                        </div>

                        <p className="text-[11px] text-slate-soft font-sans">{tool.description}</p>

                        {/* Input & Output Accordion / Preview */}
                        <div className="space-y-1 text-[10px]">
                          <details className="rounded-lg border border-hairline bg-surface-raised p-2 cursor-pointer">
                            <summary className="font-semibold text-slate hover:text-ink">
                              Input Payload
                            </summary>
                            <pre className="mt-1.5 overflow-x-auto text-slate-soft p-1">
                              {JSON.stringify(tool.input, null, 2)}
                            </pre>
                          </details>

                          <details className="rounded-lg border border-hairline bg-surface-raised p-2 cursor-pointer">
                            <summary className="font-semibold text-emerald-600 hover:text-emerald-700">
                              Output Result
                            </summary>
                            <pre className="mt-1.5 overflow-x-auto text-slate p-1">
                              {JSON.stringify(tool.output, null, 2)}
                            </pre>
                          </details>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              /* Clinic Radar Tab */
              <div className="space-y-4">
                <div className="rounded-xl border border-hairline bg-surface-raised p-3.5 space-y-3">
                  <h4 className="text-xs font-bold text-ink flex items-center gap-1.5">
                    <Stethoscope className="h-3.5 w-3.5 text-[#0f5b4c]" />
                    <span>Clinic Doctors & Active System Connection</span>
                  </h4>
                  <p className="text-[11px] text-slate-soft font-sans">
                    Real-time synchronization with doctors and procedure catalogs.
                  </p>

                  <div className="space-y-2">
                    {doctors.map((d) => (
                      <div
                        key={d.id}
                        className="rounded-lg border border-hairline bg-surface p-2.5 flex items-center justify-between text-xs"
                      >
                        <div>
                          <p className="font-bold text-ink">{d.name}</p>
                          <p className="text-[10px] text-slate-soft">
                            {d.specialty} · Slot: {d.slotDuration}m · Hours: {d.workingHours}
                          </p>
                        </div>
                        <span className="h-2 w-2 rounded-full bg-emerald-500 ring-2 ring-emerald-500/20" />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-xl border border-hairline bg-surface p-3.5 space-y-2 text-xs">
                  <h4 className="font-bold text-ink flex items-center gap-1.5">
                    <CalendarDays className="h-3.5 w-3.5 text-signal" />
                    <span>Procedures & Duration Catalog</span>
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    {procedures.map((p) => (
                      <div key={p.id} className="rounded-lg border border-hairline p-2">
                        <span className="font-semibold text-ink block">{p.name}</span>
                        <span className="text-[10px] text-slate-soft font-mono">
                          {p.durationMinutes} mins · ${p.price}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Quick Links */}
            <div className="pt-2 border-t border-hairline flex items-center justify-between text-xs font-sans">
              <Link
                to="/app/appointments"
                className="text-[#0f5b4c] font-semibold hover:underline flex items-center gap-1"
              >
                <span>View Appointments Calendar</span>
                <ExternalLink className="h-3 w-3" />
              </Link>
              <Link
                to="/app/people"
                className="text-slate-soft font-semibold hover:text-ink flex items-center gap-1"
              >
                <span>Patient Directory</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
