import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Post,
  Put,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import { saveEscalationRuleSchema, type SaveEscalationRuleInput } from '@firstelement/shared';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { EscalationService } from './escalation.service';

@Controller()
export class EscalationController {
  constructor(private readonly escalation: EscalationService) {}

  @Get('projects/:projectId/escalation-rules')
  @RequirePermissions(Permission.ESCALATION_RULE_READ)
  listRules(@Tenant() ctx: TenantContext, @Param('projectId', ParseUUIDPipe) projectId: string) {
    return this.escalation.listRules(ctx, projectId);
  }

  @Post('projects/:projectId/escalation-rules')
  @RequirePermissions(Permission.ESCALATION_RULE_MANAGE)
  createRule(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Body(zodBody(saveEscalationRuleSchema)) body: SaveEscalationRuleInput,
    @Req() request: Request,
  ) {
    return this.escalation.createRule(ctx, projectId, body, request.ip);
  }

  @Put('projects/:projectId/escalation-rules/:ruleId')
  @RequirePermissions(Permission.ESCALATION_RULE_MANAGE)
  updateRule(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('ruleId', ParseUUIDPipe) ruleId: string,
    @Body(zodBody(saveEscalationRuleSchema)) body: SaveEscalationRuleInput,
    @Req() request: Request,
  ) {
    return this.escalation.updateRule(ctx, projectId, ruleId, body, request.ip);
  }

  @Delete('projects/:projectId/escalation-rules/:ruleId')
  @RequirePermissions(Permission.ESCALATION_RULE_MANAGE)
  @HttpCode(204)
  deleteRule(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('ruleId', ParseUUIDPipe) ruleId: string,
    @Req() request: Request,
  ) {
    return this.escalation.deleteRule(ctx, projectId, ruleId, request.ip);
  }

  /** Score history behind the conversation's frustration sparkline. */
  @Get('conversations/:conversationId/scores')
  @RequirePermissions(Permission.CONVERSATION_READ)
  scores(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
  ) {
    return this.escalation.scoresFor(ctx, conversationId);
  }

  @Get('conversations/:conversationId/escalations')
  @RequirePermissions(Permission.CONVERSATION_READ)
  escalations(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
  ) {
    return this.escalation.escalationsFor(ctx, conversationId);
  }
}
