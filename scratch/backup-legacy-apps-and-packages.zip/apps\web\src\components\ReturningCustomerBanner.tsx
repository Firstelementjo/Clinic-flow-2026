import { StatusChip } from '@firstelement/ui';
import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api';
import { useT } from '../lib/i18n';
import type { CustomerDetail } from '../lib/customers';

/**
 * Banner shown when a customer has previous tickets.
 * Displays in the ConversationThread header area to alert the agent
 * that this is a returning customer.
 */
export function ReturningCustomerBanner({
  customerId,
}: {
  customerId: string;
}) {
  const t = useT();

  const customer = useQuery({
    queryKey: ['customer', customerId],
    queryFn: () => api.get<CustomerDetail>(`/customers/${customerId}`),
    staleTime: 60_000,
  });

  if (!customer.data || customer.data.conversations.length <= 1) {
    return null;
  }

  const previousCount = customer.data.conversations.length - 1;

  return (
    <div className="flex items-center gap-2 rounded bg-signal-wash/40 px-3 py-1.5 text-xs">
      <StatusChip tone="ai">{t('customer.returning')}</StatusChip>
      <span className="text-slate">
        {previousCount} {t('customer.previousTickets')}
      </span>
    </div>
  );
}
