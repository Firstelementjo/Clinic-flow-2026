import { Global, Module } from '@nestjs/common';
import { DomainEventBus } from './domain-event-bus';
import { ConversationTimelineSubscriber } from './conversation-timeline.subscriber';

@Global()
@Module({
  providers: [DomainEventBus, ConversationTimelineSubscriber],
  exports: [DomainEventBus],
})
export class EventsModule {}
