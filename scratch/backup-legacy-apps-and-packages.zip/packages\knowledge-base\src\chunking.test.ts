import { describe, expect, it } from 'vitest';
import { DEFAULT_CHUNK_OPTIONS, chunkText, cleanText, estimateTokens } from './chunking';

describe('cleanText', () => {
  it('normalizes line endings and collapses runs of blank lines', () => {
    expect(cleanText('a\r\n\r\n\r\n\r\nb')).toBe('a\n\nb');
  });

  it('strips zero-width and bidi control characters that ride along with copied Arabic', () => {
    const withControls = 'سياسة‏الاسترجاع​';
    expect(cleanText(withControls)).toBe('سياسةالاسترجاع');
  });

  it('keeps paragraph structure, which is what chunking splits on', () => {
    expect(cleanText('one\n\ntwo')).toBe('one\n\ntwo');
  });
});

describe('chunkText', () => {
  it('returns nothing for empty input rather than one empty chunk', () => {
    expect(chunkText('   \n\n  ')).toEqual([]);
  });

  it('keeps a short document in a single chunk', () => {
    const chunks = chunkText('Refunds are processed within 3 business days.');
    expect(chunks).toHaveLength(1);
    expect(chunks[0]!.content).toContain('3 business days');
  });

  it('merges small paragraphs so a heading stays with the answer under it', () => {
    const chunks = chunkText('Refund policy\n\nRefunds take 3 days.\n\nExchanges take 5 days.');
    expect(chunks).toHaveLength(1);
    expect(chunks[0]!.content).toContain('Refund policy');
    expect(chunks[0]!.content).toContain('Exchanges');
  });

  it('splits a long document into chunks that respect the ceiling', () => {
    const paragraph = 'This sentence explains the returns policy in detail. '.repeat(20);
    const document = Array.from({ length: 6 }, () => paragraph).join('\n\n');
    const chunks = chunkText(document);

    expect(chunks.length).toBeGreaterThan(1);
    for (const chunk of chunks) {
      // Ceiling plus the overlap that is prepended to later chunks.
      expect(chunk.content.length).toBeLessThanOrEqual(
        DEFAULT_CHUNK_OPTIONS.maxChars + DEFAULT_CHUNK_OPTIONS.overlapChars + 4,
      );
    }
  });

  it('carries overlap forward so a fact spanning a boundary survives whole', () => {
    const document = Array.from(
      { length: 8 },
      (_, i) => `Paragraph ${i}. ${'filler text here. '.repeat(40)}`,
    ).join('\n\n');
    const chunks = chunkText(document);

    expect(chunks.length).toBeGreaterThan(1);
    const secondStart = chunks[1]!.content.slice(0, 40);
    expect(chunks[0]!.content).toContain(secondStart.trim().split('\n')[0]!.slice(0, 20));
  });

  it('splits Arabic prose on its own sentence punctuation', () => {
    const sentence = 'يمكنك استرجاع المنتج خلال أسبوع من تاريخ الاستلام؟ ';
    const chunks = chunkText(sentence.repeat(80));
    expect(chunks.length).toBeGreaterThan(1);
    // A cut mid-word would leave a chunk starting with a partial token.
    for (const chunk of chunks) {
      expect(chunk.content.trim().length).toBeGreaterThan(0);
    }
  });

  it('hard-cuts a single sentence longer than the ceiling instead of emitting one huge chunk', () => {
    const chunks = chunkText('x'.repeat(10_000));
    expect(chunks.length).toBeGreaterThan(1);
    for (const chunk of chunks) {
      expect(chunk.content.length).toBeLessThanOrEqual(
        DEFAULT_CHUNK_OPTIONS.maxChars + DEFAULT_CHUNK_OPTIONS.overlapChars + 4,
      );
    }
  });

  it('numbers chunks sequentially from zero, matching the unique index on the table', () => {
    const chunks = chunkText('para. '.repeat(2_000));
    expect(chunks.map((chunk) => chunk.index)).toEqual(chunks.map((_, i) => i));
  });
});

describe('estimateTokens', () => {
  it('never returns zero, so a chunk always has a positive cost', () => {
    expect(estimateTokens('')).toBeGreaterThan(0);
    expect(estimateTokens('a'.repeat(400))).toBe(100);
  });
});
