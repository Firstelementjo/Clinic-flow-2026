import type { PrismaClient } from '@firstelement/database';
import {
  DomainEventType,
  type DomainEvent,
  type DomainEventPublisher,
} from '@firstelement/events';
import { ConversationEventType, MessageDirection } from '@firstelement/shared';

/**
 * Maps a domain event onto the append-only conversation timeline (plan §7).
 *
 * Shared because both processes produce these events: the API when an
 * agent acts, the worker when a customer's message arrives. A timeline
 * that only recorded half of them would be worse than no timeline.
 */
export async function recordTimelineEvent(
  prisma: PrismaClient,
  event: DomainEvent,
): Promise<void> {
  const entry = mapEvent(event);
  if (!entry) return;

  await prisma.conversationEvent.create({
    data: {
      organizationId: event.organizationId,
      projectId: event.projectId,
      conversationId: entry.conversationId,
      type: entry.type,
      actorType: entry.actorType,
      actorUserId: event.actorUserId ?? null,
      payload: entry.payload as object,
      occurredAt: event.occurredAt,
    },
  });
}

interface TimelineEntry {
  conversationId: string;
  type: ConversationEventType;
  actorType: 'CUSTOMER' | 'EMPLOYEE' | 'AI' | 'SYSTEM';
  payload: Record<string, unknown>;
}

function mapEvent(event: DomainEvent): TimelineEntry | null {
  switch (event.type) {
    case DomainEventType.CONVERSATION_CREATED:
      return {
        conversationId: event.aggregateId,
        type: ConversationEventType.CONVERSATION_CREATED,
        actorType: 'SYSTEM',
        payload: { channel: event.payload.channel, mode: event.payload.mode },
      };

    case DomainEventType.MESSAGE_CREATED:
      return {
        conversationId: event.payload.conversationId,
        type:
          event.payload.direction === MessageDirection.INBOUND
            ? ConversationEventType.MESSAGE_RECEIVED
            : ConversationEventType.MESSAGE_SENT,
        actorType: event.payload.authorType,
        // Length, not content: the body already lives in `messages`, where
        // access is tenant-scoped.
        payload: { messageId: event.aggregateId, bodyLength: event.payload.bodyLength },
      };

    case DomainEventType.CONVERSATION_ASSIGNED:
      return {
        conversationId: event.aggregateId,
        type: event.payload.employeeId
          ? ConversationEventType.ASSIGNED
          : ConversationEventType.UNASSIGNED,
        actorType: event.actorUserId ? 'EMPLOYEE' : 'SYSTEM',
        payload: {
          employeeId: event.payload.employeeId,
          previousEmployeeId: event.payload.previousEmployeeId,
          reason: event.payload.reason,
        },
      };

    case DomainEventType.CONVERSATION_UPDATED:
      if (event.payload.status) {
        return {
          conversationId: event.aggregateId,
          type: ConversationEventType.STATUS_CHANGED,
          actorType: event.actorUserId ? 'EMPLOYEE' : 'SYSTEM',
          payload: { from: event.payload.previousStatus, to: event.payload.status },
        };
      }
      if (event.payload.priority) {
        return {
          conversationId: event.aggregateId,
          type: ConversationEventType.PRIORITY_CHANGED,
          actorType: event.actorUserId ? 'EMPLOYEE' : 'SYSTEM',
          payload: { to: event.payload.priority },
        };
      }
      return null;

    case DomainEventType.CONVERSATION_RESOLVED:
      return {
        conversationId: event.aggregateId,
        type: ConversationEventType.STATUS_CHANGED,
        actorType: event.payload.resolvedBy,
        payload: { to: 'RESOLVED', messageCount: event.payload.messageCount },
      };

    case DomainEventType.CONVERSATION_SCORED:
      return {
        conversationId: event.aggregateId,
        type: ConversationEventType.SCORE_UPDATED,
        actorType: 'SYSTEM',
        payload: {
          frustration: event.payload.frustration,
          sentiment: event.payload.sentiment,
          urgency: event.payload.urgency,
          risk: event.payload.risk,
          intent: event.payload.intent,
        },
      };

    case DomainEventType.CONVERSATION_ESCALATED:
      return {
        conversationId: event.aggregateId,
        type: ConversationEventType.ESCALATED,
        actorType: 'AI',
        payload: {
          escalationId: event.payload.escalationId,
          trigger: event.payload.trigger,
          reason: event.payload.reason,
          intent: event.payload.intent,
        },
      };

    case DomainEventType.CONVERSATION_MODE_CHANGED:
      return {
        conversationId: event.aggregateId,
        type:
          event.payload.to === 'HUMAN'
            ? ConversationEventType.TAKEN_OVER
            : ConversationEventType.RETURNED_TO_AI,
        actorType: event.actorUserId ? 'EMPLOYEE' : 'SYSTEM',
        payload: { from: event.payload.from, to: event.payload.to, reason: event.payload.reason },
      };

    default:
      // Customer-level events have no conversation to hang from.
      return null;
  }
}

/**
 * Publisher for processes without an event bus (the worker). Records the
 * timeline and forwards to an optional delegate.
 *
 * Recording failures are logged, never thrown: a timeline write must not
 * roll back the message it describes.
 */
export class TimelineRecordingPublisher implements DomainEventPublisher {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly onError: (error: unknown, event: DomainEvent) => void = () => {},
    private readonly delegate?: DomainEventPublisher,
  ) {}

  publish(event: DomainEvent): void {
    void recordTimelineEvent(this.prisma, event).catch((error) => this.onError(error, event));
    this.delegate?.publish(event);
  }
}
