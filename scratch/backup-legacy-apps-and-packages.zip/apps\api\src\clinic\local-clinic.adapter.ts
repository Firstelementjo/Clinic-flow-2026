import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import {
  accessibleProjectsScope,
  projectScope,
  type TenantContext,
} from '@firstelement/database';
import type {
  ClinicSystemAdapter,
  ClinicDoctor,
  ClinicProcedure,
  ClinicAppointment,
  CreateClinicAppointmentInput,
} from './clinic-adapter.interface';

/**
 * Audit actions for the clinician roster, and the one rule that governs them.
 *
 * <h2>Why the roster was unaudited, and what that cost</h2>
 *
 * <p>Phase 26 closed a live cross-tenant breach on this surface and then could not
 * answer whether it had been exploited. The reason is recorded in the migration
 * ledger: the most exposed write paths — doctor and procedure
 * create/update/delete — <em>wrote no audit row at all</em>. An application log
 * cannot answer it either, because a <em>successful</em> unauthorized write produces
 * no log line. The writes that would have shown it left no trace, and deletes were
 * unaudited entirely.
 *
 * <h2>The convention this follows, not the one invented here</h2>
 *
 * <p>These six actions match the four the clinic module already wrote
 * ({@code APPOINTMENT_CREATED}, {@code APPOINTMENT_RESCHEDULED},
 * {@code APPOINTMENT_CANCELLED}, {@code REMINDER_SENT}): a past-tense
 * {@code RESOURCE_VERB} string, the resource's own id in {@code resourceId}, and a
 * direct {@code auditLog.create} rather than {@code AuditService}. They are written
 * the same way for the same reason — see {@link LocalClinicAdapter#audit}. No second
 * audit path is introduced, and the four existing actions are not renamed.
 *
 * <h2>What is deliberately never written</h2>
 *
 * <p>No patient data and no secret, in any of the six rows. A doctor and a procedure
 * carry no patient data at all, so that part is structural rather than a filtering
 * rule. The judgement is about <em>clinician</em> contact details: {@code email} and
 * {@code phone} are personal contact information, and the audit table is read by
 * {@code GET /analytics/audit-log}, which a wider set of principals can reach than the
 * roster itself. So a change to either is recorded <b>as a change</b> —
 * {@code { field: 'phone', changed: true }} — and never as a value. The evidence
 * survives ("the phone on this clinician's row was altered by this actor at this
 * time") without copying the number into a second, less-protected store.
 */
type RosterAuditAction =
  | 'DOCTOR_CREATED'
  | 'DOCTOR_UPDATED'
  | 'DOCTOR_DELETED'
  | 'PROCEDURE_CREATED'
  | 'PROCEDURE_UPDATED'
  | 'PROCEDURE_DELETED';

/**
 * The clinician fields the roster audit records, and how each is captured.
 *
 * <ul>
 *   <li>{@code DIFFED} — recorded with its before and after values. Descriptive and
 *       operational: who is on the roster, when they work, what they do, what it
 *       costs. This is what an investigator needs to reconstruct a changed roster.</li>
 *   <li>{@code PRESENCE_ONLY} — {@code email} and {@code phone}. Recorded as "this
 *       changed" and never as a value, for the reason above.</li>
 * </ul>
 *
 * <p>Deliberately excluded from the audit entirely: {@code organizationId} and
 * {@code projectId} are real columns on the row ({@code projectId}) and must never be
 * a client-supplied value in an audit blob; {@code createdAt}/{@code updatedAt} are
 * timestamps the row itself already carries; {@code appointments} is a relation with
 * no scalar to record and whose contents are patient data.
 */
const DOCTOR_DIFFED_FIELDS = [
  'name',
  'specialty',
  'department',
  'workingDays',
  'startHour',
  'endHour',
  'slotDuration',
  'isActive',
] as const;

const PROCEDURE_DIFFED_FIELDS = [
  'name',
  'specialty',
  'durationMinutes',
  'bufferMinutes',
  'price',
  'isActive',
] as const;

/** Contact details: recorded as a change, never as a value. */
const PRESENCE_ONLY_FIELDS = ['email', 'phone'] as const;

interface RosterAuditChange {
  field: string;
  before?: unknown;
  after?: unknown;
  /** True when the field exists but its value is deliberately not recorded. */
  changed?: boolean;
}

/** Value equality for the scalar + number-array fields a roster row carries. */
function sameValue(a: unknown, b: unknown): boolean {
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((v, i) => v === b[i]);
  }
  return a === b;
}

/**
 * The clinic system, backed by the same PostgreSQL database.
 *
 * <h2>Every method is tenant- and project-scoped</h2>
 *
 * <p>Clinic rows are clinical data, so this adapter is the security boundary for
 * doctors, procedures and appointments — the routes that reach it do not all carry
 * a {@code :projectId} route param, and for the ones that do not,
 * {@code PermissionsGuard} supplies no project scope at all. The check therefore
 * happens here, in the adapter, because {@code plan.md} §0.4 forbids
 * controller-only authorization and {@code packages/auth}'s {@code can()} only
 * enforces the project boundary when a project id is handed to it.
 *
 * <p>Every read and every write is keyed on {@code accessibleProjectsScope(ctx)} or
 * {@code projectScope(ctx, …)}, so {@code organizationId} always rides along and a
 * membership bug cannot cross a tenant. A denial raises
 * {@link NotFoundException}, which the global exception filter renders as a 404 that
 * is identical to the one a nonexistent record produces.
 */
@Injectable()
export class LocalClinicAdapter implements ClinicSystemAdapter {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Resolves a caller-supplied project id through {@link projectScope}, which
   * refuses a project the principal does not hold membership of. With no id the
   * caller's own first project is used, which is membership-derived by
   * construction. A body or query {@code projectId} is a request, never an
   * authorization.
   */
  private resolveProject(ctx: TenantContext, requestedProjectId?: string): string {
    if (requestedProjectId) return projectScope(ctx, requestedProjectId).projectId;
    const first = ctx.projectIds[0];
    if (!first) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });
    }
    return first;
  }

  /**
   * Writes one roster audit row, or none at all.
   *
   * <h3>Why this is called after the write, not before</h3>
   *
   * <p>Every caller invokes this <em>after</em> its scope check has passed and its
   * write has landed, and throws before reaching it otherwise. That ordering is the
   * guarantee that matters most here: <b>a refused request writes no audit row</b>.
   * A security control that fires on every refusal regardless of outcome is not
   * evidence, and an audit write that leaks the tenant of a refused actor is a new
   * defect rather than a fix. A row is therefore only ever written for a mutation
   * that actually happened to a row the caller was entitled to touch.
   *
   * <h3>Why the tenant is the target's, not the actor's</h3>
   *
   * <p>{@code organizationId} and {@code projectId} are taken from the row the caller
   * reached, not from {@code ctx}. They are equal whenever this is reached — the scope
   * check proved it — and recording the row's own values preserves the invariant the
   * incident forensics depends on: an audit row's organization should agree with the
   * organization that owns the resource it names. That is precisely the mismatch
   * `F-cross-tenant-access.sql` looks for, so the invariant has to hold by
   * construction or the detector is measuring nothing.
   *
   * <p>{@code actorUserId} is the caller, so "who did this" stays answerable even
   * though the row is scoped to the target.
   */
  private async audit(entry: {
    action: RosterAuditAction;
    resourceType: 'DOCTOR' | 'PROCEDURE';
    resourceId: string;
    organizationId: string;
    projectId: string;
    actorUserId: string;
    metadata: Record<string, unknown>;
  }): Promise<void> {
    await this.prisma.client.auditLog.create({
      data: {
        organizationId: entry.organizationId,
        projectId: entry.projectId,
        actorUserId: entry.actorUserId,
        actorType: 'USER',
        action: entry.action,
        resourceType: entry.resourceType,
        resourceId: entry.resourceId,
        metadata: entry.metadata as object,
      },
    });
  }

  /**
   * The named fields of a row, for a create or delete snapshot.
   *
   * <p>An explicit field list rather than the row, so a column added to `doctors`
   * or `procedures` later cannot silently start appearing in the audit log — which
   * would be how patient data ends up in a table more principals can read.
   */
  private snapshotFields(
    row: Record<string, unknown>,
    fields: readonly string[],
  ): Record<string, unknown> {
    const out: Record<string, unknown> = {};
    for (const field of fields) out[field] = row[field] ?? null;
    return out;
  }

  /** Whether a contact detail was supplied, without recording what it was. */
  private present(value: unknown): boolean {
    return typeof value === 'string' && value.length > 0;
  }

  /**
   * Builds the before/after record for an update.
   *
   * <p>Only fields that actually changed appear, so a request that re-sends the
   * values already on the row produces an <b>empty</b> {@code changes} list and is
   * distinguishable from a real edit. `PRESENCE_ONLY_FIELDS` appear as
   * `{ field, changed: true }` with no values; the others carry both.
   */
  private diff(
    before: Record<string, unknown>,
    after: Record<string, unknown>,
    diffedFields: readonly string[],
  ): RosterAuditChange[] {
    const changes: RosterAuditChange[] = [];
    for (const field of diffedFields) {
      const from = before[field];
      const to = after[field];
      if (!sameValue(from, to)) changes.push({ field, before: from, after: to });
    }
    for (const field of PRESENCE_ONLY_FIELDS) {
      // The value is deliberately absent from both sides. Recording presence alone
      // would be useless (the row nearly always has one); recording the value would
      // copy a clinician's contact details into a more widely readable table. So the
      // question asked is only "did this change at all".
      const from = before[field];
      const to = after[field];
      if (!sameValue(from, to)) changes.push({ field, changed: true });
    }
    return changes;
  }

  /** Proves a doctor is in the caller's reachable projects before a read or write. */
  private async assertDoctorInScope(ctx: TenantContext, doctorId: string) {
    const existing = await this.prisma.client.doctor.findFirst({
      where: { id: doctorId, ...accessibleProjectsScope(ctx) },
      select: { id: true, projectId: true, organizationId: true },
    });
    if (!existing) throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });
    return existing;
  }

  /**
   * As {@link assertDoctorInScope}, but also returns the full row.
   *
   * <p>The update and delete paths need the pre-image to build an honest before/after
   * diff, and delete needs the whole row because the row is about to stop existing.
   * The scope predicate is byte-identical to {@link assertDoctorInScope}; the extra
   * columns are the only difference.
   */
  private async requireDoctorInScope(ctx: TenantContext, doctorId: string) {
    const existing = await this.prisma.client.doctor.findFirst({
      where: { id: doctorId, ...accessibleProjectsScope(ctx) },
    });
    if (!existing) throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });
    return existing;
  }

  /** As {@link assertProcedureInScope}, but also returns the full row. */
  private async requireProcedureInScope(ctx: TenantContext, procedureId: string) {
    const existing = await this.prisma.client.procedure.findFirst({
      where: { id: procedureId, ...accessibleProjectsScope(ctx) },
    });
    if (!existing) throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });
    return existing;
  }

  /** Proves a procedure is in the caller's reachable projects before a read or write. */
  private async assertProcedureInScope(ctx: TenantContext, procedureId: string) {
    const existing = await this.prisma.client.procedure.findFirst({
      where: { id: procedureId, ...accessibleProjectsScope(ctx) },
      select: { id: true, projectId: true, organizationId: true },
    });
    if (!existing) throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });
    return existing;
  }

  /** Proves an appointment is in the caller's reachable projects before a read or write. */
  private async assertAppointmentInScope(ctx: TenantContext, appointmentId: string) {
    const existing = await this.prisma.client.appointment.findFirst({
      where: { id: appointmentId, ...accessibleProjectsScope(ctx) },
      select: { id: true, projectId: true, organizationId: true },
    });
    if (!existing) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });
    }
    return existing;
  }

  async getDoctors(ctx: TenantContext, requestedProjectId?: string): Promise<ClinicDoctor[]> {
    const projectId = this.resolveProject(ctx, requestedProjectId);
    const doctors = await this.prisma.client.doctor.findMany({
      where: { projectId, organizationId: ctx.organizationId, isActive: true },
      orderBy: { name: 'asc' },
    });
    return doctors.map((d) => ({
      id: d.id,
      name: d.name,
      specialty: d.specialty,
      department: d.department,
      workingDays: d.workingDays,
      startHour: d.startHour,
      endHour: d.endHour,
      slotDuration: d.slotDuration,
      isActive: d.isActive,
    }));
  }

  async getDoctorById(ctx: TenantContext, doctorId: string): Promise<ClinicDoctor | null> {
    const d = await this.prisma.client.doctor.findFirst({
      where: { id: doctorId, ...accessibleProjectsScope(ctx) },
    });
    if (!d) return null;
    return {
      id: d.id,
      name: d.name,
      specialty: d.specialty,
      department: d.department,
      workingDays: d.workingDays,
      startHour: d.startHour,
      endHour: d.endHour,
      slotDuration: d.slotDuration,
      isActive: d.isActive,
    };
  }

  async getAllDoctors(ctx: TenantContext, requestedProjectId?: string): Promise<any[]> {
    const projectId = this.resolveProject(ctx, requestedProjectId);
    const doctors = await this.prisma.client.doctor.findMany({
      where: { projectId, organizationId: ctx.organizationId },
      orderBy: { name: 'asc' },
      include: {
        _count: {
          select: { appointments: true },
        },
      },
    });
    return doctors.map((d) => ({
      id: d.id,
      name: d.name,
      specialty: d.specialty,
      department: d.department,
      email: d.email,
      phone: d.phone,
      workingDays: d.workingDays,
      startHour: d.startHour,
      endHour: d.endHour,
      slotDuration: d.slotDuration,
      isActive: d.isActive,
      appointmentCount: d._count.appointments,
    }));
  }

  async createDoctor(ctx: TenantContext, data: {
    projectId?: string;
    name: string;
    specialty: string;
    department?: string;
    email?: string;
    phone?: string;
    workingDays?: number[];
    startHour?: string;
    endHour?: string;
    slotDuration?: number;
  }) {
    // The organization is the caller's, always. The project is resolved through
    // the membership check rather than read from the request, so a doctor can
    // never be created inside a project the caller does not belong to.
    //
    // Every refusal below uses the same message as the global filter's
    // `PermissionDeniedError` branch. That is not cosmetic: it makes "you may not",
    // "not yours" and "does not exist" one indistinguishable answer, so this surface
    // cannot be probed for the existence of a row the caller has no right to know
    // about. Phase 26 left these strings naming the resource; phase 33 removed the
    // difference, because a per-resource message is a per-resource oracle.
    const projectId = this.resolveProject(ctx, data.projectId);
    const created = await this.prisma.client.doctor.create({
      data: {
        organizationId: ctx.organizationId,
        projectId,
        name: data.name,
        specialty: data.specialty,
        department: data.department,
        email: data.email,
        phone: data.phone,
        workingDays: data.workingDays || [0, 1, 2, 3, 4],
        startHour: data.startHour || '09:00',
        endHour: data.endHour || '17:00',
        slotDuration: data.slotDuration || 30,
        isActive: true,
      },
    });

    await this.audit({
      action: 'DOCTOR_CREATED',
      resourceType: 'DOCTOR',
      resourceId: created.id,
      organizationId: created.organizationId,
      projectId: created.projectId,
      actorUserId: ctx.userId,
      // The roster as it now stands, which is the only durable record of a clinician
      // who did not exist before this request. `email`/`phone` are recorded as
      // presence, never as values.
      metadata: {
        after: this.snapshotFields(created, DOCTOR_DIFFED_FIELDS),
        contactProvided: {
          email: this.present(data.email),
          phone: this.present(data.phone),
        },
      },
    });

    return created;
  }

  async updateDoctor(
    ctx: TenantContext,
    doctorId: string,
    data: {
      name?: string;
      specialty?: string;
      department?: string;
      email?: string;
      phone?: string;
      workingDays?: number[];
      startHour?: string;
      endHour?: string;
      slotDuration?: number;
      isActive?: boolean;
    },
  ) {
    const before = await this.requireDoctorInScope(ctx, doctorId);

    // Fields are enumerated, never spread. `organizationId` and `projectId` are
    // deliberately not assignable from a request body: the tenant and the project
    // of a doctor are the server's decision, and honouring them would let a caller
    // move a clinical record between tenants. `undefined` values are ignored by
    // Prisma, so partial updates keep working.
    const updated = await this.prisma.client.doctor.update({
      where: { id: doctorId },
      data: {
        name: data.name,
        specialty: data.specialty,
        department: data.department,
        email: data.email,
        phone: data.phone,
        workingDays: data.workingDays,
        startHour: data.startHour,
        endHour: data.endHour,
        slotDuration: data.slotDuration,
        isActive: data.isActive,
      },
    });

    const changes = this.diff(before, updated, DOCTOR_DIFFED_FIELDS);

    await this.audit({
      action: 'DOCTOR_UPDATED',
      resourceType: 'DOCTOR',
      resourceId: updated.id,
      organizationId: updated.organizationId,
      projectId: updated.projectId,
      actorUserId: ctx.userId,
      // `changes` is empty when the request re-sent the values already on the row, so
      // a real edit and a no-op are distinguishable from the row alone.
      metadata: { changes, noOp: changes.length === 0 },
    });

    return updated;
  }

  async deleteDoctor(ctx: TenantContext, doctorId: string) {
    // The full row, not just the scope columns: once this returns, the row is gone and
    // this pre-image is the only surviving description of what was removed.
    const before = await this.requireDoctorInScope(ctx, doctorId);

    const result = await this.prisma.client.doctor.deleteMany({
      where: { id: doctorId, ...accessibleProjectsScope(ctx) },
    });
    if (result.count === 0) throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });

    // Audited last, and only after the delete is known to have removed exactly one
    // row. A refused delete never reaches this line, so it writes nothing.
    await this.audit({
      action: 'DOCTOR_DELETED',
      resourceType: 'DOCTOR',
      resourceId: before.id,
      organizationId: before.organizationId,
      projectId: before.projectId,
      actorUserId: ctx.userId,
      metadata: {
        before: this.snapshotFields(before, DOCTOR_DIFFED_FIELDS),
        hadContact: {
          email: this.present(before.email),
          phone: this.present(before.phone),
        },
        // A delete cannot be undone from the audit log. Recording whether the row was
        // active at deletion time is what lets an investigator tell a deliberate
        // retirement from a row that was disabled and then removed.
        wasActive: before.isActive,
      },
    });
  }

  async createProcedure(ctx: TenantContext, data: {
    projectId?: string;
    name: string;
    specialty: string;
    durationMinutes: number;
    bufferMinutes?: number;
    price?: number;
  }) {
    const projectId = this.resolveProject(ctx, data.projectId);
    const created = await this.prisma.client.procedure.create({
      data: {
        organizationId: ctx.organizationId,
        projectId,
        name: data.name,
        specialty: data.specialty,
        durationMinutes: data.durationMinutes,
        bufferMinutes: data.bufferMinutes || 0,
        price: data.price,
        isActive: true,
      },
    });

    // A procedure carries no contact details and no patient data, so every field in
    // PROCEDURE_DIFFED_FIELDS is recorded by value.
    await this.audit({
      action: 'PROCEDURE_CREATED',
      resourceType: 'PROCEDURE',
      resourceId: created.id,
      organizationId: created.organizationId,
      projectId: created.projectId,
      actorUserId: ctx.userId,
      metadata: { after: this.snapshotFields(created, PROCEDURE_DIFFED_FIELDS) },
    });

    return created;
  }

  async updateProcedure(
    ctx: TenantContext,
    procedureId: string,
    data: {
      name?: string;
      specialty?: string;
      durationMinutes?: number;
      bufferMinutes?: number;
      price?: number;
      isActive?: boolean;
    },
  ) {
    const before = await this.requireProcedureInScope(ctx, procedureId);

    // Enumerated, never spread — see updateDoctor. Tenant and project are not
    // caller-assignable.
    const updated = await this.prisma.client.procedure.update({
      where: { id: procedureId },
      data: {
        name: data.name,
        specialty: data.specialty,
        durationMinutes: data.durationMinutes,
        bufferMinutes: data.bufferMinutes,
        price: data.price,
        isActive: data.isActive,
      },
    });

    const changes = this.diff(before, updated, PROCEDURE_DIFFED_FIELDS);

    await this.audit({
      action: 'PROCEDURE_UPDATED',
      resourceType: 'PROCEDURE',
      resourceId: updated.id,
      organizationId: updated.organizationId,
      projectId: updated.projectId,
      actorUserId: ctx.userId,
      metadata: { changes, noOp: changes.length === 0 },
    });

    return updated;
  }

  async deleteProcedure(ctx: TenantContext, procedureId: string) {
    // Full pre-image — after this returns the row no longer exists to be described.
    const before = await this.requireProcedureInScope(ctx, procedureId);

    const result = await this.prisma.client.procedure.deleteMany({
      where: { id: procedureId, ...accessibleProjectsScope(ctx) },
    });
    if (result.count === 0) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });
    }

    await this.audit({
      action: 'PROCEDURE_DELETED',
      resourceType: 'PROCEDURE',
      resourceId: before.id,
      organizationId: before.organizationId,
      projectId: before.projectId,
      actorUserId: ctx.userId,
      metadata: {
        before: this.snapshotFields(before, PROCEDURE_DIFFED_FIELDS),
        wasActive: before.isActive,
      },
    });
  }

  async getAllProcedures(ctx: TenantContext, requestedProjectId?: string): Promise<any[]> {
    const projectId = this.resolveProject(ctx, requestedProjectId);
    const procedures = await this.prisma.client.procedure.findMany({
      where: { projectId, organizationId: ctx.organizationId },
      orderBy: { name: 'asc' },
      include: {
        _count: {
          select: { appointments: true },
        },
      },
    });
    return procedures.map((p) => ({
      id: p.id,
      name: p.name,
      specialty: p.specialty,
      durationMinutes: p.durationMinutes,
      bufferMinutes: p.bufferMinutes,
      price: p.price,
      isActive: p.isActive,
      appointmentCount: p._count.appointments,
    }));
  }

  async getProcedures(ctx: TenantContext, requestedProjectId?: string): Promise<ClinicProcedure[]> {
    const projectId = this.resolveProject(ctx, requestedProjectId);
    const procedures = await this.prisma.client.procedure.findMany({
      where: { projectId, organizationId: ctx.organizationId, isActive: true },
      orderBy: { name: 'asc' },
    });
    return procedures.map((p) => ({
      id: p.id,
      name: p.name,
      specialty: p.specialty,
      durationMinutes: p.durationMinutes,
      bufferMinutes: p.bufferMinutes,
      price: p.price,
      isActive: p.isActive,
    }));
  }

  async getProcedureById(ctx: TenantContext, procedureId: string): Promise<ClinicProcedure | null> {
    const p = await this.prisma.client.procedure.findFirst({
      where: { id: procedureId, ...accessibleProjectsScope(ctx) },
    });
    if (!p) return null;
    return {
      id: p.id,
      name: p.name,
      specialty: p.specialty,
      durationMinutes: p.durationMinutes,
      bufferMinutes: p.bufferMinutes,
      price: p.price,
      isActive: p.isActive,
    };
  }

  async getDoctorSchedule(
    ctx: TenantContext,
    doctorId: string,
    date: Date,
  ): Promise<{ isWorkingDay: boolean; startHour: string; endHour: string } | null> {
    const doctor = await this.getDoctorById(ctx, doctorId);
    if (!doctor) return null;

    const dayOfWeek = date.getDay(); // 0 = Sunday, 1 = Monday, etc.
    const isWorkingDay = doctor.workingDays.includes(dayOfWeek);

    return {
      isWorkingDay,
      startHour: doctor.startHour,
      endHour: doctor.endHour,
    };
  }

  async getExistingAppointments(
    ctx: TenantContext,
    doctorId: string,
    date: Date,
  ): Promise<ClinicAppointment[]> {
    const dayStart = new Date(date);
    dayStart.setHours(0, 0, 0, 0);

    const dayEnd = new Date(date);
    dayEnd.setHours(23, 59, 59, 999);

    const appointments = await this.prisma.client.appointment.findMany({
      where: {
        doctorId,
        ...accessibleProjectsScope(ctx),
        appointmentDate: {
          gte: dayStart,
          lte: dayEnd,
        },
        status: {
          notIn: ['CANCELLED', 'NO_SHOW'],
        },
      },
      orderBy: { appointmentDate: 'asc' },
    });

    return appointments.map((a) => ({
      id: a.id,
      organizationId: a.organizationId,
      projectId: a.projectId,
      customerId: a.customerId,
      doctorId: a.doctorId,
      procedureId: a.procedureId,
      title: a.title,
      patientName: a.patientName,
      patientPhone: a.patientPhone,
      patientEmail: a.patientEmail,
      appointmentDate: a.appointmentDate,
      durationMinutes: a.durationMinutes,
      status: a.status,
      service: a.service,
      doctorName: a.doctorName,
      notes: a.notes,
    }));
  }

  async createAppointment(ctx: TenantContext, input: CreateClinicAppointmentInput): Promise<ClinicAppointment> {
    // The tenant is the caller's, always. The project goes through the
    // membership check, so an appointment cannot be filed into a project the
    // caller does not belong to by naming it in the request.
    const projectId = this.resolveProject(ctx, input.projectId);
    const a = await this.prisma.client.appointment.create({
      data: {
        organizationId: ctx.organizationId,
        projectId,
        customerId: input.customerId ?? null,
        doctorId: input.doctorId ?? null,
        procedureId: input.procedureId ?? null,
        title: input.title,
        patientName: input.patientName ?? null,
        patientPhone: input.patientPhone ?? null,
        patientEmail: input.patientEmail ?? null,
        appointmentDate: input.appointmentDate,
        durationMinutes: input.durationMinutes,
        status: 'PENDING',
        service: input.service ?? null,
        doctorName: input.doctorName ?? null,
        notes: input.notes ?? null,
        isAiProposed: input.isAiProposed ?? true,
        aiProposalReason: input.aiProposalReason ?? null,
        ticketNumber: input.ticketNumber ?? null,
        ticketDate: input.ticketDate ?? null,
        createdById: input.createdById ?? null,
      },
    });

    return {
      id: a.id,
      organizationId: a.organizationId,
      projectId: a.projectId,
      customerId: a.customerId,
      doctorId: a.doctorId,
      procedureId: a.procedureId,
      title: a.title,
      patientName: a.patientName,
      patientPhone: a.patientPhone,
      patientEmail: a.patientEmail,
      appointmentDate: a.appointmentDate,
      durationMinutes: a.durationMinutes,
      status: a.status,
      service: a.service,
      doctorName: a.doctorName,
      notes: a.notes,
    };
  }

  async rescheduleAppointment(
    ctx: TenantContext,
    appointmentId: string,
    newDate: Date,
  ): Promise<ClinicAppointment> {
    await this.assertAppointmentInScope(ctx, appointmentId);
    const a = await this.prisma.client.appointment.update({
      where: { id: appointmentId },
      data: {
        appointmentDate: newDate,
        status: 'PENDING', // AI rescheduled proposals go back to PENDING for confirmation
      },
    });

    return {
      id: a.id,
      organizationId: a.organizationId,
      projectId: a.projectId,
      customerId: a.customerId,
      doctorId: a.doctorId,
      procedureId: a.procedureId,
      title: a.title,
      patientName: a.patientName,
      patientPhone: a.patientPhone,
      patientEmail: a.patientEmail,
      appointmentDate: a.appointmentDate,
      durationMinutes: a.durationMinutes,
      status: a.status,
      service: a.service,
      doctorName: a.doctorName,
      notes: a.notes,
    };
  }

  async cancelAppointment(
    ctx: TenantContext,
    appointmentId: string,
    reason?: string,
  ): Promise<boolean> {
    const existing = await this.prisma.client.appointment.findFirst({
      where: { id: appointmentId, ...accessibleProjectsScope(ctx) },
    });
    if (!existing) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });
    }

    await this.prisma.client.appointment.update({
      where: { id: appointmentId },
      data: {
        status: 'CANCELLED',
        notes: reason ? `${existing.notes ? existing.notes + ' | ' : ''}Cancellation reason: ${reason}` : existing.notes,
      },
    });

    return true;
  }
}
