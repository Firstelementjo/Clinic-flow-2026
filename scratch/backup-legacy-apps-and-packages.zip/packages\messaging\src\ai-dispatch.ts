import type { PrismaClient } from '@firstelement/database';
import { DomainEventType, type DomainEventPublisher } from '@firstelement/events';

/**
 * Decides whether an inbound message should get an AI turn, and performs
 * the handover when it should not.
 *
 * Kept out of the inbound pipeline itself so that pipeline does not grow a
 * branch per downstream consumer, and shared by the worker and the inline
 * dev path so both answer the question the same way.
 */

export interface AIEligibility {
  eligible: boolean;
  reason: string;
}

export async function resolveAIEligibility(
  prisma: PrismaClient,
  params: { organizationId: string; projectId: string; conversationId: string },
): Promise<AIEligibility> {
  const conversation = await prisma.conversation.findFirst({
    where: {
      id: params.conversationId,
      organizationId: params.organizationId,
      projectId: params.projectId,
    },
    select: { mode: true, status: true },
  });

  if (!conversation) return { eligible: false, reason: 'Conversation not found' };
  // The hard rule: once a conversation is HUMAN, the AI does not answer,
  // period (plan §10).
  if (conversation.mode !== 'AI') return { eligible: false, reason: 'Conversation is with a human' };

  const agent = await prisma.aIAgent.findFirst({
    where: { projectId: params.projectId, organizationId: params.organizationId, isEnabled: true },
    select: { activeVersionId: true },
  });

  if (!agent) return { eligible: false, reason: 'Project has no enabled AI agent' };
  if (!agent.activeVersionId) return { eligible: false, reason: 'Agent has no active version' };

  return { eligible: true, reason: 'AI agent is active' };
}

/** Whether a *new* conversation in this project should start in AI mode. */
export async function projectHasActiveAgent(
  prisma: PrismaClient,
  params: { organizationId: string; projectId: string },
): Promise<boolean> {
  const agent = await prisma.aIAgent.findFirst({
    where: {
      projectId: params.projectId,
      organizationId: params.organizationId,
      isEnabled: true,
      NOT: { activeVersionId: null },
    },
    select: { id: true },
  });
  return Boolean(agent);
}

/**
 * Moves a conversation from AI to HUMAN.
 *
 * The update is conditional on the conversation still being in AI mode and
 * on the version it was read at, so two concurrent transitions — an
 * escalation and a manual takeover arriving together — cannot both
 * succeed (plan §10). The loser is told it lost rather than silently
 * overwriting.
 */
export async function handOverToHuman(
  prisma: PrismaClient,
  events: DomainEventPublisher,
  params: {
    organizationId: string;
    projectId: string;
    conversationId: string;
    reason: string;
    actorUserId?: string;
  },
): Promise<{ changed: boolean }> {
  const current = await prisma.conversation.findFirst({
    where: {
      id: params.conversationId,
      organizationId: params.organizationId,
      projectId: params.projectId,
    },
    select: { mode: true, modeVersion: true },
  });

  if (!current || current.mode === 'HUMAN') return { changed: false };

  const result = await prisma.conversation.updateMany({
    where: {
      id: params.conversationId,
      mode: 'AI',
      modeVersion: current.modeVersion,
    },
    data: {
      mode: 'HUMAN',
      modeVersion: { increment: 1 },
      status: 'PENDING',
    },
  });

  if (result.count === 0) return { changed: false };

  events.publish({
    type: DomainEventType.CONVERSATION_MODE_CHANGED,
    organizationId: params.organizationId,
    projectId: params.projectId,
    aggregateId: params.conversationId,
    aggregateType: 'Conversation',
    actorUserId: params.actorUserId,
    payload: { from: 'AI', to: 'HUMAN', reason: params.reason },
    occurredAt: new Date(),
  });

  return { changed: true };
}
