import { Global, Module } from '@nestjs/common';
import { MessageQueueService } from './message-queue.service';
import {
  ConnectorRegistryProvider,
  InboundPipelineProvider,
  OutboundDispatcherProvider,
} from './messaging.providers';

@Global()
@Module({
  providers: [
    ConnectorRegistryProvider,
    InboundPipelineProvider,
    OutboundDispatcherProvider,
    MessageQueueService,
  ],
  exports: [
    ConnectorRegistryProvider,
    InboundPipelineProvider,
    OutboundDispatcherProvider,
    MessageQueueService,
  ],
})
export class MessagingModule {}
