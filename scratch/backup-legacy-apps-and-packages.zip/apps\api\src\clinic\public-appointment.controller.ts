import { Controller, Get, Post, Param, Body } from '@nestjs/common';
import { Public } from '../auth/decorators';
import { RemindersService } from './reminders.service';

/**
 * The patient-facing side of the clinic, and the only unauthenticated surface here.
 *
 * <h2>These routes stay exactly this narrow</h2>
 *
 * <p>They are gated on nothing but the unguessable {@code actionToken}: possession of
 * the link <em>is</em> the capability, which is the correct design for a patient
 * clicking a WhatsApp. Phase 26 found and removed the one path that broke it — both
 * handlers used to accept a bare appointment UUID as well, which let anyone who
 * learned an id read a patient's name, phone, time and doctor, and cancel their
 * appointment, with no session at all.
 *
 * <p>So this controller is deliberately left with <b>no</b> {@code @RequirePermissions}:
 * a permission here would be unreachable (there is no principal) and adding one would
 * mean inventing a fake identity for patients. What protects it is token-only
 * resolution — {@code resolveReminderByToken} never accepts an id — and that is
 * asserted in {@code clinic-permissions.test.ts} rather than left to this comment.
 *
 * <p>A wrong or absent token is a 404 with the same body a nonexistent reminder
 * produces. The clinic's own denial shape is used for consistency, not because a
 * patient can be authorized: there is nothing here to disclose.
 */
@Public()
@Controller('public/appointments')
export class PublicAppointmentController {
  constructor(private readonly remindersService: RemindersService) {}

  @Get(':token')
  async getAppointmentByToken(@Param('token') token: string) {
    return this.remindersService.getPublicAppointmentDetails(token);
  }

  @Post(':token/respond')
  async respondToAppointment(
    @Param('token') token: string,
    @Body() body: { action: 'CONFIRM' | 'RESCHEDULE' | 'CANCEL'; reason?: string },
  ) {
    // Token-only: the unguessable action token *is* the capability on this route.
    // The previous shared method also accepted a bare appointment id here, which
    // let an unauthenticated caller who learned an id act on the appointment.
    return this.remindersService.processPatientResponseByToken(token, body.action, body.reason);
  }
}
