import clsx from 'clsx';
import type { ButtonHTMLAttributes, ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
type Size = 'sm' | 'md';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  /** Renders a busy state and blocks repeat submits. */
  loading?: boolean;
  children: ReactNode;
}

const VARIANTS: Record<Variant, string> = {
  primary: 'bg-[var(--fe-signal)] text-white hover:bg-[var(--fe-signal-strong)] border border-[var(--fe-signal)]',
  secondary: 'bg-[var(--fe-surface)] text-[var(--fe-ink)] border border-[var(--fe-hairline)] hover:bg-[var(--fe-surf2)]',
  ghost: 'bg-transparent text-[var(--fe-slate)] border border-transparent hover:bg-[var(--fe-mist-deep)] hover:text-[var(--fe-ink)]',
  danger: 'bg-[var(--fe-danger)] text-white border border-transparent hover:brightness-95',
};

const SIZES: Record<Size, string> = {
  sm: 'h-7 px-2.5 text-xs',
  md: 'h-[36px] px-4 text-sm',
};

export function Button({
  variant = 'secondary',
  size = 'md',
  loading = false,
  disabled,
  className,
  children,
  ...rest
}: ButtonProps) {
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={clsx(
        'inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-colors',
        'disabled:cursor-not-allowed disabled:opacity-55',
        VARIANTS[variant],
        SIZES[size],
        className,
      )}
    >
      {loading && <span className="fe-spinner" aria-hidden="true" />}
      {children}
    </button>
  );
}
