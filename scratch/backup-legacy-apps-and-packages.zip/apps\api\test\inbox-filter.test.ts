import { describe, expect, it } from 'vitest';
import { InboxFilter } from '@firstelement/shared';
import { buildInboxWhere } from '../src/conversations/inbox-filter';

const userId = 'user-1';

describe('inbox saved views', () => {
  it('assigned-to-me: matches by assigned employee OR last replier', () => {
    const where = buildInboxWhere({ filter: InboxFilter.ASSIGNED_TO_ME, userId });
    expect(where.AND).toBeDefined();
    const and = where.AND as Array<Record<string, unknown>>;
    expect(and[0]).toEqual({ status: { in: ['OPEN', 'PENDING'] } });
    expect(and[1]).toEqual({
      OR: [
        { assignedEmployee: { is: { userId } } },
        { lastReplierUserId: userId },
      ],
    });
  });

  it('history: matches resolved/closed where employee was involved', () => {
    const where = buildInboxWhere({ filter: InboxFilter.HISTORY, userId });
    expect(where.AND).toBeDefined();
    const and = where.AND as Array<Record<string, unknown>>;
    expect(and[0]).toEqual({ status: { in: ['RESOLVED', 'CLOSED'] } });
    expect(and[1]).toEqual({
      OR: [
        { assignedEmployee: { is: { userId } } },
        { lastReplierUserId: userId },
      ],
    });
  });
});

describe('additional constraints', () => {
  it('combines a channel filter with the saved view', () => {
    const where = buildInboxWhere({
      filter: InboxFilter.ASSIGNED_TO_ME,
      userId,
      channel: 'WHATSAPP',
    });
    expect(where.channel).toBe('WHATSAPP');
    expect(where.AND).toBeDefined();
  });

  it('searches subject, cxId, ticket number and message bodies', () => {
    const where = buildInboxWhere({ filter: InboxFilter.ASSIGNED_TO_ME, userId, search: 'refund' });
    expect(where.AND).toBeDefined();
    const and = where.AND as Array<Record<string, unknown>>;
    const searchClause = and.find((c) => (c as Record<string, unknown>).OR);
    expect(searchClause).toBeDefined();
    expect((searchClause as Record<string, unknown>).OR).toBeDefined();
  });

  it('ignores whitespace-only search terms', () => {
    const where = buildInboxWhere({ filter: InboxFilter.ASSIGNED_TO_ME, userId, search: '   ' });
    const and = where.AND as Array<Record<string, unknown>>;
    expect(and).toHaveLength(2);
  });

  it('never returns tenant columns — the caller supplies the scope', () => {
    for (const filter of Object.values(InboxFilter)) {
      const where = buildInboxWhere({ filter, userId, search: 'x' });
      expect(where).not.toHaveProperty('organizationId');
      expect(where).not.toHaveProperty('projectId');
    }
  });
});
