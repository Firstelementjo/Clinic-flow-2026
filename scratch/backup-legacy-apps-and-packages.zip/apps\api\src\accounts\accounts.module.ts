import { Module } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { AccountsService } from './accounts.service';
import { AccountsController } from './accounts.controller';

@Module({
  providers: [AccountsService, PrismaService],
  controllers: [AccountsController],
  exports: [AccountsService],
})
export class AccountsModule {}