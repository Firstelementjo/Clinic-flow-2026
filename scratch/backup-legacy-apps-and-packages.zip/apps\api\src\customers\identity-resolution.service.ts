import { Injectable } from '@nestjs/common';
import { IdentityResolver } from '@firstelement/messaging';
import { PrismaService } from '../common/prisma.service';
import { DomainEventBus } from '../events/domain-event-bus';

/**
 * Nest wrapper over the shared resolver.
 *
 * The logic lives in `@firstelement/messaging` because the worker resolves
 * identities on every inbound message without Nest in the picture. Two
 * implementations would mean two definitions of who a customer is.
 */
@Injectable()
export class IdentityResolutionService extends IdentityResolver {
  constructor(prisma: PrismaService, events: DomainEventBus) {
    super(prisma.client, events);
  }
}

export type { InboundIdentity, ResolvedCustomer } from '@firstelement/messaging';
