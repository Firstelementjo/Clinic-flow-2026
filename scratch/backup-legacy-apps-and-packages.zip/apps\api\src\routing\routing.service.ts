import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { randomBytes } from 'node:crypto';
import { hashPassword } from '@firstelement/auth';
import { projectScope, type TenantContext } from '@firstelement/database';
import {
  isWithinWorkingHours,
  parseCsv,
  parseXlsx,
  suggestMapping,
  validateRows,
  type ColumnMapping,
  type EmployeeImportRecord,
} from '@firstelement/routing';
import {
  AuditAction,
  ErrorCode,
  type CommitImportInput,
  type EmployeeRoutingView,
  type ImportPreviewView,
  type ImportResultView,
  type RoutingRuleView,
  type SaveRoutingRuleInput,

  type SetSkillsInput,
  type SetWorkingHoursInput,
} from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';

const MAX_IMPORT_BYTES = 5 * 1024 * 1024;

@Injectable()
export class RoutingService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  // --- roster ---------------------------------------------------------------

  async listEmployees(ctx: TenantContext, projectId?: string): Promise<EmployeeRoutingView[]> {
    const employees = await this.prisma.client.employee.findMany({
      where: {
        organizationId: ctx.organizationId,
        ...(projectId
          ? { user: { memberships: { some: { projectId } } } }
          : {}),
      },
      select: {
        id: true,
        userId: true,
        department: true,
        availabilityStatus: true,
        statusChangedAt: true,
        activeConversationCount: true,
        maxConcurrentConversations: true,
        user: { select: { fullName: true, email: true } },
        skills: { select: { skill: true, level: true }, orderBy: { skill: 'asc' } },
        availability: {
          select: { dayOfWeek: true, startMinute: true, endMinute: true, timezone: true },
          orderBy: [{ dayOfWeek: 'asc' }, { startMinute: 'asc' }],
        },
      },
      orderBy: { createdAt: 'asc' },
    });

    const now = new Date();
    return employees.map((employee) => ({
      id: employee.id,
      userId: employee.userId,
      fullName: employee.user.fullName,
      email: employee.user.email,
      department: employee.department,
      availabilityStatus: employee.availabilityStatus,
      statusChangedAt: employee.statusChangedAt.toISOString(),
      activeConversationCount: employee.activeConversationCount,
      maxConcurrentConversations: employee.maxConcurrentConversations,
      skills: employee.skills,
      windows: employee.availability,
      isOnShift: isWithinWorkingHours(employee.availability, now),
    }));
  }

  async setWorkingHours(
    ctx: TenantContext,
    employeeId: string,
    input: SetWorkingHoursInput,
  ): Promise<EmployeeRoutingView> {
    await this.requireEmployee(ctx, employeeId);

    for (const window of input.windows) {
      // A zone the runtime cannot resolve would silently make an employee
      // permanently off-shift, which looks like a routing bug months later.
      if (!isValidTimeZone(window.timezone)) {
        throw new BadRequestException({
          code: ErrorCode.VALIDATION_FAILED,
          message: `Unknown timezone "${window.timezone}"`,
        });
      }
    }

    await this.prisma.client.$transaction([
      this.prisma.client.employeeAvailability.deleteMany({ where: { employeeId } }),
      this.prisma.client.employeeAvailability.createMany({
        data: input.windows.map((window) => ({
          organizationId: ctx.organizationId,
          employeeId,
          dayOfWeek: window.dayOfWeek,
          startMinute: window.startMinute,
          endMinute: window.endMinute,
          timezone: window.timezone,
        })),
      }),
    ]);

    return this.requireEmployeeView(ctx, employeeId);
  }

  async setSkills(
    ctx: TenantContext,
    employeeId: string,
    input: SetSkillsInput,
  ): Promise<EmployeeRoutingView> {
    await this.requireEmployee(ctx, employeeId);

    await this.prisma.client.$transaction([
      this.prisma.client.employeeSkill.deleteMany({ where: { employeeId } }),
      this.prisma.client.employeeSkill.createMany({
        data: input.skills.map((entry) => ({
          organizationId: ctx.organizationId,
          employeeId,
          skill: entry.skill.toLowerCase(),
          level: entry.level,
        })),
        skipDuplicates: true,
      }),
    ]);

    return this.requireEmployeeView(ctx, employeeId);
  }

  // --- routing rules --------------------------------------------------------

  async listRules(ctx: TenantContext, projectId: string): Promise<RoutingRuleView[]> {
    const rules = await this.prisma.client.routingRule.findMany({
      where: projectScope(ctx, projectId),
      orderBy: [{ priority: 'asc' }, { id: 'asc' }],
    });
    return rules.map(toRuleView);
  }

  async createRule(
    ctx: TenantContext,
    projectId: string,
    input: SaveRoutingRuleInput,
    ipAddress?: string,
  ): Promise<RoutingRuleView> {
    const rule = await this.prisma.client.routingRule.create({
      data: {
        ...projectScope(ctx, projectId),
        name: input.name,
        isEnabled: input.isEnabled,
        priority: input.priority,
        intent: input.intent ?? null,
        department: input.department ?? null,
        requiredSkill: input.requiredSkill?.toLowerCase() ?? null,
        strategy: input.strategy,
      },
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CHANGED_ESCALATION_RULE,
      resourceType: 'RoutingRule',
      resourceId: rule.id,
      metadata: { change: 'created', name: input.name },
      ipAddress,
    });

    return toRuleView(rule);
  }

  async updateRule(
    ctx: TenantContext,
    projectId: string,
    ruleId: string,
    input: SaveRoutingRuleInput,
    ipAddress?: string,
  ): Promise<RoutingRuleView> {
    const scope = projectScope(ctx, projectId);

    const result = await this.prisma.client.routingRule.updateMany({
      where: { id: ruleId, ...scope },
      data: {
        name: input.name,
        isEnabled: input.isEnabled,
        priority: input.priority,
        intent: input.intent ?? null,
        department: input.department ?? null,
        requiredSkill: input.requiredSkill?.toLowerCase() ?? null,
        strategy: input.strategy,
      },
    });
    if (result.count === 0) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Routing rule not found' });
    }

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CHANGED_ESCALATION_RULE,
      resourceType: 'RoutingRule',
      resourceId: ruleId,
      metadata: { change: 'updated', name: input.name },
      ipAddress,
    });

    const rule = await this.prisma.client.routingRule.findFirstOrThrow({
      where: { id: ruleId, ...scope },
    });
    return toRuleView(rule);
  }

  async deleteRule(ctx: TenantContext, projectId: string, ruleId: string): Promise<void> {
    const result = await this.prisma.client.routingRule.deleteMany({
      where: { id: ruleId, ...projectScope(ctx, projectId) },
    });
    if (result.count === 0) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Routing rule not found' });
    }
  }

  // --- import ---------------------------------------------------------------

  /**
   * Step one of the wizard: parse, guess the column mapping, validate, and
   * report. Nothing is written — the admin sees valid, invalid and
   * duplicate rows before deciding (plan §10).
   */
  async previewImport(
    ctx: TenantContext,
    file: { buffer: Buffer; originalname: string; mimetype: string; size: number },
    mappingOverride?: ColumnMapping,
  ): Promise<ImportPreviewView> {
    if (file.size > MAX_IMPORT_BYTES) {
      throw new BadRequestException({
        code: ErrorCode.VALIDATION_FAILED,
        message: 'Import files are limited to 5MB',
      });
    }

    const isExcel =
      file.originalname.toLowerCase().endsWith('.xlsx') ||
      file.mimetype.includes('spreadsheetml');

    const sheet = isExcel
      ? await parseXlsx(file.buffer)
      : parseCsv(file.buffer.toString('utf8'));

    if (sheet.headers.length === 0) {
      throw new BadRequestException({
        code: ErrorCode.VALIDATION_FAILED,
        message: 'That file has no header row',
      });
    }

    const mapping = { ...suggestMapping(sheet.headers), ...mappingOverride };
    if (!mapping.email || !mapping.fullName) {
      throw new BadRequestException({
        code: ErrorCode.VALIDATION_FAILED,
        message: 'The file needs at least an email column and a name column',
      });
    }

    const existing = await this.prisma.client.user.findMany({
      where: { organizationId: ctx.organizationId },
      select: { email: true },
    });

    const preview = validateRows(
      sheet,
      mapping,
      new Set(existing.map((user) => user.email.toLowerCase())),
    );

    return {
      headers: preview.headers,
      totalRows: preview.totalRows,
      mapping: mapping as Record<string, string>,
      valid: preview.validRows.map((row) => ({
        rowNumber: row.rowNumber,
        email: row.record!.email,
        fullName: row.record!.fullName,
        department: row.record!.department,
      })),
      invalid: preview.invalidRows.map((row) => ({
        rowNumber: row.rowNumber,
        errors: row.errors,
      })),
      duplicates: preview.duplicateRows.map((row) => ({
        rowNumber: row.rowNumber,
        email: row.record!.email,
      })),
    };
  }

  /**
   * Step two: create only the confirmed rows.
   *
   * Each employee gets a random password they are never told — the account
   * exists but is unusable until a reset, so an import cannot quietly
   * create logins with a predictable secret.
   */
  async commitImport(
    ctx: TenantContext,
    input: CommitImportInput,
    ipAddress?: string,
  ): Promise<ImportResultView> {
    const projectIds = await this.filterProjects(ctx, input.projectIds);
    const skipped: ImportResultView['skipped'] = [];
    const created: string[] = [];

    for (const record of input.employees) {
      const existing = await this.prisma.client.user.findUnique({
        where: { email: record.email },
        select: { id: true },
      });
      if (existing) {
        skipped.push({ email: record.email, reason: 'An account with this email already exists' });
        continue;
      }

      await this.createEmployee(ctx, record, projectIds);
      created.push(record.email);
    }

    await this.audit.record({
      organizationId: ctx.organizationId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CREATED_EMPLOYEE,
      resourceType: 'EmployeeImport',
      metadata: { created: created.length, skipped: skipped.length, projectIds },
      ipAddress,
    });

    return { created: created.length, skipped, requiresPasswordReset: created };
  }

  private async createEmployee(
    ctx: TenantContext,
    record: EmployeeImportRecord,
    projectIds: string[],
  ): Promise<void> {
    const passwordHash = await hashPassword(randomBytes(24).toString('hex'));

    await this.prisma.client.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          organizationId: ctx.organizationId,
          email: record.email,
          fullName: record.fullName,
          passwordHash,
          role: 'EMPLOYEE',
        },
        select: { id: true },
      });

      const employee = await tx.employee.create({
        data: {
          organizationId: ctx.organizationId,
          userId: user.id,
          department: record.department ?? null,
          maxConcurrentConversations: record.maxConcurrentConversations ?? 5,
        },
        select: { id: true },
      });

      if (record.skills.length > 0) {
        await tx.employeeSkill.createMany({
          data: record.skills.map((skill) => ({
            organizationId: ctx.organizationId,
            employeeId: employee.id,
            skill: skill.toLowerCase(),
          })),
          skipDuplicates: true,
        });
      }

      if (projectIds.length > 0) {
        await tx.projectMembership.createMany({
          data: projectIds.map((projectId) => ({
            organizationId: ctx.organizationId,
            projectId,
            userId: user.id,
          })),
          skipDuplicates: true,
        });
      }
    });
  }

  /** Project ids from the client are a request, never an authorization. */
  private async filterProjects(ctx: TenantContext, projectIds: string[]): Promise<string[]> {
    if (projectIds.length === 0) return [];
    const projects = await this.prisma.client.project.findMany({
      where: { id: { in: projectIds }, organizationId: ctx.organizationId },
      select: { id: true },
    });
    return projects.map((project) => project.id);
  }

  private async requireEmployee(ctx: TenantContext, employeeId: string) {
    const employee = await this.prisma.client.employee.findFirst({
      where: { id: employeeId, organizationId: ctx.organizationId },
      select: { id: true },
    });
    if (!employee) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Employee not found' });
    }
    return employee;
  }

  private async requireEmployeeView(
    ctx: TenantContext,
    employeeId: string,
  ): Promise<EmployeeRoutingView> {
    const all = await this.listEmployees(ctx);
    const found = all.find((employee) => employee.id === employeeId);
    if (!found) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Employee not found' });
    }
    return found;
  }
}

function toRuleView(rule: {
  id: string;
  name: string;
  isEnabled: boolean;
  priority: number;
  intent: string | null;
  department: string | null;
  requiredSkill: string | null;
  strategy: 'LEAST_LOADED' | 'ROUND_ROBIN';
}): RoutingRuleView {
  return {
    id: rule.id,
    name: rule.name,
    isEnabled: rule.isEnabled,
    priority: rule.priority,
    intent: rule.intent,
    department: rule.department,
    requiredSkill: rule.requiredSkill,
    strategy: rule.strategy,
  };
}

function isValidTimeZone(timezone: string): boolean {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: timezone });
    return true;
  } catch {
    return false;
  }
}
