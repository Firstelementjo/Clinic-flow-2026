import type { UiLocale } from '@firstelement/ui';

/**
 * Numerals stay Western (0–9) in both locales — these are operational
 * figures compared across rows and against dashboards, which is how Gulf
 * business software sets them (docs/design-system.md). The `-u-nu-latn`
 * extension is what holds that for Arabic.
 */
function intlLocale(locale: UiLocale): string {
  return locale === 'ar' ? 'ar-u-nu-latn' : 'en-GB';
}

export function formatTime(iso: string, locale: UiLocale): string {
  return new Intl.DateTimeFormat(intlLocale(locale), {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(new Date(iso));
}

export function formatDate(iso: string, locale: UiLocale): string {
  return new Intl.DateTimeFormat(intlLocale(locale), {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(new Date(iso));
}

/**
 * Inbox rows show a clock for today and a date beyond it: an operator
 * scanning the queue needs "how long has this been waiting", and a full
 * timestamp on every row costs the width that the message preview needs.
 */
export function formatListStamp(iso: string, locale: UiLocale): string {
  const date = new Date(iso);
  const now = new Date();
  const sameDay =
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth() &&
    date.getDate() === now.getDate();

  return sameDay ? formatTime(iso, locale) : formatDate(iso, locale);
}
