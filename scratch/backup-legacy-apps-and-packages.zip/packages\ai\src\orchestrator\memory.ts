import type { ChatMessage } from '../providers/types';

export interface StoredTurn {
  authorType: 'CUSTOMER' | 'EMPLOYEE' | 'AI' | 'SYSTEM';
  body: string;
  sentAt: Date;
}

export interface Memory {
  messages: ChatMessage[];
  summary: string | null;
  summarizedTurns: number;
}

/**
 * Conversation memory (plan §9): recent turns verbatim, older turns as a
 * rolling summary.
 *
 * Shipping the whole transcript forever is the default that quietly
 * doubles cost every week and eventually exceeds the context window
 * mid-conversation — on the longest, most frustrated threads, which are
 * exactly the ones that must not break.
 *
 * The summary here is extractive rather than model-generated: it costs
 * nothing, is deterministic (so a run trace is reproducible), and cannot
 * itself be poisoned by a summarization prompt injection. Slice 6 adds the
 * model-written summary for escalation handover, which is a different job
 * — that one is read by a person.
 */
export function buildMemory(turns: StoredTurn[], window: number): Memory {
  const recent = turns.slice(-window);
  const older = turns.slice(0, Math.max(0, turns.length - window));

  return {
    messages: recent.map(toChatMessage),
    summary: older.length > 0 ? summarize(older) : null,
    summarizedTurns: older.length,
  };
}

function toChatMessage(turn: StoredTurn): ChatMessage {
  return {
    // Employee and AI replies are both "the business" from the model's
    // point of view; what matters downstream is that customer text is
    // never given a privileged role.
    role: turn.authorType === 'CUSTOMER' ? 'user' : 'assistant',
    content: turn.body,
  };
}

function summarize(turns: StoredTurn[]): string {
  const customerPoints = turns
    .filter((turn) => turn.authorType === 'CUSTOMER')
    .map((turn) => firstSentence(turn.body))
    .filter(Boolean)
    .slice(-6);

  const businessPoints = turns
    .filter((turn) => turn.authorType !== 'CUSTOMER')
    .map((turn) => firstSentence(turn.body))
    .filter(Boolean)
    .slice(-4);

  const lines: string[] = [];
  if (customerPoints.length) lines.push(`Customer said: ${customerPoints.join(' | ')}`);
  if (businessPoints.length) lines.push(`We replied: ${businessPoints.join(' | ')}`);
  lines.push(`(${turns.length} earlier messages summarized.)`);

  return lines.join('\n').slice(0, 2_000);
}

function firstSentence(text: string): string {
  const trimmed = text.trim().replace(/\s+/g, ' ');
  const match = trimmed.match(/^.{0,160}?[.!?؟۔]/u);
  return (match?.[0] ?? trimmed.slice(0, 160)).trim();
}
