import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import {
  accessibleProjectsScope,
  projectScope,
  type TenantContext,
} from '@firstelement/database';
import {
  AuditAction,
  ErrorCode,
  type CreateProjectInput,
  type UpdateProjectInput,
} from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';

const PROJECT_FIELDS = {
  id: true,
  name: true,
  slug: true,
  description: true,
  defaultLocale: true,
  timezone: true,
  isArchived: true,
  createdAt: true,
  updatedAt: true,
} as const;

@Injectable()
export class ProjectsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  /**
   * Lists only what the caller can reach. Note the `id: { in: projectIds }`
   * rather than a bare organization filter — an ADMIN's list happens to be
   * every project, but that is a property of how their membership resolves,
   * not a branch in this query.
   */
  async list(ctx: TenantContext, opts: { includeArchived?: boolean } = {}) {
    const scope = accessibleProjectsScope(ctx);
    return this.prisma.client.project.findMany({
      where: {
        organizationId: scope.organizationId,
        id: scope.projectId,
        ...(opts.includeArchived ? {} : { isArchived: false }),
      },
      select: PROJECT_FIELDS,
      orderBy: { createdAt: 'desc' },
    });
  }

  async getById(ctx: TenantContext, projectId: string) {
    const project = await this.prisma.client.project.findFirst({
      where: { id: projectId, ...projectScope(ctx, projectId) },
      select: { ...PROJECT_FIELDS, _count: { select: { memberships: true } } },
    });
    if (!project) throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Project not found' });
    return project;
  }

  async create(ctx: TenantContext, input: CreateProjectInput, ipAddress?: string) {
    const existing = await this.prisma.client.project.findUnique({
      where: { organizationId_slug: { organizationId: ctx.organizationId, slug: input.slug } },
      select: { id: true },
    });
    if (existing) {
      throw new ConflictException({
        code: ErrorCode.CONFLICT,
        message: `A project with slug "${input.slug}" already exists`,
      });
    }

    // The creating admin is enrolled as a member so that membership stays
    // the single source of project access for every role.
    const project = await this.prisma.client.$transaction(async (tx) => {
      const created = await tx.project.create({
        data: { ...input, organizationId: ctx.organizationId },
        select: PROJECT_FIELDS,
      });
      await tx.projectMembership.create({
        data: {
          organizationId: ctx.organizationId,
          projectId: created.id,
          userId: ctx.userId,
        },
      });
      return created;
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId: project.id,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CREATED_PROJECT,
      resourceType: 'Project',
      resourceId: project.id,
      metadata: { slug: project.slug },
      ipAddress,
    });

    return project;
  }

  async update(
    ctx: TenantContext,
    projectId: string,
    input: UpdateProjectInput,
    ipAddress?: string,
  ) {
    const scope = projectScope(ctx, projectId);

    const result = await this.prisma.client.project.updateMany({
      where: { id: projectId, organizationId: scope.organizationId },
      data: input,
    });
    if (result.count === 0) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Project not found' });
    }

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: input.isArchived ? AuditAction.ADMIN_ARCHIVED_PROJECT : AuditAction.ADMIN_UPDATED_PROJECT,
      resourceType: 'Project',
      resourceId: projectId,
      metadata: { changedFields: Object.keys(input) },
      ipAddress,
    });

    return this.getById(ctx, projectId);
  }

  async delete(ctx: TenantContext, projectId: string, ipAddress?: string) {
    const scope = projectScope(ctx, projectId);

    const existing = await this.prisma.client.project.findFirst({
      where: { id: projectId, organizationId: scope.organizationId },
      select: { id: true, name: true, slug: true },
    });
    if (!existing) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Project not found' });
    }

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_DELETED_PROJECT,
      resourceType: 'Project',
      resourceId: projectId,
      metadata: { name: existing.name, slug: existing.slug },
      ipAddress,
    });

    await this.prisma.client.project.delete({
      where: { id: projectId, organizationId: scope.organizationId },
    });

    return { deleted: true };
  }
}
