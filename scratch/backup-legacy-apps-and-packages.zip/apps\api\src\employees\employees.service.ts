import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { hashPassword } from '@firstelement/auth';
import { type TenantContext } from '@firstelement/database';
import {
  AuditAction,
  ErrorCode,
  UserRole,
  type CreateEmployeeInput,
  type UpdateEmployeeInput,
} from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';
import { SessionService } from '../auth/session.service';

const EMPLOYEE_SELECT = {
  id: true,
  email: true,
  fullName: true,
  role: true,
  locale: true,
  isActive: true,
  lastLoginAt: true,
  createdAt: true,
  employee: {
    select: {
      department: true,
      availabilityStatus: true,
      maxConcurrentConversations: true,
      activeConversationCount: true,
    },
  },
  memberships: { select: { projectId: true } },
} as const;

@Injectable()
export class EmployeesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly sessions: SessionService,
  ) {}

  async list(ctx: TenantContext, opts: { projectId?: string } = {}) {
    return this.prisma.client.user.findMany({
      where: {
        organizationId: ctx.organizationId,
        ...(opts.projectId ? { memberships: { some: { projectId: opts.projectId } } } : {}),
      },
      select: EMPLOYEE_SELECT,
      orderBy: { fullName: 'asc' },
    });
  }

  async getById(ctx: TenantContext, userId: string) {
    const user = await this.prisma.client.user.findFirst({
      where: { id: userId, organizationId: ctx.organizationId },
      select: EMPLOYEE_SELECT,
    });
    if (!user) throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Employee not found' });
    return user;
  }

  async create(ctx: TenantContext, input: CreateEmployeeInput, ipAddress?: string) {
    const existing = await this.prisma.client.user.findUnique({
      where: { email: input.email },
      select: { id: true },
    });
    if (existing) {
      throw new ConflictException({
        code: ErrorCode.CONFLICT,
        message: 'An account with this email already exists',
      });
    }

    // Requested project ids are filtered against the admin's own reach, so
    // a crafted request cannot enroll someone into another tenant's project.
    const projectIds = input.projectIds.filter((id) => ctx.projectIds.includes(id));
    const passwordHash = await hashPassword(input.password);

    const user = await this.prisma.client.$transaction(async (tx) => {
      const created = await tx.user.create({
        data: {
          organizationId: ctx.organizationId,
          email: input.email,
          fullName: input.fullName,
          passwordHash,
          role: input.role,
          locale: input.locale,
        },
        select: { id: true },
      });

      await tx.employee.create({
        data: {
          organizationId: ctx.organizationId,
          userId: created.id,
          department: input.department,
        },
      });

      if (projectIds.length) {
        await tx.projectMembership.createMany({
          data: projectIds.map((projectId) => ({
            organizationId: ctx.organizationId,
            projectId,
            userId: created.id,
          })),
        });
      }

      return created;
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CREATED_EMPLOYEE,
      resourceType: 'User',
      resourceId: user.id,
      metadata: { role: input.role, projectCount: projectIds.length },
      ipAddress,
    });

    return this.getById(ctx, user.id);
  }

  async update(ctx: TenantContext, userId: string, input: UpdateEmployeeInput, ipAddress?: string) {
    await this.getById(ctx, userId);

    const { projectIds, department, availabilityStatus, maxConcurrentConversations, ...userFields } =
      input;

    await this.prisma.client.$transaction(async (tx) => {
      if (Object.keys(userFields).length) {
        await tx.user.updateMany({
          where: { id: userId, organizationId: ctx.organizationId },
          data: userFields,
        });
      }

      if (
        department !== undefined ||
        availabilityStatus !== undefined ||
        maxConcurrentConversations !== undefined
      ) {
        await tx.employee.updateMany({
          where: { userId, organizationId: ctx.organizationId },
          data: { department, availabilityStatus, maxConcurrentConversations },
        });
      }

      if (projectIds) {
        const allowed = projectIds.filter((id) => ctx.projectIds.includes(id));
        await tx.projectMembership.deleteMany({
          where: { userId, organizationId: ctx.organizationId },
        });
        if (allowed.length) {
          await tx.projectMembership.createMany({
            data: allowed.map((projectId) => ({
              organizationId: ctx.organizationId,
              projectId,
              userId,
            })),
          });
        }
      }
    });

    // Deactivation must take effect now, not whenever the session expires.
    if (input.isActive === false) {
      await this.sessions.revokeAllForUser(userId);
    }

    await this.audit.record({
      organizationId: ctx.organizationId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_UPDATED_EMPLOYEE,
      resourceType: 'User',
      resourceId: userId,
      metadata: { changedFields: Object.keys(input) },
      ipAddress,
    });

    return this.getById(ctx, userId);
  }

  async delete(ctx: TenantContext, userId: string, ipAddress?: string) {
    const user = await this.getById(ctx, userId);

    // Cannot delete yourself.
    if (userId === ctx.userId) {
      throw new ConflictException({
        code: ErrorCode.CONFLICT,
        message: 'You cannot delete your own account',
      });
    }

    // Revoke sessions first.
    await this.sessions.revokeAllForUser(userId);

    // Hard delete: User cascades to Employee, ProjectMembership, Sessions, etc.
    await this.prisma.client.user.delete({
      where: { id: userId, organizationId: ctx.organizationId },
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_DELETED_EMPLOYEE,
      resourceType: 'User',
      resourceId: userId,
      metadata: { email: user.email, fullName: user.fullName },
      ipAddress,
    });

    return { deleted: true };
  }

  /** Self-service availability toggle for the logged-in employee (plan §5). */
  async setOwnAvailability(ctx: TenantContext, status: UpdateEmployeeInput['availabilityStatus']) {
    if (!status) return this.getById(ctx, ctx.userId);

    const updated = await this.prisma.client.employee.updateMany({
      where: { userId: ctx.userId, organizationId: ctx.organizationId },
      data: { availabilityStatus: status },
    });

    if (updated.count === 0 && ctx.role === UserRole.ADMIN) {
      // Admins may not have an employee profile; nothing to toggle.
      return this.getById(ctx, ctx.userId);
    }

    return this.getById(ctx, ctx.userId);
  }
}
