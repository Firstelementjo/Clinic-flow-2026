import { useState, type FormEvent } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useT } from '../lib/i18n';
import { api } from '../lib/api';
import type { AccountRow } from '../lib/accounts';
import {
  CreateRecordDrawer,
  FormSection,
  TextField,
  SelectField,
  TextAreaField,
  TagsField,
  useFormOptions,
  useEmployees,
  INDUSTRY_SUGGESTIONS,
  COUNTRY_SUGGESTIONS,
  textOrUndefined,
} from './CreateRecordDrawer';

const accountsKey = ['accounts'] as const;

interface CreateCompanyDrawerProps {
  open: boolean;
  onClose: () => void;
}

const emptyForm = {
  name: '',
  companyType: '',
  industry: '',
  website: '',
  size: '',
  phone: '',
  email: '',
  linkedin: '',
  country: '',
  city: '',
  address: '',
  postalCode: '',
  description: '',
  ownerId: '',
  accountStatus: '',
  leadSource: '',
  priority: '',
  notes: '',
} as const;

export function CreateCompanyDrawer({ open, onClose }: CreateCompanyDrawerProps) {
  const t = useT();
  const qc = useQueryClient();
  const opts = useFormOptions();
  const ownerOptions = (useEmployees().data ?? []).map((employee) => ({
    value: employee.userId,
    label: employee.fullName,
  }));

  const [form, setForm] = useState({ ...emptyForm, tags: [] as string[] });
  const set = (field: keyof typeof emptyForm) => (e: { target: { value: string } }) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const reset = () => setForm({ ...emptyForm, tags: [] });

  const create = useMutation({
    mutationFn: () =>
      api.post<AccountRow>('/accounts', {
        name: form.name.trim(),
        companyType: textOrUndefined(form.companyType),
        industry: textOrUndefined(form.industry),
        website: textOrUndefined(form.website),
        size: form.size || undefined,
        phone: textOrUndefined(form.phone),
        email: textOrUndefined(form.email),
        linkedin: textOrUndefined(form.linkedin),
        country: textOrUndefined(form.country),
        city: textOrUndefined(form.city),
        address: textOrUndefined(form.address),
        postalCode: textOrUndefined(form.postalCode),
        description: textOrUndefined(form.description),
        ownerId: form.ownerId || undefined,
        status: form.accountStatus || undefined,
        leadSource: form.leadSource || undefined,
        priority: form.priority || undefined,
        tags: form.tags,
        notes: textOrUndefined(form.notes),
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: accountsKey });
      reset();
      onClose();
    },
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (form.name.trim()) create.mutate();
  };

  const close = () => {
    reset();
    onClose();
  };

  const nameProps = {
    value: form.name,
    onChange: set('name'),
  };

  return (
    <CreateRecordDrawer
      open={open}
      onClose={close}
      title={t('form.company.title')}
      description={t('form.company.about')}
      submitLabel={t('form.company.save')}
      isSubmitting={create.isPending}
      canSubmit={Boolean(form.name.trim())}
      onSubmit={onSubmit}
    >
      <FormSection title={t('form.section.companyInfo')}>
        <TextField label={t('form.field.name')} required autoFocus placeholder="…" {...nameProps} />
        <TextField
          label={t('form.field.industry')}
          list="industry-suggestions"
          placeholder="…"
          value={form.industry}
          onChange={set('industry')}
        />
        <SelectField
          label={t('form.field.companyType')}
          placeholder="—"
          options={opts.companyTypes}
          value={form.companyType}
          onChange={set('companyType')}
        />
        <TextField
          label={t('form.field.website')}
          type="url"
          dir="ltr"
          placeholder="https://"
          value={form.website}
          onChange={set('website')}
        />
        <SelectField
          label={t('form.field.companySize')}
          placeholder="—"
          options={opts.sizes}
          value={form.size}
          onChange={set('size')}
        />
        <TextAreaField label={t('form.field.description')} wide value={form.description} onChange={set('description')} />
      </FormSection>

      <FormSection title={t('form.section.contactInfo')}>
        <TextField label={t('form.field.phone')} dir="ltr" placeholder="+" value={form.phone} onChange={set('phone')} />
        <TextField label={t('form.field.email')} type="email" dir="ltr" value={form.email} onChange={set('email')} />
        <TextField label={t('form.field.linkedin')} dir="ltr" placeholder="linkedin.com/in/" value={form.linkedin} onChange={set('linkedin')} />
      </FormSection>

      <FormSection title={t('form.section.location')}>
        <TextField
          label={t('form.field.country')}
          list="country-suggestions"
          placeholder="…"
          value={form.country}
          onChange={set('country')}
        />
        <TextField label={t('form.field.city')} placeholder="…" value={form.city} onChange={set('city')} />
        <TextField label={t('form.field.address')} placeholder="…" value={form.address} onChange={set('address')} />
        <TextField label={t('form.field.postalCode')} dir="ltr" value={form.postalCode} onChange={set('postalCode')} />
      </FormSection>

      <FormSection title={t('form.section.crm')}>
        <SelectField label={t('form.field.owner')} placeholder="—" options={ownerOptions} value={form.ownerId} onChange={set('ownerId')} />
        <SelectField label={t('form.field.status')} placeholder="—" options={opts.accountStatuses} value={form.accountStatus} onChange={set('accountStatus')} />
        <SelectField label={t('form.field.leadSource')} placeholder="—" options={opts.leadSources} value={form.leadSource} onChange={set('leadSource')} />
        <SelectField label={t('form.field.priority')} placeholder="—" options={opts.priorities} value={form.priority} onChange={set('priority')} />
        <TagsField label={t('form.field.tags')} value={form.tags} onChange={(tags) => setForm((prev) => ({ ...prev, tags }))} placeholder={t('form.field.tagsAdd')} />
        <TextAreaField label={t('form.field.notes')} wide value={form.notes} onChange={set('notes')} />
      </FormSection>

      <datalist id="industry-suggestions">
        {INDUSTRY_SUGGESTIONS.map((suggestion) => (
          <option key={suggestion} value={suggestion} />
        ))}
      </datalist>
      <datalist id="country-suggestions">
        {COUNTRY_SUGGESTIONS.map((suggestion) => (
          <option key={suggestion} value={suggestion} />
        ))}
      </datalist>
    </CreateRecordDrawer>
  );
}