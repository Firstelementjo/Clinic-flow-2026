import { Module } from '@nestjs/common';
import { KnowledgeController } from './knowledge.controller';
import { KnowledgeService } from './knowledge.service';
import { KnowledgeQueueService } from './knowledge-queue.service';
import {
  EmbeddingProviderHolder,
  IngestionPipelineProvider,
  KnowledgeRetrieverProvider,
  StorageDriverHolder,
} from './knowledge.providers';

@Module({
  controllers: [KnowledgeController],
  providers: [
    EmbeddingProviderHolder,
    StorageDriverHolder,
    KnowledgeRetrieverProvider,
    IngestionPipelineProvider,
    KnowledgeQueueService,
    KnowledgeService,
  ],
  // Slice 5's AI orchestrator retrieves through the same retriever.
  exports: [KnowledgeRetrieverProvider, EmbeddingProviderHolder],
})
export class KnowledgeModule {}
