import type {
  ChannelType,
  ConversationMode,
  ConversationPriority,
  ConversationStatus,
  MessageAuthorType,
  MessageDirection,
} from '@firstelement/shared';

/**
 * Domain events (plan §8b).
 *
 * This system is event-heavy — a message arrives, a score changes, an
 * escalation fires, an employee is assigned — and the modules that react
 * (routing, notifications, analytics, audit, realtime) must not be called
 * synchronously from inside the AI orchestrator or the scoring engine.
 * They subscribe here instead.
 *
 * The package is framework-neutral on purpose: it defines the vocabulary
 * and the envelope, while the API supplies the transport (EventEmitter2
 * today; the shape does not change if that ever becomes a broker).
 */

export const DomainEventType = {
  CONVERSATION_CREATED: 'conversation.created',
  CONVERSATION_UPDATED: 'conversation.updated',
  CONVERSATION_ASSIGNED: 'conversation.assigned',
  CONVERSATION_RESOLVED: 'conversation.resolved',
  CONVERSATION_ESCALATED: 'conversation.escalated',
  CONVERSATION_MODE_CHANGED: 'conversation.mode-changed',
  CONVERSATION_SCORED: 'conversation.scored',
  MESSAGE_CREATED: 'message.created',
  CUSTOMER_CREATED: 'customer.created',
  CUSTOMER_UPDATED: 'customer.updated',
  EMPLOYEE_AVAILABILITY_CHANGED: 'employee.availability.changed',
} as const;
export type DomainEventType = (typeof DomainEventType)[keyof typeof DomainEventType];

/** Every event carries its tenant, so subscribers never have to re-resolve it. */
export interface DomainEventEnvelope<TType extends DomainEventType, TPayload> {
  type: TType;
  organizationId: string;
  projectId: string;
  aggregateId: string;
  aggregateType: 'Conversation' | 'Message' | 'Customer' | 'Employee';
  payload: TPayload;
  occurredAt: Date;
  /** Who caused it. Absent for system-initiated events. */
  actorUserId?: string;
}

export type ConversationCreatedEvent = DomainEventEnvelope<
  typeof DomainEventType.CONVERSATION_CREATED,
  { customerId: string; channel: ChannelType; mode: ConversationMode }
>;

export type ConversationUpdatedEvent = DomainEventEnvelope<
  typeof DomainEventType.CONVERSATION_UPDATED,
  {
    status?: ConversationStatus;
    priority?: ConversationPriority;
    previousStatus?: ConversationStatus;
  }
>;

export type ConversationAssignedEvent = DomainEventEnvelope<
  typeof DomainEventType.CONVERSATION_ASSIGNED,
  { employeeId: string | null; previousEmployeeId: string | null; reason: 'MANUAL' | 'ROUTING' }
>;

export type ConversationResolvedEvent = DomainEventEnvelope<
  typeof DomainEventType.CONVERSATION_RESOLVED,
  { resolvedBy: MessageAuthorType; messageCount: number }
>;

export type ConversationModeChangedEvent = DomainEventEnvelope<
  typeof DomainEventType.CONVERSATION_MODE_CHANGED,
  { from: ConversationMode; to: ConversationMode; reason: string }
>;

export type ConversationScoredEvent = DomainEventEnvelope<
  typeof DomainEventType.CONVERSATION_SCORED,
  {
    frustration: number;
    sentiment: number;
    urgency: number;
    risk: number;
    intent: string | null;
    evaluator: string;
  }
>;

export type ConversationEscalatedEvent = DomainEventEnvelope<
  typeof DomainEventType.CONVERSATION_ESCALATED,
  {
    escalationId: string;
    trigger: string;
    reason: string;
    intent: string | null;
    department: string | null;
    frustration: number | null;
  }
>;

export type MessageCreatedEvent = DomainEventEnvelope<
  typeof DomainEventType.MESSAGE_CREATED,
  {
    conversationId: string;
    customerId: string;
    channel: ChannelType;
    direction: MessageDirection;
    authorType: MessageAuthorType;
    /** Length only — message content never travels on the event bus. */
    bodyLength: number;
  }
>;

export type CustomerCreatedEvent = DomainEventEnvelope<
  typeof DomainEventType.CUSTOMER_CREATED,
  { channel: ChannelType; externalId: string | null }
>;

export type DomainEvent =
  | ConversationCreatedEvent
  | ConversationUpdatedEvent
  | ConversationAssignedEvent
  | ConversationResolvedEvent
  | ConversationModeChangedEvent
  | ConversationScoredEvent
  | ConversationEscalatedEvent
  | MessageCreatedEvent
  | CustomerCreatedEvent;

export interface DomainEventPublisher {
  publish(event: DomainEvent): void;
}

/** Narrowing helper for subscribers that listen on a wildcard. */
export function isEventOfType<T extends DomainEvent['type']>(
  event: DomainEvent,
  type: T,
): event is Extract<DomainEvent, { type: T }> {
  return event.type === type;
}
