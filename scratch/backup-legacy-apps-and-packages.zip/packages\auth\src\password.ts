import bcrypt from 'bcryptjs';

const COST = 12;

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, COST);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

/**
 * A bcrypt hash of a value nobody knows, used to keep the failed-login path
 * as expensive as the successful one. Without it, "unknown email" returns
 * measurably faster than "wrong password" and the login endpoint becomes a
 * user-enumeration oracle.
 */
export const DUMMY_PASSWORD_HASH =
  '$2a$12$C6UzMDM.H6dfI/f/IKcEe.5vHZm9O7DkfHRzD1zZLM3wDW8Xn9Wia';

export async function burnPasswordComparison(): Promise<void> {
  await bcrypt.compare('not-the-password', DUMMY_PASSWORD_HASH);
}
