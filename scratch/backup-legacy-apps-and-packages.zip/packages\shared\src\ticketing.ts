/**
 * Ticket number format: #MMDDXXXXXXXXX (13 digits, 14 chars with #)
 *   - First 4: MMDD (month + day)
 *   - Last 9:  unique sequence, zero-padded
 *
 * CX ID format: #33XXXXXX (8 digits, 9 chars with #)
 *   - Prefix: 33
 *   - Last 6:  unique sequence
 */

const TICKET_PREFIX = '#';
const CX_PREFIX = '#33';

/**
 * Generate a ticket number for a given date + sequence.
 * seq should be unique per day (1-based).
 */
export function generateTicketNumber(date: Date, seq: number): string {
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  const s = String(seq).padStart(9, '0');
  return `${TICKET_PREFIX}${mm}${dd}${s}`;
}

/**
 * Generate a CX ID from a sequence (0-based).
 */
export function generateCxId(seq: number): string {
  const s = String(seq).padStart(6, '0');
  return `${CX_PREFIX}${s}`;
}

/**
 * Find the next available ticket number for a date in the database.
 * Counts existing tickets created on that date and returns the next sequence.
 */
export async function nextTicketSequence(
  prisma: { conversation: { count: (args: { where: { createdAt: { gte: Date; lt: Date } } }) => Promise<number> } },
  date: Date,
): Promise<number> {
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(startOfDay);
  endOfDay.setDate(endOfDay.getDate() + 1);

  const count = await prisma.conversation.count({
    where: { createdAt: { gte: startOfDay, lt: endOfDay } },
  });
  return count + 1;
}

/**
 * Find the next available CX ID sequence by counting existing customers.
 */
export async function nextCxSequence(
  prisma: { customer: { count: () => Promise<number> } },
): Promise<number> {
  const count = await prisma.customer.count();
  return count;
}
