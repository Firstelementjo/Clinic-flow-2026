import { randomUUID } from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import type { SessionUser } from '@firstelement/shared';
import type { TenantContext } from '@firstelement/database';

declare module 'express-serve-static-core' {
  interface Request {
    requestId: string;
    /** Populated by AuthGuard. Absent on public routes. */
    sessionUser?: SessionUser;
    tenant?: TenantContext;
    sessionId?: string;
  }
}

/**
 * Correlation id for every request (plan §11). It is echoed in the
 * `x-request-id` response header and attached to structured logs and
 * error bodies, so a support report ("I got an error at 14:02") maps to
 * exact log lines without guessing.
 */
export function requestContextMiddleware(req: Request, res: Response, next: NextFunction): void {
  const incoming = req.header('x-request-id');
  req.requestId = incoming && /^[\w-]{8,64}$/.test(incoming) ? incoming : randomUUID();
  res.setHeader('x-request-id', req.requestId);
  next();
}
