import { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Stethoscope,
  Clock,
  Calendar,
  Plus,
  Search,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Sparkles,
  Edit2,
  Trash2,
  Activity,
  Layers,
  CalendarDays,
  ShieldCheck,
  UserCheck,
  ChevronRight,
  Flame,
  Check,
} from 'lucide-react';
import { Button, Spinner, useDirection } from '@firstelement/ui';
import { api } from '../lib/api';
import { useT } from '../lib/i18n';
import {
  CreateRecordDrawer,
  FormSection,
  TextField,
  SelectField,
  textOrUndefined,
} from '../components/CreateRecordDrawer';

export interface ManagedDoctor {
  id: string;
  name: string;
  specialty: string;
  department?: string | null;
  email?: string | null;
  phone?: string | null;
  workingDays: number[];
  startHour: string;
  endHour: string;
  slotDuration: number;
  isActive: boolean;
  appointmentCount?: number;
}

export interface ManagedProcedure {
  id: string;
  name: string;
  specialty: string;
  durationMinutes: number;
  bufferMinutes: number;
  price?: number | null;
  isActive: boolean;
  appointmentCount?: number;
}

const DAY_LABELS: { day: number; en: string; ar: string; shortEn: string; shortAr: string }[] = [
  { day: 0, en: 'Sunday', ar: 'الأحد', shortEn: 'Sun', shortAr: 'أحد' },
  { day: 1, en: 'Monday', ar: 'الإثنين', shortEn: 'Mon', shortAr: 'إثنين' },
  { day: 2, en: 'Tuesday', ar: 'الثلاثاء', shortEn: 'Tue', shortAr: 'ثلاثاء' },
  { day: 3, en: 'Wednesday', ar: 'الأربعاء', shortEn: 'Wed', shortAr: 'أربعاء' },
  { day: 4, en: 'Thursday', ar: 'الخميس', shortEn: 'Thu', shortAr: 'خميس' },
  { day: 5, en: 'Friday', ar: 'الجمعة', shortEn: 'Fri', shortAr: 'جمعة' },
  { day: 6, en: 'Saturday', ar: 'السبت', shortEn: 'Sat', shortAr: 'سبت' },
];

const SPECIALTY_OPTIONS = [
  'Dentistry',
  'Dermatology',
  'General Medicine',
  'Pediatrics',
  'Cardiology',
  'Orthopedics',
  'Ophthalmology',
];

const SLOT_DURATIONS = [15, 20, 30, 45, 60];

const HOURS_GRID = [
  '08:00',
  '09:00',
  '10:00',
  '11:00',
  '12:00',
  '13:00',
  '14:00',
  '15:00',
  '16:00',
  '17:00',
  '18:00',
];

export function DoctorSchedulesPage() {
  const t = useT();
  const { locale } = useDirection();
  const isAr = locale === 'ar';
  const qc = useQueryClient();

  // Active Tab
  const [activeTab, setActiveTab] = useState<'SHIFTS' | 'HEATMAP' | 'PROCEDURES'>('SHIFTS');
  const [search, setSearch] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('ALL');

  // Drawer states
  const [doctorDrawerOpen, setDoctorDrawerOpen] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState<ManagedDoctor | null>(null);

  const [procedureDrawerOpen, setProcedureDrawerOpen] = useState(false);
  const [editingProcedure, setEditingProcedure] = useState<ManagedProcedure | null>(null);

  // Queries
  const doctorsQuery = useQuery({
    queryKey: ['clinic', 'doctors', 'manage'],
    queryFn: () => api.get<ManagedDoctor[]>('/clinic/doctors/manage'),
  });

  const proceduresQuery = useQuery({
    queryKey: ['clinic', 'procedures', 'manage'],
    queryFn: () => api.get<ManagedProcedure[]>('/clinic/procedures/manage'),
  });

  const doctors = doctorsQuery.data || [];
  const procedures = proceduresQuery.data || [];

  // Mutations
  const updateDoctorMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<ManagedDoctor> }) =>
      api.patch(`/clinic/doctors/${id}`, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clinic', 'doctors'] });
    },
  });

  const deleteDoctorMutation = useMutation({
    mutationFn: (id: string) => api.delete(`/clinic/doctors/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clinic', 'doctors'] });
    },
  });

  const updateProcedureMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<ManagedProcedure> }) =>
      api.patch(`/clinic/procedures/${id}`, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clinic', 'procedures'] });
    },
  });

  const deleteProcedureMutation = useMutation({
    mutationFn: (id: string) => api.delete(`/clinic/procedures/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clinic', 'procedures'] });
    },
  });

  // Filtered lists
  const filteredDoctors = useMemo(() => {
    return doctors.filter((doc) => {
      const matchSearch =
        search === '' ||
        doc.name.toLowerCase().includes(search.toLowerCase()) ||
        doc.specialty.toLowerCase().includes(search.toLowerCase()) ||
        (doc.department && doc.department.toLowerCase().includes(search.toLowerCase()));
      const matchSpecialty = selectedSpecialty === 'ALL' || doc.specialty === selectedSpecialty;
      return matchSearch && matchSpecialty;
    });
  }, [doctors, search, selectedSpecialty]);

  const filteredProcedures = useMemo(() => {
    return procedures.filter((proc) => {
      const matchSearch =
        search === '' ||
        proc.name.toLowerCase().includes(search.toLowerCase()) ||
        proc.specialty.toLowerCase().includes(search.toLowerCase());
      const matchSpecialty = selectedSpecialty === 'ALL' || proc.specialty === selectedSpecialty;
      return matchSearch && matchSpecialty;
    });
  }, [procedures, search, selectedSpecialty]);

  // High-level statistics
  const stats = useMemo(() => {
    const activeDocs = doctors.filter((d) => d.isActive).length;
    let totalWeeklyHours = 0;
    doctors.forEach((d) => {
      if (!d.isActive) return;
      const startH = parseInt(d.startHour.split(':')[0] || '9', 10);
      const endH = parseInt(d.endHour.split(':')[0] || '17', 10);
      const hoursPerDay = Math.max(0, endH - startH);
      totalWeeklyHours += hoursPerDay * (d.workingDays?.length || 5);
    });

    const avgSlot =
      doctors.length > 0
        ? Math.round(doctors.reduce((acc, d) => acc + (d.slotDuration || 30), 0) / doctors.length)
        : 30;

    const activeProcs = procedures.filter((p) => p.isActive).length;

    return {
      activeDocs,
      totalDocs: doctors.length,
      totalWeeklyHours,
      avgSlot,
      activeProcs,
      totalProcs: procedures.length,
    };
  }, [doctors, procedures]);

  // Toggle doctor working day inline
  const handleToggleDay = (doc: ManagedDoctor, dayNum: number) => {
    const current = [...(doc.workingDays || [])];
    const exists = current.includes(dayNum);
    const updated = exists ? current.filter((d) => d !== dayNum) : [...current, dayNum].sort();
    updateDoctorMutation.mutate({ id: doc.id, data: { workingDays: updated } });
  };

  // Toggle doctor slot duration inline
  const handleSlotDurationChange = (doc: ManagedDoctor, duration: number) => {
    updateDoctorMutation.mutate({ id: doc.id, data: { slotDuration: duration } });
  };

  // Toggle doctor active inline
  const handleToggleActive = (doc: ManagedDoctor) => {
    updateDoctorMutation.mutate({ id: doc.id, data: { isActive: !doc.isActive } });
  };

  // Toggle procedure active inline
  const handleToggleProcedureActive = (proc: ManagedProcedure) => {
    updateProcedureMutation.mutate({ id: proc.id, data: { isActive: !proc.isActive } });
  };

  // Quick procedure duration change inline
  const handleProcedureDurationChange = (proc: ManagedProcedure, duration: number) => {
    updateProcedureMutation.mutate({ id: proc.id, data: { durationMinutes: duration } });
  };

  // Current day index
  const todayDay = new Date().getDay();

  return (
    <div className="flex h-full flex-col overflow-y-auto">
      {/* Header Banner */}
      <div className="ph">
        <div>
          <h2>{t('doctors.title')}</h2>
          <p>{t('doctors.subtitle')}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 ms-auto">
          <Button
            variant="secondary"
            onClick={() => {
              setEditingProcedure(null);
              setProcedureDrawerOpen(true);
            }}
          >
            {t('doctors.addProcedure')}
          </Button>

          <Button
            variant="primary"
            onClick={() => {
              setEditingDoctor(null);
              setDoctorDrawerOpen(true);
            }}
          >
            {t('doctors.addDoctor')}
          </Button>
        </div>
      </div>

      {/* High-level Metric Cards */}
      <div className="grid-ds g5 p-[40px]">
        {/* Metric 1 */}
        <div className="kpi">
          <div className="sub">{t('doctors.stat.activeDoctors')}</div>
          <div className="v">{stats.activeDocs} <span className="sub" style={{ fontSize: '14px', fontWeight: 'normal' }}>/ {stats.totalDocs} {isAr ? 'طبيب' : 'doctors'}</span></div>
        </div>

        {/* Metric 2 */}
        <div className="kpi">
          <div className="sub">{t('doctors.stat.totalHours')}</div>
          <div className="v">{stats.totalWeeklyHours}h <span className="sub" style={{ fontSize: '14px', fontWeight: 'normal' }}>{isAr ? 'ساعة / أسبوع' : 'hours / week'}</span></div>
        </div>

        {/* Metric 3 */}
        <div className="kpi">
          <div className="sub">{t('doctors.stat.avgSlot')}</div>
          <div className="v">{stats.avgSlot} <span className="sub" style={{ fontSize: '14px', fontWeight: 'normal' }}>{isAr ? 'دقيقة / جلسة' : 'min standard'}</span></div>
        </div>

        {/* Metric 4 */}
        <div className="kpi">
          <div className="sub">{t('doctors.stat.totalProcedures')}</div>
          <div className="v">{stats.activeProcs} <span className="sub" style={{ fontSize: '14px', fontWeight: 'normal' }}>/ {stats.totalProcs} {isAr ? 'إجراء متاح' : 'services'}</span></div>
        </div>
      </div>

      {/* Tabs Navigation & Search Toolbar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between px-[40px] pb-[20px]">
        {/* Tabs */}
        <div className="seg">
          <button
            type="button"
            onClick={() => setActiveTab('SHIFTS')}
            className={activeTab === 'SHIFTS' ? 'on' : ''}
          >
            {t('doctors.tab.shifts')} ({doctors.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('HEATMAP')}
            className={activeTab === 'HEATMAP' ? 'on' : ''}
          >
            {t('doctors.tab.heatmap')}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('PROCEDURES')}
            className={activeTab === 'PROCEDURES' ? 'on' : ''}
          >
            {t('doctors.tab.procedures')} ({procedures.length})
          </button>
        </div>

        {/* Search & Specialty Filter */}
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <Search className="absolute start-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-soft" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={isAr ? 'بحث بالاسم أو التخصص...' : 'Search doctor or procedure...'}
              className="h-8.5 w-48 sm:w-60 rounded-lg border border-hairline bg-surface ps-8 pe-3 text-xs text-ink placeholder:text-slate-soft focus:border-signal focus:outline-none"
            />
          </div>

          <select
            value={selectedSpecialty}
            onChange={(e) => setSelectedSpecialty(e.target.value)}
            className="h-8.5 rounded-lg border border-hairline bg-surface px-2.5 text-xs text-ink focus:border-signal focus:outline-none"
          >
            <option value="ALL">{isAr ? 'كافة التخصصات' : 'All Specialties'}</option>
            {SPECIALTY_OPTIONS.map((spec) => (
              <option key={spec} value={spec}>
                {spec}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Tab Content Area */}
      <div className="mt-6 flex-1">
        {doctorsQuery.isLoading || proceduresQuery.isLoading ? (
          <div className="flex h-64 items-center justify-center card">
            <Spinner label={t('common.loading')} />
          </div>
        ) : doctorsQuery.isError || proceduresQuery.isError ? (
          <div className="card p-8 text-center text-sm text-[var(--fe-danger)]">
            {t('common.error')}
          </div>
        ) : (
          <>
            {activeTab === 'SHIFTS' && (
              <div className="card overflow-hidden">
                {filteredDoctors.length === 0 ? (
                  <div className="p-[40px] text-center">
                    <h3 className="mt-2 text-sm font-semibold text-[var(--fe-ink)]">
                      {isAr ? 'لا يوجد أطباء مطابقين' : 'No doctors found'}
                    </h3>
                    <p className="mt-1 text-xs text-[var(--fe-slate)]">
                      {isAr ? 'جرّب تعديل معايير البحث أو أضف طبيباً جديداً' : 'Try adjusting filters or add a new clinician.'}
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col">
                    {filteredDoctors.map((doc, idx) => {
                      const startH = parseInt(doc.startHour.split(':')[0] || '9', 10);
                      const endH = parseInt(doc.endHour.split(':')[0] || '17', 10);
                      const hoursDuration = Math.max(0, endH - startH);
                      const isLast = idx === filteredDoctors.length - 1;

                      return (
                        <div
                          key={doc.id}
                          className={`flex flex-col gap-4 p-4 hover:bg-[var(--fe-surf2)] ${!isLast ? 'border-b border-[var(--fe-hairline)]' : ''} ${!doc.isActive ? 'opacity-75 bg-[var(--fe-surf2)]' : ''}`}
                        >
                          {/* Row Header: Avatar & Info & Toggles */}
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-[var(--fe-mist-deep)] text-sm font-bold text-[var(--fe-ink)]">
                                {doc.name.replace('Dr. ', '').substring(0, 2).toUpperCase()}
                                {doc.isActive && (
                                  <span className="absolute -bottom-1 -right-1 flex h-3 w-3 items-center justify-center rounded-full bg-[var(--fe-surface)]">
                                    <span className="h-2 w-2 rounded-full bg-green-500" />
                                  </span>
                                )}
                              </div>
                              <div>
                                <h3 className="text-[14px] font-bold text-[var(--fe-ink)]">
                                  {doc.name}
                                </h3>
                                <div className="mt-1 flex flex-wrap items-center gap-2">
                                  <span className="text-[12px] font-medium text-[var(--fe-agent)]">
                                    {doc.specialty}
                                  </span>
                                  {doc.department && (
                                    <span className="text-[12px] text-[var(--fe-slate)]">
                                      {doc.department}
                                    </span>
                                  )}
                                  <span className="text-[12px] text-[var(--fe-slate)]">
                                    • {doc.appointmentCount || 0} {isAr ? 'مواعيد مسجلة' : 'appts'}
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-3">
                              {/* Edit / Delete */}
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingDoctor(doc);
                                  setDoctorDrawerOpen(true);
                                }}
                                className="text-[12px] font-medium text-[var(--fe-ink)] hover:underline"
                              >
                                {isAr ? 'تعديل' : 'Edit'}
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(isAr ? `هل أنت متأكد من حذف الطبيب ${doc.name}؟` : `Are you sure you want to delete ${doc.name}?`)) {
                                    deleteDoctorMutation.mutate(doc.id);
                                  }
                                }}
                                className="text-[12px] font-medium text-[var(--fe-danger)] hover:underline"
                              >
                                {isAr ? 'حذف' : 'Delete'}
                              </button>

                              {/* Active Switch */}
                              <button
                                type="button"
                                onClick={() => handleToggleActive(doc)}
                                className={`ml-4 relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full transition-colors duration-200 ease-in-out ${
                                  doc.isActive ? 'bg-[var(--fe-agent)]' : 'bg-[var(--fe-hairline)]'
                                }`}
                              >
                                <span
                                  className={`pointer-events-none inline-block h-4 w-4 mt-[2px] transform rounded-full bg-white transition duration-200 ease-in-out ${
                                    doc.isActive ? (isAr ? '-translate-x-4 ml-[2px]' : 'translate-x-4 ml-[2px]') : 'translate-x-0 ml-[2px]'
                                  }`}
                                />
                              </button>
                            </div>
                          </div>

                          {/* Schedules & Duration */}
                          <div className="flex flex-col sm:flex-row sm:items-center gap-6 mt-1">
                            <div className="flex flex-col gap-1">
                              <span className="text-[11px] font-medium text-[var(--fe-slate)]">Shift Hours</span>
                              <span className="text-[13px] font-medium text-[var(--fe-ink)]">{doc.startHour} — {doc.endHour}</span>
                            </div>
                            
                            <div className="flex flex-col gap-1">
                              <span className="text-[11px] font-medium text-[var(--fe-slate)]">Slot Duration</span>
                              <div className="flex items-center gap-1">
                                {SLOT_DURATIONS.map((dur) => (
                                  <button
                                    key={dur}
                                    type="button"
                                    onClick={() => handleSlotDurationChange(doc, dur)}
                                    className={`rounded px-1.5 py-0.5 text-[11px] font-medium transition ${
                                      doc.slotDuration === dur
                                        ? 'bg-[var(--fe-ink)] text-[var(--fe-surface)]'
                                        : 'bg-[var(--fe-surface)] border border-[var(--fe-hairline)] text-[var(--fe-slate)] hover:text-[var(--fe-ink)]'
                                    }`}
                                  >
                                    {dur}m
                                  </button>
                                ))}
                              </div>
                            </div>

                            <div className="flex flex-col gap-1 sm:ml-auto">
                              <span className="text-[11px] font-medium text-[var(--fe-slate)] text-right">Shift Days</span>
                              <div className="flex items-center gap-1">
                                {DAY_LABELS.map((d) => {
                                  const isSelected = (doc.workingDays || []).includes(d.day);
                                  const isToday = todayDay === d.day;
                                  return (
                                    <button
                                      key={d.day}
                                      type="button"
                                      onClick={() => handleToggleDay(doc, d.day)}
                                      className={`flex items-center justify-center rounded w-7 h-7 text-[11px] font-bold transition ${
                                        isSelected
                                          ? 'bg-[var(--fe-agent)] text-[var(--fe-surface)]'
                                          : 'bg-[var(--fe-surface)] border border-[var(--fe-hairline)] text-[var(--fe-slate)] hover:bg-[var(--fe-surf2)]'
                                      } ${isToday ? 'ring-1 ring-[var(--fe-ink)]' : ''}`}
                                    >
                                      {isAr ? d.shortAr : d.shortEn}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}


            {/* TAB 2: WEEKLY COVERAGE GRID (HEATMAP) */}
            {activeTab === 'HEATMAP' && (
              <div className="rounded-2xl border border-hairline bg-surface p-5 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-hairline gap-2">
                  <div>
                    <h3 className="text-base font-bold text-ink flex items-center gap-2">
                      <CalendarDays className="h-4 w-4 text-agent" />
                      {isAr ? 'مصفوفة التغطية الطبية والورديات' : 'Weekly Clinician Coverage Grid'}
                    </h3>
                    <p className="mt-0.5 text-xs text-slate-soft">
                      {isAr
                        ? 'نظرة شمولية على الأطباء المتاحين في كل ساعة من أيام الأسبوع'
                        : 'Overview of scheduled doctors across each working hour of the week.'}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-2xs text-slate-soft">
                    <span className="flex items-center gap-1">
                      <span className="h-2.5 w-2.5 rounded-sm bg-agent-wash0" />
                      {isAr ? 'تغطية متوفرة' : 'Clinician On Duty'}
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="h-2.5 w-2.5 rounded-sm bg-surface-muted border border-hairline" />
                      {isAr ? 'مغلق / لا أطباء' : 'Clinic Off / No Clinician'}
                    </span>
                  </div>
                </div>

                {/* The 7-Day Matrix */}
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full min-w-[700px] border-collapse text-xs">
                    <thead>
                      <tr>
                        <th className="border-b border-hairline py-3 ps-3 pe-4 text-start font-bold text-slate-soft w-20">
                          {isAr ? 'الساعة' : 'Hour'}
                        </th>
                        {DAY_LABELS.map((d) => {
                          const isToday = todayDay === d.day;
                          return (
                            <th
                              key={d.day}
                              className={`border-b border-hairline py-3 px-2 text-center font-bold ${
                                isToday
                                  ? 'bg-agent-wash text-agent rounded-t-lg'
                                  : 'text-ink'
                              }`}
                            >
                              <div className="text-xs">{isAr ? d.ar : d.en}</div>
                              {isToday && (
                                <span className="inline-block mt-0.5 text-2xs text-agent font-normal">
                                  {isAr ? 'اليوم' : 'Today'}
                                </span>
                              )}
                            </th>
                          );
                        })}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-hairline">
                      {HOURS_GRID.map((hourStr) => {
                        const currentHourInt = parseInt(hourStr.split(':')[0] || '8', 10);

                        return (
                          <tr key={hourStr} className="hover:bg-surface-muted/20 transition-colors">
                            <td className="py-2.5 ps-3 pe-4 font-mono font-semibold text-slate-soft">
                              {hourStr}
                            </td>
                            {DAY_LABELS.map((d) => {
                              const isToday = todayDay === d.day;
                              // Find all doctors on duty this day and hour
                              const doctorsOnDuty = doctors.filter((doc) => {
                                if (!doc.isActive) return false;
                                if (!doc.workingDays.includes(d.day)) return false;
                                const docStart = parseInt(doc.startHour.split(':')[0] || '9', 10);
                                const docEnd = parseInt(doc.endHour.split(':')[0] || '17', 10);
                                return currentHourInt >= docStart && currentHourInt < docEnd;
                              });

                              return (
                                <td
                                  key={d.day}
                                  className={`p-1.5 text-center align-top ${
                                    isToday ? 'bg-agent-wash0/5' : ''
                                  }`}
                                >
                                  {doctorsOnDuty.length === 0 ? (
                                    <div className="h-9 rounded-lg border border-dashed border-hairline/60 bg-surface-muted/10 flex items-center justify-center text-3xs text-slate-soft/50">
                                      —
                                    </div>
                                  ) : (
                                    <div className="flex flex-col gap-1">
                                      {doctorsOnDuty.map((doc) => (
                                        <div
                                          key={doc.id}
                                          className="flex items-center gap-1 rounded-md bg-agent-wash px-2 py-1 text-2xs font-semibold text-agent border border-agent shadow-2xs hover:bg-agent-wash transition"
                                          title={`${doc.name} (${doc.specialty})`}
                                        >
                                          <span className="h-1.5 w-1.5 rounded-full bg-agent-wash0 shrink-0" />
                                          <span className="truncate">{doc.name.replace('Dr. ', '')}</span>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Heatmap Insights Summary */}
                <div className="mt-5 rounded-xl bg-agent-wash p-3.5 border border-agent text-xs text-agent flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Flame className="h-4 w-4 text-agent" />
                    <span>
                      {isAr
                        ? 'ذروة التغطية الطبية: من 09:00 إلى 17:00 بتواجد كامل الكادر الطبي.'
                        : 'Peak clinical coverage: 09:00 to 17:00 with full multi-specialty roster available.'}
                    </span>
                  </div>
                  <span className="font-semibold text-agent text-2xs">
                    {stats.activeDocs} {isAr ? 'أطباء نشطين' : 'Active Clinicians'}
                  </span>
                </div>
              </div>
            )}

            {/* TAB 3: PROCEDURES & DURATIONS CATALOG */}
            {activeTab === 'PROCEDURES' && (
              <div className="card p-[18px]">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-[18px] border-b border-[var(--fe-hairline)] gap-2">
                  <div>
                    <h3 className="fe-display text-[var(--fe-ink)] text-lg">
                      {isAr ? 'كتالوج الإجراءات الطبية والمدد الزمنية' : 'Procedures & Durations Catalog'}
                    </h3>
                    <p className="sub mt-1">
                      {isAr
                        ? 'المدد الزمنية المعتمدة لكل إجراء تستخدم لحساب وحجز الفترات الزمنية الشاغرة لدى الأطباء'
                        : 'Procedure durations configure exact slot allocation during automated AI and staff bookings.'}
                    </p>
                  </div>

                  <Button
                    onClick={() => {
                      setEditingProcedure(null);
                      setProcedureDrawerOpen(true);
                    }}
                    variant="primary"
                  >
                    {t('doctors.addProcedure')}
                  </Button>
                </div>

                {filteredProcedures.length === 0 ? (
                  <div className="p-[40px] text-center">
                    <h3 className="mt-2 text-sm font-semibold text-[var(--fe-ink)]">
                      {isAr ? 'لا توجد إجراءات طبية مسجلة' : 'No procedures found'}
                    </h3>
                    <p className="mt-1 text-xs text-[var(--fe-slate)]">
                      {isAr ? 'أضف أول إجراء طبي لتحديد مدته وسعره' : 'Add your first clinical procedure to configure duration.'}
                    </p>
                  </div>
                ) : (
                  <div className="table-responsive mt-[18px]">
                    <table className="fe-table w-full text-left">
                      <thead>
                        <tr>
                          <th>{isAr ? 'اسم الإجراء' : 'Procedure'}</th>
                          <th>{isAr ? 'التخصص' : 'Specialty'}</th>
                          <th>{isAr ? 'مدة الجلسة (دقيقة)' : 'Duration (mins)'}</th>
                          <th>{isAr ? 'فترة التعقيم والتحضير' : 'Buffer Turnaround'}</th>
                          <th>{isAr ? 'السعر التقديري' : 'Standard Price'}</th>
                          <th>{isAr ? 'الحجوزات' : 'Bookings'}</th>
                          <th>{isAr ? 'الحالة' : 'Status'}</th>
                          <th>{isAr ? 'إجراءات' : 'Actions'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredProcedures.map((proc) => (
                          <tr key={proc.id}>
                            {/* Name */}
                            <td className="font-semibold text-[var(--fe-ink)]">
                              {proc.name}
                            </td>

                            {/* Specialty */}
                            <td>
                              <span className="text-[12px] font-medium text-[var(--fe-agent)]">
                                {proc.specialty}
                              </span>
                            </td>

                            {/* Duration with Quick Selector */}
                            <td>
                              <div className="flex items-center gap-1">
                                {[15, 30, 45, 60, 90].map((mins) => (
                                  <button
                                    key={mins}
                                    type="button"
                                    onClick={() => handleProcedureDurationChange(proc, mins)}
                                    className={`rounded px-1.5 py-0.5 text-[11px] font-medium transition ${
                                      proc.durationMinutes === mins
                                        ? 'bg-[var(--fe-ink)] text-[var(--fe-surface)]'
                                        : 'bg-[var(--fe-surface)] border border-[var(--fe-hairline)] text-[var(--fe-slate)] hover:text-[var(--fe-ink)]'
                                    }`}
                                  >
                                    {mins}m
                                  </button>
                                ))}
                              </div>
                            </td>

                            {/* Buffer */}
                            <td className="text-[var(--fe-slate)]">
                              +{proc.bufferMinutes || 0} {isAr ? 'د' : 'min'}
                            </td>

                            {/* Price */}
                            <td className="font-mono font-semibold text-[var(--fe-ink)]">
                              {proc.price ? `${proc.price} SAR` : (isAr ? 'غير محدد' : 'N/A')}
                            </td>

                            {/* Bookings count */}
                            <td>
                              <span className="rounded-full bg-[var(--fe-mist-deep)] px-2 py-0.5 text-[11px] font-medium text-[var(--fe-slate)]">
                                {proc.appointmentCount || 0}
                              </span>
                            </td>

                            {/* Active Switch */}
                            <td>
                              <button
                                type="button"
                                onClick={() => handleToggleProcedureActive(proc)}
                                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full transition-colors duration-200 ease-in-out ${
                                  proc.isActive ? 'bg-[var(--fe-agent)]' : 'bg-[var(--fe-hairline)]'
                                }`}
                              >
                                <span
                                  className={`pointer-events-none inline-block h-4 w-4 mt-[2px] transform rounded-full bg-white transition duration-200 ease-in-out ${
                                    proc.isActive ? (isAr ? '-translate-x-4 ml-[2px]' : 'translate-x-4 ml-[2px]') : 'translate-x-0 ml-[2px]'
                                  }`}
                                />
                              </button>
                            </td>

                            {/* Actions */}
                            <td className="text-right">
                              <div className="flex items-center justify-end gap-3">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingProcedure(proc);
                                    setProcedureDrawerOpen(true);
                                  }}
                                  className="text-[12px] font-medium text-[var(--fe-ink)] hover:underline"
                                  title={isAr ? 'تعديل' : 'Edit'}
                                >
                                  {isAr ? 'تعديل' : 'Edit'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (confirm(isAr ? `هل أنت متأكد من حذف ${proc.name}؟` : `Are you sure you want to delete ${proc.name}?`)) {
                                      deleteProcedureMutation.mutate(proc.id);
                                    }
                                  }}
                                  className="text-[12px] font-medium text-[var(--fe-danger)] hover:underline"
                                  title={isAr ? 'حذف' : 'Delete'}
                                >
                                  {isAr ? 'حذف' : 'Delete'}
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* DOCTOR CREATE / EDIT DRAWER */}
      <DoctorFormDrawer
        open={doctorDrawerOpen}
        onClose={() => setDoctorDrawerOpen(false)}
        doctor={editingDoctor}
      />

      {/* PROCEDURE CREATE / EDIT DRAWER */}
      <ProcedureFormDrawer
        open={procedureDrawerOpen}
        onClose={() => setProcedureDrawerOpen(false)}
        procedure={editingProcedure}
      />
    </div>
  );
}

// ---------------------------------------------------------
// DOCTOR DRAWER COMPONENT
// ---------------------------------------------------------
function DoctorFormDrawer({
  open,
  onClose,
  doctor,
}: {
  open: boolean;
  onClose: () => void;
  doctor: ManagedDoctor | null;
}) {
  const t = useT();
  const qc = useQueryClient();
  const { locale } = useDirection();
  const isAr = locale === 'ar';

  const [name, setName] = useState('');
  const [specialty, setSpecialty] = useState('Dentistry');
  const [department, setDepartment] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [startHour, setStartHour] = useState('09:00');
  const [endHour, setEndHour] = useState('17:00');
  const [slotDuration, setSlotDuration] = useState(30);
  const [workingDays, setWorkingDays] = useState<number[]>([0, 1, 2, 3, 4]);

  // Sync initial state when doctor changes
  useMemo(() => {
    if (doctor) {
      setName(doctor.name || '');
      setSpecialty(doctor.specialty || 'Dentistry');
      setDepartment(doctor.department || '');
      setEmail(doctor.email || '');
      setPhone(doctor.phone || '');
      setStartHour(doctor.startHour || '09:00');
      setEndHour(doctor.endHour || '17:00');
      setSlotDuration(doctor.slotDuration || 30);
      setWorkingDays(doctor.workingDays || [0, 1, 2, 3, 4]);
    } else {
      setName('');
      setSpecialty('Dentistry');
      setDepartment('Dental Department');
      setEmail('');
      setPhone('');
      setStartHour('09:00');
      setEndHour('17:00');
      setSlotDuration(30);
      setWorkingDays([0, 1, 2, 3, 4]);
    }
  }, [doctor, open]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        name,
        specialty,
        department: textOrUndefined(department),
        email: textOrUndefined(email),
        phone: textOrUndefined(phone),
        startHour,
        endHour,
        slotDuration: Number(slotDuration),
        workingDays,
      };

      if (doctor) {
        return api.patch(`/clinic/doctors/${doctor.id}`, payload);
      } else {
        return api.post('/clinic/doctors', payload);
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clinic', 'doctors'] });
      onClose();
    },
  });

  const toggleDay = (day: number) => {
    if (workingDays.includes(day)) {
      setWorkingDays(workingDays.filter((d) => d !== day));
    } else {
      setWorkingDays([...workingDays, day].sort());
    }
  };

  return (
    <CreateRecordDrawer
      open={open}
      onClose={onClose}
      title={doctor ? (isAr ? 'تعديل بيانات الطبيب' : 'Edit Clinician') : (isAr ? 'إضافة طبيب جديد' : 'Add New Clinician')}
      description={
        isAr
          ? 'تحديد ساعات وأيام العمل التي يلتزم بها المساعد الذكي'
          : 'Define working hours and days strictly enforced by AI receptionist'
      }
      submitLabel={doctor ? (isAr ? 'حفظ التعديلات' : 'Save Changes') : (isAr ? 'إضافة الطبيب' : 'Create Clinician')}
      isSubmitting={saveMutation.isPending}
      canSubmit={name.trim().length > 0}
      onSubmit={(e) => {
        e.preventDefault();
        saveMutation.mutate();
      }}
    >
      <FormSection title={isAr ? 'البيانات الشخصية والمهنية' : 'Clinician Identity'}>
        <TextField
          label={isAr ? 'اسم الطبيب' : 'Doctor Name'}
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Dr. Ahmed Al-Otaibi"
          required
        />
        <SelectField
          label={isAr ? 'التخصص' : 'Specialty'}
          value={specialty}
          onChange={(e) => setSpecialty(e.target.value)}
          options={SPECIALTY_OPTIONS.map((s) => ({ value: s, label: s }))}
        />
        <TextField
          label={isAr ? 'القسم' : 'Department'}
          value={department}
          onChange={(e) => setDepartment(e.target.value)}
          placeholder="Dental Care"
        />
        <TextField
          label={isAr ? 'البريد الإلكتروني' : 'Email'}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="doctor@clinic.com"
          type="email"
        />
        <TextField
          label={isAr ? 'رقم الهاتف' : 'Phone'}
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          placeholder="+966 50 123 4567"
        />
      </FormSection>

      <FormSection title={isAr ? 'جدول المناوبات والوردية' : 'Shift & Hours'}>
        <div className="grid grid-cols-2 gap-3">
          <TextField
            label={isAr ? 'ساعة البدء' : 'Start Hour'}
            value={startHour}
            onChange={(e) => setStartHour(e.target.value)}
            placeholder="09:00"
          />
          <TextField
            label={isAr ? 'ساعة الانتهاء' : 'End Hour'}
            value={endHour}
            onChange={(e) => setEndHour(e.target.value)}
            placeholder="17:00"
          />
        </div>

        <div className="mt-2">
          <label className="block text-2xs font-medium uppercase tracking-wide text-slate-soft mb-1.5">
            {isAr ? 'مدة الجلسة الافتراضية (دقيقة)' : 'Default Slot Duration (mins)'}
          </label>
          <div className="grid grid-cols-5 gap-1.5">
            {SLOT_DURATIONS.map((dur) => (
              <button
                key={dur}
                type="button"
                onClick={() => setSlotDuration(dur)}
                className={`rounded-lg py-1.5 text-xs font-bold transition ${
                  slotDuration === dur
                    ? 'bg-agent text-white shadow-sm'
                    : 'bg-surface border border-hairline text-slate-soft hover:bg-nav-dim dark:hover:bg-nav-dim'
                }`}
              >
                {dur}m
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4">
          <label className="block text-2xs font-medium uppercase tracking-wide text-slate-soft mb-1.5">
            {isAr ? 'أيام العمل الأسبوعية' : 'Weekly Working Days'}
          </label>
          <div className="grid grid-cols-7 gap-1">
            {DAY_LABELS.map((d) => {
              const active = workingDays.includes(d.day);
              return (
                <button
                  key={d.day}
                  type="button"
                  onClick={() => toggleDay(d.day)}
                  className={`flex flex-col items-center justify-center rounded-lg py-1.5 text-center text-xs font-semibold transition ${
                    active
                      ? 'bg-agent text-white shadow-sm'
                      : 'bg-surface border border-hairline text-slate-soft hover:bg-nav-dim dark:hover:bg-nav-dim'
                  }`}
                >
                  <span className="text-2xs font-bold leading-none">{isAr ? d.shortAr : d.shortEn}</span>
                  <span className="mt-1">
                    {active ? <Check className="h-2.5 w-2.5 stroke-[3]" /> : <span className="h-1 w-1 rounded-full bg-nav-raised " />}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </FormSection>
    </CreateRecordDrawer>
  );
}

// ---------------------------------------------------------
// PROCEDURE DRAWER COMPONENT
// ---------------------------------------------------------
function ProcedureFormDrawer({
  open,
  onClose,
  procedure,
}: {
  open: boolean;
  onClose: () => void;
  procedure: ManagedProcedure | null;
}) {
  const qc = useQueryClient();
  const { locale } = useDirection();
  const isAr = locale === 'ar';

  const [name, setName] = useState('');
  const [specialty, setSpecialty] = useState('Dentistry');
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [bufferMinutes, setBufferMinutes] = useState(5);
  const [price, setPrice] = useState<string>('150');

  useMemo(() => {
    if (procedure) {
      setName(procedure.name || '');
      setSpecialty(procedure.specialty || 'Dentistry');
      setDurationMinutes(procedure.durationMinutes || 30);
      setBufferMinutes(procedure.bufferMinutes || 5);
      setPrice(procedure.price ? String(procedure.price) : '');
    } else {
      setName('');
      setSpecialty('Dentistry');
      setDurationMinutes(30);
      setBufferMinutes(5);
      setPrice('150');
    }
  }, [procedure, open]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        name,
        specialty,
        durationMinutes: Number(durationMinutes),
        bufferMinutes: Number(bufferMinutes),
        price: price ? Number(price) : undefined,
      };

      if (procedure) {
        return api.patch(`/clinic/procedures/${procedure.id}`, payload);
      } else {
        return api.post('/clinic/procedures', payload);
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clinic', 'procedures'] });
      onClose();
    },
  });

  return (
    <CreateRecordDrawer
      open={open}
      onClose={onClose}
      title={procedure ? (isAr ? 'تعديل الإجراء الطبي' : 'Edit Procedure') : (isAr ? 'إضافة إجراء جديد' : 'Add Procedure')}
      description={
        isAr
          ? 'تحديد مدة الجلسة بالدقائق والسعر التقديري'
          : 'Define procedure slot length and turnaround buffer'
      }
      submitLabel={procedure ? (isAr ? 'حفظ التعديلات' : 'Save Changes') : (isAr ? 'إضافة الإجراء' : 'Create Procedure')}
      isSubmitting={saveMutation.isPending}
      canSubmit={name.trim().length > 0}
      onSubmit={(e) => {
        e.preventDefault();
        saveMutation.mutate();
      }}
    >
      <FormSection title={isAr ? 'تفاصيل الخدمة الطبية' : 'Service Details'}>
        <TextField
          label={isAr ? 'اسم الإجراء أو الفحص' : 'Procedure Name'}
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Dental Cleaning"
          required
        />
        <SelectField
          label={isAr ? 'التخصص الطبي' : 'Specialty'}
          value={specialty}
          onChange={(e) => setSpecialty(e.target.value)}
          options={SPECIALTY_OPTIONS.map((s) => ({ value: s, label: s }))}
        />
      </FormSection>

      <FormSection title={isAr ? 'المدة الزمنية والتسعير' : 'Duration & Pricing'}>
        <div className="grid grid-cols-2 gap-3">
          <TextField
            label={isAr ? 'مدة الجلسة (دقيقة)' : 'Duration (mins)'}
            value={String(durationMinutes)}
            onChange={(e) => setDurationMinutes(Number(e.target.value) || 30)}
            type="number"
            required
          />
          <TextField
            label={isAr ? 'وقت التجهيز الإضافي' : 'Buffer Time (mins)'}
            value={String(bufferMinutes)}
            onChange={(e) => setBufferMinutes(Number(e.target.value) || 0)}
            type="number"
          />
        </div>

        <TextField
          label={isAr ? 'السعر التقديري (SAR)' : 'Estimated Price (SAR)'}
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          placeholder="150"
          type="number"
        />
      </FormSection>
    </CreateRecordDrawer>
  );
}
