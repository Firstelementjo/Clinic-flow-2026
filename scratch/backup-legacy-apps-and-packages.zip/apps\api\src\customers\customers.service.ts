import { Injectable, NotFoundException } from '@nestjs/common';
import {
  accessibleProjectsScope,
  projectScope,
  type TenantContext,
} from '@firstelement/database';
import { AuditAction, ErrorCode, type UpdateCustomerInput } from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';

const CUSTOMER_LIST_SELECT = {
  id: true,
  projectId: true,
  cxId: true,
  displayName: true,
  primaryEmail: true,
  primaryPhone: true,
  locale: true,
  tags: true,
  metadata: true,
  lastSeenAt: true,
  createdAt: true,
  project: { select: { name: true } },
  _count: { select: { conversations: true } },
  conversations: {
    select: {
      id: true,
      ticketNumber: true,
      createdAt: true,
      status: true,
      subject: true,
    },
    orderBy: { createdAt: 'desc' },
    take: 1,
  },
  leads: {
    select: {
      id: true,
      name: true,
      status: true,
      priority: true,
      ticketNumber: true,
      ticketDate: true,
      followUpDate: true,
      createdAt: true,
    },
    orderBy: { createdAt: 'desc' },
    take: 5,
  },
  appointments: {
    select: {
      id: true,
      title: true,
      appointmentDate: true,
      durationMinutes: true,
      status: true,
      service: true,
      doctorName: true,
    },
    orderBy: { appointmentDate: 'desc' },
    take: 5,
  },
} as const;

@Injectable()
export class CustomersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  async list(
    ctx: TenantContext,
    opts: { projectId?: string; search?: string; cursor?: string; limit: number },
  ) {
    // A supplied projectId narrows the scope; its absence means "every
    // project I can see", never "every project".
    const scope = opts.projectId
      ? projectScope(ctx, opts.projectId)
      : accessibleProjectsScope(ctx);

    const search = opts.search?.trim();

    const items = await this.prisma.client.customer.findMany({
      where: {
        ...scope,
        ...(search
          ? {
              OR: [
                { cxId: { contains: search, mode: 'insensitive' } },
                { displayName: { contains: search, mode: 'insensitive' } },
                { primaryEmail: { contains: search, mode: 'insensitive' } },
                { primaryPhone: { contains: search } },
              ],
            }
          : {}),
      },
      select: CUSTOMER_LIST_SELECT,
      orderBy: [{ lastSeenAt: 'desc' }, { id: 'desc' }],
      take: opts.limit + 1,
      ...(opts.cursor ? { cursor: { id: opts.cursor }, skip: 1 } : {}),
    });

    const hasMore = items.length > opts.limit;
    const page = hasMore ? items.slice(0, opts.limit) : items;

    return {
      items: page.map((customer) => ({
        id: customer.id,
        projectId: customer.projectId,
        projectName: customer.project.name,
        cxId: customer.cxId,
        displayName: customer.displayName,
        primaryEmail: customer.primaryEmail,
        primaryPhone: customer.primaryPhone,
        locale: customer.locale,
        tags: customer.tags,
        metadata: customer.metadata,
        conversationCount: customer._count.conversations,
        lastSeenAt: customer.lastSeenAt.toISOString(),
        createdAt: customer.createdAt.toISOString(),
        latestTicket: customer.conversations[0]
          ? {
              id: customer.conversations[0].id,
              ticketNumber: customer.conversations[0].ticketNumber,
              createdAt: customer.conversations[0].createdAt.toISOString(),
              status: customer.conversations[0].status,
              subject: customer.conversations[0].subject,
            }
          : null,
        followUps: customer.leads.map((f) => ({
          id: f.id,
          name: f.name,
          status: f.status,
          priority: f.priority,
          ticketNumber: f.ticketNumber,
          ticketDate: f.ticketDate ? f.ticketDate.toISOString() : null,
          followUpDate: f.followUpDate ? f.followUpDate.toISOString() : null,
          createdAt: f.createdAt.toISOString(),
        })),
        appointments: customer.appointments.map((a) => ({
          id: a.id,
          title: a.title,
          appointmentDate: a.appointmentDate.toISOString(),
          durationMinutes: a.durationMinutes,
          status: a.status,
          service: a.service,
          doctorName: a.doctorName,
        })),
      })),
      nextCursor: hasMore ? (page[page.length - 1]?.id ?? null) : null,
    };
  }

  /**
   * Customer 360 (plan §14): the resolved person, every handle they write
   * from, and every conversation across every channel in one place.
   */
  async getById(ctx: TenantContext, customerId: string) {
    const customer = await this.prisma.client.customer.findFirst({
      where: { id: customerId, ...accessibleProjectsScope(ctx) },
      select: {
        id: true,
        projectId: true,
        cxId: true,
        displayName: true,
        primaryEmail: true,
        primaryPhone: true,
        locale: true,
        tags: true,
        notes: true,
        metadata: true,
        firstSeenAt: true,
        lastSeenAt: true,
        project: { select: { name: true } },
        identities: {
          select: {
            id: true,
            platform: true,
            externalId: true,
            displayName: true,
            isVerified: true,
            createdAt: true,
          },
          orderBy: { createdAt: 'asc' },
        },
        conversations: {
          select: {
            id: true,
            ticketNumber: true,
            channel: true,
            status: true,
            mode: true,
            priority: true,
            subject: true,
            messageCount: true,
            lastMessageAt: true,
            createdAt: true,
            assignedEmployee: {
              select: { user: { select: { fullName: true } } },
            },
          },
          orderBy: { lastMessageAt: 'desc' },
          take: 50,
        },
        leads: {
          select: {
            id: true,
            name: true,
            status: true,
            priority: true,
            ticketNumber: true,
            ticketDate: true,
            followUpDate: true,
            createdAt: true,
          },
          orderBy: { createdAt: 'desc' },
        },
        appointments: {
          select: {
            id: true,
            title: true,
            appointmentDate: true,
            durationMinutes: true,
            status: true,
            service: true,
            doctorName: true,
            notes: true,
            ticketNumber: true,
            ticketDate: true,
            createdAt: true,
          },
          orderBy: { appointmentDate: 'desc' },
        },
      },
    });

    if (!customer) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Customer not found' });
    }

    return {
      ...customer,
      projectName: customer.project.name,
      firstSeenAt: customer.firstSeenAt.toISOString(),
      lastSeenAt: customer.lastSeenAt.toISOString(),
      identities: customer.identities.map((identity) => ({
        ...identity,
        createdAt: identity.createdAt.toISOString(),
      })),
      conversations: customer.conversations.map((conversation) => ({
        id: conversation.id,
        ticketNumber: conversation.ticketNumber,
        channel: conversation.channel,
        status: conversation.status,
        mode: conversation.mode,
        priority: conversation.priority,
        subject: conversation.subject,
        messageCount: conversation.messageCount,
        lastMessageAt: conversation.lastMessageAt.toISOString(),
        createdAt: conversation.createdAt.toISOString(),
        assignedAgent: conversation.assignedEmployee?.user?.fullName ?? null,
      })),
      appointments: customer.appointments.map((a) => ({
        ...a,
        appointmentDate: a.appointmentDate.toISOString(),
        createdAt: a.createdAt.toISOString(),
        ticketDate: a.ticketDate ? a.ticketDate.toISOString() : null,
      })),
    };
  }

  async getByCxId(ctx: TenantContext, cxId: string) {
    const customer = await this.prisma.client.customer.findFirst({
      where: { cxId, ...accessibleProjectsScope(ctx) },
      select: { id: true },
    });

    if (!customer) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Customer not found' });
    }

    return this.getById(ctx, customer.id);
  }

  async update(
    ctx: TenantContext,
    customerId: string,
    input: UpdateCustomerInput,
    ipAddress?: string,
  ) {
    const existing = await this.getById(ctx, customerId);

    await this.prisma.client.customer.updateMany({
      where: { id: customerId, ...projectScope(ctx, existing.projectId) },
      data: input,
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId: existing.projectId,
      actorUserId: ctx.userId,
      action: AuditAction.CUSTOMER_DATA_UPDATED,
      resourceType: 'Customer',
      resourceId: customerId,
      // Field names only — customer data does not belong in the audit log.
      metadata: { changedFields: Object.keys(input) },
      ipAddress,
    });

    return this.getById(ctx, customerId);
  }
}
