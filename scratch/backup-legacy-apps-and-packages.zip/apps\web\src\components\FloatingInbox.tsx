import { createContext, useCallback, useContext, useRef, type ReactNode } from 'react';

interface FloatingInboxApi {
  isOpen: boolean;
  open: (conversationId?: string) => void;
  close: () => void;
}

const FloatingInboxContext = createContext<FloatingInboxApi | null>(null);

export function useFloatingInbox(): FloatingInboxApi {
  const context = useContext(FloatingInboxContext);
  if (!context) throw new Error('useFloatingInbox used outside FloatingInboxProvider');
  return context;
}

/**
 * Opens the inbox in a real separate browser window (Salesforce-style
 * pop-out, V1.2 §16–§19).
 *
 * The popup shares the session cookie with the main window, so no
 * extra auth is needed. The conversation stays live because the popup
 * runs its own React tree with its own SSE connection.
 */
export function FloatingInboxProvider({ children }: { children: ReactNode }) {
  const popupRef = useRef<Window | null>(null);

  const open = useCallback((conversationId?: string) => {
    // If a popup is already open, focus it and optionally navigate.
    if (popupRef.current && !popupRef.current.closed) {
      if (conversationId) {
        popupRef.current.location.href = `/inbox/pop?c=${conversationId}`;
      }
      popupRef.current.focus();
      return;
    }

    const width = 1100;
    const height = 700;
    const left = Math.max(0, (screen.width - width) / 2);
    const top = Math.max(0, (screen.height - height) / 2);
    const params = conversationId ? `?c=${conversationId}` : '';

    popupRef.current = window.open(
      `/inbox/pop${params}`,
      'firstelement-inbox',
      `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=no`,
    );
  }, []);

  const close = useCallback(() => {
    if (popupRef.current && !popupRef.current.closed) {
      popupRef.current.close();
    }
    popupRef.current = null;
  }, []);

  const isOpen = Boolean(popupRef.current && !popupRef.current.closed);

  const api = { isOpen, open, close };

  return <FloatingInboxContext.Provider value={api}>{children}</FloatingInboxContext.Provider>;
}
