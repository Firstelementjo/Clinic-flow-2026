import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { InboxFilter, type SessionUser } from '@firstelement/shared';
import { InboxWorkspace } from '../components/InboxWorkspace';
import { useFloatingInbox } from '../components/FloatingInbox';
import { useT } from '../lib/i18n';
import { useSession } from '../lib/session';

/**
 * The inbox route. The workspace itself lives in `InboxWorkspace` so the
 * floating window renders exactly the same tree (V1.2 §17).
 *
 * Selection and filter stay in the URL here: an agent hands a colleague a
 * link to the exact thread, and a refresh does not lose their place.
 */
export function InboxPage() {
  const t = useT();
  const session = useSession();
  const user = session.data as SessionUser | null;
  const floating = useFloatingInbox();

  const [searchParams, setSearchParams] = useSearchParams();
  const filter = (searchParams.get('filter') as InboxFilter | null) ?? InboxFilter.ASSIGNED_TO_ME;
  const selectedId = searchParams.get('c');
  const [search, setSearch] = useState('');

  const setParam = (key: string, value: string | null) => {
    const next = new URLSearchParams(searchParams);
    if (value === null) next.delete(key);
    else next.set(key, value);
    setSearchParams(next, { replace: true });
  };

  return (
    <>
      <div className="ph">
        <div>
          <h2>{t('nav.inbox')}</h2>
          <p>Patient conversations assigned to you.</p>
        </div>
        <div className="seg ms-auto">
          <button 
            className={filter === InboxFilter.ASSIGNED_TO_ME ? 'on' : ''} 
            onClick={() => setParam('filter', InboxFilter.ASSIGNED_TO_ME)}
          >
            Assigned to me
          </button>
          <button 
            className={filter === InboxFilter.HISTORY ? 'on' : ''} 
            onClick={() => setParam('filter', InboxFilter.HISTORY)}
          >
            History
          </button>
        </div>
        <button
          type="button"
          onClick={() => floating.open(selectedId ?? undefined)}
          className="ms-2 flex items-center gap-1 rounded border border-[var(--fe-hairline)] bg-[var(--fe-surface)] px-2 py-1 text-xs text-[var(--fe-slate)] hover:text-[var(--fe-ink)] hover:bg-[var(--fe-surf2)]"
          aria-label={t('inbox.popOut')}
          title={t('inbox.popOut')}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M7 17L17 7" />
            <path d="M7 7h10v10" />
          </svg>
        </button>
      </div>

      <InboxWorkspace
        user={user}
        filter={filter}
        onFilter={(next) => setParam('filter', next)}
        selectedId={selectedId}
        onSelect={(id) => setParam('c', id)}
        search={search}
        onSearch={setSearch}
      />
    </>
  );
}
