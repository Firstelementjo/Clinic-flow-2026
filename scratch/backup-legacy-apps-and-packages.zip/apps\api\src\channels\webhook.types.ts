import type { Request } from 'express';

/**
 * Express request carrying the untouched request body.
 *
 * Populated by the `json({ verify })` hook in main.ts, because Meta signs
 * the bytes it sent and a re-serialized object hashes differently.
 */
export interface RawBodyRequest extends Request {
  rawBody?: Buffer;
}
