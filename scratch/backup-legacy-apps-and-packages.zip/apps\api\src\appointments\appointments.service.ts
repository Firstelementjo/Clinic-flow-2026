import { Injectable, NotFoundException } from '@nestjs/common';
import { accessibleProjectsScope, projectScope, type TenantContext } from '@firstelement/database';
import { PrismaService } from '../common/prisma.service';

export interface AppointmentFilters {
  status?: string;
  search?: string;
  customerId?: string;
  projectId?: string;
}

export interface CreateAppointmentInput {
  title: string;
  patientName?: string;
  patientPhone?: string;
  patientEmail?: string;
  appointmentDate: string | Date;
  durationMinutes?: number;
  status?: string;
  service?: string;
  doctorName?: string;
  isAiProposed?: boolean;
  aiProposalReason?: string;
  notes?: string;
  customerId?: string;
  ticketNumber?: string;
  ticketDate?: string | Date;
  projectId?: string;
}

export interface UpdateAppointmentInput {
  title?: string;
  patientName?: string;
  patientPhone?: string;
  patientEmail?: string;
  appointmentDate?: string | Date;
  durationMinutes?: number;
  status?: string;
  service?: string;
  doctorName?: string;
  isAiProposed?: boolean;
  aiProposalReason?: string;
  notes?: string;
  customerId?: string;
  ticketNumber?: string;
  ticketDate?: string | Date;
}

const APPOINTMENT_SELECT = {
  id: true,
  organizationId: true,
  projectId: true,
  customerId: true,
  title: true,
  patientName: true,
  patientPhone: true,
  patientEmail: true,
  appointmentDate: true,
  durationMinutes: true,
  status: true,
  service: true,
  doctorName: true,
  isAiProposed: true,
  aiProposalReason: true,
  notes: true,
  ticketNumber: true,
  ticketDate: true,
  createdById: true,
  createdAt: true,
  updatedAt: true,
  customer: {
    select: {
      id: true,
      cxId: true,
      displayName: true,
      primaryEmail: true,
      primaryPhone: true,
    },
  },
  createdBy: {
    select: {
      id: true,
      fullName: true,
    },
  },
} as const;

@Injectable()
export class AppointmentsService {
  constructor(private readonly prisma: PrismaService) {}

  private defaultProjectId(ctx: TenantContext): string | undefined {
    return ctx.projectIds[0];
  }

  async list(ctx: TenantContext, filters: AppointmentFilters = {}) {
    const where: Record<string, unknown> = filters.projectId
      ? { ...projectScope(ctx, filters.projectId) }
      : { ...accessibleProjectsScope(ctx) };

    if (filters.status && filters.status !== 'ALL') {
      where.status = filters.status;
    }

    if (filters.customerId) {
      where.customerId = filters.customerId;
    }

    if (filters.search) {
      where.OR = [
        { title: { contains: filters.search, mode: 'insensitive' } },
        { patientName: { contains: filters.search, mode: 'insensitive' } },
        { patientPhone: { contains: filters.search, mode: 'insensitive' } },
        { doctorName: { contains: filters.search, mode: 'insensitive' } },
        { service: { contains: filters.search, mode: 'insensitive' } },
        { ticketNumber: { contains: filters.search, mode: 'insensitive' } },
      ];
    }

    return this.prisma.client.appointment.findMany({
      where,
      select: APPOINTMENT_SELECT,
      orderBy: { appointmentDate: 'desc' },
    });
  }

  async getById(ctx: TenantContext, id: string) {
    const appointment = await this.prisma.client.appointment.findFirst({
      where: { id, ...accessibleProjectsScope(ctx) },
      select: APPOINTMENT_SELECT,
    });

    if (!appointment) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Appointment not found' });
    }

    return appointment;
  }

  async create(ctx: TenantContext, input: CreateAppointmentInput) {
    let projectId = input.projectId ? projectScope(ctx, input.projectId).projectId : this.defaultProjectId(ctx);
    let patientName = input.patientName;
    let patientPhone = input.patientPhone;
    let patientEmail = input.patientEmail;
    let ticketNumber = input.ticketNumber;
    let ticketDate = input.ticketDate ? new Date(input.ticketDate) : undefined;

    if (input.customerId) {
      // Scoped: a customer id from the request is a claim, not a fact. Reading it
      // with `findUnique({ id })` would copy another tenant's display name, phone,
      // email and ticket number into the caller's own appointment.
      const customer = await this.prisma.client.customer.findFirst({
        where: { id: input.customerId, ...accessibleProjectsScope(ctx) },
        include: {
          conversations: {
            orderBy: { createdAt: 'desc' },
            take: 1,
            select: { ticketNumber: true, createdAt: true },
          },
        },
      });

      if (customer) {
        if (!projectId) projectId = customer.projectId;
        if (!patientName) patientName = customer.displayName;
        if (!patientPhone) patientPhone = customer.primaryPhone ?? undefined;
        if (!patientEmail) patientEmail = customer.primaryEmail ?? undefined;
        if (!ticketNumber && customer.conversations[0]) {
          ticketNumber = customer.conversations[0].ticketNumber;
        }
        if (!ticketDate && customer.conversations[0]) {
          ticketDate = customer.conversations[0].createdAt;
        }
      }
    }

    if (!projectId) {
      const firstProject = await this.prisma.client.project.findFirst({
        where: { organizationId: ctx.organizationId },
        select: { id: true },
      });
      projectId = firstProject?.id ?? ctx.projectIds[0];
    }

    return this.prisma.client.appointment.create({
      data: {
        organizationId: ctx.organizationId,
        projectId: projectId ?? '',
        customerId: input.customerId ?? null,
        title: input.title,
        patientName: patientName ?? null,
        patientPhone: patientPhone ?? null,
        patientEmail: patientEmail ?? null,
        appointmentDate: new Date(input.appointmentDate),
        durationMinutes: input.durationMinutes ?? 30,
        status: input.status ?? 'PENDING',
        service: input.service ?? null,
        doctorName: input.doctorName ?? null,
        isAiProposed: input.isAiProposed ?? true,
        aiProposalReason: input.aiProposalReason ?? null,
        notes: input.notes ?? null,
        ticketNumber: ticketNumber ?? null,
        ticketDate: ticketDate ?? null,
        createdById: ctx.userId,
      },
      select: APPOINTMENT_SELECT,
    });
  }

  async update(ctx: TenantContext, id: string, input: UpdateAppointmentInput) {
    const existing = await this.prisma.client.appointment.findFirst({
      where: { id, ...accessibleProjectsScope(ctx) },
    });

    if (!existing) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Appointment not found' });
    }

    const data: Record<string, unknown> = {};
    if (input.title !== undefined) data.title = input.title;
    if (input.patientName !== undefined) data.patientName = input.patientName;
    if (input.patientPhone !== undefined) data.patientPhone = input.patientPhone;
    if (input.patientEmail !== undefined) data.patientEmail = input.patientEmail;
    if (input.appointmentDate !== undefined) data.appointmentDate = new Date(input.appointmentDate);
    if (input.durationMinutes !== undefined) data.durationMinutes = input.durationMinutes;
    if (input.status !== undefined) data.status = input.status;
    if (input.service !== undefined) data.service = input.service;
    if (input.doctorName !== undefined) data.doctorName = input.doctorName;
    if (input.isAiProposed !== undefined) data.isAiProposed = input.isAiProposed;
    if (input.aiProposalReason !== undefined) data.aiProposalReason = input.aiProposalReason;
    if (input.notes !== undefined) data.notes = input.notes;
    if (input.customerId !== undefined) data.customerId = input.customerId;
    if (input.ticketNumber !== undefined) data.ticketNumber = input.ticketNumber;
    if (input.ticketDate !== undefined) data.ticketDate = input.ticketDate ? new Date(input.ticketDate) : null;

    return this.prisma.client.appointment.update({
      where: { id },
      data,
      select: APPOINTMENT_SELECT,
    });
  }

  async delete(ctx: TenantContext, id: string) {
    const existing = await this.prisma.client.appointment.findFirst({
      where: { id, ...accessibleProjectsScope(ctx) },
      select: { id: true },
    });

    if (!existing) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Appointment not found' });
    }

    return this.prisma.client.appointment.delete({
      where: { id },
    });
  }
}
