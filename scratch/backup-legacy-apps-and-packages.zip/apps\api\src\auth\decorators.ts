import { createParamDecorator, ExecutionContext, SetMetadata } from '@nestjs/common';
import type { Request } from 'express';
import type { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import type { SessionUser } from '@firstelement/shared';

export const IS_PUBLIC_KEY = 'firstelement:isPublic';
export const PERMISSIONS_KEY = 'firstelement:permissions';

/** Opt a route out of authentication. Everything else requires a session. */
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);

/**
 * Declares the capabilities a route requires. PermissionsGuard evaluates
 * them against the caller's role *and* the `:projectId` route param, so a
 * project-scoped route is membership-checked without extra code.
 */
export const RequirePermissions = (...permissions: Permission[]) =>
  SetMetadata(PERMISSIONS_KEY, permissions);

export const CurrentUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): SessionUser => {
    const request = ctx.switchToHttp().getRequest<Request>();
    if (!request.sessionUser) {
      throw new Error('CurrentUser used on a route without AuthGuard');
    }
    return request.sessionUser;
  },
);

export const Tenant = createParamDecorator((_data: unknown, ctx: ExecutionContext): TenantContext => {
  const request = ctx.switchToHttp().getRequest<Request>();
  if (!request.tenant) {
    throw new Error('Tenant used on a route without AuthGuard');
  }
  return request.tenant;
});

export const SessionId = createParamDecorator((_data: unknown, ctx: ExecutionContext): string => {
  const request = ctx.switchToHttp().getRequest<Request>();
  if (!request.sessionId) {
    throw new Error('SessionId used on a route without AuthGuard');
  }
  return request.sessionId;
});
