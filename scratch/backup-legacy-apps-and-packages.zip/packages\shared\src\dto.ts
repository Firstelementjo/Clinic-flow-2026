import { z } from 'zod';
import {
  ChannelType,
  ConversationEventType,
  ConversationMode,
  ConversationPriority,
  ConversationStatus,
  CrmObjectType,
  EmployeeAvailabilityStatus,
  InboxFilter,
  Locale,
  MessageAuthorType,
  MessageDeliveryStatus,
  MessageDirection,
  UserRole,
  ViewType,
} from './enums';

/**
 * Wire contracts. The API validates every request body against these
 * schemas (plan §12: input validation on every endpoint) and the web app
 * imports the inferred types, so a contract change breaks both sides at
 * compile time instead of at runtime.
 */

export const uuid = z.string().uuid();

/** Client-supplied ids are never trusted for authorization — see ProjectMembershipGuard. */
export const projectIdParam = z.object({ projectId: uuid });

// --- auth ------------------------------------------------------------------

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(1).max(200),
});
export type LoginInput = z.infer<typeof loginSchema>;

export const sessionUserSchema = z.object({
  id: uuid,
  email: z.string().email(),
  fullName: z.string(),
  role: z.nativeEnum(UserRole),
  locale: z.nativeEnum(Locale),
  organizationId: uuid,
  organizationName: z.string(),
  /** Present when the user has an employee profile — assignment targets it. */
  employeeId: uuid.nullable(),
  /** Projects this user may access. ADMINs get every project in the org. */
  projectIds: z.array(uuid),
});
export type SessionUser = z.infer<typeof sessionUserSchema>;

// --- organization ----------------------------------------------------------

export const updateOrganizationSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  defaultLocale: z.nativeEnum(Locale).optional(),
  timezone: z.string().trim().min(1).max(64).optional(),
});
export type UpdateOrganizationInput = z.infer<typeof updateOrganizationSchema>;

// --- project ---------------------------------------------------------------

export const createProjectSchema = z.object({
  name: z.string().trim().min(2).max(120),
  slug: z
    .string()
    .trim()
    .toLowerCase()
    .min(2)
    .max(64)
    .regex(/^[a-z0-9][a-z0-9-]*$/, 'Slug may contain lowercase letters, digits and hyphens'),
  description: z.string().trim().max(2000).optional(),
  defaultLocale: z.nativeEnum(Locale).default(Locale.AR),
  timezone: z.string().trim().min(1).max(64).default('Asia/Riyadh'),
});
export type CreateProjectInput = z.infer<typeof createProjectSchema>;

export const updateProjectSchema = createProjectSchema.partial().extend({
  isArchived: z.boolean().optional(),
});
export type UpdateProjectInput = z.infer<typeof updateProjectSchema>;

// --- saved views -------------------------------------------------------------

/**
 * The JSON snapshots refit the object grid's own vocabulary rather than a
 * normalized schema: `filters` is the text search, `sort` is
 * `{ field, direction }`, and `columnConfig` is `{ hidden: string[] }`.
 * They are stored opaque so a future object type can save its own shape
 * without a wire-contract change.
 */
export const createViewSchema = z.object({
  name: z.string().trim().min(1).max(120),
  type: z.nativeEnum(ViewType).default(ViewType.TABLE),
  isFavorite: z.boolean().default(false),
  filters: z.record(z.string(), z.unknown()).nullish(),
  sort: z.record(z.string(), z.unknown()).nullish(),
  columnConfig: z.record(z.string(), z.unknown()).nullish(),
});
export type CreateViewInput = z.infer<typeof createViewSchema>;

export const updateViewSchema = createViewSchema.partial();
export type UpdateViewInput = z.infer<typeof updateViewSchema>;

/** The `:objectType` path segment in `/objects/:objectType/views`. */
export const crmObjectTypeSchema = z.nativeEnum(CrmObjectType);
export type CrmObjectTypeParam = z.infer<typeof crmObjectTypeSchema>;

// --- employees / membership ------------------------------------------------

export const createEmployeeSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  fullName: z.string().trim().min(2).max(120),
  password: z.string().min(12).max(200),
  role: z.nativeEnum(UserRole).default(UserRole.EMPLOYEE),
  locale: z.nativeEnum(Locale).default(Locale.AR),
  department: z.string().trim().max(120).optional(),
  projectIds: z.array(uuid).default([]),
});
export type CreateEmployeeInput = z.infer<typeof createEmployeeSchema>;

export const updateEmployeeSchema = z.object({
  fullName: z.string().trim().min(2).max(120).optional(),
  role: z.nativeEnum(UserRole).optional(),
  locale: z.nativeEnum(Locale).optional(),
  department: z.string().trim().max(120).optional(),
  isActive: z.boolean().optional(),
  availabilityStatus: z.nativeEnum(EmployeeAvailabilityStatus).optional(),
  maxConcurrentConversations: z.number().int().min(1).max(200).optional(),
  projectIds: z.array(uuid).optional(),
});
export type UpdateEmployeeInput = z.infer<typeof updateEmployeeSchema>;

// --- customers -------------------------------------------------------------

export const updateCustomerSchema = z.object({
  displayName: z.string().trim().min(1).max(160).optional(),
  primaryEmail: z.string().trim().toLowerCase().email().nullish(),
  primaryPhone: z
    .string()
    .trim()
    .regex(/^\+?[0-9\s-]{6,20}$/, 'Enter a phone number in international format')
    .nullish(),
  locale: z.nativeEnum(Locale).optional(),
  notes: z.string().trim().max(5000).nullish(),
  tags: z.array(z.string().trim().min(1).max(40)).max(30).optional(),
  metadata: z.record(z.any()).optional(),
});
export type UpdateCustomerInput = z.infer<typeof updateCustomerSchema>;

// --- channels --------------------------------------------------------------

export const createChannelConnectionSchema = z.object({
  channel: z.nativeEnum(ChannelType),
  displayName: z.string().trim().max(120).optional(),
});
export type CreateChannelConnectionInput = z.infer<typeof createChannelConnectionSchema>;

export const updateChannelConnectionSchema = z.object({
  displayName: z.string().trim().max(120).nullish(),
  isEnabled: z.boolean().optional(),
});
export type UpdateChannelConnectionInput = z.infer<typeof updateChannelConnectionSchema>;

/** What the frontend may see about a connection. Never credentials (plan §12). */
export interface ChannelConnectionView {
  id: string;
  channel: ChannelType;
  displayName: string | null;
  isEnabled: boolean;
  status: 'DISCONNECTED' | 'CONNECTED' | 'ERROR';
  lastError: string | null;
  lastInboundAt: string | null;
  lastOutboundAt: string | null;
  /** True once credentials exist — the values themselves never leave the API. */
  hasCredentials: boolean;
  capabilities: {
    sendText: boolean;
    sendMedia: boolean;
    markAsRead: boolean;
    sessionWindowHours: number | null;
    maxTextLength: number;
    verifiesWebhookSignature: boolean;
  };
  /** False for channels whose adapter is not implemented in this build. */
  isImplemented: boolean;
}

/**
 * Connector credentials. Field names differ per channel and are validated
 * server-side against what that adapter needs; values are encrypted on
 * arrival and never returned (plan §12).
 */
export const setChannelCredentialsSchema = z.object({
  credentials: z.record(z.string().trim().min(1).max(4000)),
});
export type SetChannelCredentialsInput = z.infer<typeof setChannelCredentialsSchema>;

export interface ChannelWebhookInfo {
  url: string;
  verifyUrl?: string;
  /** Field names this channel needs — never their values. */
  requiredFields: string[];
}

/** Dev-only simulated inbound message (plan §13). */
export const mockIncomingMessageSchema = z.object({
  projectId: uuid,
  externalUserId: z.string().trim().min(1).max(120),
  text: z.string().trim().min(1).max(4000),
  displayName: z.string().trim().max(160).optional(),
  phone: z.string().trim().max(30).optional(),
  email: z.string().trim().toLowerCase().email().optional(),
  /** Reuse an id to prove the pipeline deduplicates a redelivered message. */
  externalMessageId: z.string().trim().max(200).optional(),
});
export type MockIncomingMessageInput = z.infer<typeof mockIncomingMessageSchema>;

// --- ai agent --------------------------------------------------------------

export const AIProviderKind = {
  MOCK: 'MOCK',
  OPENAI: 'OPENAI',
  ANTHROPIC: 'ANTHROPIC',
  GEMINI: 'GEMINI',
  OPENAI_COMPATIBLE: 'OPENAI_COMPATIBLE',
  LOCAL: 'LOCAL',
} as const;
export type AIProviderKind = (typeof AIProviderKind)[keyof typeof AIProviderKind];

/**
 * One payload for both create and edit: editing an agent always creates a
 * new version rather than mutating the live one (plan §9), so the two
 * operations take the same shape.
 */
export const saveAgentSchema = z.object({
  name: z.string().trim().min(2).max(120).default('Customer service agent'),
  isEnabled: z.boolean().default(false),
  systemInstructions: z.string().trim().min(20).max(20_000),
  tone: z.string().trim().max(200).nullish(),
  provider: z.nativeEnum(AIProviderKind).default(AIProviderKind.MOCK),
  model: z.string().trim().max(120).nullish(),
  temperature: z.number().min(0).max(2).default(0.3),
  maxTokens: z.number().int().min(64).max(8_000).default(800),
  failoverChain: z.array(z.nativeEnum(AIProviderKind)).max(4).default([]),
  enabledTools: z.array(z.string().trim().max(64)).max(20).default([]),
  knowledgeBaseIds: z.array(uuid).max(20).default([]),
  minRetrievalScore: z.number().min(0).max(1).default(0.25),
  memoryWindow: z.number().int().min(2).max(60).default(12),
});
export type SaveAgentInput = z.infer<typeof saveAgentSchema>;

export interface AgentVersionView {
  id: string;
  version: number;
  systemInstructions: string;
  tone: string | null;
  provider: AIProviderKind;
  model: string | null;
  temperature: number;
  maxTokens: number;
  failoverChain: AIProviderKind[];
  enabledTools: string[];
  knowledgeBaseIds: string[];
  minRetrievalScore: number;
  memoryWindow: number;
  createdAt: string;
}

export interface AgentView {
  id: string;
  name: string;
  isEnabled: boolean;
  activeVersion: AgentVersionView | null;
  versionCount: number;
  /** Tool catalogue, so the editor never hardcodes tool names. */
  availableTools: { name: string; description: string; mutates: boolean; isImplemented: boolean }[];
}

export type AIRunStatus = 'RUNNING' | 'COMPLETED' | 'FAILED' | 'ABORTED';
export type AIRunDecision = 'REPLY' | 'ASK_CLARIFICATION' | 'ESCALATE' | 'NO_ACTION' | 'RESOLVE';

export interface AIRunSummaryView {
  id: string;
  conversationId: string;
  status: AIRunStatus;
  decision: AIRunDecision | null;
  decisionReason: string | null;
  provider: AIProviderKind;
  model: string | null;
  latencyMs: number | null;
  agentVersion: number;
  startedAt: string;
}

/**
 * The trace an employee or admin opens to see why the AI answered or
 * escalated the way it did. Citations and operational metadata only —
 * never the model's reasoning (plan §48).
 */
export interface AIRunTraceView extends AIRunSummaryView {
  steps: {
    sequence: number;
    kind: 'CONTEXT' | 'RETRIEVAL' | 'TOOL_EXECUTION' | 'GENERATION' | 'EVALUATION' | 'DECISION';
    status: string;
    latencyMs: number | null;
    detail: Record<string, unknown>;
  }[];
  retrievals: {
    documentId: string;
    documentTitle: string;
    score: number;
    wasUsed: boolean;
  }[];
  toolCalls: {
    sequence: number;
    toolName: string;
    authorized: boolean;
    isError: boolean;
    errorMessage: string | null;
    latencyMs: number | null;
  }[];
  usage: {
    inputTokens: number;
    outputTokens: number;
    latencyMs: number;
    estimatedCost: number;
  } | null;
}

// --- routing ---------------------------------------------------------------

export const setAvailabilitySchema = z.object({
  availabilityStatus: z.nativeEnum(EmployeeAvailabilityStatus),
  /** Optional context for the status change, kept on the session record. */
  note: z.string().trim().max(200).optional(),
  /** Admins may set another agent's status; agents may only set their own. */
  employeeId: uuid.optional(),
});
export type SetAvailabilityInput = z.infer<typeof setAvailabilitySchema>;

export interface AgentStatusView {
  employeeId: string;
  status: EmployeeAvailabilityStatus;
  since: string;
  elapsedSeconds: number;
  isRoutable: boolean;
}

export interface StatusTotalsView {
  from: string;
  to: string;
  totals: { status: EmployeeAvailabilityStatus; seconds: number }[];
  routablePercentage: number;
}

export const availabilityWindowSchema = z
  .object({
    /** 0 = Sunday, matching the Gulf working week. */
    dayOfWeek: z.number().int().min(0).max(6),
    startMinute: z.number().int().min(0).max(1439),
    endMinute: z.number().int().min(1).max(1440),
    timezone: z.string().trim().min(1).max(64).default('Asia/Riyadh'),
  })
  .refine((window) => window.startMinute !== window.endMinute, {
    message: 'A window cannot start and end at the same minute',
  });
export type AvailabilityWindowInput = z.infer<typeof availabilityWindowSchema>;

export const setWorkingHoursSchema = z.object({
  windows: z.array(availabilityWindowSchema).max(28),
});
export type SetWorkingHoursInput = z.infer<typeof setWorkingHoursSchema>;

export const setSkillsSchema = z.object({
  skills: z
    .array(
      z.object({
        skill: z.string().trim().min(1).max(40),
        level: z.number().int().min(1).max(5).default(3),
      }),
    )
    .max(30),
});
export type SetSkillsInput = z.infer<typeof setSkillsSchema>;

export const saveRoutingRuleSchema = z.object({
  name: z.string().trim().min(2).max(120),
  isEnabled: z.boolean().default(true),
  priority: z.number().int().min(1).max(1000).default(100),
  /** Null matches any intent — a wildcard, not a requirement to be null. */
  intent: z.string().trim().max(60).nullish(),
  department: z.string().trim().max(120).nullish(),
  requiredSkill: z.string().trim().max(40).nullish(),
  strategy: z.enum(['LEAST_LOADED', 'ROUND_ROBIN']).default('LEAST_LOADED'),
});
export type SaveRoutingRuleInput = z.infer<typeof saveRoutingRuleSchema>;

export interface RoutingRuleView {
  id: string;
  name: string;
  isEnabled: boolean;
  priority: number;
  intent: string | null;
  department: string | null;
  requiredSkill: string | null;
  strategy: 'LEAST_LOADED' | 'ROUND_ROBIN';
}

export interface EmployeeRoutingView {
  id: string;
  userId: string;
  fullName: string;
  email: string;
  department: string | null;
  availabilityStatus: EmployeeAvailabilityStatus;
  /** When the current status began, for the live timer. */
  statusChangedAt: string;
  activeConversationCount: number;
  maxConcurrentConversations: number;
  skills: { skill: string; level: number }[];
  windows: { dayOfWeek: number; startMinute: number; endMinute: number; timezone: string }[];
  /** Whether they are inside a working-hours window right now. */
  isOnShift: boolean;
}

export interface ImportPreviewView {
  headers: string[];
  totalRows: number;
  mapping: Record<string, string>;
  valid: { rowNumber: number; email: string; fullName: string; department?: string }[];
  invalid: { rowNumber: number; errors: string[] }[];
  duplicates: { rowNumber: number; email: string }[];
}

export const commitImportSchema = z.object({
  /** Only the rows the admin confirmed, echoed back after preview. */
  employees: z
    .array(
      z.object({
        email: z.string().trim().toLowerCase().email(),
        fullName: z.string().trim().min(2).max(120),
        department: z.string().trim().max(120).optional(),
        maxConcurrentConversations: z.number().int().min(1).max(200).optional(),
        skills: z.array(z.string().trim().max(40)).max(20).default([]),
      }),
    )
    .min(1)
    .max(2_000),
  /** Projects the imported employees become members of. */
  projectIds: z.array(uuid).max(50).default([]),
});
export type CommitImportInput = z.infer<typeof commitImportSchema>;

export interface ImportResultView {
  created: number;
  skipped: { email: string; reason: string }[];
  /** Generated passwords are never returned; admins send a reset instead. */
  requiresPasswordReset: string[];
}

// --- case classification and resolution (V1.2 §12-§15) ---------------------

export const CaseOutcome = {
  RESOLVED: 'RESOLVED',
  ESCALATED: 'ESCALATED',
  UNRESOLVED: 'UNRESOLVED',
} as const;
export type CaseOutcome = (typeof CaseOutcome)[keyof typeof CaseOutcome];

export const classificationOptionSchema = z.object({
  value: z.string().trim().min(1).max(60),
  labelAr: z.string().trim().min(1).max(160),
  labelEn: z.string().trim().min(1).max(160),
});

/**
 * The exact questions arrive later (V1.2 §23), so they are configuration
 * rather than code — an admin writes them and they take effect at once.
 */
export const saveClassificationQuestionSchema = z.object({
  position: z.number().int().min(1).max(20),
  promptAr: z.string().trim().min(2).max(300),
  promptEn: z.string().trim().min(2).max(300),
  options: z.array(classificationOptionSchema).min(2).max(20),
  isRequired: z.boolean().default(true),
  isEnabled: z.boolean().default(true),
});
export type SaveClassificationQuestionInput = z.infer<typeof saveClassificationQuestionSchema>;

export interface ClassificationQuestionView {
  id: string;
  position: number;
  promptAr: string;
  promptEn: string;
  options: { value: string; labelAr: string; labelEn: string }[];
  isRequired: boolean;
  isEnabled: boolean;
}

export const saveClassificationSchema = z.object({
  answers: z
    .array(z.object({ questionId: uuid, value: z.string().trim().min(1).max(60) }))
    .max(20),
});
export type SaveClassificationInput = z.infer<typeof saveClassificationSchema>;

export interface ClassificationView {
  answers: { questionId: string; value: string }[];
  classifiedAt: string | null;
  /** The solution the classification pointed at, if one was found. */
  suggestion: {
    documentId: string;
    documentTitle: string;
    score: number | null;
    excerpt: string;
    /** How it was found: an admin mapping, or a knowledge search. */
    source: 'MAPPING' | 'SEARCH';
  } | null;
  /** True when required questions are still unanswered. */
  isComplete: boolean;
}

export const saveResolutionSchema = z.object({
  customerIssue: z.string().trim().min(2).max(2000),
  agentAction: z.string().trim().min(2).max(2000),
  usedKnowledgeBase: z.boolean().default(false),
  documentId: uuid.nullish(),
  customerAccepted: z.boolean().nullish(),
  customerSatisfied: z.boolean().nullish(),
  escalationRequested: z.boolean().default(false),
  escalatedToSupervisor: z.boolean().default(false),
  outcome: z.nativeEnum(CaseOutcome),
  notes: z.string().trim().max(4000).nullish(),
});
export type SaveResolutionInput = z.infer<typeof saveResolutionSchema>;

export interface ResolutionView extends Omit<SaveResolutionInput, 'documentId'> {
  id: string;
  documentId: string | null;
  recordedByName: string | null;
  createdAt: string;
}

// --- scoring and escalation ------------------------------------------------

export const ScoreSignal = {
  FRUSTRATION: 'frustration',
  SENTIMENT: 'sentiment',
  URGENCY: 'urgency',
  RISK: 'risk',
  INTENT_CONFIDENCE: 'intentConfidence',
  AI_CONFIDENCE: 'aiConfidence',
  AI_TURNS_WITHOUT_RESOLUTION: 'aiTurnsWithoutResolution',
  EXPLICIT_HUMAN_REQUEST: 'explicitHumanRequest',
} as const;
export type ScoreSignal = (typeof ScoreSignal)[keyof typeof ScoreSignal];

export const RuleOperator = {
  GTE: 'gte',
  LTE: 'lte',
  GT: 'gt',
  LT: 'lt',
  EQ: 'eq',
} as const;
export type RuleOperator = (typeof RuleOperator)[keyof typeof RuleOperator];

export const ruleConditionSchema = z.object({
  signal: z.nativeEnum(ScoreSignal),
  operator: z.nativeEnum(RuleOperator),
  value: z.number().min(0).max(100),
});
export type RuleConditionInput = z.infer<typeof ruleConditionSchema>;

export const saveEscalationRuleSchema = z.object({
  name: z.string().trim().min(2).max(120),
  description: z.string().trim().max(500).nullish(),
  isEnabled: z.boolean().default(true),
  priority: z.number().int().min(1).max(1000).default(100),
  conditions: z.array(ruleConditionSchema).min(1).max(6),
  combinator: z.enum(['ALL', 'ANY']).default('ALL'),
  department: z.string().trim().max(120).nullish(),
});
export type SaveEscalationRuleInput = z.infer<typeof saveEscalationRuleSchema>;

export interface EscalationRuleView {
  id: string;
  name: string;
  description: string | null;
  isEnabled: boolean;
  priority: number;
  conditions: RuleConditionInput[];
  combinator: 'ALL' | 'ANY';
  department: string | null;
}

export interface ConversationScoreView {
  id: string;
  frustration: number;
  sentiment: number;
  urgency: number;
  risk: number;
  intentConfidence: number;
  aiConfidence: number | null;
  intent: string | null;
  createdAt: string;
}

export interface EscalationView {
  id: string;
  conversationId: string;
  trigger: 'RULE' | 'EXPLICIT_REQUEST' | 'AI_FAILURE' | 'LOW_CONFIDENCE' | 'MANUAL';
  status: 'PENDING' | 'ASSIGNED' | 'RESOLVED' | 'CANCELLED';
  reason: string;
  summary: string | null;
  intent: string | null;
  department: string | null;
  createdAt: string;
}

// --- knowledge base --------------------------------------------------------

export const createKnowledgeBaseSchema = z.object({
  name: z.string().trim().min(2).max(120),
  description: z.string().trim().max(2000).optional(),
});
export type CreateKnowledgeBaseInput = z.infer<typeof createKnowledgeBaseSchema>;

export const createTextDocumentSchema = z.object({
  title: z.string().trim().min(2).max(200),
  content: z.string().trim().min(1).max(500_000),
});
export type CreateTextDocumentInput = z.infer<typeof createTextDocumentSchema>;

export const retrievalPreviewSchema = z.object({
  query: z.string().trim().min(1).max(1000),
  limit: z.coerce.number().int().min(1).max(20).default(6),
});
export type RetrievalPreviewInput = z.infer<typeof retrievalPreviewSchema>;

export type DocumentStatus = 'UPLOADED' | 'PROCESSING' | 'INDEXING' | 'READY' | 'FAILED';

export interface KnowledgeBaseView {
  id: string;
  name: string;
  description: string | null;
  documentCount: number;
  readyCount: number;
  createdAt: string;
}

export interface DocumentView {
  id: string;
  knowledgeBaseId: string;
  title: string;
  sourceType: 'FILE' | 'URL' | 'TEXT';
  mimeType: string | null;
  sizeBytes: number | null;
  status: DocumentStatus;
  failureReason: string | null;
  chunkCount: number;
  processedAt: string | null;
  createdAt: string;
}

export interface RetrievedChunkView {
  chunkId: string;
  documentId: string;
  documentTitle: string;
  chunkIndex: number;
  content: string;
  score: number;
}

export interface RetrievalPreviewResult {
  chunks: RetrievedChunkView[];
  isGap: boolean;
  bestScore: number | null;
}

// --- conversations ---------------------------------------------------------

export const inboxQuerySchema = z.object({
  /** Optional: omitted means "every project I can see". */
  projectId: uuid.optional(),
  filter: z.nativeEnum(InboxFilter).default(InboxFilter.ASSIGNED_TO_ME),
  channel: z.nativeEnum(ChannelType).optional(),
  search: z.string().trim().max(200).optional(),
  cursor: uuid.optional(),
  limit: z.coerce.number().int().min(1).max(100).default(30),
});
export type InboxQuery = z.infer<typeof inboxQuerySchema>;

export const sendMessageSchema = z.object({
  body: z.string().trim().min(1).max(4000),
});
export type SendMessageInput = z.infer<typeof sendMessageSchema>;

export const assignConversationSchema = z.object({
  /** null unassigns and returns the conversation to the queue. */
  employeeId: uuid.nullable(),
});
export type AssignConversationInput = z.infer<typeof assignConversationSchema>;

export const updateConversationSchema = z.object({
  status: z.nativeEnum(ConversationStatus).optional(),
  priority: z.nativeEnum(ConversationPriority).optional(),
  subject: z.string().trim().max(200).nullish(),
});
export type UpdateConversationInput = z.infer<typeof updateConversationSchema>;

export interface ConversationSummary {
  id: string;
  projectId: string;
  projectName: string;
  ticketNumber: string;
  channel: ChannelType;
  status: ConversationStatus;
  mode: ConversationMode;
  priority: ConversationPriority;
  subject: string | null;
  customer: { id: string; cxId: string; displayName: string };
  assignedEmployee: { id: string; fullName: string } | null;
  lastMessagePreview: string | null;
  messageCount: number;
  lastMessageAt: string;
}

export interface MessageView {
  id: string;
  direction: MessageDirection;
  authorType: MessageAuthorType;
  authorName: string | null;
  body: string;
  deliveryStatus: MessageDeliveryStatus;
  failureReason: string | null;
  sentAt: string;
}

export interface ConversationEventView {
  id: string;
  type: ConversationEventType;
  actorType: MessageAuthorType;
  actorName: string | null;
  payload: Record<string, unknown>;
  occurredAt: string;
}

export interface ConversationDetail extends ConversationSummary {
  messages: MessageView[];
  events: ConversationEventView[];
}

// --- ticketing / customer profile -------------------------------------------

export interface CustomerProfileView {
  id: string;
  cxId: string;
  displayName: string;
  primaryPhone: string | null;
  primaryEmail: string | null;
  locale: string;
  firstSeenAt: string;
  lastSeenAt: string;
  ticketHistory: {
    id: string;
    ticketNumber: string;
    channel: ChannelType;
    status: ConversationStatus;
    assignedAgent: string | null;
    createdAt: string;
    lastMessageAt: string;
  }[];
}

export interface TicketHistoryItem {
  ticketNumber: string;
  status: ConversationStatus;
  channel: ChannelType;
  createdAt: string;
  lastMessageAt: string;
}

// --- pagination ------------------------------------------------------------

export const paginationSchema = z.object({
  cursor: uuid.optional(),
  limit: z.coerce.number().int().min(1).max(100).default(25),
  search: z.string().trim().max(200).optional(),
});
export type PaginationInput = z.infer<typeof paginationSchema>;

export interface Paginated<T> {
  items: T[];
  nextCursor: string | null;
}
