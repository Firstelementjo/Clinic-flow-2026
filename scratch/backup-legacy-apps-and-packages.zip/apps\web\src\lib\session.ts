import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { LoginInput, SessionUser } from '@firstelement/shared';
import { api, ApiError } from './api';

export const sessionQueryKey = ['session'] as const;

/**
 * The session is server state, so it lives in TanStack Query rather than a
 * client store: one fetch of `/auth/me` on load, and a 401 anywhere in the
 * app resolves to "logged out" without a second source of truth.
 */
export function useSession() {
  return useQuery({
    queryKey: sessionQueryKey,
    queryFn: async (): Promise<SessionUser | null> => {
      try {
        const { user } = await api.get<{ user: SessionUser }>('/auth/me');
        return user;
      } catch (error) {
        if (error instanceof ApiError && error.status === 401) return null;
        throw error;
      }
    },
    staleTime: 30_000,
    retry: false,
  });
}

export function useLogin() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: LoginInput) => api.post<{ user: SessionUser }>('/auth/login', input),
    onSuccess: ({ user }) => {
      queryClient.setQueryData(sessionQueryKey, user);
    },
  });
}

export function useLogout() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => api.post<void>('/auth/logout'),
    /**
     * Teardown runs on settle, not on success.
     *
     * The request can be reported as aborted by the browser even though
     * the server processed it and revoked the session — a 204 with no body
     * arriving as the page tears down is enough. Keying the teardown to
     * `onSuccess` left the user staring at a dashboard whose session was
     * already dead, with every later request 401ing.
     *
     * Signing out locally is safe to do unconditionally: the worst case
     * for a genuinely failed request is that a server session outlives the
     * browser's, which the TTL closes. The opposite failure — the UI
     * believing you are still signed in — is the one that matters.
     */
    onSettled: () => {
      // Drop every cached tenant-scoped response, not just the session —
      // the next user on this machine must not see the previous one's data.
      queryClient.clear();
      queryClient.setQueryData(sessionQueryKey, null);
    },
  });
}
