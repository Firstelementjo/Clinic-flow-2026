import { useState, type FormEvent, useEffect, useMemo } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Calendar, Clock, Ticket, UserCheck, Stethoscope, Sparkles, CheckCircle2 } from 'lucide-react';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import { useCustomers, type CustomerListRow } from '../lib/customers';
import {
  CreateRecordDrawer,
  FormSection,
  TextField,
  SelectField,
  TextAreaField,
  textOrUndefined,
} from './CreateRecordDrawer';

export const APPOINTMENT_STATUSES = [
  'PENDING',
  'APPROVED',
  'CONFIRMED',
  'COMPLETED',
  'CANCELLED',
  'NO_SHOW',
] as const;

export type AppointmentStatus = (typeof APPOINTMENT_STATUSES)[number];

export const APPOINTMENT_STATUS_LABEL: Record<AppointmentStatus, StringKey> = {
  PENDING: 'appointments.tab.pending',
  APPROVED: 'appointments.tab.approved',
  CONFIRMED: 'appointments.tab.confirmed',
  COMPLETED: 'appointments.tab.completed',
  CANCELLED: 'appointments.tab.cancelled',
  NO_SHOW: 'appointments.tab.noShow',
};

export interface AppointmentRow {
  id: string;
  organizationId: string;
  projectId: string;
  customerId: string | null;
  doctorId?: string | null;
  procedureId?: string | null;
  title: string;
  patientName: string | null;
  patientPhone: string | null;
  patientEmail: string | null;
  appointmentDate: string;
  durationMinutes: number;
  status: string;
  service: string | null;
  doctorName: string | null;
  isAiProposed: boolean;
  aiProposalReason: string | null;
  notes: string | null;
  ticketNumber: string | null;
  ticketDate: string | null;
  createdById: string | null;
  createdAt: string;
  customer?: {
    id: string;
    cxId: string;
    displayName: string;
    primaryEmail: string | null;
    primaryPhone: string | null;
  } | null;
  createdBy?: {
    id: string;
    fullName: string;
  } | null;
}

export interface ClinicDoctor {
  id: string;
  name: string;
  specialty: string;
  workingDays: number[];
  workingHours: string;
  slotDuration: number;
}

export interface ClinicProcedure {
  id: string;
  name: string;
  specialty: string;
  durationMinutes: number;
  bufferMinutes: number;
  price: number;
}

export interface CreateAppointmentDrawerProps {
  open: boolean;
  onClose: () => void;
  initialCustomerId?: string | null;
  initialTicketNumber?: string | null;
  initialTicketDate?: string | null;
}

export function CreateAppointmentDrawer({
  open,
  onClose,
  initialCustomerId,
  initialTicketNumber,
  initialTicketDate,
}: CreateAppointmentDrawerProps) {
  const t = useT();
  const qc = useQueryClient();
  const customersQuery = useCustomers('');

  // Clinic doctors & procedures queries
  const doctorsQuery = useQuery({
    queryKey: ['clinic', 'doctors'],
    queryFn: () => api.get<ClinicDoctor[]>('/clinic/doctors'),
  });

  const proceduresQuery = useQuery({
    queryKey: ['clinic', 'procedures'],
    queryFn: () => api.get<ClinicProcedure[]>('/clinic/procedures'),
  });

  const customerList = customersQuery.data?.items ?? [];
  const doctors = doctorsQuery.data ?? [];
  const procedures = proceduresQuery.data ?? [];

  const customerOptions = useMemo(() => {
    return customerList.map((c) => ({
      value: c.id,
      label: `${c.displayName} (${c.cxId})${c.latestTicket ? ` · Ticket ${c.latestTicket.ticketNumber}` : ''}`,
    }));
  }, [customerList]);

  // Default date time tomorrow at 10:00 AM
  const defaultDateStr = useMemo(() => {
    const d = new Date(Date.now() + 24 * 60 * 60 * 1000);
    d.setHours(10, 0, 0, 0);
    return d.toISOString().slice(0, 16);
  }, []);

  const [form, setForm] = useState({
    title: '',
    customerId: initialCustomerId ?? '',
    doctorId: '',
    procedureId: '',
    patientName: '',
    patientPhone: '',
    patientEmail: '',
    appointmentDate: defaultDateStr,
    durationMinutes: '30',
    service: 'General Consultation',
    doctorName: '',
    status: 'PENDING',
    ticketNumber: initialTicketNumber ?? '',
    ticketDate: initialTicketDate ?? '',
    notes: '',
  });

  useEffect(() => {
    if (initialCustomerId) {
      const match = customerList.find((c) => c.id === initialCustomerId);
      setForm((prev) => ({
        ...prev,
        customerId: initialCustomerId,
        patientName: match?.displayName || prev.patientName,
        patientPhone: match?.primaryPhone || prev.patientPhone,
        patientEmail: match?.primaryEmail || prev.patientEmail,
        ticketNumber: initialTicketNumber ?? match?.latestTicket?.ticketNumber ?? '',
        ticketDate: initialTicketDate ?? match?.latestTicket?.createdAt ?? '',
        title: prev.title || (match ? `Consultation for ${match.displayName}` : ''),
      }));
    }
  }, [initialCustomerId, initialTicketNumber, initialTicketDate, customerList]);

  // When doctor or procedure changes, compute available slots
  const selectedDateOnly = form.appointmentDate ? form.appointmentDate.slice(0, 10) : '';

  const slotsQuery = useQuery({
    queryKey: ['clinic', 'slots', form.doctorId, form.procedureId, selectedDateOnly],
    queryFn: () => {
      if (!form.doctorId || !form.procedureId || !selectedDateOnly) return null;
      return api.get<{ isWorkingDay: boolean; slots: string[]; reason?: string }>(
        `/clinic/slots?doctorId=${form.doctorId}&procedureId=${form.procedureId}&date=${selectedDateOnly}`,
      );
    },
    enabled: Boolean(form.doctorId && form.procedureId && selectedDateOnly),
  });

  const handleCustomerSelect = (customerId: string) => {
    const selected = customerList.find((c) => c.id === customerId);
    setForm((prev) => {
      const ticketNum = selected?.latestTicket?.ticketNumber ?? prev.ticketNumber;
      const ticketDt = selected?.latestTicket?.createdAt ?? prev.ticketDate;
      return {
        ...prev,
        customerId,
        patientName: selected?.displayName || prev.patientName,
        patientPhone: selected?.primaryPhone || prev.patientPhone,
        patientEmail: selected?.primaryEmail || prev.patientEmail,
        ticketNumber: ticketNum,
        ticketDate: ticketDt,
        title: prev.title || (selected ? `Consultation for ${selected.displayName}` : ''),
      };
    });
  };

  const handleDoctorSelect = (doctorId: string) => {
    const doc = doctors.find((d) => d.id === doctorId);
    setForm((prev) => ({
      ...prev,
      doctorId,
      doctorName: doc ? doc.name : '',
      title: prev.procedureId
        ? `${prev.service} with ${doc?.name || 'Doctor'}`
        : prev.title,
    }));
  };

  const handleProcedureSelect = (procedureId: string) => {
    const proc = procedures.find((p) => p.id === procedureId);
    setForm((prev) => ({
      ...prev,
      procedureId,
      service: proc ? proc.name : prev.service,
      durationMinutes: proc ? String(proc.durationMinutes) : prev.durationMinutes,
      title: proc
        ? `${proc.name}${prev.doctorName ? ` with ${prev.doctorName}` : ''}`
        : prev.title,
    }));
  };

  const handleSlotClick = (slot: string) => {
    if (!selectedDateOnly) return;
    setForm((prev) => ({
      ...prev,
      appointmentDate: `${selectedDateOnly}T${slot}`,
    }));
  };

  const set = (field: string) => (e: { target: { value: string } }) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const reset = () => {
    setForm({
      title: '',
      customerId: '',
      doctorId: '',
      procedureId: '',
      patientName: '',
      patientPhone: '',
      patientEmail: '',
      appointmentDate: defaultDateStr,
      durationMinutes: '30',
      service: 'General Consultation',
      doctorName: '',
      status: 'PENDING',
      ticketNumber: '',
      ticketDate: '',
      notes: '',
    });
  };

  const create = useMutation({
    mutationFn: () =>
      api.post<AppointmentRow>('/appointments', {
        title: form.title.trim(),
        customerId: form.customerId || undefined,
        doctorId: form.doctorId || undefined,
        procedureId: form.procedureId || undefined,
        patientName: textOrUndefined(form.patientName),
        patientPhone: textOrUndefined(form.patientPhone),
        patientEmail: textOrUndefined(form.patientEmail),
        appointmentDate: new Date(form.appointmentDate).toISOString(),
        durationMinutes: parseInt(form.durationMinutes, 10) || 30,
        service: textOrUndefined(form.service),
        doctorName: textOrUndefined(form.doctorName),
        status: form.status,
        ticketNumber: form.ticketNumber || undefined,
        ticketDate: form.ticketDate || undefined,
        notes: textOrUndefined(form.notes),
        isAiProposed: false,
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['appointments'] });
      reset();
      onClose();
    },
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (form.title.trim()) create.mutate();
  };

  // Live ticket elapsed measurement
  const ticketAgeDisplay = useMemo(() => {
    if (!form.ticketDate) return null;
    const diffMs = Date.now() - new Date(form.ticketDate).getTime();
    if (diffMs < 0) return 'Just now';
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h elapsed`;
    return `${hours}h elapsed`;
  }, [form.ticketDate]);

  const doctorOptions = useMemo(() => {
    return [
      { value: '', label: 'Select clinic doctor (optional)...' },
      ...doctors.map((d) => ({
        value: d.id,
        label: `${d.name} (${d.specialty}) · ${d.workingHours}`,
      })),
    ];
  }, [doctors]);

  const procedureOptions = useMemo(() => {
    return [
      { value: '', label: 'Select procedure / service...' },
      ...procedures.map((p) => ({
        value: p.id,
        label: `${p.name} (${p.specialty}) · ${p.durationMinutes} min · SAR ${p.price}`,
      })),
    ];
  }, [procedures]);

  return (
    <CreateRecordDrawer
      open={open}
      onClose={() => {
        reset();
        onClose();
      }}
      title={t('appointments.form.title')}
      description={t('appointments.form.about')}
      submitLabel={t('appointments.form.save')}
      isSubmitting={create.isPending}
      canSubmit={Boolean(form.title.trim())}
      onSubmit={onSubmit}
    >
      {/* Linked Person & Ticket */}
      <FormSection title={t('followUps.form.sectionPerson')}>
        <div className="space-y-3">
          <SelectField
            label={t('appointments.form.fieldPatient')}
            placeholder={t('appointments.form.selectPatientPlaceholder')}
            options={customerOptions}
            value={form.customerId}
            onChange={(e) => handleCustomerSelect(e.target.value)}
          />

          {/* Ticket Information & Age Measurement */}
          <div className="rounded-lg border border-hairline bg-surface-raised p-3 text-xs">
            <div className="flex items-center justify-between font-medium text-ink mb-1.5">
              <span className="flex items-center gap-1.5 text-signal">
                <Ticket className="h-3.5 w-3.5" />
                {t('followUps.form.ticketDetails')}
              </span>
              {ticketAgeDisplay && (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 font-mono text-[11px]">
                  <Clock className="h-3 w-3" />
                  {ticketAgeDisplay}
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2 mt-2">
              <TextField
                label={t('followUps.form.ticketNumber')}
                placeholder="e.g. TCK-1042"
                value={form.ticketNumber}
                onChange={set('ticketNumber')}
              />
              <TextField
                label={t('followUps.form.ticketDate')}
                type="date"
                value={form.ticketDate ? form.ticketDate.slice(0, 10) : ''}
                onChange={set('ticketDate')}
              />
            </div>
          </div>
        </div>
      </FormSection>

      {/* Clinic System Integration: Doctor & Procedure Selection */}
      <FormSection title="Clinic Flow Scheduling & Integration">
        <div className="space-y-3">
          <SelectField
            label="Clinic Doctor"
            options={doctorOptions}
            value={form.doctorId}
            onChange={(e) => handleDoctorSelect(e.target.value)}
          />

          <SelectField
            label="Procedure / Service"
            options={procedureOptions}
            value={form.procedureId}
            onChange={(e) => handleProcedureSelect(e.target.value)}
          />

          {/* Available Slots Indicator */}
          {form.doctorId && form.procedureId && (
            <div className="rounded-lg border border-[#b2ded5] bg-[#f0faf7] p-3 text-xs">
              <div className="flex items-center justify-between font-medium text-[#0f5b4c] mb-1.5">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5 text-[#0f5b4c]" />
                  <span>Real-time Available Slots ({selectedDateOnly})</span>
                </span>
                {slotsQuery.isLoading && <span className="text-[11px] text-slate-soft">Checking...</span>}
              </div>

              {slotsQuery.data?.isWorkingDay === false ? (
                <p className="text-rose-600 font-medium text-[11px]">
                  {slotsQuery.data.reason || 'Doctor does not work on this date.'}
                </p>
              ) : slotsQuery.data?.slots && slotsQuery.data.slots.length > 0 ? (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {slotsQuery.data.slots.map((slot) => {
                    const isSelected = form.appointmentDate.endsWith(slot);
                    return (
                      <button
                        key={slot}
                        type="button"
                        onClick={() => handleSlotClick(slot)}
                        className={`rounded px-2.5 py-1 text-xs font-mono font-medium transition-colors ${
                          isSelected
                            ? 'bg-[#0f5b4c] text-white shadow-xs'
                            : 'bg-surface border border-[#b2ded5] text-[#0f5b4c] hover:bg-[#d5ece7]'
                        }`}
                      >
                        {slot}
                      </button>
                    );
                  })}
                </div>
              ) : slotsQuery.data ? (
                <p className="text-amber-700 text-[11px]">
                  All slots are fully booked for this date. Try another day.
                </p>
              ) : (
                <p className="text-slate-soft text-[11px]">
                  Pick a date below to view available doctor slots.
                </p>
              )}
            </div>
          )}
        </div>
      </FormSection>

      {/* Appointment Information */}
      <FormSection title={t('appointments.title')}>
        <TextField
          label={t('appointments.form.fieldTitle')}
          required
          autoFocus
          placeholder="e.g. Dental Checkup / Consultation"
          value={form.title}
          onChange={set('title')}
        />

        <div className="grid grid-cols-2 gap-2">
          <TextField
            label={t('appointments.form.fieldDate')}
            type="datetime-local"
            value={form.appointmentDate}
            onChange={set('appointmentDate')}
          />
          <SelectField
            label={t('appointments.form.fieldDuration')}
            options={[
              { value: '15', label: '15 min' },
              { value: '20', label: '20 min' },
              { value: '30', label: '30 min' },
              { value: '45', label: '45 min' },
              { value: '60', label: '60 min (1 hr)' },
              { value: '90', label: '90 min (1.5 hr)' },
            ]}
            value={form.durationMinutes}
            onChange={set('durationMinutes')}
          />
        </div>

        <SelectField
          label={t('appointments.col.status')}
          options={[
            { value: 'PENDING', label: t('appointments.tab.pending') },
            { value: 'APPROVED', label: t('appointments.tab.approved') },
            { value: 'CONFIRMED', label: t('appointments.tab.confirmed') },
            { value: 'COMPLETED', label: t('appointments.tab.completed') },
            { value: 'CANCELLED', label: t('appointments.tab.cancelled') },
            { value: 'NO_SHOW', label: t('appointments.tab.noShow') },
          ]}
          value={form.status}
          onChange={set('status')}
        />
      </FormSection>

      {/* Patient Contact Info */}
      <FormSection title={t('followUps.form.sectionContact')}>
        <TextField
          label={t('form.field.name')}
          placeholder="Patient Full Name"
          value={form.patientName}
          onChange={set('patientName')}
        />
        <TextField
          label={t('form.field.phone')}
          dir="ltr"
          placeholder="+966..."
          value={form.patientPhone}
          onChange={set('patientPhone')}
        />
        <TextField
          label={t('form.field.email')}
          type="email"
          dir="ltr"
          value={form.patientEmail}
          onChange={set('patientEmail')}
        />
        <TextAreaField
          label={t('appointments.form.fieldNotes')}
          wide
          value={form.notes}
          onChange={set('notes')}
        />
      </FormSection>
    </CreateRecordDrawer>
  );
}
