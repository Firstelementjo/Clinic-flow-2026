import { Body, Controller, Get, HttpCode, Post, Req, Res } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import type { Request, Response } from 'express';
import { SESSION_COOKIE_NAME, sessionCookieOptions } from '@firstelement/auth';
import { getConfig } from '@firstelement/config';
import { loginSchema, type LoginInput, type SessionUser } from '@firstelement/shared';
import { zodBody } from '../common/zod-validation.pipe';
import { AuthService } from './auth.service';
import { CurrentUser, Public, SessionId } from './decorators';

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  /** Tighter limit than the global default: this is the credential-stuffing surface. */
  @Public()
  @Throttle({ default: { limit: 10, ttl: 60_000 } })
  @Post('login')
  @HttpCode(200)
  async login(
    @Body(zodBody(loginSchema)) body: LoginInput,
    @Req() request: Request,
    @Res({ passthrough: true }) response: Response,
  ): Promise<{ user: SessionUser }> {
    const { session, user } = await this.auth.login(body, {
      userAgent: request.header('user-agent'),
      ipAddress: request.ip,
    });

    const config = getConfig();
    response.cookie(
      SESSION_COOKIE_NAME,
      session.token,
      sessionCookieOptions({
        secure: config.isProduction,
        ttlHours: config.SESSION_TTL_HOURS,
      }),
    );

    return { user };
  }

  @Post('logout')
  @HttpCode(204)
  async logout(
    @CurrentUser() user: SessionUser,
    @SessionId() sessionId: string,
    @Req() request: Request,
    @Res({ passthrough: true }) response: Response,
  ): Promise<void> {
    await this.auth.logout(sessionId, user, request.ip);
    response.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
  }

  @Get('me')
  me(@CurrentUser() user: SessionUser): { user: SessionUser } {
    return { user };
  }
}
