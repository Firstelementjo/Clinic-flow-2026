import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';

export interface FloatingWindowState {
  x: number;
  y: number;
  width: number;
  height: number;
  minimized: boolean;
}

const MIN_WIDTH = 420;
const MIN_HEIGHT = 320;
const STORAGE_KEY = 'firstelement:floating-inbox';

/**
 * A movable, resizable window *inside* the app (V1.2 §16–§18).
 *
 * Explicitly not a browser popup or a second tab: the requirement is that
 * an agent keeps the live conversation visible while using the rest of the
 * CRM, and a real window would lose the React tree, the session cache and
 * the SSE stream (§19).
 *
 * The children are rendered once and simply repositioned, never remounted,
 * which is what keeps the conversation live while it is dragged, resized
 * or minimized. Minimizing hides the body with CSS rather than unmounting
 * it, so an in-flight reply and the scroll position both survive.
 *
 * Geometry persists to localStorage: an agent who arranges their workspace
 * expects it to still be arranged tomorrow.
 */
export function FloatingWindow({
  title,
  onClose,
  children,
}: {
  title: ReactNode;
  onClose: () => void;
  children: ReactNode;
}) {
  const [state, setState] = useState<FloatingWindowState>(() => loadState());
  const dragRef = useRef<{ pointerId: number; offsetX: number; offsetY: number } | null>(null);
  const resizeRef = useRef<{ pointerId: number; startX: number; startY: number; width: number; height: number } | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  // Clamp back into view when the viewport shrinks, otherwise a window
  // arranged on a large monitor is unreachable on a laptop.
  useEffect(() => {
    const onResize = () =>
      setState((current) => ({
        ...current,
        x: clamp(current.x, 0, Math.max(0, window.innerWidth - 200)),
        y: clamp(current.y, 0, Math.max(0, window.innerHeight - 80)),
      }));

    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const onPointerMove = useCallback((event: PointerEvent) => {
    if (dragRef.current?.pointerId === event.pointerId) {
      const { offsetX, offsetY } = dragRef.current;
      setState((current) => ({
        ...current,
        x: clamp(event.clientX - offsetX, 0, window.innerWidth - 120),
        y: clamp(event.clientY - offsetY, 0, window.innerHeight - 60),
      }));
    }

    if (resizeRef.current?.pointerId === event.pointerId) {
      const { startX, startY, width, height } = resizeRef.current;
      setState((current) => ({
        ...current,
        width: Math.max(MIN_WIDTH, width + (event.clientX - startX)),
        height: Math.max(MIN_HEIGHT, height + (event.clientY - startY)),
      }));
    }
  }, []);

  const endGesture = useCallback(() => {
    dragRef.current = null;
    resizeRef.current = null;
  }, []);

  useEffect(() => {
    // Listeners live on the window, not the element: a fast drag outruns
    // the pointer and would otherwise drop the gesture.
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', endGesture);
    window.addEventListener('pointercancel', endGesture);

    return () => {
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', endGesture);
      window.removeEventListener('pointercancel', endGesture);
    };
  }, [onPointerMove, endGesture]);

  return (
    <div
      role="dialog"
      aria-label={typeof title === 'string' ? title : 'Inbox'}
      className="fixed z-40 flex flex-col overflow-hidden rounded border border-hairline bg-surface shadow-panel"
      style={{
        insetInlineStart: state.x,
        insetBlockStart: state.y,
        width: state.width,
        height: state.minimized ? undefined : state.height,
      }}
    >
      <header
        onPointerDown={(event) => {
          // Only the bar drags; buttons inside it must still click.
          if ((event.target as HTMLElement).closest('button')) return;
          dragRef.current = {
            pointerId: event.pointerId,
            offsetX: event.clientX - state.x,
            offsetY: event.clientY - state.y,
          };
        }}
        className="flex cursor-move select-none items-center gap-2 border-b border-hairline bg-mist/60 px-3 py-1.5"
      >
        <span className="fe-eyebrow truncate">{title}</span>

        <div className="ms-auto flex items-center gap-1">
          <button
            type="button"
            onClick={() => setState({ ...state, minimized: !state.minimized })}
            aria-label={state.minimized ? 'Restore' : 'Minimize'}
            className="rounded px-1.5 text-xs text-slate hover:bg-mist hover:text-ink"
          >
            {state.minimized ? '▢' : '—'}
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded px-1.5 text-xs text-slate hover:bg-mist hover:text-ink"
          >
            ✕
          </button>
        </div>
      </header>

      {/*
        Hidden, not unmounted. The conversation keeps its subscription,
        its scroll position and any half-written reply while minimized
        (§18: "minimizable without closing the active conversation").
      */}
      <div className={state.minimized ? 'hidden' : 'min-h-0 flex-1 overflow-auto'}>{children}</div>

      {!state.minimized && (
        <div
          onPointerDown={(event) => {
            resizeRef.current = {
              pointerId: event.pointerId,
              startX: event.clientX,
              startY: event.clientY,
              width: state.width,
              height: state.height,
            };
          }}
          role="separator"
          aria-label="Resize"
          // Bottom-inline-end in both directions: the grip follows the
          // reading direction rather than sitting in the wrong corner in RTL.
          className="absolute bottom-0 end-0 h-4 w-4 cursor-nwse-resize bg-hairline/60"
        />
      )}
    </div>
  );
}

function loadState(): FloatingWindowState {
  const fallback: FloatingWindowState = {
    x: Math.max(20, window.innerWidth - 900),
    y: 90,
    width: 860,
    height: 560,
    minimized: false,
  };

  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return fallback;
    const parsed = JSON.parse(stored) as Partial<FloatingWindowState>;

    return {
      x: clamp(parsed.x ?? fallback.x, 0, Math.max(0, window.innerWidth - 200)),
      y: clamp(parsed.y ?? fallback.y, 0, Math.max(0, window.innerHeight - 80)),
      width: Math.max(MIN_WIDTH, parsed.width ?? fallback.width),
      height: Math.max(MIN_HEIGHT, parsed.height ?? fallback.height),
      minimized: parsed.minimized ?? false,
    };
  } catch {
    return fallback;
  }
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}
