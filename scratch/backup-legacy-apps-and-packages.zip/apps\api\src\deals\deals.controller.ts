import { Controller, Get, Post, Patch, Delete, Param, Body, UseGuards, Query } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { Tenant, RequirePermissions } from '../auth/decorators';
import type { TenantContext } from '@firstelement/database';
import { Permission } from '@firstelement/auth';
import { DealsService } from './deals.service';

@Controller('deals')
@UseGuards(AuthGuard)
export class DealsController {
  constructor(private readonly dealsService: DealsService) {}

  @Get()
  @RequirePermissions(Permission.DEAL_READ)
  async list(
    @Tenant() ctx: TenantContext,
    @Query() query: { projectId?: string; stage?: string; pipeline?: string; search?: string },
  ) {
    return this.dealsService.list(ctx, query.projectId, query.stage, query.pipeline, query.search);
  }

  @Get(':id')
  @RequirePermissions(Permission.DEAL_READ)
  async get(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.dealsService.getById(ctx, id);
  }

  @Post()
  @RequirePermissions(Permission.DEAL_CREATE)
  async create(
    @Tenant() ctx: TenantContext,
    @Body() body: {
      name: string;
      company?: string;
      value?: number;
      currency?: string;
      pipeline?: string;
      stage?: string;
      expectedClose?: Date;
      probability?: number;
      priority?: string;
      dealSource?: string;
      description?: string;
      ownerId?: string;
      tags?: string[];
      notes?: string;
      projectId?: string;
      organizationId?: string;
    },
  ) {
    return this.dealsService.create(ctx, {
      name: body.name,
      company: body.company,
      value: body.value,
      currency: body.currency,
      pipeline: body.pipeline,
      stage: body.stage,
      expectedClose: body.expectedClose,
      probability: body.probability,
      priority: body.priority,
      dealSource: body.dealSource,
      description: body.description,
      ownerId: body.ownerId,
      tags: body.tags,
      notes: body.notes,
    }, body.projectId);
  }

  @Patch(':id')
  @RequirePermissions(Permission.DEAL_UPDATE)
  async update(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body() body: {
      name?: string;
      company?: string;
      value?: number;
      currency?: string;
      pipeline?: string;
      stage?: string;
      expectedClose?: Date;
      probability?: number;
      priority?: string;
      dealSource?: string;
      description?: string;
      ownerId?: string;
      closedWon?: boolean;
      tags?: string[];
      notes?: string;
    }
  ) {
    return this.dealsService.update(ctx, id, body);
  }

  @Post(':id/close')
  @RequirePermissions(Permission.DEAL_CLOSE)
  async close(@Tenant() ctx: TenantContext, @Param('id') id: string, @Body('won') won: boolean) {
    return this.dealsService.closeDeal(ctx, id, won);
  }

  @Delete(':id')
  @RequirePermissions(Permission.DEAL_DELETE)
  async delete(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.dealsService.delete(ctx, id);
  }
}