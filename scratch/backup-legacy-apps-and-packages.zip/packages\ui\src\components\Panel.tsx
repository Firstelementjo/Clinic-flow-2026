import clsx from 'clsx';
import type { ReactNode } from 'react';

export interface PanelProps {
  /** Rendered as the wallboard-style micro-label above the panel body. */
  eyebrow?: string;
  title?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  /** Removes body padding for tables and lists that manage their own rows. */
  flush?: boolean;
}

export function Panel({ eyebrow, title, actions, children, className, flush }: PanelProps) {
  return (
    <section
      className={clsx(
        'rounded-2xl bg-[var(--fe-surface)] border border-[var(--fe-hairline)] shadow-[var(--fe-shadow-panel)]',
        className,
      )}
    >
      {(eyebrow || title || actions) && (
        <header className="flex items-center justify-between gap-4 border-b border-[var(--fe-hairline)] px-5 py-4 bg-[var(--fe-surface)] rounded-t-2xl">
          <div className="min-w-0">
            {eyebrow && <p className="fe-eyebrow">{eyebrow}</p>}
            {title && <h2 className="fe-display truncate text-lg text-ink">{title}</h2>}
          </div>
          {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
        </header>
      )}
      <div className={flush ? undefined : 'p-4'}>{children}</div>
    </section>
  );
}

export function EmptyState({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center gap-2 px-6 py-10 text-center">
      <h3 className="fe-display text-lg text-ink">{title}</h3>
      <p className="max-w-sm text-sm text-slate">{body}</p>
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}
