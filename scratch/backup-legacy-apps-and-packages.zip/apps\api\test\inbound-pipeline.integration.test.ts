/**
 * Inbound pipeline against a real database (plan §16 slice 3).
 *
 * The point of these is the guarantee that cannot be unit-tested: webhook
 * idempotency is enforced by a unique index, not by application logic, so
 * it has to be exercised against PostgreSQL.
 *
 * Requires a database — see the header of tenant-isolation.integration.test.ts.
 * Skips loudly without one.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { MockConnector } from '@firstelement/connectors';
import { disconnectPrisma, getPrismaClient } from '@firstelement/database';
import { InboundMessagePipeline, TimelineRecordingPublisher } from '@firstelement/messaging';
import type { DomainEvent } from '@firstelement/events';

const prisma = getPrismaClient();

async function databaseReachable(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return true;
  } catch {
    return false;
  }
}

const hasDatabase = await databaseReachable();

describe.skipIf(!hasDatabase)('inbound message pipeline', () => {
  const suffix = Date.now().toString(36);
  const published: DomainEvent[] = [];
  const events = new TimelineRecordingPublisher(prisma, () => {}, {
    publish: (event) => published.push(event),
  });
  const pipeline = new InboundMessagePipeline(prisma, events);
  const connector = new MockConnector(`conn-${suffix}`);

  let organizationId: string;
  let projectId: string;
  let connectionId: string;

  beforeAll(async () => {
    const org = await prisma.organization.create({
      data: { name: `Pipeline ${suffix}`, slug: `pipeline-${suffix}` },
    });
    organizationId = org.id;

    const project = await prisma.project.create({
      data: { organizationId, name: 'Support', slug: 'support' },
    });
    projectId = project.id;

    const connection = await prisma.channelConnection.create({
      data: { organizationId, projectId, channel: 'MOCK', status: 'CONNECTED' },
    });
    connectionId = connection.id;
  });

  afterAll(async () => {
    if (!hasDatabase) return;
    await prisma.organization.delete({ where: { id: organizationId } });
    await disconnectPrisma();
  });

  async function deliver(payload: {
    externalUserId: string;
    text: string;
    externalMessageId?: string;
    displayName?: string;
    phone?: string;
  }) {
    const [message] = await connector.receiveWebhook(payload);
    return pipeline.process({
      organizationId,
      projectId,
      connectionId,
      channel: 'MOCK',
      message: message!,
    });
  }

  it('creates the customer, the conversation and the message from one inbound webhook', async () => {
    const result = await deliver({
      externalUserId: `cust-${suffix}`,
      text: 'أين طلبي؟',
      displayName: 'نورة',
      phone: `+96650${suffix.slice(-7)}`,
    });

    expect(result.status).toBe('processed');
    if (result.status !== 'processed') return;
    expect(result.conversationCreated).toBe(true);

    const conversation = await prisma.conversation.findUniqueOrThrow({
      where: { id: result.conversationId },
      include: { customer: true },
    });
    expect(conversation.messageCount).toBe(1);
    expect(conversation.status).toBe('OPEN');
    // Nothing may auto-reply before slice 5 gives the project an agent.
    expect(conversation.mode).toBe('HUMAN');
    expect(conversation.customer.displayName).toBe('نورة');
  });

  it('rejects a redelivered webhook without double-posting', async () => {
    const externalMessageId = `dup-${suffix}`;
    const first = await deliver({
      externalUserId: `dup-cust-${suffix}`,
      text: 'same message',
      externalMessageId,
    });
    expect(first.status).toBe('processed');

    const second = await deliver({
      externalUserId: `dup-cust-${suffix}`,
      text: 'same message',
      externalMessageId,
    });
    expect(second.status).toBe('duplicate');

    if (first.status !== 'processed') return;
    const conversation = await prisma.conversation.findUniqueOrThrow({
      where: { id: first.conversationId },
    });
    // The counter must not move either — a duplicate that bumps
    // lastMessageAt reorders the whole inbox.
    expect(conversation.messageCount).toBe(1);
  });

  it('adds later messages from the same customer to the open conversation', async () => {
    const externalUserId = `thread-${suffix}`;
    const first = await deliver({ externalUserId, text: 'first' });
    const second = await deliver({ externalUserId, text: 'second' });

    expect(first.status).toBe('processed');
    expect(second.status).toBe('processed');
    if (first.status !== 'processed' || second.status !== 'processed') return;

    expect(second.conversationId).toBe(first.conversationId);
    expect(second.conversationCreated).toBe(false);
    expect(second.customerId).toBe(first.customerId);
  });

  it('reopens a resolved conversation when the customer writes again', async () => {
    const externalUserId = `reopen-${suffix}`;
    const first = await deliver({ externalUserId, text: 'thanks' });
    if (first.status !== 'processed') throw new Error('setup failed');

    await prisma.conversation.update({
      where: { id: first.conversationId },
      data: { status: 'RESOLVED', resolvedAt: new Date() },
    });

    const again = await deliver({ externalUserId, text: 'actually, one more thing' });
    expect(again.status).toBe('processed');

    const conversation = await prisma.conversation.findUniqueOrThrow({
      where: { id: first.conversationId },
    });
    expect(conversation.status).toBe('OPEN');
    expect(conversation.resolvedAt).toBeNull();
  });

  it('records the timeline for inbound traffic from the worker side', async () => {
    const result = await deliver({ externalUserId: `timeline-${suffix}`, text: 'hello' });
    if (result.status !== 'processed') throw new Error('setup failed');

    // The publisher records asynchronously; give it a turn to land.
    await new Promise((resolve) => setTimeout(resolve, 200));

    const timeline = await prisma.conversationEvent.findMany({
      where: { conversationId: result.conversationId },
      orderBy: { occurredAt: 'asc' },
    });

    const types = timeline.map((event) => event.type);
    expect(types).toContain('CONVERSATION_CREATED');
    expect(types).toContain('MESSAGE_RECEIVED');

    // Message content must not be copied onto the timeline.
    const received = timeline.find((event) => event.type === 'MESSAGE_RECEIVED');
    expect(JSON.stringify(received?.payload)).not.toContain('hello');
  });

  it('keeps publishing events for downstream consumers', async () => {
    expect(published.some((event) => event.type === 'message.created')).toBe(true);
    expect(published.some((event) => event.type === 'conversation.created')).toBe(true);
  });
});

describe.skipIf(hasDatabase)('inbound message pipeline (skipped)', () => {
  it('needs a database — see the file header for setup', () => {
    expect(hasDatabase).toBe(false);
  });
});
