import { Injectable } from '@nestjs/common';
import { AIOrchestrator, EscalationEngine } from '@firstelement/ai';
import { PrismaService } from '../common/prisma.service';
import { KnowledgeRetrieverProvider } from '../knowledge/knowledge.providers';
import { DomainEventBus } from '../events/domain-event-bus';

/**
 * The orchestrator, wired for the API process.
 *
 * The API only runs AI turns on the inline queue driver (development
 * without Redis). In production the worker owns this path — an HTTP
 * process should not be spending 30 seconds inside a model call.
 */
@Injectable()
export class AIOrchestratorProvider extends AIOrchestrator {
  constructor(prisma: PrismaService, retriever: KnowledgeRetrieverProvider) {
    super(prisma.client, async (params) => {
      const result = await retriever.retrieve({
        organizationId: params.organizationId,
        projectId: params.projectId,
        knowledgeBaseIds:
          params.knowledgeBaseIds.length > 0 ? params.knowledgeBaseIds : undefined,
        query: params.query,
        minScore: params.minScore,
      });

      return result.chunks.map((chunk) => ({
        chunkId: chunk.chunkId,
        documentId: chunk.documentId,
        knowledgeBaseId: chunk.knowledgeBaseId,
        documentTitle: chunk.documentTitle,
        content: chunk.content,
        score: chunk.score,
      }));
    });
  }
}

/** Scoring and escalation, wired for the API's inline development path. */
@Injectable()
export class EscalationEngineProvider extends EscalationEngine {
  constructor(prisma: PrismaService, events: DomainEventBus) {
    super(prisma.client, events);
  }
}
