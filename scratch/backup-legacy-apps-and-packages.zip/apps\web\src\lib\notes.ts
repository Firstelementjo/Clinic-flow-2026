import { useQuery } from '@tanstack/react-query';
import { api } from './api';

export interface NoteRow {
  id: string;
  resourceType: string;
  resourceId: string;
  body: string;
  authorUserId: string | null;
  projectId?: string;
  createdAt: string;
  updatedAt?: string;
}

export function useNotes(resourceType: string, resourceId: string | undefined, projectId: string | undefined) {
  const enabled = Boolean(resourceId) && Boolean(projectId);
  const query = new URLSearchParams();
  if (projectId) query.set('projectId', projectId);

  return useQuery({
    queryKey: ['notes', resourceType, resourceId, projectId ?? ''],
    queryFn: () =>
      api.get<NoteRow[]>(`/notes?resourceType=${resourceType}&resourceId=${resourceId}&${query.toString()}`),
    enabled,
  });
}