import { Controller, Get, NotFoundException, Param, ParseUUIDPipe, Query } from '@nestjs/common';
import { Permission } from '@firstelement/auth';
import { accessibleProjectsScope, type TenantContext } from '@firstelement/database';
import {
  ErrorCode,
  type AIRunSummaryView,
  type AIRunTraceView,
} from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { RequirePermissions, Tenant } from '../auth/decorators';

/**
 * The "AI Run #18492" view (plan §7/§48).
 *
 * An employee inheriting an escalation can see what the agent retrieved,
 * which tools it called, what it decided and what it cost — the
 * operational metadata that makes an escalation explainable. What is never
 * exposed: the model's raw reasoning.
 */
@Controller('ai-runs')
export class AIRunsController {
  constructor(private readonly prisma: PrismaService) {}

  @Get()
  @RequirePermissions(Permission.AI_RUN_READ)
  async list(
    @Tenant() ctx: TenantContext,
    @Query('conversationId') conversationId?: string,
  ): Promise<AIRunSummaryView[]> {
    const runs = await this.prisma.client.aIRun.findMany({
      where: {
        ...accessibleProjectsScope(ctx),
        ...(conversationId ? { conversationId } : {}),
      },
      select: {
        id: true,
        conversationId: true,
        status: true,
        decision: true,
        decisionReason: true,
        provider: true,
        model: true,
        latencyMs: true,
        startedAt: true,
        agentVersion: { select: { version: true } },
      },
      orderBy: { startedAt: 'desc' },
      take: 50,
    });

    return runs.map((run) => ({
      id: run.id,
      conversationId: run.conversationId,
      status: run.status,
      decision: run.decision,
      decisionReason: run.decisionReason,
      provider: run.provider,
      model: run.model,
      latencyMs: run.latencyMs,
      agentVersion: run.agentVersion.version,
      startedAt: run.startedAt.toISOString(),
    }));
  }

  @Get(':runId')
  @RequirePermissions(Permission.AI_RUN_READ)
  async trace(
    @Tenant() ctx: TenantContext,
    @Param('runId', ParseUUIDPipe) runId: string,
  ): Promise<AIRunTraceView> {
    const run = await this.prisma.client.aIRun.findFirst({
      where: { id: runId, ...accessibleProjectsScope(ctx) },
      select: {
        id: true,
        conversationId: true,
        status: true,
        decision: true,
        decisionReason: true,
        provider: true,
        model: true,
        latencyMs: true,
        startedAt: true,
        agentVersion: { select: { version: true } },
        steps: {
          select: { sequence: true, kind: true, status: true, latencyMs: true, detail: true },
          orderBy: { sequence: 'asc' },
        },
        retrievals: {
          select: { documentId: true, documentTitle: true, score: true, wasUsed: true },
          orderBy: { score: 'desc' },
        },
        toolCalls: {
          // Arguments and results are deliberately not selected: they can
          // contain customer data, and the trace answers "what did it do",
          // not "what did it see".
          select: {
            sequence: true,
            toolName: true,
            authorized: true,
            isError: true,
            errorMessage: true,
            latencyMs: true,
          },
          orderBy: { sequence: 'asc' },
        },
        usage: {
          select: {
            inputTokens: true,
            outputTokens: true,
            latencyMs: true,
            estimatedCost: true,
          },
        },
      },
    });

    if (!run) throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'AI run not found' });

    return {
      id: run.id,
      conversationId: run.conversationId,
      status: run.status,
      decision: run.decision,
      decisionReason: run.decisionReason,
      provider: run.provider,
      model: run.model,
      latencyMs: run.latencyMs,
      agentVersion: run.agentVersion.version,
      startedAt: run.startedAt.toISOString(),
      steps: run.steps.map((step) => ({
        sequence: step.sequence,
        kind: step.kind,
        status: step.status,
        latencyMs: step.latencyMs,
        detail: (step.detail ?? {}) as Record<string, unknown>,
      })),
      retrievals: run.retrievals,
      toolCalls: run.toolCalls,
      usage: run.usage,
    };
  }
}
