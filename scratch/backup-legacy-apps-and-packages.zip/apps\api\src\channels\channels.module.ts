import { Module } from '@nestjs/common';
import { ChannelsController } from './channels.controller';
import { ChannelsService } from './channels.service';
import { MockWebhookController } from './mock-webhook.controller';
import { WebhooksController } from './webhooks.controller';

@Module({
  controllers: [ChannelsController, MockWebhookController, WebhooksController],
  providers: [ChannelsService],
  exports: [ChannelsService],
})
export class ChannelsModule {}
