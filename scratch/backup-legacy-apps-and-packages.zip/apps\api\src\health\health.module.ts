import { Module } from '@nestjs/common';
import { HealthController } from './health.controller';
import { SystemHealthController } from './system-health.controller';

@Module({
  controllers: [HealthController, SystemHealthController],
})
export class HealthModule {}
