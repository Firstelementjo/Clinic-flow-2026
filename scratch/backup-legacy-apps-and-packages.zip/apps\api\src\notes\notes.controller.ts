import { Controller, Delete, Get, Patch, Post, Param, Body, UseGuards, Query } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { Tenant, RequirePermissions } from '../auth/decorators';
import type { TenantContext } from '@firstelement/database';
import { Permission } from '@firstelement/auth';
import { NotesService } from './notes.service';

@Controller('notes')
@UseGuards(AuthGuard)
export class NotesController {
  constructor(private readonly notesService: NotesService) {}

  @Get()
  @RequirePermissions(Permission.NOTE_READ)
  async listForResource(
    @Tenant() ctx: TenantContext,
    @Query() query: { resourceType: string; resourceId: string; projectId?: string },
  ) {
    return this.notesService.listForResource(ctx, query.resourceType, query.resourceId, query.projectId);
  }

  @Get('project')
  @RequirePermissions(Permission.NOTE_READ)
  async listProject(@Tenant() ctx: TenantContext, @Query() query: { projectId: string }) {
    return this.notesService.listProject(ctx, query.projectId);
  }

  @Post()
  @RequirePermissions(Permission.NOTE_CREATE)
  async create(
    @Tenant() ctx: TenantContext,
    @Body() body: { resourceType: string; resourceId: string; body: string; projectId: string },
  ) {
    return this.notesService.create(ctx, body.resourceType, body.resourceId, body.body, body.projectId);
  }

  @Patch(':id')
  @RequirePermissions(Permission.NOTE_UPDATE)
  async update(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body() body: { body: string; projectId?: string },
  ) {
    return this.notesService.update(ctx, id, body.body, body.projectId);
  }

  @Delete(':id')
  @RequirePermissions(Permission.NOTE_DELETE)
  async delete(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Query() query: { projectId?: string },
  ) {
    return this.notesService.delete(ctx, id, query.projectId);
  }
}