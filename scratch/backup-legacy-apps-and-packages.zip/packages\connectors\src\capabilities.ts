import { ChannelType } from '@firstelement/shared';
import type { ConnectorCapabilities } from './types';

/**
 * Declared capabilities per platform (plan §8).
 *
 * These are stated up front — before the adapters exist in slice 8 —
 * because the UI and the outbound path need them now: a composer that
 * silently allows a 5,000-character WhatsApp message, or an agent that
 * replies four days into a closed session window, fails at the platform
 * boundary where the failure is hardest to explain to a customer.
 *
 * Numbers reflect the official APIs (Meta Cloud API, Telegram Bot API).
 * They are configuration, not guesses to be scattered through the code.
 */
export const CHANNEL_CAPABILITIES: Record<ChannelType, ConnectorCapabilities> = {
  [ChannelType.MOCK]: {
    channel: ChannelType.MOCK,
    sendText: true,
    sendMedia: true,
    markAsRead: true,
    editMessage: false,
    deleteMessage: false,
    sessionWindowHours: null,
    requiresTemplateOutsideSession: false,
    maxTextLength: 4000,
    supportedAttachmentTypes: ['image', 'document', 'audio', 'video'],
    verifiesWebhookSignature: false,
  },

  [ChannelType.WHATSAPP]: {
    channel: ChannelType.WHATSAPP,
    sendText: true,
    sendMedia: true,
    markAsRead: true,
    editMessage: false,
    deleteMessage: false,
    // The customer-service window: outside it, only approved templates.
    sessionWindowHours: 24,
    requiresTemplateOutsideSession: true,
    maxTextLength: 4096,
    supportedAttachmentTypes: ['image', 'video', 'audio', 'document', 'sticker', 'location'],
    verifiesWebhookSignature: true,
  },

  [ChannelType.INSTAGRAM]: {
    channel: ChannelType.INSTAGRAM,
    sendText: true,
    sendMedia: true,
    markAsRead: true,
    editMessage: false,
    deleteMessage: false,
    sessionWindowHours: 24,
    requiresTemplateOutsideSession: false,
    maxTextLength: 1000,
    supportedAttachmentTypes: ['image', 'video', 'audio'],
    verifiesWebhookSignature: true,
  },

  [ChannelType.MESSENGER]: {
    channel: ChannelType.MESSENGER,
    sendText: true,
    sendMedia: true,
    markAsRead: true,
    editMessage: false,
    deleteMessage: false,
    sessionWindowHours: 24,
    requiresTemplateOutsideSession: false,
    maxTextLength: 2000,
    supportedAttachmentTypes: ['image', 'video', 'audio', 'document'],
    verifiesWebhookSignature: true,
  },

  [ChannelType.TELEGRAM]: {
    channel: ChannelType.TELEGRAM,
    sendText: true,
    sendMedia: true,
    markAsRead: false,
    editMessage: true,
    deleteMessage: true,
    sessionWindowHours: null,
    requiresTemplateOutsideSession: false,
    maxTextLength: 4096,
    supportedAttachmentTypes: ['image', 'video', 'audio', 'document', 'sticker', 'location'],
    // Telegram uses a secret token header rather than a payload signature.
    verifiesWebhookSignature: true,
  },
};

export function capabilitiesFor(channel: ChannelType): ConnectorCapabilities {
  return CHANNEL_CAPABILITIES[channel];
}
