import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import type { Request, Response } from 'express';
import { PermissionDeniedError } from '@firstelement/auth';
import { TenantAccessError } from '@firstelement/database';
import { ErrorCode, type ApiErrorBody } from '@firstelement/shared';

/**
 * One error shape on the wire (`ApiErrorBody`), and one place that decides
 * how much to say.
 *
 * Tenant and permission failures are deliberately reported as 404, not 403:
 * telling a caller "this project exists but is not yours" is itself a
 * cross-tenant information leak. The real reason is logged server-side.
 */
@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger('HttpException');

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();
    const requestId = request.requestId;

    if (exception instanceof TenantAccessError || exception instanceof PermissionDeniedError) {
      this.logger.warn({
        message: 'Access denied',
        requestId,
        userId: request.sessionUser?.id,
        path: request.path,
        reason: exception.message,
      });
      return this.send(response, HttpStatus.NOT_FOUND, {
        code: ErrorCode.NOT_FOUND,
        message: 'Resource not found',
        requestId,
      });
    }

    if (exception instanceof HttpException) {
      const status = exception.getStatus();
      const payload = exception.getResponse();
      const body: ApiErrorBody =
        typeof payload === 'object' && payload !== null && 'code' in payload
          ? { ...(payload as ApiErrorBody), requestId }
          : {
              code: statusToCode(status),
              message: typeof payload === 'string' ? payload : exception.message,
              requestId,
            };
      return this.send(response, status, body);
    }

    this.logger.error({
      message: 'Unhandled exception',
      requestId,
      path: request.path,
      error: exception instanceof Error ? exception.stack : String(exception),
    });

    return this.send(response, HttpStatus.INTERNAL_SERVER_ERROR, {
      code: ErrorCode.INTERNAL,
      message: 'Internal server error',
      requestId,
    });
  }

  private send(response: Response, status: number, body: ApiErrorBody): void {
    response.status(status).json(body);
  }
}

function statusToCode(status: number): ErrorCode {
  switch (status) {
    case HttpStatus.UNAUTHORIZED:
      return ErrorCode.SESSION_EXPIRED;
    case HttpStatus.FORBIDDEN:
      return ErrorCode.FORBIDDEN;
    case HttpStatus.NOT_FOUND:
      return ErrorCode.NOT_FOUND;
    case HttpStatus.CONFLICT:
      return ErrorCode.CONFLICT;
    case HttpStatus.BAD_REQUEST:
      return ErrorCode.VALIDATION_FAILED;
    case HttpStatus.TOO_MANY_REQUESTS:
      return ErrorCode.RATE_LIMITED;
    default:
      return ErrorCode.INTERNAL;
  }
}
