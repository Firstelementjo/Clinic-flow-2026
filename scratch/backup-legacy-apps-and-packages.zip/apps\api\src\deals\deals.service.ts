import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { accessibleProjectsScope, projectScope, type TenantContext } from '@firstelement/database';

@Injectable()
export class DealsService {
  constructor(private readonly prisma: PrismaService) {}

  private defaultProjectId(ctx: TenantContext): string | undefined {
    return ctx.projectIds[0];
  }

  async list(ctx: TenantContext, projectId?: string, stage?: string, pipeline?: string, search?: string) {
    const where: Record<string, unknown> = {
      ...(projectId
        ? projectScope(ctx, projectId)
        : { projectId: this.defaultProjectId(ctx) as string | undefined }),
    };
    if (stage) where.stage = stage;
    if (pipeline) where.pipeline = pipeline;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { company: { contains: search, mode: 'insensitive' } },
      ];
    }

    return this.prisma.client.deal.findMany({
      where,
      select: {
        id: true,
        name: true,
        company: true,
        value: true,
        currency: true,
        pipeline: true,
        stage: true,
        closedWon: true,
        closedAt: true,
        expectedClose: true,
        probability: true,
        priority: true,
        dealSource: true,
        description: true,
        ownerId: true,
        createdById: true,
        createdBy: { select: { id: true, fullName: true } },
        owner: { select: { id: true, fullName: true } },
        tags: true,
        notes: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getById(ctx: TenantContext, id: string) {
    const deal = await this.prisma.client.deal.findFirst({
      where: { id, ...accessibleProjectsScope(ctx) },
      select: {
        id: true,
        name: true,
        company: true,
        value: true,
        currency: true,
        pipeline: true,
        stage: true,
        closedWon: true,
        expectedClose: true,
        probability: true,
        priority: true,
        dealSource: true,
        description: true,
        ownerId: true,
        tags: true,
        notes: true,
        createdAt: true,
      },
    });

    if (!deal) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Deal not found' });
    }

    return deal;
  }

  async create(
    ctx: TenantContext,
    data: {
      name: string;
      company?: string;
      value?: number;
      currency?: string;
      pipeline?: string;
      stage?: string;
      expectedClose?: Date;
      probability?: number;
      priority?: string;
      dealSource?: string;
      description?: string;
      ownerId?: string;
      tags?: string[];
      notes?: string;
    },
    projectId?: string,
  ) {
    const createData: Record<string, unknown> = {
      name: data.name,
      company: data.company || undefined,
      value: data.value ?? 0,
      currency: data.currency || 'USD',
      pipeline: data.pipeline || 'Sales',
      stage: data.stage || 'Prospect',
      tags: data.tags ?? [],
      notes: data.notes || undefined,
      ...(projectId
        ? projectScope(ctx, projectId)
        : { projectId: this.defaultProjectId(ctx) as string | undefined }),
    };
    if (data.expectedClose !== undefined) createData.expectedClose = new Date(data.expectedClose);
    if (data.probability !== undefined) createData.probability = data.probability;
    if (data.priority !== undefined) createData.priority = data.priority;
    if (data.dealSource !== undefined) createData.dealSource = data.dealSource;
    if (data.description !== undefined) createData.description = data.description;
    if (data.ownerId !== undefined) createData.ownerId = data.ownerId;
    createData.createdById = ctx.userId;
    return this.prisma.client.deal.create({
      data: createData as never,
      select: {
        id: true,
        name: true,
        company: true,
        value: true,
        currency: true,
        pipeline: true,
        stage: true,
        closedWon: true,
        expectedClose: true,
        probability: true,
        priority: true,
        dealSource: true,
        description: true,
        ownerId: true,
        createdById: true,
        createdBy: { select: { id: true, fullName: true } },
        tags: true,
        notes: true,
        createdAt: true,
      },
    });
  }

  async update(
    ctx: TenantContext,
    id: string,
    data: {
      name?: string;
      company?: string;
      value?: number;
      currency?: string;
      pipeline?: string;
      stage?: string;
      expectedClose?: Date;
      probability?: number;
      priority?: string;
      dealSource?: string;
      description?: string;
      ownerId?: string;
      closedWon?: boolean;
      tags?: string[];
      notes?: string;
    },
  ) {
    await this.assertOwned(ctx, id);

    const updateData: Record<string, unknown> = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.company !== undefined) updateData.company = data.company;
    if (data.value !== undefined) updateData.value = data.value;
    if (data.currency !== undefined) updateData.currency = data.currency;
    if (data.pipeline !== undefined) updateData.pipeline = data.pipeline;
    if (data.stage !== undefined) updateData.stage = data.stage;
    if (data.expectedClose !== undefined) updateData.expectedClose = new Date(data.expectedClose);
    if (data.probability !== undefined) updateData.probability = data.probability;
    if (data.priority !== undefined) updateData.priority = data.priority;
    if (data.dealSource !== undefined) updateData.dealSource = data.dealSource;
    if (data.description !== undefined) updateData.description = data.description;
    if (data.ownerId !== undefined) updateData.ownerId = data.ownerId || null;
    if (data.closedWon !== undefined) updateData.closedWon = data.closedWon;
    if (data.tags !== undefined) updateData.tags = data.tags;
    if (data.notes !== undefined) updateData.notes = data.notes;

    return this.prisma.client.deal.update({
      where: { id },
      data: updateData as never,
      select: {
        id: true,
        name: true,
        company: true,
        value: true,
        currency: true,
        pipeline: true,
        stage: true,
        closedWon: true,
        expectedClose: true,
        probability: true,
        priority: true,
        dealSource: true,
        description: true,
        ownerId: true,
        tags: true,
        notes: true,
        createdAt: true,
      },
    });
  }

  async delete(ctx: TenantContext, id: string) {
    await this.assertOwned(ctx, id);

    return this.prisma.client.deal.delete({
      where: { id },
    });
  }

  async closeDeal(ctx: TenantContext, id: string, won: boolean) {
    await this.assertOwned(ctx, id);

    return this.prisma.client.deal.update({
      where: { id },
      data: { closedWon: won, closedAt: new Date() },
      select: {
        id: true,
        name: true,
        closedWon: true,
        closedAt: true,
      },
    });
  }

  private async assertOwned(ctx: TenantContext, id: string) {
    const existing = await this.prisma.client.deal.findFirst({
      where: { id, ...accessibleProjectsScope(ctx) },
      select: { id: true },
    });

    if (!existing) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Deal not found' });
    }
  }
}