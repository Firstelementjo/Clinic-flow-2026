const fs = require('fs');
const path = require('path');

const dashPath = 'c:\\Users\\adama\\OneDrive\\Desktop\\Clinec Flow\\saas-crm-main (2)\\saas-crm-main\\apps\\web\\src\\routes\\DashboardPage.tsx';
let content = fs.readFileSync(dashPath, 'utf-8');

// Replace flat panel classes with glass-panel
content = content.replace(/border border-hairline bg-surface p-5 shadow-sm transition-all hover:shadow-md hover:border-(agent|signal|warning)/g, 'glass-panel p-5 group');
content = content.replace(/border border-hairline bg-surface p-5 shadow-sm transition-all hover:shadow-md/g, 'glass-panel p-5 group');

// Replace some other backgrounds
content = content.replace(/bg-surface border border-hairline/g, 'glass-panel');

fs.writeFileSync(dashPath, content);
console.log('Applied glass-panel to Dashboard');
