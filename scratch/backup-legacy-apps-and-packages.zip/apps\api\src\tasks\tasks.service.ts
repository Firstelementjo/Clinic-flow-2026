import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { accessibleProjectsScope, projectScope, type TenantContext } from '@firstelement/database';

type TaskStatus = 'open' | 'completed';

interface TaskFilters {
  projectId?: string;
  status?: TaskStatus;
  search?: string;
}

export interface TaskCreateInput {
  title: string;
  description?: string;
  priority?: string;
  dueDate?: string;
  customerId?: string;
  leadId?: string;
  dealId?: string;
  assignedToId?: string;
  organizationId?: string;
  projectId?: string;
  status?: string;
}

@Injectable()
export class TasksService {
  constructor(private readonly prisma: PrismaService) {}

  private defaultProjectId(ctx: TenantContext): string | undefined {
    return ctx.projectIds[0];
  }

  /**
   * A `projectId` on a query string or request body is a *request*, never an
   * authorization: `PermissionsGuard` only supplies a project scope for a
   * `:projectId` route param, and this route has none, so the check happens
   * here. `projectScope` refuses a project the caller does not hold membership
   * of, and the global exception filter renders that as the same 404
   * "Resource not found" used for a project that does not exist, so a denial
   * does not disclose that the project is there.
   */
  private resolveProject(ctx: TenantContext, requestedProjectId?: string): string | undefined {
    return requestedProjectId
      ? projectScope(ctx, requestedProjectId).projectId
      : this.defaultProjectId(ctx);
  }

  async list(ctx: TenantContext, filters: TaskFilters = {}) {
    const where: Record<string, unknown> = {
      organizationId: ctx.organizationId,
      projectId: this.resolveProject(ctx, filters.projectId),
    };

    if (filters.status) {
      where.status = filters.status;
    }

    if (filters.search) {
      where.OR = [
        { title: { contains: filters.search, mode: 'insensitive' } },
        { description: { contains: filters.search, mode: 'insensitive' } },
      ];
    }

    return this.prisma.client.task.findMany({
      where,
      select: {
        id: true,
        title: true,
        description: true,
        priority: true,
        dueDate: true,
        status: true,
        createdAt: true,
        customer: true,
        lead: true,
        deal: true,
        assignedTo: true,
        createdById: true,
        createdBy: { select: { id: true, fullName: true } },
      },
      orderBy: [{ dueDate: 'asc' }, { createdAt: 'desc' }],
    });
  }

  async getById(ctx: TenantContext, id: string) {
    const task = await this.prisma.client.task.findFirst({
      // A task belongs to a project: a principal who is not a member of that
      // project must not read it, so the lookup is bounded by the projects they
      // can reach rather than by the organization alone.
      where: { id, ...accessibleProjectsScope(ctx) },
      select: {
        id: true,
        title: true,
        description: true,
        priority: true,
        dueDate: true,
        status: true,
      },
    });

    if (!task) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Task not found' });
    }

    return task;
  }

  async create(ctx: TenantContext, input: {
    title: string;
    description?: string;
    priority?: string;
    dueDate?: string;
    customerId?: string;
    leadId?: string;
    dealId?: string;
    assignedToId?: string;
    organizationId?: string;
    projectId?: string;
    status?: string;
  }) {
    const data: Record<string, unknown> = {
      title: input.title,
      organizationId: ctx.organizationId,
      projectId: this.resolveProject(ctx, input.projectId),
    };
    if (input.description !== undefined) data.description = input.description;
    data.priority = input.priority || 'medium';
    if (input.dueDate) data.dueDate = new Date(input.dueDate);
    data.status = input.status || 'open';
    if (input.assignedToId !== undefined) data.assignedTo = input.assignedToId;
    data.createdById = ctx.userId;

    return this.prisma.client.task.create({
      data: data as never,
      select: {
        id: true,
        title: true,
        description: true,
        priority: true,
        dueDate: true,
        status: true,
        createdAt: true,
        customer: true,
        lead: true,
        deal: true,
        assignedTo: true,
        createdById: true,
        createdBy: { select: { id: true, fullName: true } },
      },
    });
  }

  async update(ctx: TenantContext, id: string, input: {
    title?: string;
    description?: string;
    priority?: string;
    dueDate?: string;
    status?: string;
    assignedToId?: string;
    organizationId?: string;
    projectId?: string;
  }) {
    await this.assertOwned(ctx, id);

    const updateData: Record<string, unknown> = {};
    if (input.title) updateData.title = input.title;
    if (input.description !== undefined) updateData.description = input.description;
    if (input.priority) updateData.priority = input.priority;
    if (input.dueDate) updateData.dueDate = input.dueDate ? new Date(input.dueDate) : null;
    if (input.status) updateData.status = input.status;
    if (input.assignedToId !== undefined) updateData.assignedTo = input.assignedToId || null;
    // `organizationId` is deliberately not assignable. It used to be copied from
    // the request body, which let any caller move a task into another tenant —
    // a cross-tenant write, and a stronger primitive than the project boundary
    // this fix closes. The tenant of a row is the server's decision.
    if (input.projectId) updateData.projectId = projectScope(ctx, input.projectId).projectId;

    const task = await this.prisma.client.task.update({
      where: { id },
      data: updateData as never,
      select: {
        id: true,
        title: true,
        description: true,
        priority: true,
        dueDate: true,
        status: true,
        createdAt: true,
        customer: true,
        lead: true,
        deal: true,
        assignedTo: true,
        createdById: true,
        createdBy: { select: { id: true, fullName: true } },
      },
    });

    return task;
  }

  async delete(ctx: TenantContext, id: string) {
    await this.assertOwned(ctx, id);

    return this.prisma.client.task.delete({
      where: { id },
    });
  }

  private async assertOwned(ctx: TenantContext, id: string) {
    const existing = await this.prisma.client.task.findFirst({
      // `update` and `delete` both mutate on `where: { id }` with no predicate of
      // their own, so this lookup is the entire write boundary. Bounding it by
      // the caller's reachable projects is what stops a same-organization
      // colleague in another project rewriting or deleting the task.
      where: { id, ...accessibleProjectsScope(ctx) },
      select: { id: true },
    });

    if (!existing) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Task not found' });
    }
  }
}