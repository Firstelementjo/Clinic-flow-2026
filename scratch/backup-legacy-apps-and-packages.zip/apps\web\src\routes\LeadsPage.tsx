import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Building2, CalendarPlus, Mail, MoreHorizontal, Phone, Send, Type, UserRound } from 'lucide-react';
import { useDirection } from '@firstelement/ui';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import { CreateLeadDrawer } from '../components/lead-form';
import { useCrmViews } from '../lib/views';
import {
  ListView,
  ListBadge,
  ListBadgeSelect,
  Menu,
  MenuItem,
  RecordAvatar,
  type BadgeTone,
  type ListColumn,
} from '../components/ListView';

interface LeadRow {
  id: string;
  name: string;
  company: string | null;
  source: string | null;
  status: string;
  jobTitle: string | null;
  email: string | null;
  phone: string | null;
  createdById: string | null;
  createdBy: { id: string; fullName: string } | null;
  ownerId: string | null;
  createdAt: string;
}

const LEAD_STATUSES = ['New', 'Contacted', 'Qualified', 'Converted', 'Disqualified'] as const;

const LEAD_STATUS_LABEL: Record<(typeof LEAD_STATUSES)[number], StringKey> = {
  New: 'leads.statuses.New',
  Contacted: 'leads.statuses.Contacted',
  Qualified: 'leads.statuses.Qualified',
  Converted: 'leads.statuses.Converted',
  Disqualified: 'leads.statuses.Disqualified',
};

const LEAD_STATUS_TONE: Record<(typeof LEAD_STATUSES)[number], BadgeTone> = {
  New: 'neutral',
  Contacted: 'warning',
  Qualified: 'signal',
  Converted: 'agent',
  Disqualified: 'danger',
};

function leadStatusLabel(status: string, t: (key: StringKey) => string): string {
  const key = (LEAD_STATUS_LABEL as Record<string, StringKey>)[status];
  return key ? t(key) : status;
}

const leadsKey = ['leads'] as const;

function useLeads(search: string) {
  const query = new URLSearchParams();
  if (search.trim()) query.set('search', search.trim());
  return useQuery({
    queryKey: ['leads', search.trim()],
    queryFn: () => api.get<LeadRow[]>(`/leads?${query.toString()}`),
  });
}

export function LeadsPage() {
  const t = useT();
  const dir = useDirection();
  const qc = useQueryClient();
  const views = useCrmViews('person', { noun: t('people.list.title'), defaultSort: 'createdAt' });
  const [createOpen, setCreateOpen] = useState(false);
  const location = useLocation();
  const nav = useNavigate();
  useEffect(() => {
    if (new URLSearchParams(location.search).get('new') === '1') {
      setCreateOpen(true);
      nav(location.pathname, { replace: true });
    }
  }, [location.search, nav]);

  const leads = useLeads(views.search);

  const rows = useMemo(() => {
    const list = [...(leads.data ?? [])];
    if (views.sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
    else if (views.sort === 'status') list.sort((a, b) => a.status.localeCompare(b.status));
    else list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return list;
  }, [leads.data, views.sort]);

  const invalidate = () => void qc.invalidateQueries({ queryKey: leadsKey });

  const convertLead = useMutation({
    mutationFn: (id: string) => api.post<{ lead: LeadRow; customer: unknown }>(`/leads/${id}/convert`),
    onSuccess: invalidate,
  });

  const setLeadStatus = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      api.patch<LeadRow>(`/leads/${id}`, { status }),
    onSuccess: invalidate,
  });

  const removeMany = useMutation({
    mutationFn: async (ids: string[]) => {
      await Promise.all(ids.map((id) => api.delete(`/leads/${id}`)));
    },
    onSuccess: invalidate,
  });

  const statusOptions = LEAD_STATUSES.map((s) => ({ value: s, label: leadStatusLabel(s, t) }));

  const nameCell = (lead: LeadRow) => (
    <button type="button" tabIndex={-1} className="flex min-w-0 max-w-full items-center gap-2 text-start">
      <RecordAvatar name={lead.name} />
      <span className="truncate text-sm font-medium text-ink">{lead.name}</span>
    </button>
  );

  const columns: ListColumn<LeadRow>[] = [
    { id: 'name', label: 'list.col.name', icon: Type, size: 'minmax(11rem, 3fr)', render: nameCell },
    {
      id: 'email',
      label: 'list.col.emails',
      icon: Mail,
      size: 'minmax(10rem, 2fr)',
      render: (lead) => lead.email,
    },
    {
      id: 'createdBy',
      label: 'list.col.createdBy',
      icon: UserRound,
      size: 'minmax(6rem, 1.25fr)',
      render: (lead) => lead.createdBy?.fullName ?? null,
    },
    {
      id: 'company',
      label: 'list.col.company',
      icon: Building2,
      size: 'minmax(8rem, 1.75fr)',
      render: (lead) => lead.company,
    },
    {
      id: 'phone',
      label: 'list.col.phones',
      icon: Phone,
      size: 'minmax(8rem, 1.5fr)',
      render: (lead) => lead.phone,
    },
    {
      id: 'createdAt',
      label: 'list.col.created',
      icon: CalendarPlus,
      size: '7rem',
      render: (lead) => formatDate(lead.createdAt, dir.locale),
    },
    {
      id: 'jobTitle',
      label: 'list.col.jobTitle',
      icon: UserRound,
      size: 'minmax(8rem, 1.5fr)',
      render: (lead) => lead.jobTitle,
    },
    {
      id: 'status',
      label: 'list.col.status',
      icon: Send,
      size: '8rem',
      render: (lead) => (
        <ListBadgeSelect
          value={(LEAD_STATUSES.includes(lead.status as (typeof LEAD_STATUSES)[number]) ? lead.status : 'New') as (typeof LEAD_STATUSES)[number]}
          options={statusOptions}
          toneFor={(s) => LEAD_STATUS_TONE[s]}
          ariaLabel={t('leads.status')}
          onChange={(status) => setLeadStatus.mutate({ id: lead.id, status })}
        />
      ),
    },
  ];

  const footerCells = [
    {
      col: 'email',
      render: (list: LeadRow[]) => {
        const unique = new Set(list.map((l) => l.email?.trim().toLowerCase()).filter(Boolean)).size;
        return `${t('list.footer.unique')} ${unique}`;
      },
    },
    {
      col: 'phone',
      render: (list: LeadRow[]) => {
        if (list.length === 0) return null;
        const empty = list.filter((l) => !l.phone).length;
        return `${Math.round((empty / list.length) * 100)}% ${t('list.footer.empty')}`;
      },
    },
    {
      col: 'createdAt',
      render: (list: LeadRow[]) => {
        if (list.length === 0) return null;
        const stamps = list.map((l) => new Date(l.createdAt).getTime());
        const earliest = formatDate(new Date(Math.min(...stamps)).toISOString(), dir.locale);
        const latest = formatDate(new Date(Math.max(...stamps)).toISOString(), dir.locale);
        return (
          <span className="flex min-w-0 items-center gap-1">
            <ListBadge>{t('list.footer.earliest')}</ListBadge>
            <span className="truncate">{earliest}</span>
            <span className="opacity-60">·</span>
            <ListBadge>{t('list.footer.latest')}</ListBadge>
            <span className="truncate">{latest}</span>
          </span>
        );
      },
    },
  ];

  return (
    <>
      <ListView<LeadRow>
        title={t('people.list.title')}
        eyebrow={t('people.list.eyebrow')}
        addLabel={t('list.newPerson')}
        onAdd={() => setCreateOpen(true)}
        noun={t('people.list.title')}
        objectType="people"
        columns={columns}
        rows={rows}
        isPending={leads.isPending}
        isError={leads.isError}
        keyOf={(l) => l.id}
        viewSwitcher={views.switcher}
        filterValue={views.search}
        onFilter={views.setSearch}
        sortValue={views.sort}
        onSort={views.setSort}
        sortOptions={[
          { value: 'createdAt', label: t('list.col.created') },
          { value: 'name', label: t('list.col.name') },
          { value: 'status', label: t('list.col.status') },
        ]}
        hiddenColumns={views.hidden}
        onHiddenColumnsChange={views.setHidden}
        onDeleteSelected={(ids) => removeMany.mutate(ids)}
        footerCells={footerCells}
        rowActions={(lead) => (
          <Menu
            button={
              <span
                aria-label={t('list.options')}
                role="img"
                className="flex h-6 w-6 items-center justify-center rounded text-slate-soft transition-colors hover:bg-mist hover:text-ink"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreHorizontal className="h-4 w-4" />
              </span>
            }
          >
            <MenuItem
              icon={Send}
              label={t('leads.convert')}
              onClick={() => convertLead.mutate(lead.id)}
            />
          </Menu>
        )}
      />
      <CreateLeadDrawer open={createOpen} onClose={() => setCreateOpen(false)} />
    </>
  );
}