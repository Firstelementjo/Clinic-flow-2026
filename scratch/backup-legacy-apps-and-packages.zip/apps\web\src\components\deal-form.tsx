import { useState, type FormEvent } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import {
  CreateRecordDrawer,
  FormSection,
  TextField,
  SelectField,
  TextAreaField,
  TagsField,
  useFormOptions,
  useEmployees,
  textOrUndefined,
  numberOrUndefined,
} from './CreateRecordDrawer';

const dealsKey = ['deals'] as const;

const PIPELINE_STAGES = ['Prospect', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'] as const;

const STAGE_LABEL: Record<(typeof PIPELINE_STAGES)[number], StringKey> = {
  Prospect: 'deals.stages.Prospect',
  Qualified: 'deals.stages.Qualified',
  Proposal: 'deals.stages.Proposal',
  Negotiation: 'deals.stages.Negotiation',
  Won: 'deals.stages.Won',
  Lost: 'deals.stages.Lost',
};

interface DealRow {
  id: string;
  name: string;
  company: string | null;
  value: number;
  currency: string;
  pipeline: string;
  stage: string;
  closedWon: boolean;
}

interface CreateDealDrawerProps {
  open: boolean;
  onClose: () => void;
}

const emptyForm = {
  name: '',
  company: '',
  value: '',
  currency: 'USD',
  stage: 'Prospect',
  expectedClose: '',
  probability: '',
  priority: '',
  source: '',
  description: '',
  ownerId: '',
  notes: '',
} as const;

export function CreateDealDrawer({ open, onClose }: CreateDealDrawerProps) {
  const t = useT();
  const qc = useQueryClient();
  const opts = useFormOptions();
  const ownerOptions = (useEmployees().data ?? []).map((employee) => ({
    value: employee.userId,
    label: employee.fullName,
  }));

  const [form, setForm] = useState({ ...emptyForm, tags: [] as string[] });
  const set = (field: keyof typeof emptyForm) => (e: { target: { value: string } }) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const reset = () => setForm({ ...emptyForm, tags: [] });

  const create = useMutation({
    mutationFn: () =>
      api.post<DealRow>('/deals', {
        name: form.name.trim(),
        company: textOrUndefined(form.company),
        value: numberOrUndefined(form.value) ?? 0,
        currency: form.currency || 'USD',
        stage: form.stage || 'Prospect',
        expectedClose: form.expectedClose || undefined,
        probability: numberOrUndefined(form.probability),
        priority: form.priority || undefined,
        dealSource: textOrUndefined(form.source),
        description: textOrUndefined(form.description),
        ownerId: form.ownerId || undefined,
        tags: form.tags,
        notes: textOrUndefined(form.notes),
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: dealsKey });
      reset();
      onClose();
    },
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (form.name.trim()) create.mutate();
  };

  const close = () => {
    reset();
    onClose();
  };

  const stageOptions = PIPELINE_STAGES.map((stage) => ({ value: stage, label: t(STAGE_LABEL[stage]) }));

  return (
    <CreateRecordDrawer
      open={open}
      onClose={close}
      title={t('form.opportunity.title')}
      description={t('form.opportunity.about')}
      submitLabel={t('form.opportunity.save')}
      isSubmitting={create.isPending}
      canSubmit={Boolean(form.name.trim())}
      onSubmit={onSubmit}
    >
      <FormSection title={t('form.section.opportunityInfo')}>
        <TextField label={t('form.field.name')} required autoFocus value={form.name} onChange={set('name')} />
        <TextField label={t('form.field.amount')} type="number" min={0} inputMode="decimal" dir="ltr" value={form.value} onChange={set('value')} />
        <TextField label={t('form.field.currency')} value={form.currency} onChange={set('currency')} />
        <SelectField label={t('form.field.stage')} options={stageOptions} value={form.stage} onChange={set('stage')} />
        <TextField label={t('form.field.closeDate')} type="date" value={form.expectedClose} onChange={set('expectedClose')} />
      </FormSection>

      <FormSection title={t('form.section.accountContact')}>
        <TextField label={t('form.field.company')} value={form.company} onChange={set('company')} />
        <SelectField label={t('form.field.owner')} placeholder="—" options={ownerOptions} value={form.ownerId} onChange={set('ownerId')} />
      </FormSection>

      <FormSection title={t('form.section.salesInfo')}>
        <SelectField label={t('form.field.source')} placeholder="—" options={opts.leadSources} value={form.source} onChange={set('source')} />
        <SelectField label={t('form.field.priority')} placeholder="—" options={opts.priorities} value={form.priority} onChange={set('priority')} />
        <TextField label={t('form.field.probability')} type="number" min={0} max={100} inputMode="decimal" dir="ltr" value={form.probability} onChange={set('probability')} />
      </FormSection>

      <FormSection title={t('form.section.crm')}>
        <TagsField label={t('form.field.tags')} value={form.tags} onChange={(tags) => setForm((prev) => ({ ...prev, tags }))} placeholder={t('form.field.tagsAdd')} />
        <TextAreaField label={t('form.field.description')} wide value={form.description} onChange={set('description')} />
        <TextAreaField label={t('form.field.notes')} wide value={form.notes} onChange={set('notes')} />
      </FormSection>
    </CreateRecordDrawer>
  );
}