import { describe, expect, it } from 'vitest';
import {
  EmptyDocumentError,
  MAX_UPLOAD_BYTES,
  UnsupportedFormatError,
  isAllowedMimeType,
  parseDocument,
} from './parsers';

const buffer = (text: string) => Buffer.from(text, 'utf8');

describe('upload validation', () => {
  it('allows the document types the pipeline can actually parse', () => {
    expect(isAllowedMimeType('text/plain')).toBe(true);
    expect(isAllowedMimeType('application/pdf')).toBe(true);
  });

  it('rejects executables and images, which have no text to index', () => {
    expect(isAllowedMimeType('application/x-msdownload')).toBe(false);
    expect(isAllowedMimeType('image/png')).toBe(false);
  });

  it('caps uploads at 20MB', () => {
    expect(MAX_UPLOAD_BYTES).toBe(20 * 1024 * 1024);
  });
});

describe('parseDocument', () => {
  it('reads plain text and markdown as-is', async () => {
    const result = await parseDocument(buffer('# Refunds\n\nWithin 3 days.'), 'text/markdown');
    expect(result.text).toContain('Refunds');
  });

  it('labels CSV values with their headers so rows retrieve as sentences', async () => {
    const csv = 'plan,price,currency\nPro,49,SAR\nBasic,19,SAR';
    const result = await parseDocument(buffer(csv), 'text/csv');

    expect(result.text).toContain('plan: Pro, price: 49, currency: SAR');
    // A bare grid of numbers would embed as noise.
    expect(result.text).not.toBe(csv);
  });

  it('handles quoted CSV fields containing commas', async () => {
    const csv = 'name,note\n"Al-Salem, Noura","Prefers WhatsApp, mornings"';
    const result = await parseDocument(buffer(csv), 'text/csv');
    expect(result.text).toContain('name: Al-Salem, Noura');
  });

  it('flattens JSON to path/value lines so structure survives embedding', async () => {
    const json = JSON.stringify({ policy: { refundDays: 3, channels: ['whatsapp', 'email'] } });
    const result = await parseDocument(buffer(json), 'application/json');

    expect(result.text).toContain('policy.refundDays: 3');
    expect(result.text).toContain('policy.channels[0]: whatsapp');
  });

  it('reports invalid JSON as an unreadable document, not a crash', async () => {
    await expect(parseDocument(buffer('{not json'), 'application/json')).rejects.toThrowError(
      EmptyDocumentError,
    );
  });

  it('refuses a type it cannot parse', async () => {
    await expect(parseDocument(buffer('binary'), 'image/png')).rejects.toThrowError(
      UnsupportedFormatError,
    );
  });

  it('fails an empty file rather than indexing a document with no content', async () => {
    await expect(parseDocument(buffer('   \n  '), 'text/plain')).rejects.toThrowError(
      EmptyDocumentError,
    );
  });

  it('preserves Arabic text through parsing', async () => {
    const result = await parseDocument(buffer('سياسة الاسترجاع خلال ٧ أيام'), 'text/plain');
    expect(result.text).toContain('سياسة الاسترجاع');
  });
});
