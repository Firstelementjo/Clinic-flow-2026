import { useState, type FormEvent } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button, Field, StatusChip } from '@firstelement/ui';
import { ChannelType, type ChannelConnectionView } from '@firstelement/shared';
import { api } from '../lib/api';
import { useT } from '../lib/i18n';

/**
 * Credential fields per channel — names only, matching what the API
 * validates. The values are write-only: nothing here ever renders a
 * stored secret, because the API does not return one to render.
 */
const FIELDS: Record<string, string[]> = {
  [ChannelType.WHATSAPP]: ['phoneNumberId', 'accessToken', 'appSecret', 'verifyToken'],
  [ChannelType.INSTAGRAM]: ['pageId', 'pageAccessToken', 'appSecret', 'verifyToken'],
  [ChannelType.MESSENGER]: ['pageId', 'pageAccessToken', 'appSecret', 'verifyToken'],
  [ChannelType.TELEGRAM]: ['botToken', 'webhookSecret'],
};

export function ChannelCredentials({
  projectId,
  channel,
  apiUrl,
}: {
  projectId: string;
  channel: ChannelConnectionView;
  apiUrl: string;
}) {
  const t = useT();
  const queryClient = useQueryClient();
  const fields = FIELDS[channel.channel] ?? [];
  const [values, setValues] = useState<Record<string, string>>({});

  const save = useMutation({
    mutationFn: () =>
      api.put<ChannelConnectionView>(
        `/projects/${projectId}/channels/${channel.id}/credentials`,
        { credentials: values },
      ),
    onSuccess: () => {
      // Clear the form: keeping typed secrets in memory after they are
      // stored serves no purpose.
      setValues({});
      void queryClient.invalidateQueries({ queryKey: ['channels', projectId] });
    },
  });

  if (fields.length === 0) return null;

  const webhookUrl =
    channel.channel === ChannelType.TELEGRAM
      ? `${apiUrl}/api/webhooks/telegram/${channel.id}`
      : `${apiUrl}/api/webhooks/meta/${channel.id}`;

  const onSubmit = (event: FormEvent) => {
    event.preventDefault();
    save.mutate();
  };

  return (
    <div className="mt-2 w-full rounded border border-hairline bg-mist/30 p-3">
      <div className="mb-2 flex items-center gap-2">
        <span className="fe-eyebrow">{t('creds.title')}</span>
        <StatusChip tone={channel.hasCredentials ? 'human' : 'neutral'}>
          {channel.hasCredentials ? t('creds.configured') : t('creds.missing')}
        </StatusChip>
      </div>

      <div className="mb-3">
        <p className="fe-eyebrow">{t('creds.webhook')}</p>
        <p className="fe-mono break-all text-xs text-slate" dir="ltr">
          {webhookUrl}
        </p>
        <p className="mt-1 text-xs text-slate">{t('creds.webhookNote')}</p>
      </div>

      <form onSubmit={onSubmit} className="flex flex-col gap-2">
        <div className="grid gap-2 sm:grid-cols-2">
          {fields.map((field) => (
            <Field
              key={field}
              label={field}
              // type=password so a shoulder-surfer in a support office
              // does not read an access token off the screen.
              type="password"
              autoComplete="off"
              dir="ltr"
              value={values[field] ?? ''}
              onChange={(e) => setValues({ ...values, [field]: e.target.value })}
            />
          ))}
        </div>

        <p className="text-xs text-slate">{t('creds.note')}</p>

        <div className="flex items-center gap-2">
          <Button
            type="submit"
            size="sm"
            variant="primary"
            loading={save.isPending}
            disabled={fields.some((field) => !values[field]?.trim())}
          >
            {t('creds.set')}
          </Button>
          {save.isSuccess && <span className="text-xs text-signal">{t('creds.saved')}</span>}
          {save.isError && (
            <span className="text-xs text-danger">{(save.error as Error).message}</span>
          )}
        </div>
      </form>
    </div>
  );
}
