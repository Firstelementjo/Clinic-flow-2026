import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { organizationScope, type TenantContext } from '@firstelement/database';

@Injectable()
export class AccountsService {
  constructor(private readonly prisma: PrismaService) {}

  async list(ctx: TenantContext, search?: string, industry?: string) {
    const where: Record<string, unknown> = { ...organizationScope(ctx) };
    if (industry) where.industry = industry;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { industry: { contains: search, mode: 'insensitive' } },
        { website: { contains: search, mode: 'insensitive' } },
      ];
    }

    const accounts = await this.prisma.client.account.findMany({
      where,
      select: {
        id: true,
        name: true,
        companyType: true,
        industry: true,
        website: true,
        size: true,
        phone: true,
        email: true,
        linkedin: true,
        country: true,
        city: true,
        address: true,
        postalCode: true,
        description: true,
        ownerId: true,
        createdById: true,
        createdBy: { select: { id: true, fullName: true } },
        owner: { select: { id: true, fullName: true } },
        status: true,
        leadSource: true,
        priority: true,
        tags: true,
        notes: true,
        createdAt: true,
        _count: {
          select: { deals: true, leads: true, customers: true },
        },
      },
      orderBy: { name: 'asc' },
    });

    return accounts.map(({ _count, ...account }) => ({
      ...account,
      dealCount: _count.deals,
      leadCount: _count.leads,
      customerCount: _count.customers,
    }));
  }

  async getById(ctx: TenantContext, id: string) {
    const account = await this.prisma.client.account.findFirst({
      where: { id, ...organizationScope(ctx) },
      select: {
        id: true,
        name: true,
        companyType: true,
        industry: true,
        website: true,
        size: true,
        phone: true,
        email: true,
        linkedin: true,
        country: true,
        city: true,
        address: true,
        postalCode: true,
        description: true,
        ownerId: true,
        createdById: true,
        createdBy: { select: { id: true, fullName: true } },
        owner: { select: { id: true, fullName: true } },
        status: true,
        leadSource: true,
        priority: true,
        tags: true,
        notes: true,
        createdAt: true,
        updatedAt: true,
        deals: { select: { id: true, name: true, stage: true, value: true, currency: true, closedWon: true } },
        leads: { select: { id: true, name: true, status: true } },
        customers: { select: { id: true, cxId: true, displayName: true, primaryEmail: true } },
      },
    });

    if (!account) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Account not found' });
    }

    return account;
  }

  async create(
    ctx: TenantContext,
    name: string,
    data: {
      companyType?: string;
      industry?: string;
      website?: string;
      size?: string;
      phone?: string;
      email?: string;
      linkedin?: string;
      country?: string;
      city?: string;
      address?: string;
      postalCode?: string;
      description?: string;
      ownerId?: string;
      status?: string;
      leadSource?: string;
      priority?: string;
      tags?: string[];
      notes?: string;
    } = {},
  ) {
    return this.prisma.client.account.create({
      data: {
        ...organizationScope(ctx),
        name,
        companyType: data.companyType || undefined,
        industry: data.industry || undefined,
        website: data.website || undefined,
        size: data.size || undefined,
        phone: data.phone || undefined,
        email: data.email || undefined,
        linkedin: data.linkedin || undefined,
        country: data.country || undefined,
        city: data.city || undefined,
        address: data.address || undefined,
        postalCode: data.postalCode || undefined,
        description: data.description || undefined,
        ownerId: data.ownerId || undefined,
        createdById: ctx.userId,
        status: data.status || undefined,
        leadSource: data.leadSource || undefined,
        priority: data.priority || undefined,
        tags: data.tags ?? [],
        notes: data.notes || undefined,
      },
      select: {
        id: true,
        name: true,
        companyType: true,
        industry: true,
        website: true,
        size: true,
        phone: true,
        email: true,
        linkedin: true,
        country: true,
        city: true,
        address: true,
        postalCode: true,
        description: true,
        ownerId: true,
        createdById: true,
        createdBy: { select: { id: true, fullName: true } },
        status: true,
        leadSource: true,
        priority: true,
        tags: true,
        notes: true,
        createdAt: true,
      },
    });
  }

  async update(
    ctx: TenantContext,
    id: string,
    data: {
      name?: string;
      companyType?: string;
      industry?: string;
      website?: string;
      size?: string;
      phone?: string;
      email?: string;
      linkedin?: string;
      country?: string;
      city?: string;
      address?: string;
      postalCode?: string;
      description?: string;
      ownerId?: string;
      status?: string;
      leadSource?: string;
      priority?: string;
      tags?: string[];
      notes?: string;
    },
  ) {
    await this.assertOwned(ctx, id);

    const updateData: Record<string, unknown> = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.companyType !== undefined) updateData.companyType = data.companyType;
    if (data.industry !== undefined) updateData.industry = data.industry;
    if (data.website !== undefined) updateData.website = data.website;
    if (data.size !== undefined) updateData.size = data.size;
    if (data.phone !== undefined) updateData.phone = data.phone;
    if (data.email !== undefined) updateData.email = data.email;
    if (data.linkedin !== undefined) updateData.linkedin = data.linkedin;
    if (data.country !== undefined) updateData.country = data.country;
    if (data.city !== undefined) updateData.city = data.city;
    if (data.address !== undefined) updateData.address = data.address;
    if (data.postalCode !== undefined) updateData.postalCode = data.postalCode;
    if (data.description !== undefined) updateData.description = data.description;
    if (data.ownerId !== undefined) updateData.ownerId = data.ownerId;
    if (data.status !== undefined) updateData.status = data.status;
    if (data.leadSource !== undefined) updateData.leadSource = data.leadSource;
    if (data.priority !== undefined) updateData.priority = data.priority;
    if (data.tags !== undefined) updateData.tags = data.tags;
    if (data.notes !== undefined) updateData.notes = data.notes;

    return this.prisma.client.account.update({
      where: { id },
      data: updateData,
      select: {
        id: true,
        name: true,
        companyType: true,
        industry: true,
        website: true,
        size: true,
        phone: true,
        email: true,
        linkedin: true,
        country: true,
        city: true,
        address: true,
        postalCode: true,
        description: true,
        ownerId: true,
        status: true,
        leadSource: true,
        priority: true,
        tags: true,
        notes: true,
        updatedAt: true,
      },
    });
  }

  async delete(ctx: TenantContext, id: string) {
    await this.assertOwned(ctx, id);
    return this.prisma.client.account.delete({ where: { id }, select: { id: true } });
  }

  private async assertOwned(ctx: TenantContext, id: string) {
    const existing = await this.prisma.client.account.findFirst({
      where: { id, ...organizationScope(ctx) },
      select: { id: true },
    });

    if (!existing) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Account not found' });
    }
  }
}