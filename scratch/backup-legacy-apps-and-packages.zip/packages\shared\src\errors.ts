/**
 * Error codes the frontend can branch on. HTTP status alone is not enough:
 * "you are not a member of this project" and "this project does not exist"
 * are both 404 on the wire (we do not leak existence across tenants), but
 * the API needs to tell them apart internally.
 */
export const ErrorCode = {
  INVALID_CREDENTIALS: 'INVALID_CREDENTIALS',
  SESSION_EXPIRED: 'SESSION_EXPIRED',
  FORBIDDEN: 'FORBIDDEN',
  NOT_FOUND: 'NOT_FOUND',
  VALIDATION_FAILED: 'VALIDATION_FAILED',
  CONFLICT: 'CONFLICT',
  RATE_LIMITED: 'RATE_LIMITED',
  PROVIDER_UNAVAILABLE: 'PROVIDER_UNAVAILABLE',
  INTERNAL: 'INTERNAL',
} as const;
export type ErrorCode = (typeof ErrorCode)[keyof typeof ErrorCode];

export interface ApiErrorBody {
  code: ErrorCode;
  message: string;
  /** Field-level messages for VALIDATION_FAILED. */
  details?: Record<string, string[]>;
  requestId?: string;
}
