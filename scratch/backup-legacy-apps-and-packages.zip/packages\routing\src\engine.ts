import type { PrismaClient } from '@firstelement/database';
import { DomainEventType, type DomainEventPublisher } from '@firstelement/events';
import { selectAssignee, type RoutingCandidate, type RoutingOutcome } from './strategy';
import type { AvailabilityWindow } from './working-hours';

export interface RouteJob {
  organizationId: string;
  projectId: string;
  conversationId: string;
  escalationId?: string;
}

export type RouteResult =
  | { status: 'assigned'; employeeId: string; employeeName: string; ruleName: string | null }
  | { status: 'queued'; reason: string; blockedAt: RoutingOutcome['blockedAt'] }
  | { status: 'skipped'; reason: string };

/**
 * The routing engine (plan §10).
 *
 * Deterministic by design: given the same escalation and the same roster,
 * it always picks the same person. An ops manager has to be able to
 * answer "why did this go to Layla?" — and a router that shuffles cannot
 * be tested, tuned or trusted.
 *
 * When nobody qualifies, the escalation stays in the unassigned queue with
 * the stage that blocked it recorded. "Nobody is on shift" and "everyone
 * is at capacity" are different problems and get different answers.
 */
export class RoutingEngine {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: DomainEventPublisher,
  ) {}

  async route(job: RouteJob): Promise<RouteResult> {
    const conversation = await this.prisma.conversation.findFirst({
      where: {
        id: job.conversationId,
        organizationId: job.organizationId,
        projectId: job.projectId,
      },
      select: { id: true, mode: true, assignedEmployeeId: true },
    });

    if (!conversation) return { status: 'skipped', reason: 'Conversation not found' };
    // A conversation someone already owns is not re-routed: reassigning
    // under an agent mid-reply is worse than a slightly uneven queue.
    if (conversation.assignedEmployeeId) {
      return { status: 'skipped', reason: 'Already assigned' };
    }
    if (conversation.mode !== 'HUMAN') {
      return { status: 'skipped', reason: 'Conversation is still with the AI' };
    }

    const escalation = job.escalationId
      ? await this.prisma.escalation.findFirst({
          where: { id: job.escalationId, projectId: job.projectId },
          select: { id: true, intent: true, department: true, status: true },
        })
      : null;

    const rule = await this.matchRule(job, escalation);
    const candidates = await this.loadCandidates(job);

    const outcome = selectAssignee(candidates, {
      department: rule?.department ?? escalation?.department ?? null,
      requiredSkill: rule?.requiredSkill ?? null,
      strategy: rule?.strategy ?? 'LEAST_LOADED',
    });

    if (!outcome.candidate) {
      const reason = describeBlock(outcome);

      if (escalation) {
        await this.prisma.escalation.update({
          where: { id: escalation.id },
          data: { status: 'PENDING' },
        });
      }

      return { status: 'queued', reason, blockedAt: outcome.blockedAt };
    }

    const chosen = outcome.candidate;

    await this.prisma.$transaction(async (tx) => {
      // Conditional on still being unassigned: two escalations landing at
      // once must not both hand the same conversation to different people.
      const claimed = await tx.conversation.updateMany({
        where: { id: job.conversationId, assignedEmployeeId: null },
        data: { assignedEmployeeId: chosen.employeeId },
      });
      if (claimed.count === 0) return;

      if (escalation) {
        await tx.escalation.update({
          where: { id: escalation.id },
          data: {
            status: 'ASSIGNED',
            assignedEmployeeId: chosen.employeeId,
            assignedAt: new Date(),
          },
        });
      }

      await recountActiveConversations(tx as unknown as PrismaClient, chosen.employeeId);
    });

    this.events.publish({
      type: DomainEventType.CONVERSATION_ASSIGNED,
      organizationId: job.organizationId,
      projectId: job.projectId,
      aggregateId: job.conversationId,
      aggregateType: 'Conversation',
      payload: { employeeId: chosen.employeeId, previousEmployeeId: null, reason: 'ROUTING' },
      occurredAt: new Date(),
    });

    return {
      status: 'assigned',
      employeeId: chosen.employeeId,
      employeeName: chosen.fullName,
      ruleName: rule?.name ?? null,
    };
  }

  /** First rule whose intent and department match, by ascending priority. */
  private async matchRule(
    job: RouteJob,
    escalation: { intent: string | null; department: string | null } | null,
  ) {
    const rules = await this.prisma.routingRule.findMany({
      where: { organizationId: job.organizationId, projectId: job.projectId, isEnabled: true },
      orderBy: [{ priority: 'asc' }, { id: 'asc' }],
    });

    return (
      rules.find((rule) => {
        // A null on the rule is a wildcard, not a requirement to be null.
        const intentMatches = !rule.intent || rule.intent === escalation?.intent;
        const departmentMatches = !rule.department || rule.department === escalation?.department;
        return intentMatches && departmentMatches;
      }) ?? null
    );
  }

  /**
   * Everyone who could take this conversation: employees of the
   * organization who are members of *this* project. Membership is the
   * first filter, so routing can never hand a conversation to someone who
   * would get a 404 opening it.
   */
  private async loadCandidates(job: RouteJob): Promise<RoutingCandidate[]> {
    const employees = await this.prisma.employee.findMany({
      where: {
        organizationId: job.organizationId,
        user: {
          isActive: true,
          memberships: { some: { projectId: job.projectId } },
        },
      },
      select: {
        id: true,
        userId: true,
        department: true,
        availabilityStatus: true,
        activeConversationCount: true,
        maxConcurrentConversations: true,
        user: { select: { fullName: true } },
        skills: { select: { skill: true, level: true } },
        availability: {
          select: { dayOfWeek: true, startMinute: true, endMinute: true, timezone: true },
        },
      },
    });

    return employees.map((employee) => ({
      employeeId: employee.id,
      userId: employee.userId,
      fullName: employee.user.fullName,
      department: employee.department,
      availabilityStatus: employee.availabilityStatus,
      activeConversationCount: employee.activeConversationCount,
      maxConcurrentConversations: employee.maxConcurrentConversations,
      skills: employee.skills,
      windows: employee.availability as AvailabilityWindow[],
    }));
  }
}

/**
 * Recomputes an employee's live workload from the conversations table.
 *
 * Deliberately a recount rather than an increment/decrement pair: counters
 * drift the first time a process dies between two writes, and a drifted
 * workload silently starves the busiest agent or overloads them. The read
 * is cheap and indexed.
 */
export async function recountActiveConversations(
  prisma: PrismaClient,
  employeeId: string,
): Promise<number> {
  const count = await prisma.conversation.count({
    where: { assignedEmployeeId: employeeId, status: { in: ['OPEN', 'PENDING'] } },
  });

  await prisma.employee.update({
    where: { id: employeeId },
    data: { activeConversationCount: count },
  });

  return count;
}

function describeBlock(outcome: RoutingOutcome): string {
  switch (outcome.blockedAt) {
    case 'MEMBERSHIP':
      return 'No employees are assigned to this project';
    case 'DEPARTMENT':
      return 'No employee in the required department';
    case 'SKILL':
      return 'No employee has the required skill';
    case 'STATUS':
      return 'Nobody is available right now';
    case 'WORKING_HOURS':
      return 'Nobody is inside their working hours';
    case 'WORKLOAD':
      return 'Everyone eligible is at their conversation limit';
    default:
      return 'No eligible employee found';
  }
}
