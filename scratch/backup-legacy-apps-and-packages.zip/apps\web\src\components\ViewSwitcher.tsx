import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, ChevronDown, Heart, List as ListIcon, Lock, MoreHorizontal, Pencil, Plus, Star, Table2, Trash2 } from 'lucide-react';
import { Button } from '@firstelement/ui';
import { useT } from '../lib/i18n';
import type { CrmView } from '../lib/views';

export interface ViewSwitcherProps {
  views: CrmView[];
  activeViewId: string | null;
  noun: string;
  onSelect: (id: string) => void;
  onCreate: (name: string) => void;
  onRename: (id: string, name: string) => void;
  onDelete: (id: string) => void;
  onToggleFavorite: (id: string, favorite: boolean) => void;
  busy?: boolean;
}

/**
 * The saved-view switcher that shows in the list toolbar beside the object
 * title (e.g. "All Companies ▾"). The popover doubles as the inline
 * create/edit form — spec keeps it out of a modal — and each saved view
 * owns a small manage menu for favorite / rename / delete. The default
 * view (a lock icon) has no menu: it is the whole table and it is locked.
 */
export function ViewSwitcher({
  views,
  activeViewId,
  noun,
  onSelect,
  onCreate,
  onRename,
  onDelete,
  onToggleFavorite,
  busy = false,
}: ViewSwitcherProps) {
  const t = useT();
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<'list' | 'form'>('list');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const triggerRef = useRef<HTMLButtonElement>(null);
  const [anchor, setAnchor] = useState<{ top: number; right: number } | null>(null);
  const [rowMenu, setRowMenu] = useState<{ id: string; top: number; left: number } | null>(null);

  const activeView = views.find((v) => v.id === activeViewId) ?? null;
  const allLabel = `${t('list.footer.all')} ${noun}`;
  const triggerLabel = activeView && !activeView.isDefault ? activeView.name : allLabel;

  // Position the popover next to the trigger with fixed coords so it escapes
  // the overflow-hidden list card and renders at full, close-fitting size.
  useEffect(() => {
    if (!open) {
      setAnchor(null);
      setRowMenu(null);
      return;
    }
    const el = triggerRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setAnchor({ top: r.bottom + 4, right: window.innerWidth - r.right });
  }, [open]);

  const openForm = (view: CrmView | null) => {
    setEditingId(view?.id ?? null);
    setName(view ? view.name : '');
    setMode('form');
  };

  const submitForm = () => {
    const trimmed = name.trim();
    if (!trimmed) return;
    if (editingId) onRename(editingId, trimmed);
    else onCreate(trimmed);
    setMode('list');
    setEditingId(null);
    setName('');
  };
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <div ref={containerRef} className="relative">
      <button
        ref={triggerRef}
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={t('views.switch')}
        className="flex min-w-0 items-center gap-1 rounded px-1 py-0.5 text-start"
      >
        <ListIcon aria-hidden="true" className="h-4 w-4 shrink-0 text-slate-soft" />
        <span className="truncate font-medium transition-colors hover:text-ink">{triggerLabel}</span>
        <ChevronDown aria-hidden="true" className="h-3.5 w-3.5 shrink-0 text-slate-soft" />
      </button>

      {open && anchor
        ? createPortal(
            <>
              <button
                type="button"
                aria-hidden="true"
                tabIndex={-1}
                onClick={() => {
                  setOpen(false);
                  setMode('list');
                }}
                className="fixed inset-0 z-20 cursor-default"
              />
              <div
                role="menu"
                style={{ top: anchor.top, right: anchor.right }}
                className="fixed z-30 min-w-60 max-w-80 w-auto max-h-[min(80vh,28rem)] overflow-auto rounded-lg border border-hairline bg-surface p-1 shadow-pop"
              >
                {mode === 'form' ? (
              <div className="p-2.5">
                <p className="fe-eyebrow">{t(editingId ? 'views.edit' : 'views.create')}</p>
                <label className="mt-2 block">
                  <span className="text-xs text-slate">{t('views.name')}</span>
                  <input
                    autoFocus
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') submitForm();
                      if (e.key === 'Escape') setMode('list');
                    }}
                    placeholder={t('views.add')}
                    className="mt-1 h-7 w-full rounded border border-hairline bg-surface px-2.5 text-xs text-ink placeholder:text-slate-soft focus:border-signal"
                  />
                </label>
                <label className="mt-2 block">
                  <span className="text-xs text-slate">{t('views.type')}</span>
                  <select
                    value="table"
                    disabled
                    className="mt-1 h-7 w-full rounded border border-hairline bg-mist px-2.5 text-xs text-slate focus:border-signal"
                  >
                    <option value="table">{t('views.type.table')}</option>
                  </select>
                </label>
                <div className="mt-3 flex justify-end gap-2">
                  <Button type="button" size="sm" variant="ghost" onClick={() => setMode('list')}>
                    {t('common.cancel')}
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="primary"
                    disabled={!name.trim()}
                    loading={busy}
                    onClick={submitForm}
                  >
                    {t(editingId ? 'views.save' : 'views.add')}
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <div className="px-2.5 pb-1 pt-1.5">
                  <p className="fe-eyebrow">{t('views.switch')}</p>
                </div>
                <div className="max-h-80 overflow-auto">
                  {views.map((view) => (
                    <div
                      key={view.id}
                      className="flex items-center gap-1 rounded hover:bg-mist"
                    >
                      <button
                        type="button"
                        role="menuitemradio"
                        aria-checked={view.id === activeViewId}
                        onClick={() => onSelect(view.id)}
                        className="flex min-w-0 flex-1 items-center gap-2 rounded px-2.5 py-1.5 text-start text-xs text-ink"
                      >
                        {view.isDefault ? (
                          <Lock aria-hidden="true" className="h-3.5 w-3.5 shrink-0 text-slate-soft" />
                        ) : view.isFavorite ? (
                          <Star aria-hidden="true" className="h-3.5 w-3.5 shrink-0 text-warning" />
                        ) : (
                          <Table2 aria-hidden="true" className="h-3.5 w-3.5 shrink-0 text-slate-soft" />
                        )}
                        <span className="truncate">{view.isDefault ? allLabel : view.name}</span>
                        {view.id === activeViewId ? (
                          <Check aria-hidden="true" className="ms-auto h-3.5 w-3.5 shrink-0 text-signal" />
                        ) : null}
                      </button>
                      <button
                        type="button"
                        aria-label={t('list.options')}
                        onClick={(e) => {
                          e.stopPropagation();
                          const r = e.currentTarget.getBoundingClientRect();
                          const left = Math.max(8, Math.min(r.left - 40, window.innerWidth - 200));
                          setRowMenu((prev) =>
                            prev?.id === view.id ? null : { id: view.id, top: r.top, left },
                          );
                        }}
                        className="flex h-6 w-6 items-center justify-center rounded text-slate-soft transition-colors hover:bg-mist hover:text-ink"
                      >
                        <MoreHorizontal aria-hidden="true" className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="mt-1 border-t border-hairline pt-1">
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => openForm(null)}
                    className="flex w-full items-center gap-2 rounded px-2.5 py-1.5 text-start text-xs font-medium text-signal transition-colors hover:bg-mist"
                  >
                    <Plus aria-hidden="true" className="h-3.5 w-3.5 shrink-0" />
                    {t('views.add')}
                  </button>
                </div>
              </>
            )}
              </div>
              {rowMenu
                ? (() => {
                    const v = views.find((x) => x.id === rowMenu.id);
                    if (!v) return null;
                    return (
                      <>
                        <button
                          type="button"
                          aria-hidden="true"
                          tabIndex={-1}
                          onClick={() => setRowMenu(null)}
                          className="fixed inset-0 z-40 cursor-default"
                        />
                        <div
                          role="menu"
                          style={{ top: rowMenu.top, left: rowMenu.left }}
                          className="fixed z-50 min-w-44 w-auto rounded-lg border border-hairline bg-surface p-1 shadow-pop"
                        >
                          <button
                            type="button"
                            role="menuitem"
                            onClick={() => {
                              onToggleFavorite(v.id, !v.isFavorite);
                              setRowMenu(null);
                            }}
                            className="flex w-full items-center gap-2 rounded px-2.5 py-1.5 text-start text-xs text-ink transition-colors hover:bg-mist"
                          >
                            <Heart aria-hidden="true" className="h-3.5 w-3.5 shrink-0" />
                            {t(v.isFavorite ? 'views.unfavorite' : 'views.favorite')}
                          </button>
                          <button
                            type="button"
                            role="menuitem"
                            onClick={() => {
                              openForm(v);
                              setRowMenu(null);
                            }}
                            className="flex w-full items-center gap-2 rounded px-2.5 py-1.5 text-start text-xs text-ink transition-colors hover:bg-mist"
                          >
                            <Pencil aria-hidden="true" className="h-3.5 w-3.5 shrink-0" />
                            {t('views.rename')}
                          </button>
                          <button
                            type="button"
                            role="menuitem"
                            onClick={() => {
                              onDelete(v.id);
                              setRowMenu(null);
                            }}
                            className="flex w-full items-center gap-2 rounded px-2.5 py-1.5 text-start text-xs font-medium text-danger transition-colors hover:bg-mist hover:text-danger"
                          >
                            <Trash2 aria-hidden="true" className="h-3.5 w-3.5 shrink-0" />
                            {t('views.delete')}
                          </button>
                        </div>
                      </>
                    );
                  })()
                : null}
            </>,
            document.body,
          )
        : null}
    </div>
  );
}