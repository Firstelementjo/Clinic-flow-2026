import { getConfig, type AppConfig } from '@firstelement/config';
import { MockEmbeddingProvider } from './mock.provider';
import { OpenAIEmbeddingProvider } from './openai.provider';
import { EmbeddingProviderError, type EmbeddingProvider } from './types';

/**
 * Chooses the embedding provider from configuration.
 *
 * A missing key is a startup-time error with a specific message, not a
 * silent fallback to the mock: an environment that thinks it is embedding
 * with OpenAI while actually producing hashed bag-of-words vectors would
 * give plausible-looking, quietly useless retrieval.
 */
export function createEmbeddingProvider(config: AppConfig = getConfig()): EmbeddingProvider {
  switch (config.EMBEDDING_PROVIDER) {
    case 'mock':
      return new MockEmbeddingProvider();

    case 'openai': {
      if (!config.OPENAI_API_KEY) {
        throw new EmbeddingProviderError(
          'openai',
          'EMBEDDING_PROVIDER=openai requires OPENAI_API_KEY',
          false,
        );
      }
      return new OpenAIEmbeddingProvider(
        config.OPENAI_API_KEY,
        config.EMBEDDING_MODEL || undefined,
      );
    }

    case 'gemini':
    case 'local':
      throw new EmbeddingProviderError(
        config.EMBEDDING_PROVIDER,
        `Embedding provider "${config.EMBEDDING_PROVIDER}" is not implemented in this build`,
        false,
      );

    default:
      throw new EmbeddingProviderError('unknown', 'Unsupported EMBEDDING_PROVIDER', false);
  }
}
