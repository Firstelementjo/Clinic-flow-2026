import { Controller, Get, HttpCode, Param, ParseUUIDPipe, Post, Query, Sse } from '@nestjs/common';
import type { Observable } from 'rxjs';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { NotificationsService } from './notifications.service';
import { RealtimeGateway } from './realtime.gateway';

@Controller()
export class NotificationsController {
  constructor(
    private readonly notifications: NotificationsService,
    private readonly realtime: RealtimeGateway,
  ) {}

  @Get('notifications')
  @RequirePermissions(Permission.PROJECT_READ)
  list(@Tenant() ctx: TenantContext, @Query('unread') unread?: string) {
    return this.notifications.list(ctx, unread === 'true');
  }

  @Get('notifications/unread-count')
  @RequirePermissions(Permission.PROJECT_READ)
  async unreadCount(@Tenant() ctx: TenantContext) {
    return { count: await this.notifications.unreadCount(ctx) };
  }

  @Post('notifications/:notificationId/read')
  @RequirePermissions(Permission.PROJECT_READ)
  @HttpCode(204)
  markRead(
    @Tenant() ctx: TenantContext,
    @Param('notificationId', ParseUUIDPipe) notificationId: string,
  ) {
    return this.notifications.markRead(ctx, notificationId);
  }

  @Post('notifications/read-all')
  @RequirePermissions(Permission.PROJECT_READ)
  markAllRead(@Tenant() ctx: TenantContext) {
    return this.notifications.markAllRead(ctx);
  }

  /**
   * The realtime stream. Authenticated like every other route — the
   * session cookie rides along on the EventSource request — and filtered
   * server-side to what this viewer may see.
   */
  @Sse('realtime/stream')
  @RequirePermissions(Permission.PROJECT_READ)
  stream(@Tenant() ctx: TenantContext): Observable<{ data: string }> {
    return this.realtime.streamFor({
      userId: ctx.userId,
      organizationId: ctx.organizationId,
      projectIds: ctx.projectIds,
    });
  }
}
