import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  CalendarClock,
  CheckCircle2,
  FileText,
  Link2,
  MoreHorizontal,
  RotateCcw,
  Trash2,
  Type,
  UserRound,
} from 'lucide-react';
import { useDirection } from '@firstelement/ui';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import { CreateTaskDrawer } from '../components/task-form';
import { useEmployees } from '../components/CreateRecordDrawer';
import { useCrmViews } from '../lib/views';
import {
  ListView,
  ListBadge,
  ListBadgeSelect,
  Menu,
  MenuItem,
  RecordAvatar,
  type BadgeTone,
  type ListColumn,
} from '../components/ListView';

interface TaskRow {
  id: string;
  title: string;
  description: string | null;
  priority: string;
  dueDate: string | null;
  status: string;
  customer: string | null;
  lead: string | null;
  deal: string | null;
  assignedTo: string | null;
  createdById: string | null;
  createdBy: { id: string; fullName: string } | null;
  createdAt: string;
}

const TASK_STATUSES = ['open', 'completed'] as const;

const TASK_STATUS_LABEL: Record<(typeof TASK_STATUSES)[number], StringKey> = {
  open: 'tasks.filter.open',
  completed: 'tasks.filter.completed',
};

const TASK_STATUS_TONE: Record<(typeof TASK_STATUSES)[number], BadgeTone> = {
  open: 'signal',
  completed: 'neutral',
};

const tasksKey = ['tasks'] as const;

function useTasks(status: string, search: string) {
  const query = new URLSearchParams();
  if (status) query.set('status', status);
  if (search.trim()) query.set('search', search.trim());
  return useQuery({
    queryKey: ['tasks', status, search.trim()],
    queryFn: () => api.get<TaskRow[]>(`/tasks?${query.toString()}`),
  });
}

export function TasksPage() {
  const t = useT();
  const dir = useDirection();
  const qc = useQueryClient();
  const views = useCrmViews('task', { noun: t('tasks.list.title'), defaultSort: 'createdAt' });
  const [createOpen, setCreateOpen] = useState(false);
  const location = useLocation();
  const nav = useNavigate();
  useEffect(() => {
    if (new URLSearchParams(location.search).get('new') === '1') {
      setCreateOpen(true);
      nav(location.pathname, { replace: true });
    }
  }, [location.search, nav]);

  const tasks = useTasks('', views.search);
  const employees = useEmployees().data ?? [];
  const assigneeName = useMemo(() => {
    const map = new Map<string, string>();
    for (const emp of employees) map.set(emp.userId, emp.fullName);
    return (id: string | null) => (id ? map.get(id) ?? null : null);
  }, [employees]);

  const updateTask = useMutation({
    mutationFn: ({ id, taskStatus }: { id: string; taskStatus: string }) =>
      api.patch<TaskRow>(`/tasks/${id}`, { status: taskStatus }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: tasksKey }),
  });

  const deleteTask = useMutation({
    mutationFn: (id: string) => api.delete(`/tasks/${id}`),
    onSuccess: () => void qc.invalidateQueries({ queryKey: tasksKey }),
  });

  const deleteManyTasks = useMutation({
    mutationFn: async (ids: string[]) => {
      await Promise.all(ids.map((id) => api.delete(`/tasks/${id}`)));
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: tasksKey }),
  });

  const statusOptions = TASK_STATUSES.map((s) => ({ value: s, label: t(TASK_STATUS_LABEL[s]) }));

  const titleCell = (task: TaskRow) => (
    <button
      type="button"
      tabIndex={-1}
      className={`flex min-w-0 max-w-full items-center gap-2 text-start ${task.status === 'completed' ? 'text-slate-soft line-through' : ''}`}
    >
      <RecordAvatar name={task.title} />
      <span className="truncate text-sm font-medium text-ink">{task.title}</span>
    </button>
  );

  const relationsCell = (task: TaskRow) => {
    const parts = [
      task.customer ? { key: task.customer, label: t('notes.resource.CUSTOMER') } : null,
      task.lead ? { key: task.lead, label: t('notes.resource.LEAD') } : null,
      task.deal ? { key: task.deal, label: t('notes.resource.DEAL') } : null,
    ].filter((p): p is { key: string; label: string } => Boolean(p));
    if (parts.length === 0) return null;
    return (
      <span className="flex min-w-0 flex-wrap items-center gap-1">
        {parts.map((p) => (
          <ListBadge key={p.key}>{p.label}</ListBadge>
        ))}
      </span>
    );
  };

  const columns: ListColumn<TaskRow>[] = [
    { id: 'title', label: 'list.col.title', icon: Type, size: 'minmax(11rem, 3fr)', render: titleCell },
    {
      id: 'status',
      label: 'list.col.status',
      icon: CheckCircle2,
      size: '6.5rem',
      render: (task) => (
        <ListBadgeSelect
          value={(task.status as (typeof TASK_STATUSES)[number]) ?? 'open'}
          options={statusOptions}
          toneFor={(s) => TASK_STATUS_TONE[s]}
          ariaLabel={t('list.col.status')}
          onChange={(taskStatus) => updateTask.mutate({ id: task.id, taskStatus })}
        />
      ),
    },
    { id: 'relations', label: 'list.col.relations', icon: Link2, size: 'minmax(8rem, 1.5fr)', render: relationsCell },
    {
      id: 'createdBy',
      label: 'list.col.createdBy',
      icon: UserRound,
      size: 'minmax(6rem, 1.25fr)',
      render: (task) => task.createdBy?.fullName ?? null,
    },
    {
      id: 'dueDate',
      label: 'list.col.due',
      icon: CalendarClock,
      size: '7rem',
      render: (task) => (task.dueDate ? formatDate(task.dueDate, dir.locale) : null),
    },
    {
      id: 'assignee',
      label: 'list.col.assignee',
      icon: UserRound,
      size: 'minmax(6rem, 1.25fr)',
      render: (task) => assigneeName(task.assignedTo),
    },
    {
      id: 'description',
      label: 'list.col.body',
      icon: FileText,
      size: 'minmax(9rem, 2fr)',
      render: (task) => task.description,
    },
    {
      id: 'createdAt',
      label: 'list.col.created',
      icon: CalendarClock,
      size: '7rem',
      render: (task) => formatDate(task.createdAt, dir.locale),
    },
  ];

  return (
    <>
      <ListView<TaskRow>
        title={t('tasks.list.title')}
        eyebrow={t('tasks.list.eyebrow')}
        addLabel={t('list.newTask')}
        onAdd={() => setCreateOpen(true)}
        noun={t('tasks.list.title')}
        objectType="tasks"
        columns={columns}
        rows={tasks.data}
        isPending={tasks.isPending}
        isError={tasks.isError}
        keyOf={(task) => task.id}
        viewSwitcher={views.switcher}
        filterValue={views.search}
        onFilter={views.setSearch}
        hiddenColumns={views.hidden}
        onHiddenColumnsChange={views.setHidden}
        onDeleteSelected={(ids) => deleteManyTasks.mutate(ids)}
        footerCells={[]}
        rowActions={(task) => (
          <Menu
            button={
              <span
                aria-label={t('list.options')}
                role="img"
                className="flex h-6 w-6 items-center justify-center rounded text-slate-soft transition-colors hover:bg-mist hover:text-ink"
              >
                <MoreHorizontal className="h-4 w-4" />
              </span>
            }
          >
            {task.status === 'open' ? (
              <MenuItem
                icon={CheckCircle2}
                label={t('tasks.complete')}
                onClick={() => updateTask.mutate({ id: task.id, taskStatus: 'completed' })}
              />
            ) : (
              <MenuItem
                icon={RotateCcw}
                label={t('tasks.reopen')}
                onClick={() => updateTask.mutate({ id: task.id, taskStatus: 'open' })}
              />
            )}
            <MenuItem danger icon={Trash2} label={t('tasks.delete')} onClick={() => deleteTask.mutate(task.id)} />
          </Menu>
        )}
      />
      <CreateTaskDrawer open={createOpen} onClose={() => setCreateOpen(false)} />
    </>
  );
}