import { Module } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { LocalClinicAdapter } from './local-clinic.adapter';
import { SchedulingEngineService } from './scheduling-engine.service';
import { ClinicService } from './clinic.service';
import { ClinicController } from './clinic.controller';
import { AiSimulatorService } from './ai-simulator.service';
import { RemindersService } from './reminders.service';
import { PublicAppointmentController } from './public-appointment.controller';

@Module({
  providers: [
    PrismaService,
    LocalClinicAdapter,
    SchedulingEngineService,
    ClinicService,
    AiSimulatorService,
    RemindersService,
  ],
  controllers: [ClinicController, PublicAppointmentController],
  exports: [
    LocalClinicAdapter,
    SchedulingEngineService,
    ClinicService,
    AiSimulatorService,
    RemindersService,
  ],
})
export class ClinicModule {}
