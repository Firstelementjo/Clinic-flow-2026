/**
 * Embedding provider abstraction (plan §9).
 *
 * The CRM must keep working when a provider is down or unconfigured
 * (plan §20.9), so callers depend on this interface and never on a
 * vendor SDK. Dimensions are part of the contract: the pgvector column is
 * fixed at 1536, and a provider that returns a different width would
 * silently corrupt retrieval, so it is checked rather than trusted.
 */

export const EMBEDDING_DIMENSIONS = 1536;

export interface EmbeddingProvider {
  readonly name: string;
  readonly model: string;
  readonly dimensions: number;
  /** Order in equals order out; one vector per input. */
  embed(texts: string[]): Promise<number[][]>;
}

export class EmbeddingProviderError extends Error {
  readonly code = 'PROVIDER_UNAVAILABLE' as const;

  constructor(
    readonly provider: string,
    message: string,
    readonly retryable = true,
  ) {
    super(message);
    this.name = 'EmbeddingProviderError';
  }
}

export function assertEmbeddingShape(
  provider: string,
  vectors: number[][],
  expectedCount: number,
  dimensions: number,
): void {
  if (vectors.length !== expectedCount) {
    throw new EmbeddingProviderError(
      provider,
      `Expected ${expectedCount} embeddings, received ${vectors.length}`,
      false,
    );
  }

  for (const [index, vector] of vectors.entries()) {
    if (vector.length !== dimensions) {
      throw new EmbeddingProviderError(
        provider,
        `Embedding ${index} has ${vector.length} dimensions, expected ${dimensions}`,
        false,
      );
    }
  }
}

/**
 * Cosine distance assumes unit-length vectors. Normalizing here means the
 * retrieval query's `<=>` scores are comparable across providers.
 */
export function l2Normalize(vector: number[]): number[] {
  let sum = 0;
  for (const value of vector) sum += value * value;
  const magnitude = Math.sqrt(sum);
  if (magnitude === 0) return vector;
  return vector.map((value) => value / magnitude);
}
