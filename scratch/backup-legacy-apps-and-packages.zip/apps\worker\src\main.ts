import type { Worker } from 'bullmq';
import { getConfig } from '@firstelement/config';
import { ConnectorRegistry } from '@firstelement/connectors';
import { disconnectPrisma, getPrismaClient } from '@firstelement/database';
import {
  InboundMessagePipeline,
  OutboundDispatcher,
  QueueName,
  TimelineRecordingPublisher,
  type InboundJob,
  type OutboundJob,
} from '@firstelement/messaging';
import {
  AIOrchestrator,
  EscalationEngine,
  createEmbeddingProvider,
  type AITurnJob,
  type ScoreTurnJob,
} from '@firstelement/ai';
import {
  DocumentIngestionPipeline,
  KnowledgeRetriever,
  LocalStorageDriver,
} from '@firstelement/knowledge-base';
import { resolveAIEligibility } from '@firstelement/messaging';
import { RoutingEngine, type RouteJob } from '@firstelement/routing';
import { createQueue, createRedisConnection, createWorker } from './queues';

interface DocumentProcessingJob {
  organizationId: string;
  projectId: string;
  documentId: string;
}

/**
 * Worker process (plan §11).
 *
 * Runs the same pipeline classes the API uses — they live in
 * `@firstelement/messaging` precisely so this process is not a second
 * implementation that drifts. Its job is scheduling, retries, logging and
 * shutdown; the domain logic is shared.
 */
async function main(): Promise<void> {
  const config = getConfig();
  const redis = createRedisConnection();
  const prisma = getPrismaClient();

  await prisma.$queryRaw`SELECT 1`;
  await redis.ping();

  // No event bus here, so the worker records the conversation timeline
  // directly. Later slices attach AI and scoring consumers to the same
  // publisher rather than calling them from inside the pipeline.
  const events = new TimelineRecordingPublisher(prisma, (error, event) => {
    console.error('[worker] failed to record timeline event', event.type, errorText(error));
  });

  const registry = new ConnectorRegistry();
  const inbound = new InboundMessagePipeline(prisma, events);
  const outbound = new OutboundDispatcher(prisma, registry, config.ENCRYPTION_KEY);

  // Resolved at boot: a misconfigured embedding provider should stop the
  // worker starting, not fail silently on the first document.
  const embeddings = createEmbeddingProvider(config);
  const ingestion = new DocumentIngestionPipeline(
    prisma,
    new LocalStorageDriver(config.STORAGE_LOCAL_PATH),
    embeddings,
  );

  // The orchestrator takes retrieval as a function rather than importing
  // the knowledge package, so the AI package stays free of a dependency
  // cycle — and so retrieval can be swapped in tests.
  const retriever = new KnowledgeRetriever(prisma, embeddings);
  const orchestrator = new AIOrchestrator(prisma, async (params) => {
    const result = await retriever.retrieve({
      organizationId: params.organizationId,
      projectId: params.projectId,
      knowledgeBaseIds: params.knowledgeBaseIds.length > 0 ? params.knowledgeBaseIds : undefined,
      query: params.query,
      minScore: params.minScore,
    });
    return result.chunks.map((chunk) => ({
      chunkId: chunk.chunkId,
      documentId: chunk.documentId,
      knowledgeBaseId: chunk.knowledgeBaseId,
      documentTitle: chunk.documentTitle,
      content: chunk.content,
      score: chunk.score,
    }));
  });

  const escalation = new EscalationEngine(prisma, events);
  const routing = new RoutingEngine(prisma, events);

  // Queues this process produces into as well as consumes from.
  const aiQueue = createQueue(QueueName.AI_RESPONSE, redis);
  const scoringQueue = createQueue(QueueName.SCORING, redis);
  const outboundQueue = createQueue(QueueName.OUTBOUND_SEND, redis);
  const routingQueue = createQueue(QueueName.ESCALATION_ROUTING, redis);

  const workers: Worker[] = [
    createWorker<InboundJob>(QueueName.INCOMING_MESSAGE, redis, async (job) => {
      const result = await inbound.process(job.data);
      if (result.status === 'duplicate') {
        // Not an error: providers redeliver. Recording it keeps the
        // distinction visible instead of looking like a lost message.
        console.log('[worker] duplicate inbound message', result.externalMessageId);
        return result;
      }

      // Whether the AI answers is decided here rather than inside the
      // pipeline, so the pipeline does not gain a branch per consumer.
      const eligibility = await resolveAIEligibility(prisma, {
        organizationId: job.data.organizationId,
        projectId: job.data.projectId,
        conversationId: result.conversationId,
      });

      // Scoring runs for every customer turn, whether or not the AI is
      // answering: a conversation already with a human still needs its
      // frustration history for analytics and for the timeline.
      await scoringQueue.add(
        'score',
        {
          organizationId: job.data.organizationId,
          projectId: job.data.projectId,
          conversationId: result.conversationId,
          messageId: result.messageId,
        } satisfies ScoreTurnJob,
        { jobId: `score:${result.messageId}` },
      );

      if (eligibility.eligible) {
        await aiQueue.add(
          'ai-turn',
          {
            organizationId: job.data.organizationId,
            projectId: job.data.projectId,
            conversationId: result.conversationId,
            messageId: result.messageId,
          } satisfies AITurnJob,
          // One AI turn per inbound message, even if this job is retried.
          { jobId: `ai:${result.messageId}` },
        );
      }

      return result;
    }),

    createWorker<AITurnJob>(
      QueueName.AI_RESPONSE,
      redis,
      async (job) => {
        const result = await orchestrator.run(job.data);

        if (result.status === 'replied' || result.status === 'resolved') {
          await outboundQueue.add(
            'outbound',
            {
              organizationId: job.data.organizationId,
              projectId: job.data.projectId,
              conversationId: job.data.conversationId,
              messageId: result.messageId,
            },
            { jobId: `send:${result.messageId}` },
          );
        }

        // The agent asking for a person, and the provider failing, both
        // produce a real escalation record with a handover summary — not
        // just a mode flip. An employee inheriting the conversation needs
        // to know why it arrived (plan §20.7).
        if (result.status === 'escalated' || result.status === 'failed') {
          const created = await escalation.escalateDirectly({
            organizationId: job.data.organizationId,
            projectId: job.data.projectId,
            conversationId: job.data.conversationId,
            reason: result.reason,
            trigger: result.status === 'failed' ? 'AI_FAILURE' : 'EXPLICIT_REQUEST',
          });

          if (created) {
            await routingQueue.add('route', {
              organizationId: job.data.organizationId,
              projectId: job.data.projectId,
              conversationId: job.data.conversationId,
              escalationId: created.id,
            } satisfies RouteJob);
          }
        }

        return result;
      },
      3,
    ),

    createWorker<ScoreTurnJob>(QueueName.SCORING, redis, async (job) => {
      const result = await escalation.scoreTurn(job.data);
      if (result.status === 'escalated') {
        console.log('[worker] conversation escalated', job.data.conversationId);
        await routingQueue.add('route', {
          organizationId: job.data.organizationId,
          projectId: job.data.projectId,
          conversationId: job.data.conversationId,
          escalationId: result.escalationId,
        } satisfies RouteJob);
      }
      return result;
    }),

    createWorker<RouteJob>(QueueName.ESCALATION_ROUTING, redis, async (job) => {
      const result = await routing.route(job.data);

      // An unassignable escalation is not an error to retry — nobody
      // becomes available because a job ran again. It waits in the
      // unassigned queue with the blocking stage recorded (plan §10).
      if (result.status === 'queued') {
        console.log('[worker] escalation left unassigned:', result.reason);
      }

      return result;
    }),

    createWorker<OutboundJob>(QueueName.OUTBOUND_SEND, redis, async (job) => {
      const result = await outbound.dispatch(job.data);
      if (result.status === 'failed') {
        // Retryable failures throw so BullMQ backs off and tries again;
        // permanent ones are already recorded on the message row.
        if (result.retryable) throw new Error(result.reason);
        console.warn('[worker] permanent send failure', result.reason);
      }
      return result;
    }),

    // Lower concurrency: embedding is the rate-limited, billed step, and
    // a burst of uploads should not blow a provider quota.
    createWorker<DocumentProcessingJob>(
      QueueName.DOCUMENT_PROCESSING,
      redis,
      async (job) => {
        const result = await ingestion.process(job.data.documentId);
        if (result.status === 'FAILED') {
          // The reason is already on the document row for the admin to
          // read; the job itself is not retried, because a malformed PDF
          // will fail identically five more times.
          console.warn('[worker] document processing failed', result.failureReason);
        }
        return result;
      },
      2,
    ),
  ];

  for (const worker of workers) {
    worker.on('failed', (job, error) => {
      console.error(`[worker] ${worker.name} job ${job?.id ?? '?'} failed`, errorText(error));
    });
  }

  console.log(
    `[worker] ready (env=${config.NODE_ENV}) — processing ${workers.map((w) => w.name).join(', ')}`,
  );

  const shutdown = async (signal: string): Promise<void> => {
    console.log(`[worker] ${signal} received, draining`);
    // Close workers before the connections they use, so in-flight jobs
    // finish rather than being killed and retried.
    await Promise.all(workers.map((worker) => worker.close()));
    await redis.quit();
    await disconnectPrisma();
    process.exit(0);
  };

  process.on('SIGINT', () => void shutdown('SIGINT'));
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
}

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

main().catch((error) => {
  console.error('[worker] failed to start', errorText(error));
  process.exit(1);
});
