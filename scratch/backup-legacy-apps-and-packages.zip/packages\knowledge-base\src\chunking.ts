/**
 * Chunking (plan §9: upload → parse → clean → chunk → embed → store).
 *
 * Chunk boundaries decide what the AI can cite. A refund policy split
 * mid-sentence retrieves as two half-answers, and the agent either
 * invents the missing half or escalates something it should have handled.
 * So this splits on structure first — paragraphs, then sentences — and
 * only falls back to hard character cuts for text that has neither.
 *
 * Overlap exists for the same reason: a fact that straddles a boundary
 * should appear whole in at least one chunk.
 */

export interface ChunkOptions {
  /** Target size in characters. ~1,500 ≈ 375 tokens for Latin script. */
  targetChars: number;
  /** Hard ceiling; a chunk is split even mid-sentence beyond this. */
  maxChars: number;
  /** Characters of trailing context repeated into the next chunk. */
  overlapChars: number;
}

export const DEFAULT_CHUNK_OPTIONS: ChunkOptions = {
  targetChars: 1_500,
  maxChars: 2_400,
  overlapChars: 200,
};

export interface TextChunk {
  index: number;
  content: string;
  /**
   * Rough token estimate for cost and context budgeting. Deliberately
   * approximate — the exact count depends on the model's tokenizer, and
   * being 10% off here changes nothing about correctness.
   */
  estimatedTokens: number;
}

/**
 * Zero-width and bidi control characters ride along in copied Arabic
 * text and would otherwise be embedded as if they were content. Built
 * from escapes so the source file stays free of invisible characters.
 */
const INVISIBLE_CHARS = new RegExp('[\u200B-\u200F\u202A-\u202E\uFEFF]', 'g');

/** Collapses whitespace and strips control characters, keeping paragraphs. */
export function cleanText(raw: string): string {
  return raw
    .replace(/\r\n?/g, '\n')
    .replace(INVISIBLE_CHARS, '')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .split('\n')
    .map((line) => line.trim())
    .join('\n')
    .trim();
}

export function chunkText(raw: string, options: Partial<ChunkOptions> = {}): TextChunk[] {
  const opts = { ...DEFAULT_CHUNK_OPTIONS, ...options };
  const text = cleanText(raw);
  if (!text) return [];

  const paragraphs = text.split(/\n{2,}/).filter(Boolean);
  const pieces: string[] = [];

  for (const paragraph of paragraphs) {
    if (paragraph.length <= opts.maxChars) {
      pieces.push(paragraph);
      continue;
    }
    pieces.push(...splitLongParagraph(paragraph, opts));
  }

  // Merge adjacent pieces up to the target size: a heading followed by a
  // two-line answer belongs in one chunk, not two.
  const merged: string[] = [];
  let current = '';

  for (const piece of pieces) {
    if (!current) {
      current = piece;
      continue;
    }
    if (current.length + piece.length + 2 <= opts.targetChars) {
      current = `${current}\n\n${piece}`;
    } else {
      merged.push(current);
      current = piece;
    }
  }
  if (current) merged.push(current);

  return merged.map((content, index) => {
    const withOverlap =
      index > 0 && opts.overlapChars > 0
        ? `${tail(merged[index - 1]!, opts.overlapChars)}\n\n${content}`
        : content;

    return {
      index,
      content: withOverlap,
      estimatedTokens: estimateTokens(withOverlap),
    };
  });
}

/**
 * Splits at sentence ends, including Arabic full stop and question mark,
 * before resorting to a hard cut.
 */
function splitLongParagraph(paragraph: string, opts: ChunkOptions): string[] {
  const sentences = paragraph.match(/[^.!?۔؟\n]+[.!?۔؟]*\s*/gu) ?? [paragraph];
  const out: string[] = [];
  let buffer = '';

  for (const sentence of sentences) {
    if (buffer.length + sentence.length <= opts.targetChars) {
      buffer += sentence;
      continue;
    }
    if (buffer) out.push(buffer.trim());

    if (sentence.length > opts.maxChars) {
      // A single sentence longer than the ceiling (minified JSON, a table
      // dumped as one line). Hard-cut it rather than emitting one huge
      // chunk that would blow the context budget on retrieval.
      for (let i = 0; i < sentence.length; i += opts.maxChars) {
        out.push(sentence.slice(i, i + opts.maxChars).trim());
      }
      buffer = '';
    } else {
      buffer = sentence;
    }
  }

  if (buffer.trim()) out.push(buffer.trim());
  return out.filter(Boolean);
}

function tail(text: string, chars: number): string {
  if (text.length <= chars) return text;
  const slice = text.slice(-chars);
  // Start the overlap at a word boundary so it does not begin mid-word.
  const space = slice.indexOf(' ');
  return space > 0 ? slice.slice(space + 1) : slice;
}

export function estimateTokens(text: string): number {
  return Math.max(1, Math.ceil(text.length / 4));
}
