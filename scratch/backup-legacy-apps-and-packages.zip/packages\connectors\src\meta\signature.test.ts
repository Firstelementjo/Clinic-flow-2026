import { createHmac } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { resolveVerificationChallenge, verifyMetaSignature } from './signature';

const APP_SECRET = 'app-secret-value';
const BODY = JSON.stringify({ entry: [{ changes: [] }] });

function sign(body: string, secret = APP_SECRET): string {
  return `sha256=${createHmac('sha256', secret).update(body).digest('hex')}`;
}

describe('verifyMetaSignature', () => {
  it('accepts a correctly signed body', () => {
    expect(
      verifyMetaSignature({
        rawBody: BODY,
        signatureHeader: sign(BODY),
        appSecret: APP_SECRET,
      }),
    ).toBe(true);
  });

  it('rejects a body that was modified after signing', () => {
    const tampered = BODY.replace('entry', 'entrY');
    expect(
      verifyMetaSignature({
        rawBody: tampered,
        signatureHeader: sign(BODY),
        appSecret: APP_SECRET,
      }),
    ).toBe(false);
  });

  it('rejects a signature made with a different app secret', () => {
    expect(
      verifyMetaSignature({
        rawBody: BODY,
        signatureHeader: sign(BODY, 'attacker-secret'),
        appSecret: APP_SECRET,
      }),
    ).toBe(false);
  });

  it('rejects a missing or malformed header instead of passing by default', () => {
    for (const signatureHeader of [undefined, '', 'garbage', 'sha1=abc', 'sha256=']) {
      expect(verifyMetaSignature({ rawBody: BODY, signatureHeader, appSecret: APP_SECRET })).toBe(
        false,
      );
    }
  });

  it('rejects when no app secret is configured, rather than accepting everything', () => {
    expect(verifyMetaSignature({ rawBody: BODY, signatureHeader: sign(BODY), appSecret: '' })).toBe(
      false,
    );
  });

  it('verifies the raw bytes, not a re-serialized object', () => {
    // This is why the API keeps the raw body: JSON.parse followed by
    // JSON.stringify drops the sender's whitespace, producing a different
    // digest for a payload that is genuinely Meta's.
    const raw = '{ "entry": [ { "id": "1" } ] }';
    const reserialized = JSON.stringify(JSON.parse(raw));

    expect(verifyMetaSignature({ rawBody: raw, signatureHeader: sign(raw), appSecret: APP_SECRET })).toBe(true);
    expect(
      verifyMetaSignature({
        rawBody: reserialized,
        signatureHeader: sign(raw),
        appSecret: APP_SECRET,
      }),
    ).toBe(false);
  });

  it('accepts a Buffer body, which is how express hands it over', () => {
    expect(
      verifyMetaSignature({
        rawBody: Buffer.from(BODY, 'utf8'),
        signatureHeader: sign(BODY),
        appSecret: APP_SECRET,
      }),
    ).toBe(true);
  });
});

describe('resolveVerificationChallenge', () => {
  const expectedToken = 'verify-me';

  it('echoes the challenge when the token matches', () => {
    expect(
      resolveVerificationChallenge({
        mode: 'subscribe',
        token: expectedToken,
        challenge: '12345',
        expectedToken,
      }),
    ).toBe('12345');
  });

  it('refuses a wrong token', () => {
    expect(
      resolveVerificationChallenge({
        mode: 'subscribe',
        token: 'wrong',
        challenge: '12345',
        expectedToken,
      }),
    ).toBeNull();
  });

  it('refuses anything other than a subscribe handshake', () => {
    expect(
      resolveVerificationChallenge({
        mode: 'unsubscribe',
        token: expectedToken,
        challenge: '12345',
        expectedToken,
      }),
    ).toBeNull();
  });

  it('refuses when parameters are missing', () => {
    expect(
      resolveVerificationChallenge({
        mode: 'subscribe',
        token: undefined,
        challenge: '12345',
        expectedToken,
      }),
    ).toBeNull();
  });
});
