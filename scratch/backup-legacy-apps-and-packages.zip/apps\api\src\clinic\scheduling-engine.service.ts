import { Injectable } from '@nestjs/common';
import type { TenantContext } from '@firstelement/database';
import { LocalClinicAdapter } from './local-clinic.adapter';

export interface AvailableSlotsResult {
  doctorId: string;
  doctorName: string;
  procedureId: string;
  procedureName: string;
  durationMinutes: number;
  date: string; // YYYY-MM-DD
  isWorkingDay: boolean;
  slots: string[]; // ["09:00", "10:00", "14:00"]
  reason?: string;
}

export interface ValidationResult {
  valid: boolean;
  code?: 'VALID' | 'OUTSIDE_WORKING_HOURS' | 'DOCTOR_UNAVAILABLE_ON_DATE' | 'DURATION_CONFLICT' | 'SLOT_OCCUPIED';
  reason?: string;
  availableAlternatives?: string[];
}

export interface AlternativeSlotOption {
  date: string;
  slots: string[];
}

export interface AlternativeDoctorOption {
  doctorId: string;
  doctorName: string;
  specialty: string;
  date: string;
  timeSlot: string;
}

/**
 * Deterministic slot computation and booking validation.
 *
 * <p>The caller's {@link TenantContext} is threaded through every method because
 * the adapter's lookups are scoped: a slot search must never be able to read a
 * doctor, a procedure, or an existing appointment belonging to a project the
 * caller cannot reach. A search that silently returned "no availability" for
 * another tenant's doctor would both disclose and mislead.
 */
@Injectable()
export class SchedulingEngineService {
  constructor(private readonly clinicAdapter: LocalClinicAdapter) {}

  /**
   * Calculates valid, collision-free slots for a doctor, procedure, and date.
   * Deterministically handles procedure duration & prevents double booking.
   */
  async findAvailableSlots(
    ctx: TenantContext,
    doctorId: string,
    procedureId: string,
    dateStr: string,
  ): Promise<AvailableSlotsResult> {
    const targetDate = new Date(`${dateStr}T00:00:00.000Z`);
    const doctor = await this.clinicAdapter.getDoctorById(ctx, doctorId);
    const procedure = await this.clinicAdapter.getProcedureById(ctx, procedureId);

    if (!doctor) {
      return {
        doctorId,
        doctorName: 'Unknown',
        procedureId,
        procedureName: procedure?.name || 'Unknown',
        durationMinutes: 30,
        date: dateStr,
        isWorkingDay: false,
        slots: [],
        reason: 'Doctor not found',
      };
    }

    const procedureDuration = procedure?.durationMinutes || doctor.slotDuration || 30;

    // Check if doctor works on this day of week
    const dayOfWeek = targetDate.getUTCDay();
    if (!doctor.workingDays.includes(dayOfWeek)) {
      return {
        doctorId,
        doctorName: doctor.name,
        procedureId,
        procedureName: procedure?.name || 'Consultation',
        durationMinutes: procedureDuration,
        date: dateStr,
        isWorkingDay: false,
        slots: [],
        reason: `${doctor.name} does not work on ${this.getDayName(dayOfWeek)}s`,
      };
    }

    // Parse start and end hours (e.g. "09:00" to 9 * 60 = 540 minutes)
    const startParts = doctor.startHour.split(':').map(Number);
    const startH = startParts[0] ?? 9;
    const startM = startParts[1] ?? 0;
    const endParts = doctor.endHour.split(':').map(Number);
    const endH = endParts[0] ?? 17;
    const endM = endParts[1] ?? 0;
    const dayStartMinutes = startH * 60 + startM;
    const dayEndMinutes = endH * 60 + endM;

    // Fetch existing appointments on that date
    const existingAppointments = await this.clinicAdapter.getExistingAppointments(
      ctx,
      doctorId,
      targetDate,
    );

    // Convert existing appointments to occupied minute ranges [start, end]
    const busyIntervals = existingAppointments.map((a) => {
      const aDate = new Date(a.appointmentDate);
      const aMinutes = aDate.getUTCHours() * 60 + aDate.getUTCMinutes();
      return {
        start: aMinutes,
        end: aMinutes + a.durationMinutes,
      };
    });

    const validSlots: string[] = [];
    const stepMinutes = Math.min(30, doctor.slotDuration);

    // Test each candidate slot from start to end
    for (
      let slotStart = dayStartMinutes;
      slotStart + procedureDuration <= dayEndMinutes;
      slotStart += stepMinutes
    ) {
      const slotEnd = slotStart + procedureDuration;

      // Check for overlap: slot overlaps with busy if slotStart < busy.end && slotEnd > busy.start
      const hasCollision = busyIntervals.some(
        (busy) => slotStart < busy.end && slotEnd > busy.start,
      );

      if (!hasCollision) {
        const hh = String(Math.floor(slotStart / 60)).padStart(2, '0');
        const mm = String(slotStart % 60).padStart(2, '0');
        validSlots.push(`${hh}:${mm}`);
      }
    }

    return {
      doctorId,
      doctorName: doctor.name,
      procedureId,
      procedureName: procedure?.name || 'Consultation',
      durationMinutes: procedureDuration,
      date: dateStr,
      isWorkingDay: true,
      slots: validSlots,
      reason: validSlots.length === 0 ? 'All slots are fully booked for this date' : undefined,
    };
  }

  /**
   * Validates if a requested appointment date and time can be booked.
   */
  async validateBooking(
    ctx: TenantContext,
    doctorId: string,
    procedureId: string,
    requestedDateTime: Date,
  ): Promise<ValidationResult> {
    const doctor = await this.clinicAdapter.getDoctorById(ctx, doctorId);
    const procedure = await this.clinicAdapter.getProcedureById(ctx, procedureId);

    if (!doctor) {
      return { valid: false, code: 'DOCTOR_UNAVAILABLE_ON_DATE', reason: 'Doctor not found' };
    }

    const procedureDuration = procedure?.durationMinutes || doctor.slotDuration || 30;
    const dayOfWeek = requestedDateTime.getUTCDay();

    if (!doctor.workingDays.includes(dayOfWeek)) {
      const alternatives = await this.findAlternativeSlots(
        ctx,
        doctorId,
        procedureId,
        requestedDateTime.toISOString().slice(0, 10),
      );
      return {
        valid: false,
        code: 'DOCTOR_UNAVAILABLE_ON_DATE',
        reason: `${doctor.name} does not work on ${this.getDayName(dayOfWeek)}s`,
        availableAlternatives: alternatives
          .flatMap((a) => a.slots.map((s) => `${a.date} ${s}`))
          .slice(0, 3),
      };
    }

    const startParts = doctor.startHour.split(':').map(Number);
    const startH = startParts[0] ?? 9;
    const startM = startParts[1] ?? 0;
    const endParts = doctor.endHour.split(':').map(Number);
    const endH = endParts[0] ?? 17;
    const endM = endParts[1] ?? 0;
    const dayStartMinutes = startH * 60 + startM;
    const dayEndMinutes = endH * 60 + endM;

    const reqMinutes = requestedDateTime.getUTCHours() * 60 + requestedDateTime.getUTCMinutes();
    const reqEndMinutes = reqMinutes + procedureDuration;

    // Check outside working hours
    if (reqMinutes < dayStartMinutes || reqEndMinutes > dayEndMinutes) {
      const dateStr = requestedDateTime.toISOString().slice(0, 10);
      const avail = await this.findAvailableSlots(ctx, doctorId, procedureId, dateStr);
      return {
        valid: false,
        code: 'OUTSIDE_WORKING_HOURS',
        reason: `Requested time is outside ${doctor.name}'s working hours (${doctor.startHour} - ${doctor.endHour})`,
        availableAlternatives: avail.slots.map((s) => `${dateStr} ${s}`).slice(0, 3),
      };
    }

    // Check collision with existing appointments
    const existingAppointments = await this.clinicAdapter.getExistingAppointments(
      ctx,
      doctorId,
      requestedDateTime,
    );
    const collision = existingAppointments.find((a) => {
      const aDate = new Date(a.appointmentDate);
      const aMinutes = aDate.getUTCHours() * 60 + aDate.getUTCMinutes();
      const aEndMinutes = aMinutes + a.durationMinutes;
      return reqMinutes < aEndMinutes && reqEndMinutes > aMinutes;
    });

    if (collision) {
      const dateStr = requestedDateTime.toISOString().slice(0, 10);
      const avail = await this.findAvailableSlots(ctx, doctorId, procedureId, dateStr);
      return {
        valid: false,
        code: 'SLOT_OCCUPIED',
        reason: `The slot around ${requestedDateTime.toISOString().slice(11, 16)} is already occupied`,
        availableAlternatives: avail.slots.map((s) => `${dateStr} ${s}`).slice(0, 3),
      };
    }

    return { valid: true, code: 'VALID' };
  }

  /**
   * Searches the next available alternative slots on the same date or upcoming working days.
   */
  async findAlternativeSlots(
    ctx: TenantContext,
    doctorId: string,
    procedureId: string,
    fromDateStr: string,
    maxDaysToSearch = 5,
  ): Promise<AlternativeSlotOption[]> {
    const results: AlternativeSlotOption[] = [];
    const baseDate = new Date(`${fromDateStr}T00:00:00.000Z`);

    for (let offset = 0; offset < maxDaysToSearch; offset++) {
      const candidateDate = new Date(baseDate.getTime() + offset * 24 * 60 * 60 * 1000);
      const dateStr = candidateDate.toISOString().slice(0, 10);

      const slotResult = await this.findAvailableSlots(ctx, doctorId, procedureId, dateStr);
      if (slotResult.slots.length > 0) {
        results.push({
          date: dateStr,
          slots: slotResult.slots.slice(0, 4), // top 4 slots per day
        });
      }

      if (results.length >= 2) break; // found 2 days with slots
    }

    return results;
  }

  /**
   * Finds alternative active doctors with the same specialty free at the requested time.
   */
  async findAlternativeDoctors(
    ctx: TenantContext,
    procedureId: string,
    requestedDateTime: Date,
  ): Promise<AlternativeDoctorOption[]> {
    const procedure = await this.clinicAdapter.getProcedureById(ctx, procedureId);
    if (!procedure) return [];

    // Scoped to the caller's reachable projects rather than to a bare projectId,
    // so an alternative-doctor search cannot reach another tenant's roster.
    const allDoctors = await this.clinicAdapter.getDoctors(ctx);
    const specialtyDoctors = allDoctors.filter(
      (d) => d.specialty.toLowerCase() === procedure.specialty.toLowerCase(),
    );

    const alternativeDoctors: AlternativeDoctorOption[] = [];

    for (const doc of specialtyDoctors) {
      const val = await this.validateBooking(ctx, doc.id, procedureId, requestedDateTime);
      if (val.valid) {
        alternativeDoctors.push({
          doctorId: doc.id,
          doctorName: doc.name,
          specialty: doc.specialty,
          date: requestedDateTime.toISOString().slice(0, 10),
          timeSlot: requestedDateTime.toISOString().slice(11, 16),
        });
      }
    }

    return alternativeDoctors;
  }

  private getDayName(dayIndex: number): string {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[dayIndex] || 'Unknown';
  }
}
