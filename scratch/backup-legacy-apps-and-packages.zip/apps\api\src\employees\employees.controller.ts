import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Patch, Post, Query, Req } from '@nestjs/common';
import type { Request } from 'express';
import { Permission } from '@firstelement/auth';
import { projectScope, type TenantContext } from '@firstelement/database';
import {
  createEmployeeSchema,
  updateEmployeeSchema,
  type CreateEmployeeInput,
  type UpdateEmployeeInput,
} from '@firstelement/shared';
import { z } from 'zod';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { EmployeesService } from './employees.service';

const availabilitySchema = updateEmployeeSchema.pick({ availabilityStatus: true }).required();

@Controller('employees')
export class EmployeesController {
  constructor(private readonly employees: EmployeesService) {}

  @Get()
  @RequirePermissions(Permission.EMPLOYEE_READ)
  list(@Tenant() ctx: TenantContext, @Query('projectId') projectId?: string) {
    // A project filter is still a tenant assertion — validate membership
    // before it reaches the query.
    if (projectId) {
      z.string().uuid().parse(projectId);
      projectScope(ctx, projectId);
    }
    return this.employees.list(ctx, { projectId });
  }

  @Patch('me/availability')
  @RequirePermissions(Permission.EMPLOYEE_SET_OWN_AVAILABILITY)
  setOwnAvailability(
    @Tenant() ctx: TenantContext,
    @Body(zodBody(availabilitySchema)) body: { availabilityStatus: UpdateEmployeeInput['availabilityStatus'] },
  ) {
    return this.employees.setOwnAvailability(ctx, body.availabilityStatus);
  }

  @Get(':userId')
  @RequirePermissions(Permission.EMPLOYEE_READ)
  getOne(@Tenant() ctx: TenantContext, @Param('userId', ParseUUIDPipe) userId: string) {
    return this.employees.getById(ctx, userId);
  }

  @Post()
  @RequirePermissions(Permission.EMPLOYEE_CREATE)
  create(
    @Tenant() ctx: TenantContext,
    @Body(zodBody(createEmployeeSchema)) body: CreateEmployeeInput,
    @Req() request: Request,
  ) {
    return this.employees.create(ctx, body, request.ip);
  }

  @Patch(':userId')
  @RequirePermissions(Permission.EMPLOYEE_UPDATE)
  update(
    @Tenant() ctx: TenantContext,
    @Param('userId', ParseUUIDPipe) userId: string,
    @Body(zodBody(updateEmployeeSchema)) body: UpdateEmployeeInput,
    @Req() request: Request,
  ) {
    return this.employees.update(ctx, userId, body, request.ip);
  }

  @Delete(':userId')
  @RequirePermissions(Permission.EMPLOYEE_DELETE)
  delete(
    @Tenant() ctx: TenantContext,
    @Param('userId', ParseUUIDPipe) userId: string,
    @Req() request: Request,
  ) {
    return this.employees.delete(ctx, userId, request.ip);
  }
}
