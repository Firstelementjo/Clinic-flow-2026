import { Controller, Get, Post, Patch, Delete, Param, Body, UseGuards, Query } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { Tenant, RequirePermissions } from '../auth/decorators';
import type { TenantContext } from '@firstelement/database';
import { Permission } from '@firstelement/auth';
import { TasksService } from './tasks.service';

@Controller('tasks')
@UseGuards(AuthGuard)
export class TasksController {
  constructor(private readonly tasksService: TasksService) {}

  @Get()
  @RequirePermissions(Permission.TASK_READ)
  async list(
    @Tenant() ctx: TenantContext,
    @Query() query: { projectId?: string; status?: string; search?: string },
  ) {
    return this.tasksService.list(ctx, {
      projectId: query.projectId,
      status: query.status as 'open' | 'completed',
      search: query.search,
    });
  }

  @Get(':id')
  @RequirePermissions(Permission.TASK_READ)
  async get(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.tasksService.getById(ctx, id);
  }

  @Post()
  @RequirePermissions(Permission.TASK_CREATE)
  async create(
    @Tenant() ctx: TenantContext,
    @Body() body: {
      title: string;
      description?: string;
      priority?: string;
      dueDate?: string;
      customerId?: string;
      leadId?: string;
      dealId?: string;
      assignedToId?: string;
    },
  ) {
    return this.tasksService.create(ctx, body);
  }

  @Patch(':id')
  @RequirePermissions(Permission.TASK_UPDATE)
  async update(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body() body: {
      title?: string;
      description?: string;
      priority?: string;
      dueDate?: string;
      status?: string;
    }
  ) {
    return this.tasksService.update(ctx, id, body);
  }

  @Delete(':id')
  @RequirePermissions(Permission.TASK_DELETE)
  async delete(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.tasksService.delete(ctx, id);
  }
}