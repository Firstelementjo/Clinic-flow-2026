import { PrismaClient } from '@prisma/client';

// Prisma is both a namespace of types and a value (Prisma.sql, Prisma.empty
// for parameterized raw queries), so it is re-exported as a value.
export { Prisma, PrismaClient } from '@prisma/client';

let singleton: PrismaClient | undefined;

/**
 * One PrismaClient per process. Re-created clients leak connection pools,
 * which shows up as "too many clients" under the worker's job concurrency
 * long before it shows up in the API.
 */
export function getPrismaClient(): PrismaClient {
  singleton ??= new PrismaClient({
    log:
      process.env.NODE_ENV === 'development'
        ? ['warn', 'error']
        : ['error'],
  });
  return singleton;
}

export async function disconnectPrisma(): Promise<void> {
  await singleton?.$disconnect();
  singleton = undefined;
}
