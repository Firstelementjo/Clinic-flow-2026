import { describe, expect, it } from 'vitest';
import { UserRole } from '@firstelement/shared';
import { Permission, PermissionDeniedError, assertCan, can, type PolicyActor } from './policy';

const ORG = 'org-1';
const OTHER_ORG = 'org-2';
const PROJECT_A = 'project-a';
const PROJECT_B = 'project-b';

const admin: PolicyActor = {
  userId: 'admin-1',
  organizationId: ORG,
  role: UserRole.ADMIN,
  projectIds: [PROJECT_A, PROJECT_B],
};

const employee: PolicyActor = {
  userId: 'employee-1',
  organizationId: ORG,
  role: UserRole.EMPLOYEE,
  projectIds: [PROJECT_A],
};

describe('role capabilities', () => {
  it('lets an admin configure the AI agent', () => {
    expect(can(admin, Permission.AI_AGENT_CONFIGURE, { projectId: PROJECT_A })).toBe(true);
  });

  it('does not let an employee configure the AI agent, even in their own project', () => {
    expect(can(employee, Permission.AI_AGENT_CONFIGURE, { projectId: PROJECT_A })).toBe(false);
  });

  it('does not let an employee connect a channel or edit escalation rules', () => {
    expect(can(employee, Permission.CHANNEL_MANAGE, { projectId: PROJECT_A })).toBe(false);
    expect(can(employee, Permission.ESCALATION_RULE_MANAGE, { projectId: PROJECT_A })).toBe(false);
  });

  it('lets an employee work the conversations in their project', () => {
    expect(can(employee, Permission.CONVERSATION_READ, { projectId: PROJECT_A })).toBe(true);
    expect(can(employee, Permission.CONVERSATION_TAKE_OVER, { projectId: PROJECT_A })).toBe(true);
    expect(can(employee, Permission.CONVERSATION_RESOLVE, { projectId: PROJECT_A })).toBe(true);
  });
});

describe('tenant boundaries', () => {
  it('blocks an employee from a project they are not a member of', () => {
    expect(can(employee, Permission.CONVERSATION_READ, { projectId: PROJECT_B })).toBe(false);
  });

  it('blocks an admin from another organization, whatever the permission', () => {
    for (const permission of Object.values(Permission)) {
      expect(can(admin, permission, { organizationId: OTHER_ORG })).toBe(false);
    }
  });

  it('blocks an admin from a project outside their resolved membership', () => {
    expect(can(admin, Permission.PROJECT_UPDATE, { projectId: 'project-elsewhere' })).toBe(false);
  });
});

describe('self-service permissions', () => {
  it('lets an employee set their own availability', () => {
    expect(
      can(employee, Permission.EMPLOYEE_SET_OWN_AVAILABILITY, { ownerUserId: employee.userId }),
    ).toBe(true);
  });

  it("does not let an employee set someone else's availability", () => {
    expect(
      can(employee, Permission.EMPLOYEE_SET_OWN_AVAILABILITY, { ownerUserId: 'employee-2' }),
    ).toBe(false);
  });

  it("lets an admin set another employee's availability", () => {
    expect(can(admin, Permission.EMPLOYEE_SET_OWN_AVAILABILITY, { ownerUserId: 'employee-2' })).toBe(
      true,
    );
  });
});

describe('assertCan', () => {
  it('throws PermissionDeniedError carrying the permission that failed', () => {
    expect(() => assertCan(employee, Permission.PROJECT_CREATE)).toThrowError(PermissionDeniedError);
    try {
      assertCan(employee, Permission.PROJECT_CREATE);
    } catch (error) {
      expect((error as PermissionDeniedError).permission).toBe(Permission.PROJECT_CREATE);
    }
  });
});
