import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const SESSION_COOKIE_NAME = 'fe_session';

/**
 * Opaque session tokens, not JWTs: revocation must be immediate (an admin
 * deactivating an employee mid-shift), and a stateless token cannot give
 * us that without a denylist that is just a session table with extra steps.
 *
 * The raw token is returned once, to be set as an httpOnly cookie. Only its
 * SHA-256 is persisted.
 */
export function createSessionToken(): { token: string; tokenHash: string } {
  const token = randomBytes(32).toString('base64url');
  return { token, tokenHash: hashSessionToken(token) };
}

export function hashSessionToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

export function safeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}

export function sessionCookieOptions(opts: { secure: boolean; ttlHours: number }) {
  return {
    httpOnly: true,
    secure: opts.secure,
    // 'lax' still sends the cookie on top-level navigation (so a bookmarked
    // /app link works) while blocking cross-site POSTs, which is the CSRF
    // vector that matters for a cookie-authenticated API.
    sameSite: 'lax' as const,
    path: '/',
    maxAge: opts.ttlHours * 60 * 60 * 1000,
  };
}
