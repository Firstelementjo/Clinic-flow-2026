import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { accessibleProjectsScope, projectScope, type TenantContext } from '@firstelement/database';
import { DomainEventType } from '@firstelement/events';
import {
  AuditAction,
  ErrorCode,
  type ClassificationQuestionView,
  type ClassificationView,
  type ResolutionView,
  type SaveClassificationInput,
  type SaveClassificationQuestionInput,
  type SaveResolutionInput,
} from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';
import { DomainEventBus } from '../events/domain-event-bus';
import { KnowledgeRetrieverProvider } from '../knowledge/knowledge.providers';

interface StoredAnswer {
  questionId: string;
  value: string;
}

@Injectable()
export class CasesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: DomainEventBus,
    private readonly retriever: KnowledgeRetrieverProvider,
  ) {}

  // --- configurable questions (V1.2 §12, §23) -------------------------------

  async listQuestions(
    ctx: TenantContext,
    projectId: string,
  ): Promise<ClassificationQuestionView[]> {
    const questions = await this.prisma.client.caseClassificationQuestion.findMany({
      where: projectScope(ctx, projectId),
      orderBy: { position: 'asc' },
    });

    return questions.map(toQuestionView);
  }

  async saveQuestion(
    ctx: TenantContext,
    projectId: string,
    input: SaveClassificationQuestionInput,
    questionId?: string,
  ): Promise<ClassificationQuestionView> {
    const scope = projectScope(ctx, projectId);

    const question = questionId
      ? await this.prisma.client.caseClassificationQuestion.update({
          where: { id: questionId },
          data: {
            position: input.position,
            promptAr: input.promptAr,
            promptEn: input.promptEn,
            options: input.options,
            isRequired: input.isRequired,
            isEnabled: input.isEnabled,
          },
        })
      : await this.prisma.client.caseClassificationQuestion.create({
          data: {
            ...scope,
            position: input.position,
            promptAr: input.promptAr,
            promptEn: input.promptEn,
            options: input.options,
            isRequired: input.isRequired,
            isEnabled: input.isEnabled,
          },
        });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CHANGED_ESCALATION_RULE,
      resourceType: 'CaseClassificationQuestion',
      resourceId: question.id,
      metadata: { position: input.position, isEnabled: input.isEnabled },
    });

    return toQuestionView(question);
  }

  async deleteQuestion(ctx: TenantContext, projectId: string, questionId: string): Promise<void> {
    const result = await this.prisma.client.caseClassificationQuestion.deleteMany({
      where: { id: questionId, ...projectScope(ctx, projectId) },
    });
    if (result.count === 0) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Question not found' });
    }
  }

  // --- classification on a conversation -------------------------------------

  async getClassification(
    ctx: TenantContext,
    conversationId: string,
  ): Promise<ClassificationView> {
    const conversation = await this.requireConversation(ctx, conversationId);

    const [record, questions] = await Promise.all([
      this.prisma.client.conversationClassification.findUnique({ where: { conversationId } }),
      this.prisma.client.caseClassificationQuestion.findMany({
        where: { projectId: conversation.projectId, isEnabled: true },
        select: { id: true, isRequired: true },
      }),
    ]);

    const answers = asAnswers(record?.answers);

    return {
      answers,
      classifiedAt: record?.classifiedAt.toISOString() ?? null,
      suggestion: record?.suggestedDocumentId
        ? await this.describeSuggestion(record.suggestedDocumentId, record.suggestionScore)
        : null,
      isComplete: isComplete(questions, answers),
    };
  }

  /**
   * Saves the agent's answers and resolves the solution they point at
   * (V1.2 §12, §13).
   *
   * Two ways a solution is found, in order:
   *
   * 1. An admin-configured mapping from answers to a specific document —
   *    the deterministic path V1.2 §23 anticipates.
   * 2. Otherwise, a knowledge search using the chosen answer labels as the
   *    query.
   *
   * Both are scoped to the conversation's own project. A case in project A
   * can never surface project B's solution, which is the requirement §13
   * states twice.
   */
  async saveClassification(
    ctx: TenantContext,
    conversationId: string,
    input: SaveClassificationInput,
  ): Promise<ClassificationView> {
    const conversation = await this.requireConversation(ctx, conversationId);

    const questions = await this.prisma.client.caseClassificationQuestion.findMany({
      where: { projectId: conversation.projectId, isEnabled: true },
    });

    // Answers referencing another project's questions are dropped rather
    // than stored: a question id from a client is a claim, not a fact.
    const validIds = new Set(questions.map((question) => question.id));
    const answers = input.answers.filter((answer) => validIds.has(answer.questionId));

    const solution = await this.findSolution(conversation.projectId, ctx, questions, answers);

    await this.prisma.client.conversationClassification.upsert({
      where: { conversationId },
      create: {
        organizationId: conversation.organizationId,
        projectId: conversation.projectId,
        conversationId,
        answers,
        suggestedDocumentId: solution?.documentId ?? null,
        suggestionScore: solution?.score ?? null,
        classifiedByUserId: ctx.userId,
      },
      update: {
        answers,
        suggestedDocumentId: solution?.documentId ?? null,
        suggestionScore: solution?.score ?? null,
        classifiedByUserId: ctx.userId,
        classifiedAt: new Date(),
      },
    });

    return {
      answers,
      classifiedAt: new Date().toISOString(),
      suggestion: solution,
      isComplete: isComplete(questions, answers),
    };
  }

  private async findSolution(
    projectId: string,
    ctx: TenantContext,
    questions: { id: string; options: unknown; promptEn: string }[],
    answers: StoredAnswer[],
  ): Promise<ClassificationView['suggestion']> {
    if (answers.length === 0) return null;

    // 1. An explicit mapping wins: it is what an ops team configured on
    // purpose, and it does not drift as documents change.
    const mappings = await this.prisma.client.caseSolutionMapping.findMany({
      where: { projectId, isEnabled: true },
      orderBy: [{ priority: 'asc' }, { id: 'asc' }],
    });

    for (const mapping of mappings) {
      const required = asAnswers(mapping.matchAnswers);
      const matches = required.every((pair) =>
        answers.some(
          (answer) => answer.questionId === pair.questionId && answer.value === pair.value,
        ),
      );
      if (required.length > 0 && matches) {
        const described = await this.describeSuggestion(mapping.documentId, null);
        if (described) return { ...described, source: 'MAPPING' };
      }
    }

    // 2. Otherwise search the project's knowledge base with the chosen
    // answer labels — readable text retrieves far better than raw values.
    const query = buildQuery(questions, answers);
    if (!query) return null;

    const result = await this.retriever.retrieve({
      organizationId: ctx.organizationId,
      projectId,
      query,
      limit: 1,
    });

    const top = result.chunks[0];
    if (!top) return null;

    return {
      documentId: top.documentId,
      documentTitle: top.documentTitle,
      score: Number(top.score.toFixed(3)),
      excerpt: top.content.slice(0, 600),
      source: 'SEARCH',
    };
  }

  private async describeSuggestion(
    documentId: string,
    score: number | null,
  ): Promise<ClassificationView['suggestion']> {
    const document = await this.prisma.client.document.findUnique({
      where: { id: documentId },
      select: {
        id: true,
        title: true,
        chunks: { select: { content: true }, orderBy: { chunkIndex: 'asc' }, take: 1 },
      },
    });

    if (!document) return null;

    return {
      documentId: document.id,
      documentTitle: document.title,
      score,
      excerpt: document.chunks[0]?.content.slice(0, 600) ?? '',
      source: 'MAPPING',
    };
  }

  // --- resolution and case state (V1.2 §14, §15) ----------------------------

  async getResolution(ctx: TenantContext, conversationId: string): Promise<ResolutionView | null> {
    await this.requireConversation(ctx, conversationId);

    const resolution = await this.prisma.client.caseResolution.findUnique({
      where: { conversationId },
    });
    if (!resolution) return null;

    const recorder = resolution.recordedByUserId
      ? await this.prisma.client.user.findUnique({
          where: { id: resolution.recordedByUserId },
          select: { fullName: true },
        })
      : null;

    return {
      id: resolution.id,
      customerIssue: resolution.customerIssue,
      agentAction: resolution.agentAction,
      usedKnowledgeBase: resolution.usedKnowledgeBase,
      documentId: resolution.documentId,
      customerAccepted: resolution.customerAccepted,
      customerSatisfied: resolution.customerSatisfied,
      escalationRequested: resolution.escalationRequested,
      escalatedToSupervisor: resolution.escalatedToSupervisor,
      outcome: resolution.outcome,
      notes: resolution.notes,
      recordedByName: recorder?.fullName ?? null,
      createdAt: resolution.createdAt.toISOString(),
    };
  }

  async saveResolution(
    ctx: TenantContext,
    conversationId: string,
    input: SaveResolutionInput,
  ): Promise<ResolutionView> {
    const conversation = await this.requireConversation(ctx, conversationId);

    // A document from another project cannot be cited as the solution.
    if (input.documentId) {
      const document = await this.prisma.client.document.findFirst({
        where: { id: input.documentId, projectId: conversation.projectId },
        select: { id: true },
      });
      if (!document) {
        throw new BadRequestException({
          code: ErrorCode.VALIDATION_FAILED,
          message: 'That document does not belong to this project',
        });
      }
    }

    const data = {
      customerIssue: input.customerIssue,
      agentAction: input.agentAction,
      usedKnowledgeBase: input.usedKnowledgeBase,
      documentId: input.documentId ?? null,
      customerAccepted: input.customerAccepted ?? null,
      customerSatisfied: input.customerSatisfied ?? null,
      escalationRequested: input.escalationRequested,
      escalatedToSupervisor: input.escalatedToSupervisor,
      outcome: input.outcome,
      notes: input.notes ?? null,
      recordedByUserId: ctx.userId,
    };

    await this.prisma.client.caseResolution.upsert({
      where: { conversationId },
      create: {
        organizationId: conversation.organizationId,
        projectId: conversation.projectId,
        conversationId,
        ...data,
      },
      update: data,
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId: conversation.projectId,
      actorUserId: ctx.userId,
      action: AuditAction.EMPLOYEE_RESOLVED_CONVERSATION,
      resourceType: 'CaseResolution',
      resourceId: conversationId,
      // Outcome and satisfaction only — the narrative fields can contain
      // customer detail and do not belong in an audit trail.
      metadata: { outcome: input.outcome, satisfied: input.customerSatisfied },
    });

    const saved = await this.getResolution(ctx, conversationId);
    if (!saved) throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Not saved' });
    return saved;
  }

  /**
   * Close or reopen the case (V1.2 §15).
   *
   * Closing requires a resolution record: a case closed with no account of
   * how it ended is exactly the gap §14 exists to prevent.
   */
  async setCaseState(
    ctx: TenantContext,
    conversationId: string,
    action: 'close' | 'reopen',
  ): Promise<{ status: string }> {
    const conversation = await this.requireConversation(ctx, conversationId);

    if (action === 'close') {
      const resolution = await this.prisma.client.caseResolution.findUnique({
        where: { conversationId },
        select: { id: true },
      });
      if (!resolution) {
        throw new BadRequestException({
          code: ErrorCode.VALIDATION_FAILED,
          message: 'Record how the case was resolved before closing it',
        });
      }
    }

    const status = action === 'close' ? 'CLOSED' : 'OPEN';

    await this.prisma.client.conversation.update({
      where: { id: conversationId },
      data: {
        status,
        closedAt: action === 'close' ? new Date() : null,
        ...(action === 'reopen' ? { resolvedAt: null } : {}),
      },
    });

    this.events.publish({
      type: DomainEventType.CONVERSATION_UPDATED,
      organizationId: conversation.organizationId,
      projectId: conversation.projectId,
      aggregateId: conversationId,
      aggregateType: 'Conversation',
      actorUserId: ctx.userId,
      payload: { status, previousStatus: conversation.status },
      occurredAt: new Date(),
    });

    return { status };
  }

  private async requireConversation(ctx: TenantContext, conversationId: string) {
    const conversation = await this.prisma.client.conversation.findFirst({
      where: { id: conversationId, ...accessibleProjectsScope(ctx) },
      select: { id: true, organizationId: true, projectId: true, status: true },
    });

    if (!conversation) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Conversation not found' });
    }

    return conversation;
  }
}

function toQuestionView(question: {
  id: string;
  position: number;
  promptAr: string;
  promptEn: string;
  options: unknown;
  isRequired: boolean;
  isEnabled: boolean;
}): ClassificationQuestionView {
  return {
    id: question.id,
    position: question.position,
    promptAr: question.promptAr,
    promptEn: question.promptEn,
    options: Array.isArray(question.options)
      ? (question.options as ClassificationQuestionView['options'])
      : [],
    isRequired: question.isRequired,
    isEnabled: question.isEnabled,
  };
}

function asAnswers(value: unknown): StoredAnswer[] {
  if (!Array.isArray(value)) return [];
  return value.filter(
    (item): item is StoredAnswer =>
      typeof item === 'object' &&
      item !== null &&
      typeof (item as StoredAnswer).questionId === 'string' &&
      typeof (item as StoredAnswer).value === 'string',
  );
}

function isComplete(
  questions: { id: string; isRequired: boolean }[],
  answers: StoredAnswer[],
): boolean {
  return questions
    .filter((question) => question.isRequired)
    .every((question) => answers.some((answer) => answer.questionId === question.id));
}

/** Builds the retrieval query from the chosen answers' readable labels. */
function buildQuery(
  questions: { id: string; options: unknown; promptEn: string }[],
  answers: StoredAnswer[],
): string {
  const parts: string[] = [];

  for (const answer of answers) {
    const question = questions.find((item) => item.id === answer.questionId);
    if (!question) continue;

    const options = Array.isArray(question.options)
      ? (question.options as { value: string; labelAr?: string; labelEn?: string }[])
      : [];
    const option = options.find((item) => item.value === answer.value);

    // Both languages go into the query: the knowledge base may be written
    // in either, and the mock embedding provider is lexical.
    parts.push(option?.labelEn ?? answer.value, option?.labelAr ?? '');
  }

  return parts.filter(Boolean).join(' ').trim();
}
