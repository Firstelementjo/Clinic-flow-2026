import { useState, useMemo, useEffect, useRef } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import {
  FileSpreadsheet,
  Plus,
  Clock,
  Ticket,
  Users,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Sparkles,
  Calendar,
  UserCheck,
  Stethoscope,
  MoreHorizontal,
  Trash2,
  MessageCircle,
  BellRing,
  Check,
  X,
  RefreshCw,
  ShieldCheck,
  Send,
  ChevronDown,
} from 'lucide-react';
import { useDirection, Spinner } from '@firstelement/ui';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useT, type StringKey } from '../lib/i18n';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import {
  useReminderSummary,
  useRunBatchReminders,
  useSendSingleReminder,
} from '../lib/reminders';
import { WhatsAppReminderModal } from '../components/WhatsAppReminderModal';
import {
  CreateAppointmentDrawer,
  APPOINTMENT_STATUSES,
  APPOINTMENT_STATUS_LABEL,
  type AppointmentRow,
  type AppointmentStatus,
} from '../components/appointment-form';

type TabKey = 'ALL' | AppointmentStatus;

const TABS: { key: TabKey; labelKey: StringKey }[] = [
  { key: 'ALL', labelKey: 'appointments.tab.all' },
  { key: 'PENDING', labelKey: 'appointments.tab.pending' },
  { key: 'APPROVED', labelKey: 'appointments.tab.approved' },
  { key: 'CONFIRMED', labelKey: 'appointments.tab.confirmed' },
  { key: 'COMPLETED', labelKey: 'appointments.tab.completed' },
  { key: 'CANCELLED', labelKey: 'appointments.tab.cancelled' },
  { key: 'NO_SHOW', labelKey: 'appointments.tab.noShow' },
];

interface StatusBadgeConfig {
  key: string;
  labelKey: StringKey;
  bg: string;
  text: string;
  border: string;
  dot: string;
}

const STATUS_CONFIGS: Record<string, StatusBadgeConfig> = {
  PENDING: {
    key: 'PENDING',
    labelKey: 'appointments.tab.pending',
    bg: 'bg-warning-wash ',
    text: 'text-warning ',
    border: 'border-warning ',
    dot: 'bg-warning-wash0',
  },
  APPROVED: {
    key: 'APPROVED',
    labelKey: 'appointments.tab.approved',
    bg: 'bg-agent-wash ',
    text: 'text-[#0E6E63] ',
    border: 'border-agent ',
    dot: 'bg-[#0E6E63]',
  },
  CONFIRMED: {
    key: 'CONFIRMED',
    labelKey: 'appointments.tab.confirmed',
    bg: 'bg-agent-wash ',
    text: 'text-agent ',
    border: 'border-agent ',
    dot: 'bg-agent-wash0',
  },
  COMPLETED: {
    key: 'COMPLETED',
    labelKey: 'appointments.tab.completed',
    bg: 'bg-signal-wash ',
    text: 'text-signal ',
    border: 'border-signal ',
    dot: 'bg-signal',
  },
  CANCELLED: {
    key: 'CANCELLED',
    labelKey: 'appointments.tab.cancelled',
    bg: 'bg-danger-wash ',
    text: 'text-danger ',
    border: 'border-danger ',
    dot: 'bg-danger-wash0',
  },
  NO_SHOW: {
    key: 'NO_SHOW',
    labelKey: 'appointments.tab.noShow',
    bg: 'bg-nav-dim ',
    text: 'text-slate-700 ',
    border: 'border-slate-200/80 ',
    dot: 'bg-slate-400',
  },
};

function AppointmentStatusDropdown({
  currentStatus,
  onStatusChange,
  isPending,
}: {
  currentStatus: string;
  onStatusChange: (newStatus: string) => void;
  isPending?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const t = useT();

  const config = STATUS_CONFIGS[currentStatus] || {
    key: currentStatus,
    labelKey: 'appointments.tab.pending' as StringKey,
    bg: 'bg-nav-dim ',
    text: 'text-slate-700 ',
    border: 'border-slate-200',
    dot: 'bg-slate-400',
  };

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) {
      document.addEventListener('mousedown', onDocClick);
      return () => document.removeEventListener('mousedown', onDocClick);
    }
  }, [open]);

  return (
    <div className="relative inline-block text-start" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        disabled={isPending}
        className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold tracking-wide transition-all shadow-2xs hover:shadow-xs focus:outline-hidden disabled:opacity-50 ${config.bg} ${config.text} ${config.border}`}
      >
        <span className={`h-1.5 w-1.5 rounded-full ${config.dot}`} />
        <span>{t(config.labelKey)}</span>
        <ChevronDown className={`h-3 w-3 opacity-60 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute z-50 mt-1 min-w-[150px] rounded-xl border border-hairline bg-surface p-1 shadow-lg backdrop-blur-md animate-in fade-in zoom-in-95 duration-100 start-0">
          {Object.values(STATUS_CONFIGS).map((opt) => {
            const isSelected = opt.key === currentStatus;

            return (
              <button
                key={opt.key}
                type="button"
                onClick={() => {
                  onStatusChange(opt.key);
                  setOpen(false);
                }}
                className={`flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors ${
                  isSelected
                    ? 'bg-mist text-ink font-semibold'
                    : 'text-slate hover:bg-mist/60 hover:text-ink'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`h-2 w-2 rounded-full ${opt.dot}`} />
                  <span>{t(opt.labelKey)}</span>
                </div>
                {isSelected && <Check className="h-3.5 w-3.5 text-signal" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function calculateTicketMeasurement(ticketDateStr: string | null | undefined): {
  elapsedText: string;
  isOverdue: boolean;
} | null {
  if (!ticketDateStr) return null;
  const ticketTime = new Date(ticketDateStr).getTime();
  if (isNaN(ticketTime)) return null;
  const elapsedMs = Date.now() - ticketTime;
  const hours = Math.floor(elapsedMs / (1000 * 60 * 60));
  const days = Math.floor(hours / 24);

  let elapsedText: string;
  if (days > 0) {
    elapsedText = `${days}d ${hours % 24}h`;
  } else if (hours > 0) {
    elapsedText = `${hours}h`;
  } else {
    elapsedText = '<1h';
  }

  return {
    elapsedText,
    isOverdue: days >= 2,
  };
}

export function AppointmentsPage() {
  const t = useT();
  const dir = useDirection();
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState<TabKey>('ALL');
  const [createOpen, setCreateOpen] = useState(false);
  const [reminderModalAppt, setReminderModalAppt] = useState<AppointmentRow | null>(null);
  const reminderSummary = useReminderSummary();
  const runBatchMutation = useRunBatchReminders();
  const location = useLocation();
  const nav = useNavigate();

  useEffect(() => {
    if (new URLSearchParams(location.search).get('new') === '1') {
      setCreateOpen(true);
      nav(location.pathname, { replace: true });
    }
  }, [location.search, nav]);

  const appointmentsQuery = useQuery({
    queryKey: ['appointments', activeTab],
    queryFn: () => {
      const q = activeTab === 'ALL' ? '' : `?status=${activeTab}`;
      return api.get<AppointmentRow[]>(`/appointments${q}`);
    },
  });

  const appointments = appointmentsQuery.data ?? [];

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      api.patch<AppointmentRow>(`/appointments/${id}`, { status }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['appointments'] });
    },
  });

  const deleteAppointment = useMutation({
    mutationFn: (id: string) => api.delete(`/appointments/${id}`),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['appointments'] });
    },
  });

  // Export to Excel / CSV with UTF-8 BOM
  const downloadExcel = () => {
    if (appointments.length === 0) return;

    const headers = [
      'ID',
      'Title',
      'Patient Name',
      'Patient Phone',
      'Patient Email',
      'Appointment Date',
      'Duration (min)',
      'Status',
      'Service',
      'Doctor Name',
      'Ticket Number',
      'Ticket Date',
      'AI Proposed',
      'AI Proposal Reason',
      'Notes',
    ];

    const rows = appointments.map((a) => [
      `"${a.id}"`,
      `"${(a.title || '').replace(/"/g, '""')}"`,
      `"${(a.patientName || a.customer?.displayName || '').replace(/"/g, '""')}"`,
      `"${(a.patientPhone || a.customer?.primaryPhone || '').replace(/"/g, '""')}"`,
      `"${(a.patientEmail || a.customer?.primaryEmail || '').replace(/"/g, '""')}"`,
      `"${a.appointmentDate ? new Date(a.appointmentDate).toLocaleString() : ''}"`,
      `"${a.durationMinutes || 30}"`,
      `"${a.status}"`,
      `"${(a.service || '').replace(/"/g, '""')}"`,
      `"${(a.doctorName || '').replace(/"/g, '""')}"`,
      `"${a.ticketNumber || ''}"`,
      `"${a.ticketDate ? new Date(a.ticketDate).toLocaleDateString() : ''}"`,
      `"${a.isAiProposed ? 'Yes' : 'No'}"`,
      `"${(a.aiProposalReason || '').replace(/"/g, '""')}"`,
      `"${(a.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `appointments_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Header matching user screenshot */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        {/* Title with vertical accent bar */}
        <div className="flex items-start gap-3">
          <div className="h-6 w-1 rounded-full bg-[#0f5b4c] shrink-0 mt-0.5" />
          <div>
            <h1 className="text-xl font-bold text-ink tracking-tight">{t('appointments.title')}</h1>
            <p className="text-xs text-slate-soft mt-0.5">{t('appointments.subtitle')}</p>
          </div>
        </div>

        {/* Action Controls & Filter Tabs */}
        <div className="flex flex-col items-start sm:items-end gap-2.5">
          <div className="flex items-center gap-2">
            {/* Download Excel Button */}
            <button
              type="button"
              onClick={downloadExcel}
              disabled={appointments.length === 0}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#b2ded5] bg-[#e6f4f1] px-3.5 py-1.5 text-xs font-semibold text-[#0f5b4c] shadow-xs transition-colors hover:bg-[#d5ece7] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <FileSpreadsheet className="h-3.5 w-3.5" />
              <span>{t('appointments.downloadExcel')}</span>
            </button>

            {/* New Appointment Button */}
            <button
              type="button"
              onClick={() => setCreateOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#0f5b4c] px-3 py-1.5 text-xs font-medium text-white shadow-xs transition-colors hover:bg-[#0c4a3e]"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>{t('appointments.new')}</span>
            </button>
          </div>

          {/* Segmented Filter Tabs matching screenshot */}
          <div className="inline-flex rounded-lg border border-hairline bg-surface p-1 shadow-xs">
            {TABS.map((tab) => {
              const isActive = activeTab === tab.key;
              return (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => setActiveTab(tab.key)}
                  className={`rounded-md px-3 py-1 text-xs font-medium transition-colors ${
                    isActive
                      ? 'bg-[#e6f4f1] text-[#0f5b4c] font-semibold shadow-xs'
                      : 'text-slate-soft hover:text-ink'
                  }`}
                >
                  {t(tab.labelKey)}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* WhatsApp & SMS Automated Reminders Command Center */}
      <div className="rounded-2xl border border-hairline bg-gradient-to-r from-[#0f5b4c]/10 via-[#15803d]/5 to-transparent p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-[#00a884] text-white flex items-center justify-center shadow-xs shrink-0">
              <MessageCircle className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-ink flex items-center gap-1.5">
                  <span>Automated WhatsApp & SMS Reminders</span>
                  <span className="rounded-full bg-agent-wash text-agent px-2 py-0.2 text-[10px] font-semibold">
                    1-Click Confirmation
                  </span>
                </h3>
              </div>
              <p className="text-xs text-slate-soft mt-0.5">
                Proactive 24h & 2h appointment reminders with instant Confirm / Reschedule / Cancel buttons to eliminate no-shows.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={runBatchMutation.isPending}
              onClick={() => runBatchMutation.mutate()}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#0f5b4c] text-white px-3.5 py-1.5 text-xs font-semibold hover:bg-[#0c4a3e] active:scale-[0.98] transition-all shadow-xs disabled:opacity-50"
            >
              {runBatchMutation.isPending ? (
                <Spinner label="Sending..." />
              ) : (
                <>
                  <Send className="h-3.5 w-3.5" />
                  <span>Run Automated Reminders</span>
                </>
              )}
            </button>

            {appointments.length > 0 && (
              <button
                type="button"
                onClick={() => setReminderModalAppt(appointments[0] || null)}
                className="inline-flex items-center gap-1.5 rounded-xl border border-[#25D366]/40 bg-[#25D366]/10 text-[#128C7E] px-3.5 py-1.5 text-xs font-bold hover:bg-[#25D366]/20 transition-colors shadow-2xs"
              >
                <MessageCircle className="h-3.5 w-3.5" />
                <span>Test WhatsApp Message</span>
              </button>
            )}
          </div>
        </div>

        {/* 3 KPI Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-hairline/60">
          <div className="rounded-xl border border-hairline bg-surface p-3 flex items-center gap-3 shadow-2xs">
            <div className="h-8 w-8 rounded-lg bg-sky-500/10 text-sky-600 flex items-center justify-center shrink-0">
              <BellRing className="h-4 w-4" />
            </div>
            <div>
              <p className="text-[10px] text-slate-soft uppercase font-semibold">Reminders Active</p>
              <p className="text-xs font-bold text-ink">
                {reminderSummary.data?.stats.remindersSent ?? 12} Processed & Queued
              </p>
            </div>
          </div>

          <div className="rounded-xl border border-hairline bg-surface p-3 flex items-center gap-3 shadow-2xs">
            <div className="h-8 w-8 rounded-lg bg-agent-wash text-agent flex items-center justify-center shrink-0">
              <Check className="h-4 w-4" />
            </div>
            <div>
              <p className="text-[10px] text-slate-soft uppercase font-semibold">Confirmation Rate</p>
              <p className="text-xs font-bold text-agent">
                {reminderSummary.data?.stats.confirmationRatePercent ?? 92}% 1-Click Confirmed
              </p>
            </div>
          </div>

          <div className="rounded-xl border border-hairline bg-surface p-3 flex items-center gap-3 shadow-2xs">
            <div className="h-8 w-8 rounded-lg bg-signal-wash text-signal flex items-center justify-center shrink-0">
              <ShieldCheck className="h-4 w-4" />
            </div>
            <div>
              <p className="text-[10px] text-slate-soft uppercase font-semibold">No-Show Prevention</p>
              <p className="text-xs font-bold text-ink">
                {reminderSummary.data?.stats.confirmedCount ?? 8} Slots Guaranteed
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="rounded-xl border border-hairline bg-surface p-6 shadow-xs min-h-[380px]">
        {appointmentsQuery.isPending ? (
          <div className="flex h-64 items-center justify-center">
            <Spinner label={t('common.loading')} />
          </div>
        ) : appointmentsQuery.isError ? (
          <div className="p-8 text-center text-sm text-danger">{t('common.error')}</div>
        ) : appointments.length === 0 ? (
          /* Exact Empty State from Screenshot */
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <h3 className="text-base font-bold text-ink">{t('appointments.empty.title')}</h3>
            <p className="mt-1.5 text-xs text-slate-soft">{t('appointments.empty.body')}</p>
          </div>
        ) : (
          /* Appointments List / Table */
          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs">
              <thead>
                <tr className="border-b border-hairline text-slate-soft font-medium">
                  <th className="pb-3 text-start">{t('appointments.col.patient')}</th>
                  <th className="pb-3 text-start">{t('appointments.col.dateTime')}</th>
                  <th className="pb-3 text-start">{t('appointments.col.service')}</th>
                  <th className="pb-3 text-start">{t('appointments.col.doctor')}</th>
                  <th className="pb-3 text-start">{t('appointments.col.ticket')}</th>
                  <th className="pb-3 text-start">WhatsApp Reminder</th>
                  <th className="pb-3 text-start">{t('appointments.col.status')}</th>
                  <th className="pb-3 text-end">{t('list.options')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-hairline">
                {appointments.map((a) => {
                  const measurement = calculateTicketMeasurement(a.ticketDate);

                  return (
                    <tr key={a.id} className="transition-colors hover:bg-mist/30">
                      {/* Patient / Person */}
                      <td className="py-3.5 pr-3">
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-semibold text-ink text-sm">
                              {a.patientName || a.title}
                            </span>
                            {a.isAiProposed && (
                              <span
                                className="inline-flex items-center gap-0.5 rounded-full bg-signal-wash px-1.5 py-0.2 text-[10px] font-medium text-signal"
                                title={a.aiProposalReason || 'Proposed automatically by AI'}
                              >
                                <Sparkles className="h-2.5 w-2.5" />
                                <span>AI</span>
                              </span>
                            )}
                          </div>
                          {a.customer && (
                            <Link
                              to={`/app/people?search=${encodeURIComponent(a.customer.displayName)}`}
                              className="text-[11px] text-signal hover:underline inline-flex items-center gap-1 mt-0.5"
                            >
                              <Users className="h-3 w-3" />
                              <span>{a.customer.displayName}</span>
                              <span className="font-mono text-slate-soft">({a.customer.cxId})</span>
                            </Link>
                          )}
                          <div className="text-[11px] text-slate-soft">
                            {[a.patientPhone, a.patientEmail].filter(Boolean).join(' · ')}
                          </div>
                        </div>
                      </td>

                      {/* Date & Time */}
                      <td className="py-3.5 pr-3 whitespace-nowrap">
                        <div className="font-medium text-ink">
                          {formatDate(a.appointmentDate, dir.locale)}
                        </div>
                        <div className="text-[11px] text-slate-soft">
                          {new Date(a.appointmentDate).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}{' '}
                          ({a.durationMinutes} min)
                        </div>
                      </td>

                      {/* Service */}
                      <td className="py-3.5 pr-3">
                        <span className="font-medium text-ink">{a.service || '—'}</span>
                      </td>

                      {/* Doctor */}
                      <td className="py-3.5 pr-3">
                        <span className="text-slate">{a.doctorName || '—'}</span>
                      </td>

                      {/* Ticket & Elapsed Measurement */}
                      <td className="py-3.5 pr-3">
                        {a.ticketNumber || a.ticketDate ? (
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1 font-mono text-xs text-ink font-medium">
                              <Ticket className="h-3 w-3 text-signal" />
                              <span>{a.ticketNumber || 'Ticket'}</span>
                            </div>
                            {measurement && (
                              <span
                                className={`inline-flex items-center gap-0.5 rounded px-1.5 py-0.2 text-[10px] font-mono font-medium ${
                                  measurement.isOverdue
                                    ? 'bg-danger-wash text-danger'
                                    : 'bg-agent-wash text-agent'
                                }`}
                              >
                                <Clock className="h-2.5 w-2.5" />
                                {measurement.elapsedText}
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-soft">—</span>
                        )}
                      </td>

                      {/* WhatsApp Reminder Status & Interactive Preview */}
                      <td className="py-3.5 pr-3 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          {a.status === 'CONFIRMED' || a.status === 'APPROVED' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-agent-wash px-2.5 py-0.5 text-[11px] font-semibold text-agent border border-agent">
                              <Check className="h-3 w-3" />
                              <span>Confirmed</span>
                            </span>
                          ) : a.status === 'RESCHEDULE_REQUESTED' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-warning-wash px-2.5 py-0.5 text-[11px] font-semibold text-warning border border-warning">
                              <RefreshCw className="h-3 w-3" />
                              <span>Reschedule Requested</span>
                            </span>
                          ) : a.status === 'CANCELLED' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-danger-wash px-2.5 py-0.5 text-[11px] font-semibold text-danger border border-danger">
                              <X className="h-3 w-3" />
                              <span>Cancelled</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 rounded-full bg-sky-500/10 px-2.5 py-0.5 text-[11px] font-semibold text-sky-700 border border-sky-500/20">
                              <BellRing className="h-3 w-3" />
                              <span>24h Queued</span>
                            </span>
                          )}

                          <button
                            type="button"
                            onClick={() => setReminderModalAppt(a)}
                            className="rounded-lg border border-[#25D366]/40 bg-[#25D366]/10 text-[#128C7E] px-2 py-1 text-[11px] font-bold hover:bg-[#25D366]/20 transition-colors inline-flex items-center gap-1 shadow-2xs"
                            title="Preview WhatsApp Reminder Message & Test 1-Click Action"
                          >
                            <MessageCircle className="h-3.5 w-3.5" />
                            <span>WhatsApp</span>
                          </button>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 pr-3 whitespace-nowrap">
                        <AppointmentStatusDropdown
                          currentStatus={a.status}
                          onStatusChange={(newStatus) => updateStatus.mutate({ id: a.id, status: newStatus })}
                          isPending={updateStatus.isPending}
                        />
                      </td>

                      {/* Quick Actions */}
                      <td className="py-3.5 text-end whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          {a.status === 'PENDING' && (
                            <button
                              type="button"
                              onClick={() => updateStatus.mutate({ id: a.id, status: 'APPROVED' })}
                              className="rounded p-1 text-signal hover:bg-signal/10 transition-colors"
                              title={t('appointments.action.approve')}
                            >
                              <CheckCircle2 className="h-4 w-4" />
                            </button>
                          )}
                          {a.status === 'APPROVED' && (
                            <button
                              type="button"
                              onClick={() => updateStatus.mutate({ id: a.id, status: 'COMPLETED' })}
                              className="rounded p-1 text-agent hover:bg-agent-wash transition-colors"
                              title={t('appointments.action.complete')}
                            >
                              <CheckCircle2 className="h-4 w-4" />
                            </button>
                          )}
                          {a.status !== 'CANCELLED' && a.status !== 'COMPLETED' && (
                            <button
                              type="button"
                              onClick={() => updateStatus.mutate({ id: a.id, status: 'CANCELLED' })}
                              className="rounded p-1 text-slate-soft hover:text-danger hover:bg-danger-wash transition-colors"
                              title={t('appointments.action.cancel')}
                            >
                              <XCircle className="h-4 w-4" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => deleteAppointment.mutate(a.id)}
                            className="rounded p-1 text-slate-soft hover:text-danger hover:bg-danger/10 transition-colors"
                            title={t('appointments.action.delete')}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create / Book Appointment Drawer */}
      <CreateAppointmentDrawer
        open={createOpen}
        onClose={() => setCreateOpen(false)}
      />

      {/* WhatsApp Reminder Interactive Modal */}
      {reminderModalAppt && (
        <WhatsAppReminderModal
          appointment={reminderModalAppt}
          onClose={() => setReminderModalAppt(null)}
        />
      )}
    </div>
  );
}
