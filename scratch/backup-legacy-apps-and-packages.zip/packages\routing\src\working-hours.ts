/**
 * Working-hours evaluation (plan §10).
 *
 * Windows are stored as a local weekday plus minutes from local midnight,
 * not as instants, because working hours are a recurring local-time
 * concept. Storing them as timestamps makes every daylight-saving change a
 * data migration, and gets the Gulf/Levant split wrong twice a year for
 * the Levant half.
 *
 * Evaluation therefore converts "now" into the employee's own zone rather
 * than converting their hours into UTC.
 */

export interface AvailabilityWindow {
  /** 0 = Sunday, matching the Gulf working week. */
  dayOfWeek: number;
  startMinute: number;
  endMinute: number;
  timezone: string;
}

export interface LocalMoment {
  dayOfWeek: number;
  minuteOfDay: number;
}

/**
 * "Now" as the employee experiences it.
 *
 * `Intl` is doing the timezone arithmetic, including DST — a hand-rolled
 * offset table is the classic way this feature breaks in October.
 */
export function toLocalMoment(instant: Date, timezone: string): LocalMoment {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone,
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(instant);

  const lookup = (type: string) => parts.find((part) => part.type === type)?.value ?? '';

  const weekdays: Record<string, number> = {
    Sun: 0,
    Mon: 1,
    Tue: 2,
    Wed: 3,
    Thu: 4,
    Fri: 5,
    Sat: 6,
  };

  const hour = Number(lookup('hour'));
  return {
    dayOfWeek: weekdays[lookup('weekday')] ?? 0,
    // Intl renders midnight as 24 in some locales' 24-hour output.
    minuteOfDay: (hour === 24 ? 0 : hour) * 60 + Number(lookup('minute')),
  };
}

/**
 * Whether an employee is inside any of their windows right now.
 *
 * No windows at all means "always available" rather than "never": an
 * organization that has not configured schedules yet should still be able
 * to receive escalations, and a routing engine that silently assigned
 * nothing would look like a broken queue.
 */
export function isWithinWorkingHours(
  windows: AvailabilityWindow[],
  instant: Date = new Date(),
): boolean {
  if (windows.length === 0) return true;

  return windows.some((window) => {
    const local = toLocalMoment(instant, window.timezone);

    // A window that ends before it starts crosses midnight — a night
    // shift is 22:00 to 06:00, and both halves must match.
    if (window.endMinute <= window.startMinute) {
      const previousDay = (window.dayOfWeek + 1) % 7;
      return (
        (local.dayOfWeek === window.dayOfWeek && local.minuteOfDay >= window.startMinute) ||
        (local.dayOfWeek === previousDay && local.minuteOfDay < window.endMinute)
      );
    }

    return (
      local.dayOfWeek === window.dayOfWeek &&
      local.minuteOfDay >= window.startMinute &&
      local.minuteOfDay < window.endMinute
    );
  });
}

/** Formats a window as `09:00–17:00` for the UI. */
export function formatWindow(window: AvailabilityWindow): string {
  return `${formatMinute(window.startMinute)}–${formatMinute(window.endMinute)}`;
}

function formatMinute(minute: number): string {
  const hours = Math.floor(minute / 60) % 24;
  const minutes = minute % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}
