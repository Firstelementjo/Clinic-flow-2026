import type { NormalizedIncomingMessage } from '@firstelement/connectors';
import type { PrismaClient } from '@firstelement/database';
import { DomainEventType, type DomainEventPublisher } from '@firstelement/events';
import { ChannelType, MessageAuthorType, MessageDirection, generateTicketNumber, nextTicketSequence } from '@firstelement/shared';
import { IdentityResolver } from './identity-resolver';
import { projectHasActiveAgent } from './ai-dispatch';

export interface InboundJob {
  organizationId: string;
  projectId: string;
  connectionId: string;
  channel: ChannelType;
  message: NormalizedIncomingMessage;
}

export type InboundResult =
  | { status: 'processed'; conversationId: string; customerId: string; messageId: string; conversationCreated: boolean }
  | { status: 'duplicate'; conversationId: string | null; externalMessageId: string };

/** Prisma's unique-constraint violation. */
const UNIQUE_VIOLATION = 'P2002';

/**
 * Inbound message pipeline (plan §16 slice 3).
 *
 * webhook → customer → conversation → message → events. The AI, scoring
 * and routing stages subscribe to those events in later slices rather than
 * being called from here, so this pipeline does not grow a branch every
 * time a new consumer appears (plan §8b).
 *
 * Runs in the worker under BullMQ. Retries are expected, so every step is
 * safe to repeat.
 */
export class InboundMessagePipeline {
  private readonly identities: IdentityResolver;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: DomainEventPublisher,
  ) {
    this.identities = new IdentityResolver(prisma, events);
  }

  async process(job: InboundJob): Promise<InboundResult> {
    const { message } = job;

    const customer = await this.identities.resolve({
      organizationId: job.organizationId,
      projectId: job.projectId,
      platform: job.channel,
      externalId: message.externalUserId,
      displayName: message.displayName,
      phone: message.phone,
      email: message.email,
      rawProfile: message.raw,
    });

    const { conversationId, created } = await this.findOrCreateConversation({
      organizationId: job.organizationId,
      projectId: job.projectId,
      customerId: customer.customerId,
      channel: job.channel,
      sentAt: message.sentAt,
    });

    try {
      const stored = await this.prisma.$transaction(async (tx) => {
        const created = await tx.message.create({
          data: {
            organizationId: job.organizationId,
            projectId: job.projectId,
            conversationId,
            channel: job.channel,
            direction: MessageDirection.INBOUND,
            authorType: MessageAuthorType.CUSTOMER,
            body: message.text,
            attachments: message.attachments as unknown as object,
            externalMessageId: message.externalMessageId,
            deliveryStatus: 'DELIVERED',
            metadata: { connectionId: job.connectionId } as object,
            sentAt: message.sentAt,
          },
          select: { id: true },
        });

        await tx.conversation.update({
          where: { id: conversationId },
          data: {
            messageCount: { increment: 1 },
            lastMessageAt: message.sentAt,
          },
        });

        return created;
      });

      this.events.publish({
        type: DomainEventType.MESSAGE_CREATED,
        organizationId: job.organizationId,
        projectId: job.projectId,
        aggregateId: stored.id,
        aggregateType: 'Message',
        payload: {
          conversationId,
          customerId: customer.customerId,
          channel: job.channel,
          direction: MessageDirection.INBOUND,
          authorType: MessageAuthorType.CUSTOMER,
          bodyLength: message.text.length,
        },
        occurredAt: message.sentAt,
      });

      return {
        status: 'processed',
        conversationId,
        customerId: customer.customerId,
        messageId: stored.id,
        conversationCreated: created,
      };
    } catch (error) {
      // The provider redelivered a message we already stored. The unique
      // index on (projectId, channel, externalMessageId) is what decides
      // this — not a prior SELECT, which would race under concurrent
      // deliveries and double-post to the customer (plan §8).
      if (isUniqueViolation(error)) {
        return {
          status: 'duplicate',
          conversationId,
          externalMessageId: message.externalMessageId,
        };
      }
      throw error;
    }
  }

  /**
   * One open conversation per customer per channel. A closed thread plus a
   * new message starts a new conversation, which keeps resolution times
   * and AI runs attributable to the exchange they belong to.
   */
  private async findOrCreateConversation(params: {
    organizationId: string;
    projectId: string;
    customerId: string;
    channel: ChannelType;
    sentAt: Date;
  }): Promise<{ conversationId: string; created: boolean }> {
    const latest = await this.prisma.conversation.findFirst({
      where: {
        organizationId: params.organizationId,
        projectId: params.projectId,
        customerId: params.customerId,
        channel: params.channel,
        status: { in: ['OPEN', 'PENDING', 'RESOLVED'] },
      },
      select: { id: true, status: true },
      orderBy: { lastMessageAt: 'desc' },
    });

    if (latest) {
      console.log('LATEST CONVERSATION FOUND:', latest.id, latest.status);
      if (latest.status === 'RESOLVED') {
        console.log('UPDATING TO OPEN');
        const updated = await this.prisma.conversation.update({
          where: { id: latest.id },
          data: { status: 'OPEN', resolvedAt: null },
        });
        console.log('UPDATED CONVERSATION:', updated.id, updated.status);
      }
      return { conversationId: latest.id, created: false };
    }

    // A project with a live agent answers with AI; one without waits for a
    // person. Defaulting to HUMAN is the safe direction (plan §20.1).
    const hasAgent = await projectHasActiveAgent(this.prisma, {
      organizationId: params.organizationId,
      projectId: params.projectId,
    });
    const mode = hasAgent ? 'AI' : 'HUMAN';

    const ticketNumber = await (async () => {
      const seq = await nextTicketSequence(this.prisma, params.sentAt);
      return generateTicketNumber(params.sentAt, seq);
    })();

    const conversation = await this.prisma.conversation.create({
      data: {
        organizationId: params.organizationId,
        projectId: params.projectId,
        customerId: params.customerId,
        channel: params.channel,
        status: 'OPEN',
        mode,
        ticketNumber,
        lastMessageAt: params.sentAt,
        messageCount: 0,
      },
      select: { id: true },
    });

    this.events.publish({
      type: DomainEventType.CONVERSATION_CREATED,
      organizationId: params.organizationId,
      projectId: params.projectId,
      aggregateId: conversation.id,
      aggregateType: 'Conversation',
      payload: { customerId: params.customerId, channel: params.channel, mode },
      occurredAt: params.sentAt,
    });

    return { conversationId: conversation.id, created: true };
  }
}

function isUniqueViolation(error: unknown): boolean {
  return (
    typeof error === 'object' &&
    error !== null &&
    'code' in error &&
    (error as { code?: unknown }).code === UNIQUE_VIOLATION
  );
}
