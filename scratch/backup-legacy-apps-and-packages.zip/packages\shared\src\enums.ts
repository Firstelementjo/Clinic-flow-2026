/**
 * Domain enums shared by API, worker, and web.
 *
 * These mirror the Prisma enums in `@firstelement/database` one-for-one.
 * Keep them in sync — the database is the enforcement point, this is the
 * transport/UI vocabulary.
 */

export const UserRole = {
  ADMIN: 'ADMIN',
  EMPLOYEE: 'EMPLOYEE',
  /**
   * The clinic front desk, and nothing else.
   *
   * Narrower than `EMPLOYEE` on purpose: an employee holds this same front-desk
   * grant *plus* the whole CRM surface, so a receptionist and an employee who can
   * read every note, customer and conversation are currently the same principal.
   * A booking clerk who cannot read clinical notes they have no case for needs a
   * role of its own. See `CLINIC_STAFF_GRANT` in `@firstelement/auth`.
   */
  CLINIC_STAFF: 'CLINIC_STAFF',
} as const;
export type UserRole = (typeof UserRole)[keyof typeof UserRole];

export const ConversationMode = {
  AI: 'AI',
  HUMAN: 'HUMAN',
} as const;
export type ConversationMode = (typeof ConversationMode)[keyof typeof ConversationMode];

export const ConversationStatus = {
  OPEN: 'OPEN',
  PENDING: 'PENDING',
  RESOLVED: 'RESOLVED',
  CLOSED: 'CLOSED',
} as const;
export type ConversationStatus = (typeof ConversationStatus)[keyof typeof ConversationStatus];

export const ChannelType = {
  MOCK: 'MOCK',
  WHATSAPP: 'WHATSAPP',
  INSTAGRAM: 'INSTAGRAM',
  MESSENGER: 'MESSENGER',
  TELEGRAM: 'TELEGRAM',
} as const;
export type ChannelType = (typeof ChannelType)[keyof typeof ChannelType];

export const ConversationPriority = {
  LOW: 'LOW',
  NORMAL: 'NORMAL',
  HIGH: 'HIGH',
  URGENT: 'URGENT',
} as const;
export type ConversationPriority = (typeof ConversationPriority)[keyof typeof ConversationPriority];

export const MessageDirection = {
  INBOUND: 'INBOUND',
  OUTBOUND: 'OUTBOUND',
} as const;
export type MessageDirection = (typeof MessageDirection)[keyof typeof MessageDirection];

export const MessageAuthorType = {
  CUSTOMER: 'CUSTOMER',
  EMPLOYEE: 'EMPLOYEE',
  AI: 'AI',
  SYSTEM: 'SYSTEM',
} as const;
export type MessageAuthorType = (typeof MessageAuthorType)[keyof typeof MessageAuthorType];

export const MessageDeliveryStatus = {
  PENDING: 'PENDING',
  SENT: 'SENT',
  DELIVERED: 'DELIVERED',
  READ: 'READ',
  FAILED: 'FAILED',
} as const;
export type MessageDeliveryStatus =
  (typeof MessageDeliveryStatus)[keyof typeof MessageDeliveryStatus];

export const ConversationEventType = {
  CONVERSATION_CREATED: 'CONVERSATION_CREATED',
  MESSAGE_SENT: 'MESSAGE_SENT',
  MESSAGE_RECEIVED: 'MESSAGE_RECEIVED',
  ASSIGNED: 'ASSIGNED',
  UNASSIGNED: 'UNASSIGNED',
  TAKEN_OVER: 'TAKEN_OVER',
  RETURNED_TO_AI: 'RETURNED_TO_AI',
  ESCALATED: 'ESCALATED',
  SCORE_UPDATED: 'SCORE_UPDATED',
  STATUS_CHANGED: 'STATUS_CHANGED',
  PRIORITY_CHANGED: 'PRIORITY_CHANGED',
  TAG_ADDED: 'TAG_ADDED',
  NOTE_ADDED: 'NOTE_ADDED',
} as const;
export type ConversationEventType =
  (typeof ConversationEventType)[keyof typeof ConversationEventType];

/**
 * The inbox's saved views (plan §14). These are named filters rather than
 * ad-hoc query params so the same vocabulary exists in the UI, the API and
 * the analytics that count them.
 */
export const InboxFilter = {
  ASSIGNED_TO_ME: 'assigned-to-me',
  HISTORY: 'history',
} as const;
export type InboxFilter = (typeof InboxFilter)[keyof typeof InboxFilter];

/**
 * Agent presence (V1.2 §8). Only ONLINE and BUSY are routable; the rest
 * are stated reasons for being away, which is what makes the status time
 * reports worth having.
 */
export const EmployeeAvailabilityStatus = {
  ONLINE: 'ONLINE',
  OFFLINE: 'OFFLINE',
  BUSY: 'BUSY',
  BREAK: 'BREAK',
  MEAL: 'MEAL',
  TRAINING: 'TRAINING',
  MEETING: 'MEETING',
} as const;

/** Statuses the routing engine may assign work to. */
export const ROUTABLE_STATUSES: EmployeeAvailabilityStatus[] = ['ONLINE', 'BUSY'];
export type EmployeeAvailabilityStatus =
  (typeof EmployeeAvailabilityStatus)[keyof typeof EmployeeAvailabilityStatus];

export const AuditAction = {
  ADMIN_CREATED_PROJECT: 'ADMIN_CREATED_PROJECT',
  ADMIN_UPDATED_PROJECT: 'ADMIN_UPDATED_PROJECT',
  ADMIN_ARCHIVED_PROJECT: 'ADMIN_ARCHIVED_PROJECT',
  ADMIN_CREATED_EMPLOYEE: 'ADMIN_CREATED_EMPLOYEE',
  ADMIN_UPDATED_EMPLOYEE: 'ADMIN_UPDATED_EMPLOYEE',
  ADMIN_UPDATED_AI_AGENT: 'ADMIN_UPDATED_AI_AGENT',
  ADMIN_UPLOADED_DOCUMENT: 'ADMIN_UPLOADED_DOCUMENT',
  ADMIN_DELETED_DOCUMENT: 'ADMIN_DELETED_DOCUMENT',
  ADMIN_CONNECTED_CHANNEL: 'ADMIN_CONNECTED_CHANNEL',
  ADMIN_CHANGED_ESCALATION_RULE: 'ADMIN_CHANGED_ESCALATION_RULE',
  ADMIN_DELETED_EMPLOYEE: 'ADMIN_DELETED_EMPLOYEE',
  ADMIN_DELETED_PROJECT: 'ADMIN_DELETED_PROJECT',
  EMPLOYEE_REPLIED: 'EMPLOYEE_REPLIED',
  EMPLOYEE_RESOLVED_CONVERSATION: 'EMPLOYEE_RESOLVED_CONVERSATION',
  EMPLOYEE_ASSIGNED_CONVERSATION: 'EMPLOYEE_ASSIGNED_CONVERSATION',
  EMPLOYEE_TOOK_CONVERSATION: 'EMPLOYEE_TOOK_CONVERSATION',
  EMPLOYEE_TRANSFERRED_CONVERSATION: 'EMPLOYEE_TRANSFERRED_CONVERSATION',
  AI_ESCALATED_CONVERSATION: 'AI_ESCALATED_CONVERSATION',
  AI_EXECUTED_TOOL: 'AI_EXECUTED_TOOL',
  CUSTOMER_DATA_UPDATED: 'CUSTOMER_DATA_UPDATED',
  USER_LOGGED_IN: 'USER_LOGGED_IN',
  USER_LOGIN_FAILED: 'USER_LOGIN_FAILED',
  USER_LOGGED_OUT: 'USER_LOGGED_OUT',
} as const;
export type AuditAction = (typeof AuditAction)[keyof typeof AuditAction];

export const Locale = {
  AR: 'ar',
  EN: 'en',
} as const;
export type Locale = (typeof Locale)[keyof typeof Locale];

/**
 * The CRM objects that own saved list views. Plurals map one-to-one onto
 * the workspace pages: company→Companies, person→People, opportunity→
 * Opportunities, task→Tasks, note→Notes. "lead" stays valid so the API
 * vocabulary matches the spec even though the product surfaces leads as
 * people.
 */
export const CrmObjectType = {
  COMPANY: 'company',
  PERSON: 'person',
  LEAD: 'lead',
  OPPORTUNITY: 'opportunity',
  TASK: 'task',
  NOTE: 'note',
} as const;
export type CrmObjectType = (typeof CrmObjectType)[keyof typeof CrmObjectType];

/** Saved-view layout. v1 ships "table" only; board/grid/calendar land here. */
export const ViewType = {
  TABLE: 'table',
} as const;
export type ViewType = (typeof ViewType)[keyof typeof ViewType];
