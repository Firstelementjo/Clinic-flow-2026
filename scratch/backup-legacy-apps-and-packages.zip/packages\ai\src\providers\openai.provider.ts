import {
  AIProviderError,
  type AIProvider,
  type ChatMessage,
  type CompletionRequest,
  type CompletionResult,
} from './types';

interface OpenAIResponse {
  choices: {
    message: {
      content: string | null;
      tool_calls?: { id: string; function: { name: string; arguments: string } }[];
    };
    finish_reason: string;
  }[];
  usage?: { prompt_tokens: number; completion_tokens: number };
  model: string;
}

/**
 * OpenAI Chat Completions over REST.
 *
 * Also serves any OpenAI-compatible endpoint (vLLM, Ollama, LM Studio,
 * OpenRouter) by pointing `baseUrl` elsewhere — which is most of what
 * "self-hosted model support" means in practice.
 */
export class OpenAIProvider implements AIProvider {
  readonly kind: 'OPENAI' | 'OPENAI_COMPATIBLE' | 'LOCAL';
  readonly defaultModel: string;

  constructor(
    private readonly apiKey: string,
    options: {
      model?: string;
      baseUrl?: string;
      kind?: 'OPENAI' | 'OPENAI_COMPATIBLE' | 'LOCAL';
      timeoutMs?: number;
    } = {},
  ) {
    this.kind = options.kind ?? 'OPENAI';
    this.defaultModel = options.model ?? 'gpt-4o-mini';
    this.baseUrl = options.baseUrl ?? 'https://api.openai.com/v1';
    this.timeoutMs = options.timeoutMs ?? 60_000;
  }

  private readonly baseUrl: string;
  private readonly timeoutMs: number;

  async generate(request: CompletionRequest): Promise<CompletionResult> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);
    const model = request.model ?? this.defaultModel;

    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.apiKey}`,
        },
        signal: controller.signal,
        body: JSON.stringify({
          model,
          temperature: request.temperature,
          max_tokens: request.maxTokens,
          messages: request.messages.map(toOpenAIMessage),
          ...(request.tools?.length
            ? {
                tools: request.tools.map((tool) => ({
                  type: 'function',
                  function: {
                    name: tool.name,
                    description: tool.description,
                    parameters: tool.parameters,
                  },
                })),
              }
            : {}),
        }),
      });

      if (!response.ok) {
        const body = await response.text().catch(() => '');
        throw new AIProviderError(
          this.kind,
          `OpenAI request failed (${response.status}): ${body.slice(0, 300)}`,
          response.status === 429 || response.status >= 500,
          response.status,
        );
      }

      const payload = (await response.json()) as OpenAIResponse;
      const choice = payload.choices[0];

      return {
        text: choice?.message.content ?? '',
        toolCalls: (choice?.message.tool_calls ?? []).map((call) => ({
          id: call.id,
          name: call.function.name,
          // A model can emit malformed JSON; that is a tool-call failure to
          // record, not a crash of the whole run.
          arguments: safeParse(call.function.arguments),
        })),
        usage: {
          inputTokens: payload.usage?.prompt_tokens ?? 0,
          outputTokens: payload.usage?.completion_tokens ?? 0,
        },
        model: payload.model ?? model,
        finishReason: mapFinishReason(choice?.finish_reason),
      };
    } catch (error) {
      if (error instanceof AIProviderError) throw error;
      if (error instanceof Error && error.name === 'AbortError') {
        throw new AIProviderError(this.kind, 'OpenAI request timed out', true);
      }
      throw new AIProviderError(
        this.kind,
        error instanceof Error ? error.message : String(error),
        true,
      );
    } finally {
      clearTimeout(timeout);
    }
  }
}

function toOpenAIMessage(message: ChatMessage): Record<string, unknown> {
  if (message.role === 'tool') {
    return { role: 'tool', content: message.content, tool_call_id: message.toolCallId };
  }
  return { role: message.role, content: message.content };
}

function mapFinishReason(reason: string | undefined): CompletionResult['finishReason'] {
  switch (reason) {
    case 'tool_calls':
      return 'tool_calls';
    case 'length':
      return 'length';
    case 'stop':
      return 'stop';
    default:
      return 'stop';
  }
}

function safeParse(raw: string): Record<string, unknown> {
  try {
    const parsed = JSON.parse(raw) as unknown;
    return typeof parsed === 'object' && parsed !== null ? (parsed as Record<string, unknown>) : {};
  } catch {
    return {};
  }
}
