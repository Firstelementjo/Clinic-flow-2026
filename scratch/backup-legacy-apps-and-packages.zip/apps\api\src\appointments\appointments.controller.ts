import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  UseGuards,
  Query,
} from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { Tenant } from '../auth/decorators';
import type { TenantContext } from '@firstelement/database';
import {
  AppointmentsService,
  type CreateAppointmentInput,
  type UpdateAppointmentInput,
} from './appointments.service';

@Controller('appointments')
@UseGuards(AuthGuard)
export class AppointmentsController {
  constructor(private readonly appointmentsService: AppointmentsService) {}

  @Get()
  async list(
    @Tenant() ctx: TenantContext,
    @Query() query: { status?: string; search?: string; customerId?: string; projectId?: string },
  ) {
    return this.appointmentsService.list(ctx, query);
  }

  @Get(':id')
  async get(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.appointmentsService.getById(ctx, id);
  }

  @Post()
  async create(@Tenant() ctx: TenantContext, @Body() body: CreateAppointmentInput) {
    return this.appointmentsService.create(ctx, body);
  }

  @Patch(':id')
  async update(
    @Tenant() ctx: TenantContext,
    @Param('id') id: string,
    @Body() body: UpdateAppointmentInput,
  ) {
    return this.appointmentsService.update(ctx, id, body);
  }

  @Delete(':id')
  async delete(@Tenant() ctx: TenantContext, @Param('id') id: string) {
    return this.appointmentsService.delete(ctx, id);
  }
}
