import { existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { config as loadDotenv } from 'dotenv';
import { z } from 'zod';

/**
 * Single source of truth for environment configuration.
 *
 * Every process (api, worker, scripts) validates the environment here at
 * boot and fails fast on a bad config rather than discovering it at the
 * first request. Secrets live only in this layer and never cross to the
 * frontend — see `publicConfig` for the only values that may be exposed.
 */

const bool = z
  .enum(['true', 'false', '1', '0'])
  .transform((v) => v === 'true' || v === '1');

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace']).default('info'),

  DATABASE_URL: z.string().url(),
  REDIS_URL: z.string().url().default('redis://localhost:6379'),

  API_PORT: z.coerce.number().int().positive().default(4000),
  WEB_PORT: z.coerce.number().int().positive().default(5173),
  WEB_ORIGIN: z.string().url().default('http://localhost:5173'),
  API_URL: z.string().url().default('http://localhost:4000'),

  SESSION_SECRET: z.string().min(32, 'SESSION_SECRET must be at least 32 characters'),
  ENCRYPTION_KEY: z
    .string()
    .regex(/^[0-9a-fA-F]{64}$/, 'ENCRYPTION_KEY must be 64 hex characters (32 bytes)'),
  SESSION_TTL_HOURS: z.coerce.number().int().positive().default(720),

  AI_PROVIDER: z
    .enum(['mock', 'openai', 'anthropic', 'gemini', 'openai-compatible', 'local'])
    .default('mock'),
  AI_MODEL: z.string().optional(),
  OPENAI_API_KEY: z.string().optional(),
  ANTHROPIC_API_KEY: z.string().optional(),
  GEMINI_API_KEY: z.string().optional(),
  OPENAI_COMPATIBLE_BASE_URL: z.string().url().optional().or(z.literal('')),
  LOCAL_AI_BASE_URL: z.string().url().optional().or(z.literal('')),
  EMBEDDING_PROVIDER: z.enum(['mock', 'openai', 'gemini', 'local']).default('mock'),
  EMBEDDING_MODEL: z.string().optional(),
  EMBEDDING_DIMENSIONS: z.coerce.number().int().positive().default(1536),

  WHATSAPP_PHONE_NUMBER_ID: z.string().optional(),
  WHATSAPP_ACCESS_TOKEN: z.string().optional(),
  WHATSAPP_VERIFY_TOKEN: z.string().optional(),
  META_APP_ID: z.string().optional(),
  META_APP_SECRET: z.string().optional(),
  INSTAGRAM_PAGE_ID: z.string().optional(),
  INSTAGRAM_ACCESS_TOKEN: z.string().optional(),
  TELEGRAM_BOT_TOKEN: z.string().optional(),
  TELEGRAM_WEBHOOK_SECRET: z.string().optional(),

  STORAGE_DRIVER: z.enum(['local', 's3']).default('local'),
  STORAGE_LOCAL_PATH: z.string().default('./storage'),
  STORAGE_S3_BUCKET: z.string().optional(),
  STORAGE_S3_REGION: z.string().optional(),
  STORAGE_S3_ACCESS_KEY_ID: z.string().optional(),
  STORAGE_S3_SECRET_ACCESS_KEY: z.string().optional(),
  STORAGE_S3_ENDPOINT: z.string().optional(),

  ENABLE_MOCK_CONNECTOR: bool.default('false'),

  /**
   * 'redis' hands work to the BullMQ worker (the production path).
   * 'inline' runs it in the calling process — only for development
   * without Redis, and rejected in production below.
   */
  QUEUE_DRIVER: z.enum(['redis', 'inline']).default('redis'),
});

export type AppConfig = z.infer<typeof envSchema> & {
  isProduction: boolean;
  isDevelopment: boolean;
  isTest: boolean;
};

let cached: AppConfig | null = null;

/**
 * Finds the repository's `.env` by walking up from the current directory.
 *
 * Each process starts in a different place — the API under `apps/api`,
 * the worker under `apps/worker`, scripts at the root — and dotenv's
 * default only looks at `process.cwd()`. Without this, `yarn dev:api`
 * fails with "DATABASE_URL: Required" while a `.env` sits one level up.
 */
function findEnvFile(startDir: string = process.cwd()): string | undefined {
  let directory = resolve(startDir);

  for (let depth = 0; depth < 6; depth += 1) {
    const candidate = join(directory, '.env');
    if (existsSync(candidate)) return candidate;

    const parent = dirname(directory);
    if (parent === directory) break;
    directory = parent;
  }

  return undefined;
}

export function loadConfig(source: NodeJS.ProcessEnv = process.env): AppConfig {
  // A variable already set in the real environment always wins; dotenv
  // fills the gaps, which is what a container with injected secrets needs.
  loadDotenv({ path: findEnvFile() });
  const parsed = envSchema.safeParse({ ...process.env, ...source });

  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((issue) => `  - ${issue.path.join('.')}: ${issue.message}`)
      .join('\n');
    throw new Error(`Invalid environment configuration:\n${issues}`);
  }

  const env = parsed.data;

  if (env.NODE_ENV === 'production' && env.ENABLE_MOCK_CONNECTOR) {
    throw new Error('ENABLE_MOCK_CONNECTOR must be false in production.');
  }

  if (env.NODE_ENV === 'production' && env.QUEUE_DRIVER === 'inline') {
    // Inline processing loses work when the process dies, which breaks
    // "customer conversations are never lost" (plan §20.8).
    throw new Error('QUEUE_DRIVER must be "redis" in production.');
  }

  return {
    ...env,
    isProduction: env.NODE_ENV === 'production',
    isDevelopment: env.NODE_ENV === 'development',
    isTest: env.NODE_ENV === 'test',
  };
}

export function getConfig(): AppConfig {
  cached ??= loadConfig();
  return cached;
}

/** Reset the memoized config. Test-only. */
export function resetConfigCache(): void {
  cached = null;
}

/**
 * The only configuration values the browser is ever allowed to see.
 * Anything not listed here stays server-side (plan §12).
 */
export function publicConfig(config: AppConfig = getConfig()) {
  return {
    apiUrl: config.API_URL,
    environment: config.NODE_ENV,
    mockConnectorEnabled: config.ENABLE_MOCK_CONNECTOR,
  };
}
