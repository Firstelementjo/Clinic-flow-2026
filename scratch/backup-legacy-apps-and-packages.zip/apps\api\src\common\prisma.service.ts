import { Injectable, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { getPrismaClient, PrismaClient } from '@firstelement/database';

/**
 * Thin Nest wrapper over the shared Prisma singleton so the worker and the
 * API use the same client construction (and the same connection-pool
 * behaviour) rather than each instantiating their own.
 */
@Injectable()
export class PrismaService implements OnModuleInit, OnModuleDestroy {
  readonly client: PrismaClient = getPrismaClient();

  async onModuleInit(): Promise<void> {
    await this.client.$connect();
  }

  async onModuleDestroy(): Promise<void> {
    await this.client.$disconnect();
  }
}
