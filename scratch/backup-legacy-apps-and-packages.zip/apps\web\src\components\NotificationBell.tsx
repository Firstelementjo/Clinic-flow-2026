import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bell } from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@firstelement/ui';
import { api } from '../lib/api';
import { useT } from '../lib/i18n';

interface NotificationView {
  id: string;
  type: string;
  title: string;
  body: string | null;
  resourceType: string | null;
  resourceId: string | null;
  readAt: string | null;
  createdAt: string;
}

/**
 * Unread badge and dropdown.
 *
 * Subscribes to the realtime stream so an assignment appears without a
 * refresh, and still refetches on open — the stream is an optimization,
 * the database is the record (see notifications.service.ts).
 */
export function NotificationBell() {
  const t = useT();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const count = useQuery({
    queryKey: ['notifications-count'],
    queryFn: () => api.get<{ count: number }>('/notifications/unread-count'),
    refetchInterval: 120_000,
  });

  const list = useQuery({
    queryKey: ['notifications'],
    queryFn: () => api.get<NotificationView[]>('/notifications'),
    enabled: open,
  });

  const markAll = useMutation({
    mutationFn: () => api.post<{ updated: number }>('/notifications/read-all'),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['notifications'] });
      void queryClient.invalidateQueries({ queryKey: ['notifications-count'] });
    },
  });

  useEffect(() => {
    // The session cookie rides along automatically; EventSource cannot
    // set headers, which is one more reason this API authenticates with a
    // cookie rather than a bearer token.
    const source = new EventSource('/api/realtime/stream', { withCredentials: true });

    source.onmessage = (event) => {
      const frame = JSON.parse(event.data) as { type: string };

      if (frame.type === 'notification') {
        void queryClient.invalidateQueries({ queryKey: ['notifications-count'] });
        void queryClient.invalidateQueries({ queryKey: ['notifications'] });
      }

      // Conversation-level frames refresh the queue views that are open.
      if (frame.type.startsWith('conversation.') || frame.type === 'message.created') {
        void queryClient.invalidateQueries({ queryKey: ['inbox'] });
        void queryClient.invalidateQueries({ queryKey: ['unassigned-escalations'] });
      }
    };

    // The browser reconnects on its own; logging every blip would be noise.
    source.onerror = () => undefined;

    return () => source.close();
  }, [queryClient]);

  const unread = count.data?.count ?? 0;

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        aria-label={t('notifications.title')}
        className="relative flex h-8 w-8 items-center justify-center rounded-md text-slate transition-colors hover:bg-mist hover:text-ink"
      >
        <Bell aria-hidden="true" className="h-5 w-5" strokeWidth={1.75} />
        {unread > 0 && (
          <span className="fe-mono absolute -end-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-escalation px-1 text-2xs leading-none text-white">
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute end-0 top-full z-20 mt-1 w-80 rounded border border-hairline bg-surface shadow-panel">
          <div className="flex items-center justify-between border-b border-hairline px-3 py-2">
            <span className="fe-eyebrow">{t('notifications.title')}</span>
            {unread > 0 && (
              <Button size="sm" variant="ghost" loading={markAll.isPending} onClick={() => markAll.mutate()}>
                {t('notifications.markAll')}
              </Button>
            )}
          </div>

          <ul className="max-h-80 divide-y divide-hairline overflow-y-auto">
            {(list.data ?? []).length === 0 ? (
              <li className="px-3 py-4 text-xs text-slate">{t('notifications.empty')}</li>
            ) : (
              (list.data ?? []).map((notification) => (
                <li key={notification.id}>
                  <Link
                    to={
                      notification.resourceType === 'Conversation' && notification.resourceId
                        ? `/app/inbox?c=${notification.resourceId}`
                        : '/app/dashboard'
                    }
                    onClick={() => setOpen(false)}
                    className={[
                      'block px-3 py-2 hover:bg-mist/60',
                      notification.readAt ? 'opacity-60' : '',
                    ].join(' ')}
                  >
                    <p className="text-xs font-medium text-ink">{notification.title}</p>
                    {notification.body && (
                      <p className="mt-0.5 line-clamp-2 text-xs text-slate">{notification.body}</p>
                    )}
                  </Link>
                </li>
              ))
            )}
          </ul>
        </div>
      )}
    </div>
  );
}
