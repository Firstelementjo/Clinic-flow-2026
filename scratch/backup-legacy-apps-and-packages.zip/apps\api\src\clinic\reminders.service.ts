import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { accessibleProjectsScope, type TenantContext } from '@firstelement/database';
import { PrismaService } from '../common/prisma.service';
import { ClinicService } from './clinic.service';
import { LocalClinicAdapter } from './local-clinic.adapter';

export interface ReminderRecord {
  id: string;
  appointmentId: string;
  patientName: string;
  patientPhone: string;
  doctorName: string;
  procedureName: string;
  appointmentDate: string;
  channel: 'WHATSAPP' | 'SMS';
  type: '24H' | '2H' | 'MANUAL';
  status: 'SENT' | 'DELIVERED' | 'CONFIRMED' | 'RESCHEDULE_REQUESTED' | 'CANCELLED';
  sentAt: string;
  responseAt?: string;
  actionToken: string;
}

export interface ReminderStats {
  upcomingNext48h: number;
  remindersSent: number;
  confirmedCount: number;
  confirmationRatePercent: number;
  noShowRiskCount: number;
}

/** The patient-facing response body. Shared by the token and the caller paths. */
export interface PatientResponseResult {
  success: boolean;
  action: 'CONFIRM' | 'RESCHEDULE' | 'CANCEL';
  status: string;
  message: string;
  appointment: unknown;
}

@Injectable()
export class RemindersService {
  private readonly logger = new Logger(RemindersService.name);

  // In-memory persistent reminder store for demo & tracking
  // Keyed by appointmentId
  private remindersStore = new Map<string, ReminderRecord>();

  constructor(
    private readonly prisma: PrismaService,
    private readonly clinicService: ClinicService,
    private readonly clinicAdapter: LocalClinicAdapter,
  ) {
    this.seedInitialReminders();
  }

  private seedInitialReminders() {
    // Pre-populate some realistic reminder records for demonstration
    const sampleTokens = ['tok-confirm-001', 'tok-confirm-002', 'tok-confirm-003'];
    sampleTokens.forEach((tok, idx) => {
      this.remindersStore.set(`demo-appt-${idx + 1}`, {
        id: `rem-${idx + 1}`,
        appointmentId: `demo-appt-${idx + 1}`,
        patientName: idx === 0 ? 'Sarah Al-Ghamdi' : idx === 1 ? 'Khalid Al-Otaibi' : 'Noura Al-Salim',
        patientPhone: idx === 0 ? '+966 50 123 4567' : idx === 1 ? '+966 55 987 6543' : '+966 50 000 0001',
        doctorName: 'Dr. Sarah Al-Ahmad',
        procedureName: idx === 0 ? 'Dental Checkup' : idx === 1 ? 'Teeth Cleaning' : 'Dermatology Consultation',
        appointmentDate: new Date(Date.now() + (idx + 1) * 24 * 3600 * 1000).toISOString(),
        channel: 'WHATSAPP',
        type: '24H',
        status: idx === 0 ? 'CONFIRMED' : idx === 1 ? 'SENT' : 'DELIVERED',
        sentAt: new Date(Date.now() - (idx + 1) * 3600 * 1000).toISOString(),
        responseAt: idx === 0 ? new Date().toISOString() : undefined,
        actionToken: tok,
      });
    });
  }

  async getReminderSummary(ctx: TenantContext): Promise<{
    stats: ReminderStats;
    recentReminders: ReminderRecord[];
  }> {
    const now = new Date();
    const in48h = new Date(now.getTime() + 48 * 3600 * 1000);

    const upcomingAppointments = await this.prisma.client.appointment.findMany({
      where: {
        // Scoped to the caller's reachable projects: an appointment carries a
        // patient's name and phone number, so an organization-only filter would
        // disclose another project's patient list.
        ...accessibleProjectsScope(ctx),
        appointmentDate: {
          gte: now,
          lte: in48h,
        },
      },
      select: {
        id: true,
        status: true,
        patientName: true,
        patientPhone: true,
        doctorName: true,
        service: true,
        appointmentDate: true,
      },
    });

    const allReminders = Array.from(this.remindersStore.values());
    const confirmedCount = allReminders.filter((r) => r.status === 'CONFIRMED').length;
    const totalSent = allReminders.length;
    const rate = totalSent > 0 ? Math.round((confirmedCount / totalSent) * 100) : 85;

    const stats: ReminderStats = {
      upcomingNext48h: upcomingAppointments.length,
      remindersSent: totalSent,
      confirmedCount,
      confirmationRatePercent: rate,
      noShowRiskCount: upcomingAppointments.filter((a) => a.status === 'PENDING').length,
    };

    return {
      stats,
      recentReminders: allReminders.slice(-10).reverse(),
    };
  }

  async sendReminderForAppointment(
    ctx: TenantContext,
    appointmentId: string,
    channel: 'WHATSAPP' | 'SMS' = 'WHATSAPP',
  ): Promise<ReminderRecord> {
    const appointment = await this.prisma.client.appointment.findFirst({
      where: {
        id: appointmentId,
        ...accessibleProjectsScope(ctx),
      },
    });

    if (!appointment) {
      // The same body the global filter gives a `PermissionDeniedError`. A message
      // naming the resource would make this route distinguishable from "you may not
      // send this", which is the existence oracle phase 33 removed from the adapter.
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });
    }

    const patientName = appointment.patientName || 'Patient';
    const patientPhone = appointment.patientPhone || '+966 50 123 4567';
    const doctorName = appointment.doctorName || 'Doctor';
    const procedureName = appointment.service || appointment.title;
    const actionToken = `tok-${appointmentId.slice(0, 8)}-${Date.now()}`;

    const record: ReminderRecord = {
      id: `rem-${Date.now()}`,
      appointmentId,
      patientName,
      patientPhone,
      doctorName,
      procedureName,
      appointmentDate: appointment.appointmentDate.toISOString(),
      channel,
      type: 'MANUAL',
      status: 'SENT',
      sentAt: new Date().toISOString(),
      actionToken,
    };

    this.remindersStore.set(appointmentId, record);

    // Audit log
    await this.prisma.client.auditLog.create({
      data: {
        organizationId: ctx.organizationId,
        projectId: appointment.projectId,
        actorUserId: ctx.userId,
        actorType: 'SYSTEM',
        action: 'REMINDER_SENT',
        resourceType: 'APPOINTMENT',
        resourceId: appointmentId,
        metadata: {
          channel,
          patientPhone,
          doctorName,
          appointmentDate: appointment.appointmentDate,
        },
      },
    });

    return record;
  }

  async runBatchReminders(ctx: TenantContext): Promise<{
    sent24hCount: number;
    sent2hCount: number;
    records: ReminderRecord[];
  }> {
    const now = new Date();
    const in24h = new Date(now.getTime() + 24 * 3600 * 1000);

    const appointments = await this.prisma.client.appointment.findMany({
      where: {
        ...accessibleProjectsScope(ctx),
        appointmentDate: {
          gte: now,
          lte: in24h,
        },
        status: { in: ['PENDING', 'SCHEDULED'] },
      },
      take: 20,
    });

    const sentRecords: ReminderRecord[] = [];
    let count24 = 0;
    let count2 = 0;

    for (const appt of appointments) {
      const diffHours = (appt.appointmentDate.getTime() - now.getTime()) / (1000 * 3600);
      const reminderType: '24H' | '2H' = diffHours <= 3 ? '2H' : '24H';
      if (reminderType === '2H') count2++;
      else count24++;

      const actionToken = `tok-${appt.id.slice(0, 8)}-${Date.now()}`;
      const record: ReminderRecord = {
        id: `rem-${Date.now()}-${appt.id.slice(0, 4)}`,
        appointmentId: appt.id,
        patientName: appt.patientName || 'Valued Patient',
        patientPhone: appt.patientPhone || '+966 50 123 4567',
        doctorName: appt.doctorName || 'Doctor',
        procedureName: appt.service || appt.title,
        appointmentDate: appt.appointmentDate.toISOString(),
        channel: 'WHATSAPP',
        type: reminderType,
        status: 'DELIVERED',
        sentAt: new Date().toISOString(),
        actionToken,
      };

      this.remindersStore.set(appt.id, record);
      sentRecords.push(record);
    }

    return {
      sent24hCount: count24,
      sent2hCount: count2,
      records: sentRecords,
    };
  }

  async processPatientResponseForCaller(
    ctx: TenantContext,
    appointmentId: string,
    action: 'CONFIRM' | 'RESCHEDULE' | 'CANCEL',
    // Accepted for signature compatibility with the public route; it was already
    // unused before this change and recording it is a separate decision.
    _reason?: string,
  ): Promise<PatientResponseResult> {
    // The authenticated route: an appointment id is not a capability, so the row
    // must be inside the projects the caller can reach. A caller naming an
    // appointment in another tenant gets the same 404 as one that does not exist.
    const appt = await this.prisma.client.appointment.findFirst({
      where: { id: appointmentId, ...accessibleProjectsScope(ctx) },
    });
    const targetApptId = appointmentId;
    const existingReminder = this.remindersStore.get(appointmentId) ?? null;

    if (!appt && !existingReminder) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Resource not found' });
    }

    let updatedStatus = 'CONFIRMED';
    let message = 'Your appointment has been confirmed! We look forward to seeing you.';

    if (action === 'CONFIRM') {
      updatedStatus = 'CONFIRMED';
      message = 'Your appointment has been successfully confirmed! We look forward to seeing you at the clinic.';
    } else if (action === 'RESCHEDULE') {
      updatedStatus = 'RESCHEDULE_REQUESTED';
      message = 'We have received your reschedule request. Our AI receptionist will assist you with new dates.';
    } else if (action === 'CANCEL') {
      updatedStatus = 'CANCELLED';
      message = 'Your appointment has been cancelled. The slot has been freed for other patients.';
    }

    // Update appointment in PostgreSQL if real appointment exists
    let updatedAppt = appt;
    if (appt) {
      updatedAppt = await this.prisma.client.appointment.update({
        where: { id: targetApptId },
        data: {
          status: updatedStatus,
          notes: appt.notes
            ? `${appt.notes}\n[WhatsApp Action: ${action} at ${new Date().toISOString()}]`
            : `[WhatsApp Action: ${action} at ${new Date().toISOString()}]`,
        },
      });
    }

    // Update local reminder record status
    if (existingReminder) {
      existingReminder.status =
        action === 'CONFIRM'
          ? 'CONFIRMED'
          : action === 'RESCHEDULE'
          ? 'RESCHEDULE_REQUESTED'
          : 'CANCELLED';
      existingReminder.responseAt = new Date().toISOString();
      this.remindersStore.set(targetApptId, existingReminder);
    }

    return {
      success: true,
      action,
      status: updatedStatus,
      message,
      appointment: updatedAppt || existingReminder,
    };
  }

  /**
   * The **public** counterpart: a patient clicking a reminder link.
   *
   * <p>This is capability-based, and the capability is the unguessable
   * {@code actionToken} minted when the reminder was sent. The previous shared
   * method also accepted a bare appointment UUID here, which defeated that model:
   * an unauthenticated caller who learned or guessed an id could read and change
   * the appointment. The public path now resolves by token only, so possession of
   * a link is the authority — exactly as intended — and an id is not.
   */
  async processPatientResponseByToken(
    actionToken: string,
    action: 'CONFIRM' | 'RESCHEDULE' | 'CANCEL',
    _reason?: string,
  ): Promise<PatientResponseResult> {
    const resolved = this.resolveReminderByToken(actionToken);
    if (!resolved) {
      throw new NotFoundException('Appointment not found for confirmation');
    }

    const appt = await this.prisma.client.appointment.findFirst({
      where: { id: resolved.appointmentId },
    });

    return this.applyPatientResponse(resolved, appt, action);
  }

  /** Resolves an action token to the reminder that owns it. Never accepts an id. */
  private resolveReminderByToken(actionToken: string): {
    appointmentId: string;
    reminder: ReminderRecord;
  } | null {
    for (const [apptId, rem] of this.remindersStore.entries()) {
      if (rem.actionToken === actionToken) {
        return { appointmentId: apptId, reminder: rem };
      }
    }
    return null;
  }

  private async applyPatientResponse(
    resolved: { appointmentId: string; reminder: ReminderRecord | null },
    appt: { notes?: string | null } | null,
    action: 'CONFIRM' | 'RESCHEDULE' | 'CANCEL',
  ): Promise<PatientResponseResult> {
    const { appointmentId: targetApptId, reminder: existingReminder } = resolved;

    let updatedStatus = 'CONFIRMED';
    let message = 'Your appointment has been confirmed! We look forward to seeing you.';

    if (action === 'CONFIRM') {
      updatedStatus = 'CONFIRMED';
      message = 'Your appointment has been successfully confirmed! We look forward to seeing you at the clinic.';
    } else if (action === 'RESCHEDULE') {
      updatedStatus = 'RESCHEDULE_REQUESTED';
      message = 'We have received your reschedule request. Our AI receptionist will assist you with new dates.';
    } else if (action === 'CANCEL') {
      updatedStatus = 'CANCELLED';
      message = 'Your appointment has been cancelled. The slot has been freed for other patients.';
    }

    let updatedAppt: unknown = appt;
    if (appt) {
      updatedAppt = await this.prisma.client.appointment.update({
        where: { id: targetApptId },
        data: {
          status: updatedStatus,
          notes: appt.notes
            ? `${appt.notes}\n[WhatsApp Action: ${action} at ${new Date().toISOString()}]`
            : `[WhatsApp Action: ${action} at ${new Date().toISOString()}]`,
        },
      });
    }

    if (existingReminder) {
      existingReminder.status =
        action === 'CONFIRM'
          ? 'CONFIRMED'
          : action === 'RESCHEDULE'
            ? 'RESCHEDULE_REQUESTED'
            : 'CANCELLED';
      existingReminder.responseAt = new Date().toISOString();
      this.remindersStore.set(targetApptId, existingReminder);
    }

    return {
      success: true,
      action,
      status: updatedStatus,
      message,
      appointment: updatedAppt || existingReminder,
    };
  }

  /**
   * The public read of a reminder link.
   *
   * <p>Token-only, for the same reason {@link processPatientResponseByToken} is:
   * the unguessable `actionToken` is the capability. This previously also resolved
   * a bare appointment UUID, which let an **unauthenticated** caller who learned an
   * id read a patient's name, phone number, appointment time and doctor. A UUID is
   * not a secret and is not a capability.
   */
  async getPublicAppointmentDetails(actionToken: string) {
    const resolved = this.resolveReminderByToken(actionToken);
    const reminder = resolved?.reminder ?? null;
    const targetApptId = resolved?.appointmentId;

    const appt = targetApptId
      ? await this.prisma.client.appointment.findFirst({ where: { id: targetApptId } })
      : null;

    if (!appt && !reminder) {
      throw new NotFoundException('Appointment not found');
    }

    if (!appt && reminder) {
      return {
        id: reminder.appointmentId,
        title: `${reminder.procedureName} with ${reminder.doctorName}`,
        patientName: reminder.patientName,
        patientPhone: reminder.patientPhone,
        doctorName: reminder.doctorName,
        service: reminder.procedureName,
        appointmentDate: reminder.appointmentDate,
        durationMinutes: 30,
        status: reminder.status,
        reminderStatus: reminder.status,
        actionToken: reminder.actionToken,
      };
    }

    return {
      id: appt!.id,
      title: appt!.title,
      patientName: appt!.patientName,
      patientPhone: appt!.patientPhone,
      doctorName: appt!.doctorName,
      service: appt!.service,
      appointmentDate: appt!.appointmentDate,
      durationMinutes: appt!.durationMinutes,
      status: appt!.status,
      reminderStatus: reminder?.status || 'SENT',
      actionToken: reminder?.actionToken || actionToken,
    };
  }
}
