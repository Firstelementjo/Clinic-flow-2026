import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import type { Prisma } from '@firstelement/database';
import { PrismaService } from '../common/prisma.service';
import { canAccessProject, type TenantContext } from '@firstelement/database';
import { CrmObjectType, type CreateViewInput, type UpdateViewInput } from '@firstelement/shared';

const DEFAULT_VIEW_NAME = 'Default';

/** The view config is opaque JSON validated on the wire; normalize it for Prisma. */
function jsonConfig(value: Record<string, unknown> | null | undefined): Prisma.InputJsonValue | undefined {
  return (value ?? undefined) as Prisma.InputJsonValue | undefined;
}

@Injectable()
export class ViewsService {
  constructor(private readonly prisma: PrismaService) {}

  private readonly select = {
    id: true,
    objectType: true,
    name: true,
    type: true,
    isDefault: true,
    isFavorite: true,
    filters: true,
    sort: true,
    columnConfig: true,
    createdById: true,
    createdAt: true,
    updatedAt: true,
  } as const;

  /** Every object type seeds one locked default view; list returns it plus the member views. */
  async list(ctx: TenantContext, objectType: string, projectId: string) {
    const scope = this.scoped(ctx, objectType, projectId);
    await this.ensureDefault(ctx, objectType, projectId, scope);
    return this.prisma.client.view.findMany({
      where: { ...scope, objectType },
      select: this.select,
      orderBy: [{ isDefault: 'desc' }, { isFavorite: 'desc' }, { name: 'asc' }],
    });
  }

  async create(ctx: TenantContext, objectType: string, projectId: string, input: CreateViewInput) {
    const scope = this.scoped(ctx, objectType, projectId);
    return this.prisma.client.view.create({
      data: {
        ...scope,
        objectType,
        name: input.name,
        type: input.type,
        isFavorite: input.isFavorite,
        filters: jsonConfig(input.filters),
        sort: jsonConfig(input.sort),
        columnConfig: jsonConfig(input.columnConfig),
        createdById: ctx.userId,
      },
      select: this.select,
    });
  }

  async update(ctx: TenantContext, id: string, input: UpdateViewInput) {
    await this.assertOwned(ctx, id);
    return this.prisma.client.view.update({
      where: { id },
      data: {
        name: input.name,
        type: input.type,
        isFavorite: input.isFavorite,
        filters: jsonConfig(input.filters),
        sort: jsonConfig(input.sort),
        columnConfig: jsonConfig(input.columnConfig),
      },
      select: this.select,
    });
  }

  async remove(ctx: TenantContext, id: string) {
    await this.assertOwned(ctx, id);
    return this.prisma.client.view.delete({ where: { id }, select: { id: true } });
  }

  private scoped(ctx: TenantContext, objectType: string, projectId: string) {
    if (!projectId) {
      throw new BadRequestException({ code: 'INVALID_REQUEST', message: 'projectId is required' });
    }
    if (!Object.values(CrmObjectType).includes(objectType as (typeof CrmObjectType)[keyof typeof CrmObjectType])) {
      throw new BadRequestException({ code: 'INVALID_REQUEST', message: `Unknown object type: ${objectType}` });
    }
    if (!canAccessProject(ctx, projectId)) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Project not found' });
    }
    return { organizationId: ctx.organizationId, projectId };
  }

  private async ensureDefault(
    ctx: TenantContext,
    objectType: string,
    projectId: string,
    scope: { organizationId: string; projectId: string },
  ) {
    const existing = await this.prisma.client.view.findFirst({
      where: { ...scope, objectType, isDefault: true },
      select: { id: true },
    });
    if (existing) return;
    await this.prisma.client.view.create({
      data: {
        ...scope,
        objectType,
        name: DEFAULT_VIEW_NAME,
        type: 'table',
        isDefault: true,
        isFavorite: false,
        filters: { search: '' },
        sort: {},
        columnConfig: { hidden: [] },
        createdById: ctx.userId,
      },
    });
  }

  /** "This exists but is not yours" is a 404 — see HttpExceptionFilter note in CLAUDE.md. */
  private async assertOwned(ctx: TenantContext, id: string) {
    const existing = await this.prisma.client.view.findFirst({
      where: { id, organizationId: ctx.organizationId },
    });
    if (!existing || !canAccessProject(ctx, existing.projectId)) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'View not found' });
    }
    return existing;
  }
}