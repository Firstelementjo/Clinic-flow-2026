import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { InboxFilter } from '@firstelement/shared';
import { InboxWorkspace } from '../components/InboxWorkspace';
import { useSession } from '../lib/session';

/**
 * Standalone inbox page rendered inside a popped-out browser window
 * (V1.2 §16–§19, Salesforce-style pop-out).
 *
 * This route lives outside the AppShell so the window has no header,
 * no nav — just the inbox workspace filling the entire viewport.
 * The session cookie is shared with the main window, so no extra
 * auth is needed.
 */
export function PopoutInboxPage() {
  const session = useSession();
  const user = session.data;

  const [searchParams, setSearchParams] = useSearchParams();
  const filter = (searchParams.get('filter') as InboxFilter | null) ?? InboxFilter.ASSIGNED_TO_ME;
  const selectedId = searchParams.get('c');
  const [search, setSearch] = useState('');

  useEffect(() => {
    document.title = 'FirstElement Inbox';
  }, []);

  const setParam = (key: string, value: string | null) => {
    const next = new URLSearchParams(searchParams);
    if (value === null) next.delete(key);
    else next.set(key, value);
    setSearchParams(next, { replace: true });
  };

  if (!user) return null;

  return (
    <div className="h-screen w-screen overflow-hidden">
      <InboxWorkspace
        user={user}
        filter={filter}
        onFilter={(next) => setParam('filter', next)}
        selectedId={selectedId}
        onSelect={(id) => setParam('c', id)}
        search={search}
        onSearch={setSearch}
        variant="floating"
      />
    </div>
  );
}
