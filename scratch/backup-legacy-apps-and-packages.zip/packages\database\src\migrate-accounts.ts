/**
 * One-time data migration for the Accounts ("Companies") feature.
 *
 * Before Accounts existed, Deal and Lead stored the company name as a free
 * string (`company`). This script promotes those strings into real `Account`
 * rows and backfills `Deal.accountId` / `Lead.accountId` so the Accounts UI
 * has populated data and existing records link through the new foreign key.
 *
 * Idempotent: safe to re-run. An Account row is created once per
 * unique (organization, trimmed company name); a deal/lead whose accountId
 * is already set is left untouched; account names are case-insensitively
 * deduplicated so a home-org with both "Acme" and "acme" gets one row.
 *
 * Refuses to run when NODE_ENV=production to match the seed script.
 */
import { getPrismaClient, disconnectPrisma } from './client';

async function main(): Promise<void> {
  if (process.env.NODE_ENV === 'production') {
    throw new Error('Refusing to run the accounts backfill migration in production.');
  }

  const prisma = getPrismaClient();

  // Distinct (organizationId, normalized company name) across deals and leads.
  const deals = await prisma.deal.findMany({
    where: { company: { not: null } },
    select: { id: true, organizationId: true, company: true, accountId: true },
  });
  const leads = await prisma.lead.findMany({
    where: { company: { not: null } },
    select: { id: true, organizationId: true, company: true, accountId: true },
  });

  const wanted = new Map<string, string>(); // key -> canonical name
  const add = (organizationId: string, raw: string | null | undefined) => {
    const name = (raw ?? '').trim();
    if (!name) return;
    const key = `${organizationId}:${name.toLowerCase()}`;
    if (!wanted.has(key)) wanted.set(key, name);
  };
  deals.forEach((d) => add(d.organizationId, d.company));
  leads.forEach((l) => add(l.organizationId, l.company));

  let created = 0;
  const accountByKey = new Map<string, string>();
  for (const [key, name] of wanted) {
    const sep = key.indexOf(':');
    const organizationId = key.slice(0, sep);
    const existing = await prisma.account.findUnique({
      where: { organizationId_name: { organizationId, name } },
      select: { id: true },
    });
    if (existing) {
      accountByKey.set(key, existing.id);
      continue;
    }
    const account = await prisma.account.create({
      data: { organizationId, name },
      select: { id: true },
    });
    accountByKey.set(key, account.id);
    created += 1;
  }

  let linked = 0;
  for (const deal of deals) {
    if (deal.accountId) continue;
    const key = `${deal.organizationId}:${(deal.company ?? '').trim().toLowerCase()}`;
    const accountId = accountByKey.get(key);
    if (!accountId) continue;
    await prisma.deal.update({ where: { id: deal.id }, data: { accountId }, select: { id: true } });
    linked += 1;
  }
  for (const lead of leads) {
    if (lead.accountId) continue;
    const key = `${lead.organizationId}:${(lead.company ?? '').trim().toLowerCase()}`;
    const accountId = accountByKey.get(key);
    if (!accountId) continue;
    await prisma.lead.update({ where: { id: lead.id }, data: { accountId }, select: { id: true } });
    linked += 1;
  }

  console.log(
    `Accounts backfill complete: ${wanted.size} distinct company names, ${created} accounts created, ${linked} records linked.`,
  );
  await disconnectPrisma();
}

main().catch((error) => {
  console.error('Accounts backfill failed:', error);
  process.exit(1);
});