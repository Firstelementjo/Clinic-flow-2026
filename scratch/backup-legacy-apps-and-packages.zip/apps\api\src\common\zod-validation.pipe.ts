import { BadRequestException, PipeTransform } from '@nestjs/common';
import { ZodError, ZodSchema } from 'zod';
import { ErrorCode } from '@firstelement/shared';

/**
 * Validates (and coerces) request payloads against the shared zod schemas
 * from `@firstelement/shared`, so the API and the web app cannot drift.
 *
 * Returns field-level details the frontend can render inline rather than a
 * single opaque "invalid request".
 */
export class ZodValidationPipe<T> implements PipeTransform<unknown, T> {
  constructor(private readonly schema: ZodSchema<T>) {}

  transform(value: unknown): T {
    try {
      return this.schema.parse(value);
    } catch (error) {
      if (error instanceof ZodError) {
        const details: Record<string, string[]> = {};
        for (const issue of error.issues) {
          const key = issue.path.join('.') || '_';
          (details[key] ??= []).push(issue.message);
        }
        throw new BadRequestException({
          code: ErrorCode.VALIDATION_FAILED,
          message: 'Validation failed',
          details,
        });
      }
      throw error;
    }
  }
}

export const zodBody = <T>(schema: ZodSchema<T>) => new ZodValidationPipe(schema);
