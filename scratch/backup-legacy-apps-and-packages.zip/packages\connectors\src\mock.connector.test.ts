import { describe, expect, it } from 'vitest';
import { ChannelType } from '@firstelement/shared';
import { MockConnector } from './mock.connector';
import { ConnectorNotConfiguredError, ConnectorRegistry } from './registry';
import { capabilitiesFor } from './capabilities';
import { checkOutboundText } from './types';

describe('MockConnector normalization', () => {
  it('turns a payload into the shape the CRM sees, with nothing platform-specific left', async () => {
    const connector = new MockConnector('conn-1');
    const [message] = await connector.receiveWebhook({
      externalUserId: 'wa-555',
      text: 'مرحبا',
      displayName: 'نورة',
      phone: '+966500000001',
    });

    expect(message).toBeDefined();
    expect(message!.channel).toBe(ChannelType.MOCK);
    expect(message!.externalUserId).toBe('wa-555');
    expect(message!.text).toBe('مرحبا');
    expect(message!.phone).toBe('+966500000001');
    expect(message!.sentAt).toBeInstanceOf(Date);
    expect(message!.attachments).toEqual([]);
  });

  it('accepts a batch, as real webhooks deliver', async () => {
    const connector = new MockConnector('conn-1');
    const messages = await connector.receiveWebhook([
      { externalUserId: 'a', text: 'one' },
      { externalUserId: 'b', text: 'two' },
    ]);
    expect(messages).toHaveLength(2);
  });

  it('drops malformed entries instead of failing the whole batch', async () => {
    const connector = new MockConnector('conn-1');
    const messages = await connector.receiveWebhook([
      { externalUserId: 'a', text: 'valid' },
      { nonsense: true },
      null,
    ]);
    expect(messages).toHaveLength(1);
  });

  it('mints a unique external id per message but honours a supplied one', async () => {
    const connector = new MockConnector('conn-1');
    const [first] = await connector.receiveWebhook({ externalUserId: 'a', text: '1' });
    const [second] = await connector.receiveWebhook({ externalUserId: 'a', text: '2' });
    expect(first!.externalMessageId).not.toBe(second!.externalMessageId);

    // Replaying an id is how a test proves the pipeline deduplicates.
    const [replay] = await connector.receiveWebhook({
      externalUserId: 'a',
      text: '1',
      externalMessageId: first!.externalMessageId,
    });
    expect(replay!.externalMessageId).toBe(first!.externalMessageId);
  });
});

describe('MockConnector sending', () => {
  it('records what it sent rather than pretending', async () => {
    const connector = new MockConnector('conn-1');
    const result = await connector.sendText({
      externalUserId: 'wa-555',
      text: 'On its way.',
      messageId: 'msg-1',
    });

    expect(result.ok).toBe(true);
    expect(result.externalMessageId).toBeTruthy();
    expect(connector.sent()).toHaveLength(1);
    expect(connector.sent()[0]!.messageId).toBe('msg-1');
  });
});

describe('capability discovery', () => {
  it('declares the session window that governs WhatsApp replies', () => {
    const whatsapp = capabilitiesFor(ChannelType.WHATSAPP);
    expect(whatsapp.sessionWindowHours).toBe(24);
    expect(whatsapp.requiresTemplateOutsideSession).toBe(true);
  });

  it('does not claim read receipts on Telegram, which has none', () => {
    expect(capabilitiesFor(ChannelType.TELEGRAM).markAsRead).toBe(false);
  });

  it('keeps per-channel text limits distinct, so parity is never assumed', () => {
    expect(capabilitiesFor(ChannelType.INSTAGRAM).maxTextLength).toBeLessThan(
      capabilitiesFor(ChannelType.WHATSAPP).maxTextLength,
    );
  });

  it('rejects an over-length message with a reason an agent can act on', () => {
    const capabilities = capabilitiesFor(ChannelType.INSTAGRAM);
    const result = checkOutboundText(capabilities, 'x'.repeat(capabilities.maxTextLength + 1));
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toContain('INSTAGRAM');
      expect(result.reason).toContain(String(capabilities.maxTextLength));
    }
  });
});

describe('registry', () => {
  const connection = {
    id: 'conn-1',
    projectId: 'project-1',
    channel: ChannelType.MOCK,
    isEnabled: true,
  };

  it('reuses one instance per connection so connector state survives', () => {
    const registry = new ConnectorRegistry();
    expect(registry.get(connection)).toBe(registry.get(connection));
  });

  it('says plainly that an unimplemented channel is not configured', () => {
    const registry = new ConnectorRegistry();
    expect(() => registry.get({ ...connection, channel: ChannelType.WHATSAPP })).toThrowError(
      ConnectorNotConfiguredError,
    );
  });
});
