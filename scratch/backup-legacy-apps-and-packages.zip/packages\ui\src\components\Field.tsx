import clsx from 'clsx';
import { useId, type InputHTMLAttributes, type ReactNode } from 'react';

export interface FieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'id'> {
  label: string;
  /** Shown under the field. Explains what to do, not that something is wrong. */
  hint?: ReactNode;
  error?: string;
}

/**
 * Label, control and message as one unit — so a field can never ship
 * without a programmatic label, and an error is always announced.
 */
export function Field({ label, hint, error, className, ...rest }: FieldProps) {
  const id = useId();
  const describedBy = error ? `${id}-error` : hint ? `${id}-hint` : undefined;

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-xs font-medium text-ink-soft">
        {label}
      </label>
      <input
        {...rest}
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        className={clsx(
          'h-9 w-full rounded border bg-surface px-3 text-sm text-ink',
          'placeholder:text-slate-soft',
          error ? 'border-danger' : 'border-hairline',
          className,
        )}
      />
      {error ? (
        <p id={`${id}-error`} className="text-xs text-danger">
          {error}
        </p>
      ) : hint ? (
        <p id={`${id}-hint`} className="text-xs text-slate">
          {hint}
        </p>
      ) : null}
    </div>
  );
}
