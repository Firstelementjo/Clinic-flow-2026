import { Injectable, NotFoundException } from '@nestjs/common';
import { DEFAULT_ESCALATION_RULES } from '@firstelement/ai';
import { accessibleProjectsScope, projectScope, type TenantContext } from '@firstelement/database';
import {
  AuditAction,
  ErrorCode,
  type ConversationScoreView,
  type EscalationRuleView,
  type EscalationView,
  type RuleConditionInput,
  type SaveEscalationRuleInput,
} from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';

@Injectable()
export class EscalationService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  /**
   * Lists a project's rules, materializing the defaults on first read.
   *
   * The engine falls back to the same defaults when a project has no rows,
   * so behaviour is identical either way — but writing them down means the
   * admin edits real rules instead of editing an invisible fallback.
   */
  async listRules(ctx: TenantContext, projectId: string): Promise<EscalationRuleView[]> {
    const scope = projectScope(ctx, projectId);

    const existing = await this.prisma.client.escalationRule.count({ where: scope });
    if (existing === 0) {
      await this.prisma.client.escalationRule.createMany({
        data: DEFAULT_ESCALATION_RULES.map((rule) => ({
          ...scope,
          name: rule.name,
          isEnabled: rule.isEnabled,
          priority: rule.priority,
          conditions: rule.conditions as object,
          combinator: rule.combinator,
        })),
      });
    }

    const rules = await this.prisma.client.escalationRule.findMany({
      where: scope,
      orderBy: { priority: 'asc' },
    });

    return rules.map(toRuleView);
  }

  async createRule(
    ctx: TenantContext,
    projectId: string,
    input: SaveEscalationRuleInput,
    ipAddress?: string,
  ): Promise<EscalationRuleView> {
    const scope = projectScope(ctx, projectId);

    const rule = await this.prisma.client.escalationRule.create({
      data: {
        ...scope,
        name: input.name,
        description: input.description ?? null,
        isEnabled: input.isEnabled,
        priority: input.priority,
        conditions: input.conditions as object,
        combinator: input.combinator,
        department: input.department ?? null,
        createdByUserId: ctx.userId,
      },
    });

    await this.recordChange(ctx, projectId, rule.id, 'created', input, ipAddress);
    return toRuleView(rule);
  }

  async updateRule(
    ctx: TenantContext,
    projectId: string,
    ruleId: string,
    input: SaveEscalationRuleInput,
    ipAddress?: string,
  ): Promise<EscalationRuleView> {
    const scope = projectScope(ctx, projectId);

    const result = await this.prisma.client.escalationRule.updateMany({
      where: { id: ruleId, ...scope },
      data: {
        name: input.name,
        description: input.description ?? null,
        isEnabled: input.isEnabled,
        priority: input.priority,
        conditions: input.conditions as object,
        combinator: input.combinator,
        department: input.department ?? null,
      },
    });
    if (result.count === 0) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Rule not found' });
    }

    await this.recordChange(ctx, projectId, ruleId, 'updated', input, ipAddress);

    const rule = await this.prisma.client.escalationRule.findFirstOrThrow({
      where: { id: ruleId, ...scope },
    });
    return toRuleView(rule);
  }

  async deleteRule(
    ctx: TenantContext,
    projectId: string,
    ruleId: string,
    ipAddress?: string,
  ): Promise<void> {
    const scope = projectScope(ctx, projectId);
    const result = await this.prisma.client.escalationRule.deleteMany({
      where: { id: ruleId, ...scope },
    });
    if (result.count === 0) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Rule not found' });
    }

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CHANGED_ESCALATION_RULE,
      resourceType: 'EscalationRule',
      resourceId: ruleId,
      metadata: { change: 'deleted' },
      ipAddress,
    });
  }

  /** Score history for the conversation timeline sparkline. */
  async scoresFor(ctx: TenantContext, conversationId: string): Promise<ConversationScoreView[]> {
    const conversation = await this.prisma.client.conversation.findFirst({
      where: { id: conversationId, ...accessibleProjectsScope(ctx) },
      select: { id: true },
    });
    if (!conversation) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Conversation not found' });
    }

    const scores = await this.prisma.client.conversationScore.findMany({
      where: { conversationId },
      orderBy: { createdAt: 'asc' },
      take: 200,
    });

    return scores.map((score) => ({
      id: score.id,
      frustration: score.frustration,
      sentiment: score.sentiment,
      urgency: score.urgency,
      risk: score.risk,
      intentConfidence: score.intentConfidence,
      aiConfidence: score.aiConfidence,
      intent: score.intent,
      createdAt: score.createdAt.toISOString(),
    }));
  }

  async escalationsFor(ctx: TenantContext, conversationId: string): Promise<EscalationView[]> {
    const escalations = await this.prisma.client.escalation.findMany({
      where: { conversationId, ...accessibleProjectsScope(ctx) },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    return escalations.map((escalation) => ({
      id: escalation.id,
      conversationId: escalation.conversationId,
      trigger: escalation.trigger,
      status: escalation.status,
      reason: escalation.reason,
      summary: escalation.summary,
      intent: escalation.intent,
      department: escalation.department,
      createdAt: escalation.createdAt.toISOString(),
    }));
  }

  private async recordChange(
    ctx: TenantContext,
    projectId: string,
    ruleId: string,
    change: string,
    input: SaveEscalationRuleInput,
    ipAddress?: string,
  ): Promise<void> {
    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_CHANGED_ESCALATION_RULE,
      resourceType: 'EscalationRule',
      resourceId: ruleId,
      // Thresholds are recorded: "who lowered the escalation bar to 30?"
      // is a question ops managers actually ask.
      metadata: { change, conditions: input.conditions, isEnabled: input.isEnabled },
      ipAddress,
    });
  }
}

function toRuleView(rule: {
  id: string;
  name: string;
  description: string | null;
  isEnabled: boolean;
  priority: number;
  conditions: unknown;
  combinator: string;
  department: string | null;
}): EscalationRuleView {
  return {
    id: rule.id,
    name: rule.name,
    description: rule.description,
    isEnabled: rule.isEnabled,
    priority: rule.priority,
    conditions: Array.isArray(rule.conditions) ? (rule.conditions as RuleConditionInput[]) : [],
    combinator: rule.combinator === 'ANY' ? 'ANY' : 'ALL',
    department: rule.department,
  };
}
