import {
  BadRequestException,
  Body,
  Controller,
  ForbiddenException,
  Delete,
  Get,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Put,
  Query,
  Req,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import type { Request } from 'express';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import {
  ErrorCode,
  commitImportSchema,
  saveRoutingRuleSchema,
  setAvailabilitySchema,
  setSkillsSchema,
  setWorkingHoursSchema,
  type CommitImportInput,
  type SaveRoutingRuleInput,
  type SetAvailabilityInput,
  type SetSkillsInput,
  type SetWorkingHoursInput,
} from '@firstelement/shared';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { RoutingService } from './routing.service';
import { AgentStatusService } from './agent-status.service';

interface UploadedImportFile {
  buffer: Buffer;
  originalname: string;
  mimetype: string;
  size: number;
}

@Controller()
export class RoutingController {
  constructor(
    private readonly routing: RoutingService,
    private readonly status: AgentStatusService,
  ) {}

  @Get('employees/routing')
  @RequirePermissions(Permission.EMPLOYEE_READ)
  list(@Tenant() ctx: TenantContext, @Query('projectId') projectId?: string) {
    return this.routing.listEmployees(ctx, projectId);
  }

  /**
   * Sets a status and starts its timer (V1.2 §8, §9).
   *
   * Without `employeeId` this is the caller's own status — the
   * self-service path every agent uses. Passing someone else's id needs
   * EMPLOYEE_UPDATE, checked below rather than trusted from the body.
   */
  @Patch('me/availability')
  @RequirePermissions(Permission.EMPLOYEE_SET_OWN_AVAILABILITY)
  async setOwnAvailability(
    @Tenant() ctx: TenantContext,
    @Body(zodBody(setAvailabilitySchema)) body: SetAvailabilityInput,
  ) {
    if (body.employeeId) {
      throw new ForbiddenException({
        code: ErrorCode.FORBIDDEN,
        message: 'Use the employee status endpoint to change another agent status',
      });
    }

    return this.status.setStatus(ctx, body.availabilityStatus, { note: body.note });
  }

  /** The caller's current status and how long they have been in it. */
  @Get('me/status')
  @RequirePermissions(Permission.EMPLOYEE_SET_OWN_AVAILABILITY)
  myStatus(@Tenant() ctx: TenantContext) {
    return this.status.current(ctx);
  }

  /** Time per status over a window — the §9 reporting totals. */
  @Get('me/status/totals')
  @RequirePermissions(Permission.EMPLOYEE_SET_OWN_AVAILABILITY)
  myTotals(@Tenant() ctx: TenantContext, @Query('days') days?: string) {
    return this.status.totals(ctx, { days: days ? Number(days) : undefined });
  }

  @Get('employees/:employeeId/status/totals')
  @RequirePermissions(Permission.EMPLOYEE_READ)
  employeeTotals(
    @Tenant() ctx: TenantContext,
    @Param('employeeId', ParseUUIDPipe) employeeId: string,
    @Query('days') days?: string,
  ) {
    return this.status.totals(ctx, { employeeId, days: days ? Number(days) : undefined });
  }

  /** An admin marking someone offline at the end of their shift. */
  @Patch('employees/:employeeId/status')
  @RequirePermissions(Permission.EMPLOYEE_UPDATE)
  setEmployeeStatus(
    @Tenant() ctx: TenantContext,
    @Param('employeeId', ParseUUIDPipe) employeeId: string,
    @Body(zodBody(setAvailabilitySchema)) body: SetAvailabilityInput,
  ) {
    return this.status.setStatus(ctx, body.availabilityStatus, { employeeId, note: body.note });
  }

  @Put('employees/:employeeId/working-hours')
  @RequirePermissions(Permission.EMPLOYEE_UPDATE)
  setWorkingHours(
    @Tenant() ctx: TenantContext,
    @Param('employeeId', ParseUUIDPipe) employeeId: string,
    @Body(zodBody(setWorkingHoursSchema)) body: SetWorkingHoursInput,
  ) {
    return this.routing.setWorkingHours(ctx, employeeId, body);
  }

  @Put('employees/:employeeId/skills')
  @RequirePermissions(Permission.EMPLOYEE_UPDATE)
  setSkills(
    @Tenant() ctx: TenantContext,
    @Param('employeeId', ParseUUIDPipe) employeeId: string,
    @Body(zodBody(setSkillsSchema)) body: SetSkillsInput,
  ) {
    return this.routing.setSkills(ctx, employeeId, body);
  }

  @Get('projects/:projectId/routing-rules')
  @RequirePermissions(Permission.EMPLOYEE_READ)
  listRules(@Tenant() ctx: TenantContext, @Param('projectId', ParseUUIDPipe) projectId: string) {
    return this.routing.listRules(ctx, projectId);
  }

  @Post('projects/:projectId/routing-rules')
  @RequirePermissions(Permission.ROUTING_RULE_MANAGE)
  createRule(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Body(zodBody(saveRoutingRuleSchema)) body: SaveRoutingRuleInput,
    @Req() request: Request,
  ) {
    return this.routing.createRule(ctx, projectId, body, request.ip);
  }

  @Put('projects/:projectId/routing-rules/:ruleId')
  @RequirePermissions(Permission.ROUTING_RULE_MANAGE)
  updateRule(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('ruleId', ParseUUIDPipe) ruleId: string,
    @Body(zodBody(saveRoutingRuleSchema)) body: SaveRoutingRuleInput,
    @Req() request: Request,
  ) {
    return this.routing.updateRule(ctx, projectId, ruleId, body, request.ip);
  }

  @Delete('projects/:projectId/routing-rules/:ruleId')
  @RequirePermissions(Permission.ROUTING_RULE_MANAGE)
  @HttpCode(204)
  deleteRule(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('ruleId', ParseUUIDPipe) ruleId: string,
  ) {
    return this.routing.deleteRule(ctx, projectId, ruleId);
  }

  /** Wizard step one: nothing is written, everything is reported. */
  @Post('employees/import/preview')
  @RequirePermissions(Permission.EMPLOYEE_IMPORT)
  @HttpCode(200)
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: 5 * 1024 * 1024, files: 1 } }))
  preview(
    @Tenant() ctx: TenantContext,
    @UploadedFile() file: UploadedImportFile | undefined,
    @Body('mapping') mapping?: string,
  ) {
    if (!file) {
      throw new BadRequestException({
        code: ErrorCode.VALIDATION_FAILED,
        message: 'No file was uploaded',
      });
    }

    return this.routing.previewImport(ctx, file, parseMapping(mapping));
  }

  /** Wizard step two: only the rows the admin confirmed. */
  @Post('employees/import')
  @RequirePermissions(Permission.EMPLOYEE_IMPORT)
  commit(
    @Tenant() ctx: TenantContext,
    @Body(zodBody(commitImportSchema)) body: CommitImportInput,
    @Req() request: Request,
  ) {
    return this.routing.commitImport(ctx, body, request.ip);
  }
}

/** The mapping rides along as a JSON string in the multipart body. */
function parseMapping(raw?: string): Record<string, string> | undefined {
  if (!raw) return undefined;
  try {
    const parsed = JSON.parse(raw) as unknown;
    return typeof parsed === 'object' && parsed !== null
      ? (parsed as Record<string, string>)
      : undefined;
  } catch {
    return undefined;
  }
}
