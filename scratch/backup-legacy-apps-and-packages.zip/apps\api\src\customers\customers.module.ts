import { Module } from '@nestjs/common';
import { CustomersController } from './customers.controller';
import { CustomersService } from './customers.service';
import { IdentityResolutionService } from './identity-resolution.service';

@Module({
  controllers: [CustomersController],
  providers: [CustomersService, IdentityResolutionService],
  // Slice 3's connectors resolve identities on every inbound message.
  exports: [CustomersService, IdentityResolutionService],
})
export class CustomersModule {}
