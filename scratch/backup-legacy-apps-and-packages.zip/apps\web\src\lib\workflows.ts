import { useQuery } from '@tanstack/react-query';
import type { EscalationRuleView, SaveEscalationRuleInput } from '@firstelement/shared';
import { api } from './api';

export function useEscalationRules(projectId: string | undefined) {
  return useQuery({
    queryKey: ['escalation-rules', projectId ?? ''],
    queryFn: () =>
      api.get<EscalationRuleView[]>(`/escalation/projects/${projectId}/escalation-rules`),
    enabled: Boolean(projectId),
  });
}

export async function createEscalationRule(projectId: string, input: SaveEscalationRuleInput) {
  return api.post<EscalationRuleView>(
    `/escalation/projects/${projectId}/escalation-rules`,
    input,
  );
}

export async function updateEscalationRule(projectId: string, ruleId: string, input: SaveEscalationRuleInput) {
  return api.put<EscalationRuleView>(
    `/escalation/projects/${projectId}/escalation-rules/${ruleId}`,
    input,
  );
}

export async function deleteEscalationRule(projectId: string, ruleId: string) {
  return api.delete<void>(`/escalation/projects/${projectId}/escalation-rules/${ruleId}`);
}