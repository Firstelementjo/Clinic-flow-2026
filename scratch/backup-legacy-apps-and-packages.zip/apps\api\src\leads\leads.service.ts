import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { accessibleProjectsScope, projectScope, type TenantContext } from '@firstelement/database';

@Injectable()
export class LeadsService {
  constructor(private readonly prisma: PrismaService) {}

  private defaultProjectId(ctx: TenantContext): string | undefined {
    return ctx.projectIds[0];
  }

  async list(ctx: TenantContext, projectId?: string, search?: string) {
    const where: Record<string, unknown> = {
      ...(projectId
        ? projectScope(ctx, projectId)
        : { projectId: this.defaultProjectId(ctx) as string | undefined }),
    };
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { company: { contains: search, mode: 'insensitive' } },
      ];
    }

    const leads = await this.prisma.client.lead.findMany({
      where,
      select: {
        id: true,
        name: true,
        company: true,
        source: true,
        status: true,
        jobTitle: true,
        email: true,
        phone: true,
        industry: true,
        leadScore: true,
        priority: true,
        estimatedValue: true,
        ownerId: true,
        createdById: true,
        customerId: true,
        ticketNumber: true,
        ticketDate: true,
        followUpDate: true,
        customer: {
          select: {
            id: true,
            cxId: true,
            displayName: true,
            primaryEmail: true,
            primaryPhone: true,
          },
        },
        createdBy: { select: { id: true, fullName: true } },
        owner: { select: { id: true, fullName: true } },
        tags: true,
        notes: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return leads;
  }

  async getById(ctx: TenantContext, id: string) {
    // The lookup is scoped to the caller's reachable projects, so "not yours" and
    // "does not exist" are the same lookup. Both now raise the same 404, matching
    // DealsService#getById, rather than a 200 carrying null.
    const lead = await this.prisma.client.lead.findFirst({
      where: { id, ...accessibleProjectsScope(ctx) },
      select: {
        id: true,
        name: true,
        company: true,
        source: true,
        status: true,
        jobTitle: true,
        email: true,
        phone: true,
        industry: true,
        leadScore: true,
        priority: true,
        estimatedValue: true,
        ownerId: true,
        customerId: true,
        ticketNumber: true,
        ticketDate: true,
        followUpDate: true,
        customer: {
          select: {
            id: true,
            cxId: true,
            displayName: true,
            primaryEmail: true,
            primaryPhone: true,
          },
        },
        tags: true,
        notes: true,
        createdAt: true,
      },
    });

    if (!lead) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Lead not found' });
    }

    return lead;
  }

  async create(
    ctx: TenantContext,
    data: {
      name: string;
      company?: string;
      jobTitle?: string;
      email?: string;
      phone?: string;
      source?: string;
      status?: string;
      industry?: string;
      leadScore?: number;
      priority?: string;
      estimatedValue?: number;
      ownerId?: string;
      customerId?: string;
      ticketNumber?: string;
      ticketDate?: string | Date;
      followUpDate?: string | Date;
      tags?: string[];
      notes?: string;
    },
    projectId?: string,
  ) {
    const leadData: Record<string, unknown> = {
      name: data.name,
      company: data.company || undefined,
      status: data.status || 'New',
      ...(projectId
        ? projectScope(ctx, projectId)
        : { projectId: this.defaultProjectId(ctx) as string | undefined }),
    };
    if (data.jobTitle !== undefined) leadData.jobTitle = data.jobTitle;
    if (data.email !== undefined) leadData.email = data.email;
    if (data.phone !== undefined) leadData.phone = data.phone;
    if (data.source !== undefined) leadData.source = data.source;
    if (data.industry !== undefined) leadData.industry = data.industry;
    if (data.leadScore !== undefined) leadData.leadScore = data.leadScore;
    if (data.priority !== undefined) leadData.priority = data.priority;
    if (data.estimatedValue !== undefined) leadData.estimatedValue = data.estimatedValue;
    if (data.ownerId !== undefined) leadData.ownerId = data.ownerId;
    if (data.customerId !== undefined) leadData.customerId = data.customerId || null;
    if (data.ticketNumber !== undefined) leadData.ticketNumber = data.ticketNumber || null;
    if (data.ticketDate !== undefined) leadData.ticketDate = data.ticketDate ? new Date(data.ticketDate) : null;
    if (data.followUpDate !== undefined) leadData.followUpDate = data.followUpDate ? new Date(data.followUpDate) : null;
    if (data.tags !== undefined) leadData.tags = data.tags;
    if (data.notes !== undefined) leadData.notes = data.notes;
    leadData.createdById = ctx.userId;

    // Auto-fetch customer project & ticket details if not explicitly provided
    if (data.customerId) {
      if (!leadData.projectId) {
        const cust = await this.prisma.client.customer.findFirst({
          where: { id: data.customerId, ...accessibleProjectsScope(ctx) },
          select: { projectId: true },
        });
        if (cust?.projectId) leadData.projectId = cust.projectId;
      }
      if (!leadData.ticketNumber || !leadData.ticketDate) {
        const latestConv = await this.prisma.client.conversation.findFirst({
          where: { customerId: data.customerId, ...accessibleProjectsScope(ctx) },
          orderBy: { createdAt: 'desc' },
          select: { ticketNumber: true, createdAt: true },
        });
        if (latestConv) {
          if (!leadData.ticketNumber) leadData.ticketNumber = latestConv.ticketNumber;
          if (!leadData.ticketDate) leadData.ticketDate = latestConv.createdAt;
        }
      }
    }

    return this.prisma.client.lead.create({
      data: leadData as never,
      select: {
        id: true,
        name: true,
        company: true,
        source: true,
        status: true,
        jobTitle: true,
        email: true,
        phone: true,
        industry: true,
        leadScore: true,
        priority: true,
        estimatedValue: true,
        ownerId: true,
        createdById: true,
        customerId: true,
        ticketNumber: true,
        ticketDate: true,
        followUpDate: true,
        customer: {
          select: {
            id: true,
            cxId: true,
            displayName: true,
            primaryEmail: true,
            primaryPhone: true,
          },
        },
        createdBy: { select: { id: true, fullName: true } },
        tags: true,
        notes: true,
        createdAt: true,
      },
    });
  }

  async update(
    ctx: TenantContext,
    id: string,
    data: {
      name?: string;
      company?: string;
      jobTitle?: string;
      email?: string;
      phone?: string;
      source?: string;
      status?: string;
      industry?: string;
      leadScore?: number;
      priority?: string;
      estimatedValue?: number;
      ownerId?: string;
      customerId?: string;
      ticketNumber?: string;
      ticketDate?: string | Date;
      followUpDate?: string | Date;
      tags?: string[];
      notes?: string;
    },
  ) {
    await this.assertOwned(ctx, id);

    const updateData: Record<string, unknown> = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.company !== undefined) updateData.company = data.company;
    if (data.jobTitle !== undefined) updateData.jobTitle = data.jobTitle;
    if (data.email !== undefined) updateData.email = data.email;
    if (data.phone !== undefined) updateData.phone = data.phone;
    if (data.source !== undefined) updateData.source = data.source;
    if (data.status !== undefined) updateData.status = data.status;
    if (data.industry !== undefined) updateData.industry = data.industry;
    if (data.leadScore !== undefined) updateData.leadScore = data.leadScore;
    if (data.priority !== undefined) updateData.priority = data.priority;
    if (data.estimatedValue !== undefined) updateData.estimatedValue = data.estimatedValue;
    if (data.ownerId !== undefined) updateData.ownerId = data.ownerId || null;
    if (data.customerId !== undefined) updateData.customerId = data.customerId || null;
    if (data.ticketNumber !== undefined) updateData.ticketNumber = data.ticketNumber || null;
    if (data.ticketDate !== undefined) updateData.ticketDate = data.ticketDate ? new Date(data.ticketDate) : null;
    if (data.followUpDate !== undefined) updateData.followUpDate = data.followUpDate ? new Date(data.followUpDate) : null;
    if (data.tags !== undefined) updateData.tags = data.tags;
    if (data.notes !== undefined) updateData.notes = data.notes;

    return this.prisma.client.lead.update({
      where: { id },
      data: updateData as never,
      select: {
        id: true,
        name: true,
        company: true,
        source: true,
        status: true,
        jobTitle: true,
        email: true,
        phone: true,
        industry: true,
        leadScore: true,
        priority: true,
        estimatedValue: true,
        ownerId: true,
        customerId: true,
        ticketNumber: true,
        ticketDate: true,
        followUpDate: true,
        customer: {
          select: {
            id: true,
            cxId: true,
            displayName: true,
            primaryEmail: true,
            primaryPhone: true,
          },
        },
        tags: true,
        notes: true,
        createdAt: true,
      },
    });
  }

  async delete(ctx: TenantContext, id: string) {
    await this.assertOwned(ctx, id);

    return this.prisma.client.lead.delete({
      where: { id },
    });
  }

  async convertToCustomer(ctx: TenantContext, id: string, customerName?: string) {
    const lead = await this.getById(ctx, id);
    if (!lead) return { lead: null, customer: { id: '', displayName: customerName || 'New Lead' } };

    return {
      lead,
      customer: {
        id: 'temp-customer-id',
        displayName: customerName || lead.name,
      },
    };
  }

  private async assertOwned(ctx: TenantContext, id: string) {
    const existing = await this.prisma.client.lead.findFirst({
      where: { id, ...accessibleProjectsScope(ctx) },
      select: { id: true },
    });

    if (!existing) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Lead not found' });
    }
  }
}