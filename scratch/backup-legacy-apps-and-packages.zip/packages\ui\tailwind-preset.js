/**
 * Tailwind preset that exposes the design tokens as utilities.
 *
 * Feature code writes `bg-surface` / `text-slate` / `border-hairline` and
 * never a hex value, so a token change propagates everywhere at once.
 * Values indirect through the CSS variables in `src/styles/tokens.css`,
 * which stays the single source of truth.
 */
/** @type {import('tailwindcss').Config} */
module.exports = {
  theme: {
    extend: {
      colors: {
        ink: 'var(--fe-ink)',
        'ink-soft': 'var(--fe-ink-soft)',
        slate: 'var(--fe-slate)',
        'slate-soft': 'var(--fe-slate-soft)',
        mist: 'var(--fe-mist)',
        'mist-deep': 'var(--fe-mist-deep)',
        surface: 'var(--fe-surface)',
        hairline: 'var(--fe-hairline)',
        signal: 'var(--fe-signal)',
        'signal-strong': 'var(--fe-signal-strong)',
        'signal-wash': 'var(--fe-signal-wash)',
        agent: 'var(--fe-agent)',
        'agent-wash': 'var(--fe-agent-wash)',
        escalation: 'var(--fe-escalation)',
        'escalation-wash': 'var(--fe-escalation-wash)',
        danger: 'var(--fe-danger)',
        'danger-wash': 'var(--fe-danger-wash)',
        warning: 'var(--fe-warning)',
        'warning-wash': 'var(--fe-warning-wash)',
        'nav-dim': 'var(--fe-nav-dim)',
        'nav-surface': 'var(--fe-nav-surface)',
        'nav-raised': 'var(--fe-nav-raised)',
        'nav-text': 'var(--fe-nav-text)',
        'nav-muted': 'var(--fe-nav-muted)',
        'nav-active': 'var(--fe-nav-active)',
        'content-bg': 'var(--fe-content-bg)',
      },
      fontFamily: {
        body: 'var(--fe-font-body)',
        display: 'var(--fe-font-display)',
        mono: 'var(--fe-font-mono)',
      },
      fontSize: {
        '2xs': 'var(--fe-text-2xs)',
        xs: 'var(--fe-text-xs)',
        sm: 'var(--fe-text-sm)',
        base: 'var(--fe-text-base)',
        lg: 'var(--fe-text-lg)',
        xl: 'var(--fe-text-xl)',
        '2xl': 'var(--fe-text-2xl)',
      },
      borderRadius: {
        sm: 'var(--fe-radius-sm)',
        DEFAULT: 'var(--fe-radius)',
        lg: 'var(--fe-radius-lg)',
      },
      boxShadow: {
        panel: 'var(--fe-shadow-panel)',
        pop: 'var(--fe-shadow-pop)',
      },
    },
  },
};
