/**
 * Queue names and the shared retry policy (plan §11).
 *
 * Declared here rather than in either app so the producer (API) and the
 * consumer (worker) cannot drift on a name or disagree about how many
 * times a customer's message is retried before it is treated as lost.
 *
 * Structurally typed instead of importing BullMQ's types: this package
 * stays free of the queue library, and BullMQ accepts the shape as-is.
 */
export const QueueName = {
  INCOMING_MESSAGE: 'incoming-message',
  AI_RESPONSE: 'ai-response',
  SCORING: 'scoring',
  SUMMARY: 'summary',
  DOCUMENT_PROCESSING: 'document-processing',
  OUTBOUND_SEND: 'outbound-send',
  ESCALATION_ROUTING: 'escalation-routing',
  ANALYTICS_ROLLUP: 'analytics-rollup',
} as const;
export type QueueName = (typeof QueueName)[keyof typeof QueueName];

export interface JobRetryPolicy {
  attempts: number;
  backoff: { type: 'exponential'; delay: number };
  removeOnComplete: { age: number; count: number };
  removeOnFail: { age: number };
}

/**
 * Customer conversations are never lost (plan §20.8): retry with backoff,
 * and keep failures around for a week so a dead-letter can be inspected
 * rather than discovered by a customer complaint.
 */
export const DEFAULT_JOB_OPTIONS: JobRetryPolicy = {
  attempts: 5,
  backoff: { type: 'exponential', delay: 2_000 },
  removeOnComplete: { age: 3_600, count: 1_000 },
  removeOnFail: { age: 7 * 24 * 3_600 },
};
