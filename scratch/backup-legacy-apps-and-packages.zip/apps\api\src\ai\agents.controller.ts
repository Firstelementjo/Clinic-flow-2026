import { Body, Controller, Get, Param, ParseUUIDPipe, Post, Put, Req } from '@nestjs/common';
import type { Request } from 'express';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import { saveAgentSchema, type SaveAgentInput } from '@firstelement/shared';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { AgentsService } from './agents.service';

@Controller('projects/:projectId/agent')
export class AgentsController {
  constructor(private readonly agents: AgentsService) {}

  @Get()
  @RequirePermissions(Permission.AI_AGENT_READ)
  get(@Tenant() ctx: TenantContext, @Param('projectId', ParseUUIDPipe) projectId: string) {
    return this.agents.get(ctx, projectId);
  }

  @Get('versions')
  @RequirePermissions(Permission.AI_AGENT_READ)
  versions(@Tenant() ctx: TenantContext, @Param('projectId', ParseUUIDPipe) projectId: string) {
    return this.agents.listVersions(ctx, projectId);
  }

  /** PUT, but it appends a version rather than replacing one (plan §9). */
  @Put()
  @RequirePermissions(Permission.AI_AGENT_CONFIGURE)
  save(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Body(zodBody(saveAgentSchema)) body: SaveAgentInput,
    @Req() request: Request,
  ) {
    return this.agents.save(ctx, projectId, body, request.ip);
  }

  @Post('versions/:versionId/activate')
  @RequirePermissions(Permission.AI_AGENT_CONFIGURE)
  activate(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('versionId', ParseUUIDPipe) versionId: string,
    @Req() request: Request,
  ) {
    return this.agents.activateVersion(ctx, projectId, versionId, request.ip);
  }
}
