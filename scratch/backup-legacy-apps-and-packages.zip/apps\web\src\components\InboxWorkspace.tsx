import { type PointerEvent as ReactPointerEvent } from 'react';
import { EmptyState, Spinner } from '@firstelement/ui';
import { InboxFilter, type SessionUser } from '@firstelement/shared';
import { ConversationList } from './ConversationList';
import { ConversationThread } from './ConversationThread';
import { CustomerCard } from './CustomerCard';
import { CasePanel } from './CasePanel';
import { AiRunPanel } from './AiRunPanel';
import { useT, type StringKey } from '../lib/i18n';
import { useConversation, useInbox } from '../lib/inbox';
import { useResizableColumns } from '../lib/useResizableColumns';

const TABS: { filter: InboxFilter; labelKey: StringKey }[] = [
  { filter: InboxFilter.ASSIGNED_TO_ME, labelKey: 'filter.assigned-to-me' },
  { filter: InboxFilter.HISTORY, labelKey: 'filter.history' },
];

export interface InboxWorkspaceProps {
  user: SessionUser | null;
  filter: InboxFilter;
  onFilter: (filter: InboxFilter) => void;
  selectedId: string | null;
  onSelect: (id: string) => void;
  search: string;
  onSearch: (search: string) => void;
  /** Floating mode fills its window; the route version sizes to the page. */
  variant?: 'page' | 'floating';
}

function DragHandle({
  onPointerDown,
  onPointerMove,
  onPointerUp,
}: {
  onPointerDown: (e: ReactPointerEvent) => void;
  onPointerMove: (e: ReactPointerEvent) => void;
  onPointerUp: (e: ReactPointerEvent) => void;
}) {
  return (
    <div
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      className="group relative z-10 w-2 shrink-0 cursor-col-resize"
      style={{ touchAction: 'none' }}
    >
      <div className="absolute inset-y-0 left-1/2 w-px -translate-x-1/2 bg-hairline group-hover:bg-agent/60 group-active:bg-agent transition-colors" />
    </div>
  );
}

export function InboxWorkspace({
  user,
  filter,
  onFilter,
  selectedId,
  onSelect,
  search,
  onSearch,
  variant = 'page',
}: InboxWorkspaceProps) {
  const t = useT();
  const inbox = useInbox({ filter, search });
  const conversation = useConversation(selectedId);

  const isFloating = variant === 'floating';
  const { widths, onPointerDown, onPointerMove, onPointerUp } = useResizableColumns(
    isFloating ? [288, 500] : [352, 500],
  );

  return (
    <div
      className={[
        'flex min-h-0 overflow-hidden',
        variant === 'page'
          ? 'card split-flex flex-1'
          : 'h-full bg-[var(--fe-surface)]',
      ].join(' ')}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
    >
      <section
        className="flex min-h-0 shrink-0 flex-col border-e border-[var(--fe-hairline)]"
        style={{ width: widths[0] }}
      >
        {/* Tabs - Only shown in floating mode since InboxPage has its own header */}
        {isFloating && (
          <div className="flex shrink-0 border-b border-[var(--fe-hairline)] bg-[var(--fe-surface)]">
            <div className="seg w-full m-2">
              {TABS.map((tab) => (
                <button
                  key={tab.filter}
                  type="button"
                  onClick={() => onFilter(tab.filter)}
                  className={filter === tab.filter ? 'on' : ''}
                >
                  {t(tab.labelKey)}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Search */}
        <div className="shrink-0 p-3">
          <input
            value={search}
            onChange={(e) => onSearch(e.target.value)}
            placeholder={t('inbox.search')}
            aria-label={t('inbox.search')}
            className="t"
          />
        </div>

        {/* Conversation list */}
        <div className="min-h-0 flex-1 overflow-y-auto">
          {inbox.isPending ? (
            <div className="p-4">
              <Spinner label={t('common.loading')} />
            </div>
          ) : inbox.isError ? (
            <p className="p-4 text-sm text-slate">{t('common.error')}</p>
          ) : inbox.data.items.length === 0 ? (
            <EmptyState title={t('inbox.empty.title')} body={t('inbox.empty.body')} />
          ) : (
            <ConversationList
              conversations={inbox.data.items}
              selectedId={selectedId}
              onSelect={onSelect}
              showCloseButton={filter === InboxFilter.ASSIGNED_TO_ME}
            />
          )}
        </div>
      </section>

      <DragHandle
        onPointerDown={onPointerDown(0)}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
      />

      {/* Conversation thread */}
      <section
        id="thread"
        className="min-h-0 shrink-0 flex flex-col border-e border-[var(--fe-hairline)] bg-[var(--fe-surf2)]"
        style={{ width: widths[1] }}
      >
        {!selectedId ? (
          <EmptyState title={t('inbox.pick.title')} body={t('inbox.pick.body')} />
        ) : conversation.isPending ? (
          <div className="p-4">
            <Spinner label={t('common.loading')} />
          </div>
        ) : conversation.isError || !conversation.data ? (
          <p className="p-4 text-sm text-slate">{t('common.error')}</p>
        ) : user ? (
          <ConversationThread conversation={conversation.data} user={user} />
        ) : null}
      </section>

      <DragHandle
        onPointerDown={onPointerDown(1)}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
      />

      {/* Right sidebar — fills remaining space */}
      <aside className="relative min-h-0 min-w-0 flex-1 overflow-y-auto overflow-x-hidden">
        {conversation.data ? (
          <>
            <CustomerCard customerId={conversation.data.customer.id} />
            <CasePanel conversation={conversation.data} />
            <AiRunPanel conversationId={conversation.data.id} />
          </>
        ) : null}

        {/* Right-edge resize handle — adjusts thread width so sidebar grows/shrinks */}
        <div
          className="absolute top-0 bottom-0 end-0 z-20 w-2 cursor-col-resize"
          style={{ touchAction: 'none' }}
          onPointerDown={onPointerDown(1)}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
        >
          <div className="absolute inset-y-0 left-1/2 w-px -translate-x-1/2 bg-hairline hover:bg-agent/60 active:bg-agent transition-colors" />
        </div>
      </aside>
    </div>
  );
}
