import { Injectable, NotFoundException } from '@nestjs/common';
import type { TenantContext } from '@firstelement/database';
import { ErrorCode, ROUTABLE_STATUSES, type EmployeeAvailabilityStatus } from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';

export interface AgentStatusView {
  employeeId: string;
  status: EmployeeAvailabilityStatus;
  /** When the current status began — the client counts up from here. */
  since: string;
  /** Server-computed elapsed seconds, so a clock-skewed browser still agrees. */
  elapsedSeconds: number;
  isRoutable: boolean;
}

export interface StatusTotalsView {
  from: string;
  to: string;
  totals: { status: EmployeeAvailabilityStatus; seconds: number }[];
  /** Time in a routable status as a share of all recorded time, 0–100. */
  routablePercentage: number;
}

/**
 * Agent status and its time accounting (V1.2 §8, §9).
 *
 * The timer is derived, never counted in the browser: the client is given
 * `since` and renders the difference. A refresh, a second tab, or a laptop
 * asleep for an hour all show the same elapsed time, and the number an
 * agent watches is the same number a supervisor reports on.
 *
 * Every change closes the open session and opens a new one, so status
 * history is an append-only record rather than a single mutable field.
 * The field on `Employee` remains as the fast read for routing.
 */
@Injectable()
export class AgentStatusService {
  constructor(private readonly prisma: PrismaService) {}

  async current(ctx: TenantContext, employeeId?: string): Promise<AgentStatusView> {
    const employee = await this.requireEmployee(ctx, employeeId);

    return {
      employeeId: employee.id,
      status: employee.availabilityStatus,
      since: employee.statusChangedAt.toISOString(),
      elapsedSeconds: Math.max(
        0,
        Math.floor((Date.now() - employee.statusChangedAt.getTime()) / 1000),
      ),
      isRoutable: ROUTABLE_STATUSES.includes(employee.availabilityStatus),
    };
  }

  /**
   * Changes status, closing the previous session and opening a new one in
   * a single transaction — otherwise a crash between the two writes leaves
   * either a double-counted overlap or a gap in the day.
   */
  async setStatus(
    ctx: TenantContext,
    status: EmployeeAvailabilityStatus,
    options: { employeeId?: string; note?: string } = {},
  ): Promise<AgentStatusView> {
    const employee = await this.requireEmployee(ctx, options.employeeId);

    // Re-selecting the same status is a no-op rather than a zero-length
    // session: an agent clicking twice should not fragment their day.
    if (employee.availabilityStatus === status) {
      return this.current(ctx, employee.id);
    }

    const now = new Date();

    await this.prisma.client.$transaction(async (tx) => {
      const open = await tx.agentStatusSession.findFirst({
        where: { employeeId: employee.id, endedAt: null },
        orderBy: { startedAt: 'desc' },
      });

      if (open) {
        await tx.agentStatusSession.update({
          where: { id: open.id },
          data: {
            endedAt: now,
            durationSeconds: Math.max(
              0,
              Math.floor((now.getTime() - open.startedAt.getTime()) / 1000),
            ),
          },
        });
      }

      await tx.agentStatusSession.create({
        data: {
          organizationId: ctx.organizationId,
          employeeId: employee.id,
          status,
          startedAt: now,
          // Recorded when an admin changes someone else's status, so a
          // report can tell "went to lunch" from "was marked offline".
          changedByUserId: ctx.userId === employee.userId ? null : ctx.userId,
          note: options.note ?? null,
        },
      });

      await tx.employee.update({
        where: { id: employee.id },
        data: { availabilityStatus: status, statusChangedAt: now },
      });
    });

    return this.current(ctx, employee.id);
  }

  /**
   * Time per status over a window (V1.2 §9 reporting).
   *
   * Closed sessions contribute their stored duration; the open one is
   * counted up to now, so today's totals include the status the agent is
   * sitting in rather than under-reporting until they switch.
   */
  async totals(
    ctx: TenantContext,
    options: { employeeId?: string; days?: number } = {},
  ): Promise<StatusTotalsView> {
    const employee = await this.requireEmployee(ctx, options.employeeId);
    const days = Math.min(Math.max(options.days ?? 7, 1), 92);
    const from = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const now = new Date();

    const sessions = await this.prisma.client.agentStatusSession.findMany({
      where: { employeeId: employee.id, startedAt: { gte: from } },
      select: { status: true, startedAt: true, endedAt: true, durationSeconds: true },
    });

    const totals = new Map<EmployeeAvailabilityStatus, number>();

    for (const session of sessions) {
      const seconds =
        session.durationSeconds ??
        Math.max(0, Math.floor(((session.endedAt ?? now).getTime() - session.startedAt.getTime()) / 1000));
      totals.set(session.status, (totals.get(session.status) ?? 0) + seconds);
    }

    const recorded = [...totals.values()].reduce((sum, value) => sum + value, 0);
    const routable = ROUTABLE_STATUSES.reduce((sum, status) => sum + (totals.get(status) ?? 0), 0);

    return {
      from: from.toISOString(),
      to: now.toISOString(),
      totals: [...totals.entries()]
        .map(([status, seconds]) => ({ status, seconds }))
        .sort((a, b) => b.seconds - a.seconds),
      routablePercentage: recorded === 0 ? 0 : Number(((routable / recorded) * 100).toFixed(1)),
    };
  }

  /** The whole team's current status, for the supervisor view. */
  async teamStatus(ctx: TenantContext): Promise<AgentStatusView[]> {
    const employees = await this.prisma.client.employee.findMany({
      where: { organizationId: ctx.organizationId },
      select: { id: true, availabilityStatus: true, statusChangedAt: true },
    });

    const now = Date.now();
    return employees.map((employee) => ({
      employeeId: employee.id,
      status: employee.availabilityStatus,
      since: employee.statusChangedAt.toISOString(),
      elapsedSeconds: Math.max(0, Math.floor((now - employee.statusChangedAt.getTime()) / 1000)),
      isRoutable: ROUTABLE_STATUSES.includes(employee.availabilityStatus),
    }));
  }

  /**
   * Resolves the target employee. Without an id this is the caller's own
   * profile — the self-service path — and an id is only honoured for
   * someone in the caller's organization.
   */
  private async requireEmployee(ctx: TenantContext, employeeId?: string) {
    const employee = await this.prisma.client.employee.findFirst({
      where: employeeId
        ? { id: employeeId, organizationId: ctx.organizationId }
        : { userId: ctx.userId, organizationId: ctx.organizationId },
      select: {
        id: true,
        userId: true,
        availabilityStatus: true,
        statusChangedAt: true,
      },
    });

    if (!employee) {
      throw new NotFoundException({
        code: ErrorCode.NOT_FOUND,
        message: employeeId ? 'Employee not found' : 'You do not have an employee profile',
      });
    }

    return employee;
  }
}
