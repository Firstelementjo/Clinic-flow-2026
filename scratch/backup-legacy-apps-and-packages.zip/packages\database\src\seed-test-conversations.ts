/**
 * Seed test conversations for each agent.
 * Run with: npx tsx packages/database/src/seed-test-conversations.ts
 */
import { PrismaClient } from '@prisma/client';
import { generateTicketNumber, generateCxId } from '@firstelement/shared';

const prisma = new PrismaClient();

const agentSpecs = [
  { email: 'omar@firstelement.dev', conversations: [
    { customer: 'أحمد testing', phone: '+966501111111', platform: 'WHATSAPP', body: 'I need help with my order', status: 'OPEN', mode: 'HUMAN' as const },
    { customer: 'محمد test2', phone: '+966502222222', platform: 'WHATSAPP', body: 'Where is my refund?', status: 'OPEN', mode: 'HUMAN' as const },
    { customer: 'خالد closed', phone: '+966503333333', platform: 'TELEGRAM', body: 'Thanks for the help!', status: 'RESOLVED', mode: 'HUMAN' as const },
  ]},
  { email: 'sara@firstelement.dev', conversations: [
    { customer: 'فاطمة test', phone: '+966504444444', platform: 'INSTAGRAM', body: 'Can I change my address?', status: 'OPEN', mode: 'HUMAN' as const },
    { customer: 'نور test2', phone: '+966505555555', platform: 'WHATSAPP', body: 'My product arrived damaged', status: 'OPEN', mode: 'HUMAN' as const },
    { customer: 'ريم closed', phone: '+966506666666', platform: 'WHATSAPP', body: 'Perfect, thank you!', status: 'RESOLVED', mode: 'HUMAN' as const },
  ]},
  { email: 'yousef@firstelement.dev', conversations: [
    { customer: 'يوسف test', phone: '+966507777777', platform: 'TELEGRAM', body: 'Cancel my subscription', status: 'OPEN', mode: 'HUMAN' as const },
    { customer: 'عمر test2', phone: '+966508888888', platform: 'WHATSAPP', body: 'When is my delivery?', status: 'OPEN', mode: 'HUMAN' as const },
    { customer: 'سلمان closed', phone: '+966509999999', platform: 'INSTAGRAM', body: 'Great service!', status: 'RESOLVED', mode: 'HUMAN' as const },
  ]},
];

async function main() {
  const org = await prisma.organization.findFirst({ select: { id: true } });
  if (!org) { console.error('No organization found'); return; }

  const project = await prisma.project.findFirst({ select: { id: true } });
  if (!project) { console.error('No project found'); return; }

  let ticketSeq = 100;

  for (const spec of agentSpecs) {
    const user = await prisma.user.findUnique({ where: { email: spec.email }, select: { id: true } });
    if (!user) { console.error(`User ${spec.email} not found`); continue; }

    const employee = await prisma.employee.findUnique({ where: { userId: user.id }, select: { id: true } });
    if (!employee) { console.error(`Employee for ${spec.email} not found`); continue; }

    for (const conv of spec.conversations) {
      ticketSeq++;
      const base = Date.now() - ticketSeq * 3_600_000;
      const cxId = generateCxId(ticketSeq);

      const customer = await prisma.customer.create({
        data: {
          organizationId: org.id,
          projectId: project.id,
          cxId,
          displayName: conv.customer,
          primaryPhone: conv.phone,
          externalIds: { [conv.platform]: `test-${ticketSeq}` },
          identities: {
            create: {
              organizationId: org.id,
              projectId: project.id,
              platform: conv.platform as any,
              externalId: `test-${ticketSeq}`,
              displayName: conv.customer,
              isVerified: true,
            },
          },
        },
        select: { id: true },
      });

      const created = await prisma.conversation.create({
        data: {
          organizationId: org.id,
          projectId: project.id,
          customerId: customer.id,
          channel: conv.platform as any,
          status: conv.status as any,
          mode: conv.mode,
          priority: 'NORMAL',
          ticketNumber: generateTicketNumber(new Date(base), ticketSeq),
          assignedEmployeeId: employee.id,
          lastReplierUserId: user.id,
          messageCount: 2,
          lastMessageAt: new Date(base + 120_000),
          resolvedAt: conv.status === 'RESOLVED' ? new Date(base + 60_000) : null,
          messages: {
            create: [
              { organizationId: org.id, projectId: project.id, channel: conv.platform as any, direction: 'INBOUND', authorType: 'CUSTOMER', body: conv.body, sentAt: new Date(base) },
              { organizationId: org.id, projectId: project.id, channel: conv.platform as any, direction: 'OUTBOUND', authorType: 'EMPLOYEE', authorUserId: user.id, body: 'I am looking into this for you.', sentAt: new Date(base + 60_000) },
            ],
          },
        },
        select: { id: true, ticketNumber: true },
      });

      console.log(`  Created ${conv.status} ticket ${created.ticketNumber} for ${spec.email}`);
    }
  }

  console.log('Done!');
}

main()
  .catch((error) => { console.error(error); process.exitCode = 1; })
  .finally(() => prisma.$disconnect());
