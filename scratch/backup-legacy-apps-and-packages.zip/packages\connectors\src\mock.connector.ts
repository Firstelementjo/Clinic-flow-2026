import { ChannelType } from '@firstelement/shared';
import type {
  ConnectorCapabilities,
  ExternalConversation,
  MessagingConnector,
  NormalizedIncomingMessage,
  OutgoingMediaMessage,
  OutgoingMessage,
  SendResult,
} from './types';

/**
 * The development connector (plan §13).
 *
 * It exists so the entire pipeline — webhook → customer → conversation →
 * message → (later) AI, scoring, escalation, routing — is exercisable
 * without live Meta or Telegram credentials. It is not a stub that fakes
 * success: sends are recorded in an outbox the dev endpoint can read back,
 * and it declares capabilities like any other channel so capability-aware
 * code paths are exercised in development rather than first meeting
 * reality in slice 8.
 */

export interface MockIncomingPayload {
  externalUserId: string;
  text: string;
  externalMessageId?: string;
  displayName?: string;
  phone?: string;
  email?: string;
  sentAt?: string;
}

export interface MockSentMessage {
  messageId: string;
  externalUserId: string;
  text: string;
  sentAt: Date;
}

export class MockConnector implements MessagingConnector {
  readonly channel = ChannelType.MOCK;

  /** In-memory record of what was "sent", for dev inspection and tests. */
  private readonly outbox: MockSentMessage[] = [];
  private counter = 0;

  constructor(readonly connectionId: string) {}

  capabilities(): ConnectorCapabilities {
    return {
      channel: ChannelType.MOCK,
      sendText: true,
      sendMedia: true,
      markAsRead: true,
      editMessage: false,
      deleteMessage: false,
      sessionWindowHours: null,
      requiresTemplateOutsideSession: false,
      maxTextLength: 4000,
      supportedAttachmentTypes: ['image', 'document', 'audio', 'video'],
      // Deliberately false: the dev endpoint is gated by configuration,
      // not by a signature it could only check against itself.
      verifiesWebhookSignature: false,
    };
  }

  async connect(): Promise<void> {}

  async disconnect(): Promise<void> {}

  async verifyWebhook(): Promise<boolean> {
    return true;
  }

  async receiveWebhook(payload: unknown): Promise<NormalizedIncomingMessage[]> {
    const items = Array.isArray(payload) ? payload : [payload];

    return items
      .filter((item): item is MockIncomingPayload => isMockPayload(item))
      .map((item) => ({
        channel: ChannelType.MOCK,
        // A caller-supplied id lets a test replay the same message and
        // assert that the pipeline deduplicates it.
        externalMessageId: item.externalMessageId ?? this.nextMessageId(),
        externalUserId: item.externalUserId,
        externalConversationId: item.externalUserId,
        displayName: item.displayName,
        phone: item.phone,
        email: item.email,
        text: item.text,
        attachments: [],
        sentAt: item.sentAt ? new Date(item.sentAt) : new Date(),
        raw: { ...item, connector: 'mock' },
      }));
  }

  async sendText(message: OutgoingMessage): Promise<SendResult> {
    const externalMessageId = this.nextMessageId();
    this.outbox.push({
      messageId: message.messageId,
      externalUserId: message.externalUserId,
      text: message.text,
      sentAt: new Date(),
    });
    return { ok: true, externalMessageId };
  }

  async sendMedia(message: OutgoingMediaMessage): Promise<SendResult> {
    return this.sendText(message);
  }

  async markAsRead(_conversation: ExternalConversation): Promise<void> {}

  /** Dev inspection: what this connector has "delivered" so far. */
  sent(): readonly MockSentMessage[] {
    return this.outbox;
  }

  private nextMessageId(): string {
    this.counter += 1;
    return `mock-${Date.now()}-${this.counter}`;
  }
}

function isMockPayload(value: unknown): value is MockIncomingPayload {
  if (typeof value !== 'object' || value === null) return false;
  const candidate = value as Record<string, unknown>;
  return typeof candidate.externalUserId === 'string' && typeof candidate.text === 'string';
}
