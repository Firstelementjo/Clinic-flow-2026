/**
 * The acceptance scenario from plan §17, end to end.
 *
 * ```
 * admin creates project → adds employees → configures availability
 *   → uploads knowledge → creates AI agent → sets escalation rule
 *   → enables mock channel → customer messages → customer + conversation
 *   created → AI retrieves knowledge and answers → customer gets frustrated
 *   → frustration crosses the threshold → escalation fires → summary
 *   written → routing finds an available employee → employee notified
 *   → conversation switches to HUMAN and the AI stops → employee replies,
 *   customer replies, employee resolves → analytics update
 * ```
 *
 * This is the test that proves the slices compose. Each one has its own
 * unit and integration coverage; this checks that the seams hold.
 *
 * Requires PostgreSQL with pgvector. Skips loudly without one.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { hashPassword } from '@firstelement/auth';
import { AIOrchestrator, EscalationEngine, MockEmbeddingProvider } from '@firstelement/ai';
import { MockConnector } from '@firstelement/connectors';
import { disconnectPrisma, getPrismaClient } from '@firstelement/database';
import {
  DocumentIngestionPipeline,
  KnowledgeRetriever,
  type StorageDriver,
} from '@firstelement/knowledge-base';
import { InboundMessagePipeline, TimelineRecordingPublisher } from '@firstelement/messaging';
import { RoutingEngine } from '@firstelement/routing';
import type { DomainEvent } from '@firstelement/events';

const prisma = getPrismaClient();

async function ready(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1 FROM document_chunks LIMIT 1`;
    return true;
  } catch {
    return false;
  }
}

const hasDatabase = await ready();

class MemoryStorage implements StorageDriver {
  private readonly files = new Map<string, Buffer>();
  async put(key: string, data: Buffer): Promise<void> {
    this.files.set(key, data);
  }
  async get(key: string): Promise<Buffer> {
    const file = this.files.get(key);
    if (!file) throw new Error(`Missing ${key}`);
    return file;
  }
  async delete(key: string): Promise<void> {
    this.files.delete(key);
  }
}

describe.skipIf(!hasDatabase)('plan §17 acceptance scenario', () => {
  const suffix = Date.now().toString(36);
  const published: DomainEvent[] = [];

  const events = new TimelineRecordingPublisher(prisma, () => {}, {
    publish: (event) => published.push(event),
  });

  const embeddings = new MockEmbeddingProvider();
  const storage = new MemoryStorage();
  const ingestion = new DocumentIngestionPipeline(prisma, storage, embeddings);
  const retriever = new KnowledgeRetriever(prisma, embeddings);
  const inbound = new InboundMessagePipeline(prisma, events);
  const escalationEngine = new EscalationEngine(prisma, events);
  const routing = new RoutingEngine(prisma, events);
  const connector = new MockConnector(`acceptance-${suffix}`);

  const orchestrator = new AIOrchestrator(prisma, async (params) => {
    const result = await retriever.retrieve({
      organizationId: params.organizationId,
      projectId: params.projectId,
      query: params.query,
      minScore: params.minScore,
    });
    return result.chunks.map((chunk) => ({
      chunkId: chunk.chunkId,
      documentId: chunk.documentId,
      knowledgeBaseId: chunk.knowledgeBaseId,
      documentTitle: chunk.documentTitle,
      content: chunk.content,
      score: chunk.score,
    }));
  });

  let organizationId: string;
  let projectId: string;
  let connectionId: string;
  let employeeId: string;
  let employeeUserId: string;
  let conversationId: string;
  let customerId: string;

  const customerHandle = `acceptance-customer-${suffix}`;

  async function deliver(text: string, externalMessageId?: string) {
    const [message] = await connector.receiveWebhook({
      externalUserId: customerHandle,
      displayName: 'نورة السالم',
      phone: `+96650${suffix.slice(-7)}`,
      text,
      externalMessageId,
    });

    return inbound.process({
      organizationId,
      projectId,
      connectionId,
      channel: 'MOCK',
      message: message!,
    });
  }

  beforeAll(async () => {
    // --- admin creates an organization and a project ----------------------
    const organization = await prisma.organization.create({
      data: { name: `Acceptance ${suffix}`, slug: `acceptance-${suffix}` },
    });
    organizationId = organization.id;

    const project = await prisma.project.create({
      data: { organizationId, name: 'Retail Support', slug: `retail-${suffix}` },
    });
    projectId = project.id;

    // --- adds an employee, with availability and capacity -----------------
    const user = await prisma.user.create({
      data: {
        organizationId,
        email: `agent-${suffix}@example.com`,
        fullName: 'Layla Haddad',
        passwordHash: await hashPassword('DemoPassword123!'),
        role: 'EMPLOYEE',
      },
    });
    employeeUserId = user.id;

    const employee = await prisma.employee.create({
      data: {
        organizationId,
        userId: user.id,
        department: 'support',
        availabilityStatus: 'ONLINE',
        maxConcurrentConversations: 5,
      },
    });
    employeeId = employee.id;

    await prisma.projectMembership.create({
      data: { organizationId, projectId, userId: user.id },
    });

    // No availability windows: an employee with no configured schedule is
    // always on shift, which is what an org that has not set hours expects.

    // --- uploads a knowledge base ----------------------------------------
    const knowledgeBase = await prisma.knowledgeBase.create({
      data: { organizationId, projectId, name: 'Policies' },
    });

    const storageKey = `acceptance/${suffix}/refunds.txt`;
    await storage.put(
      storageKey,
      // Bilingual on purpose: this is an Arabic-first product, and the
      // bundled embedding provider is lexical, so an Arabic question
      // cannot match an English-only document. A real knowledge base for
      // this market carries both, and the fixture should too.
      Buffer.from(
        'Refund policy. A refund takes three business days after we receive the return.\n\n' +
          'سياسة الاسترجاع. يستغرق الاسترجاع ثلاثة أيام عمل بعد استلام المرتجع.\n\n' +
          'Exchanges are processed within five business days.',
        'utf8',
      ),
    );

    const document = await prisma.document.create({
      data: {
        organizationId,
        projectId,
        knowledgeBaseId: knowledgeBase.id,
        title: 'refund-policy.txt',
        sourceType: 'TEXT',
        storageKey,
        mimeType: 'text/plain',
        status: 'UPLOADED',
      },
    });

    const ingested = await ingestion.process(document.id);
    expect(ingested.status).toBe('READY');

    // --- creates an AI agent ---------------------------------------------
    const agent = await prisma.aIAgent.create({
      data: { organizationId, projectId, name: 'Support agent', isEnabled: true },
    });

    const version = await prisma.aIAgentVersion.create({
      data: {
        organizationId,
        projectId,
        agentId: agent.id,
        version: 1,
        systemInstructions:
          'You are the customer service agent. Answer only from the knowledge base. ' +
          'If the answer is not there, ask a clarifying question or hand over to a colleague.',
        provider: 'MOCK',
        enabledTools: ['search_knowledge_base', 'get_customer', 'request_human'],
      },
    });

    await prisma.aIAgent.update({
      where: { id: agent.id },
      data: { activeVersionId: version.id },
    });

    // --- sets the escalation rule from the plan: frustration ≥ 70 ---------
    await prisma.escalationRule.create({
      data: {
        organizationId,
        projectId,
        name: 'Frustration threshold',
        priority: 10,
        combinator: 'ALL',
        conditions: [{ signal: 'frustration', operator: 'gte', value: 70 }],
        department: 'support',
      },
    });

    // --- enables the mock channel ----------------------------------------
    const connection = await prisma.channelConnection.create({
      data: { organizationId, projectId, channel: 'MOCK', status: 'CONNECTED' },
    });
    connectionId = connection.id;
  }, 120_000);

  afterAll(async () => {
    if (!hasDatabase) return;
    await prisma.organization.delete({ where: { id: organizationId } });
    await disconnectPrisma();
  });

  it('creates the customer and conversation from the first inbound message', async () => {
    const result = await deliver('كم يستغرق الاسترجاع؟ How long does a refund take?');
    expect(result.status).toBe('processed');
    if (result.status !== 'processed') return;

    conversationId = result.conversationId;
    customerId = result.customerId;

    const conversation = await prisma.conversation.findUniqueOrThrow({
      where: { id: conversationId },
    });

    // The project has a live agent, so the conversation starts in AI mode.
    expect(conversation.mode).toBe('AI');
    expect(conversation.status).toBe('OPEN');
  });

  it('answers from the project knowledge base and records the run', async () => {
    const message = await prisma.message.findFirstOrThrow({
      where: { conversationId, authorType: 'CUSTOMER' },
      orderBy: { sentAt: 'desc' },
    });

    const result = await orchestrator.run({
      organizationId,
      projectId,
      conversationId,
      messageId: message.id,
    });

    expect(result.status).toBe('replied');
    if (result.status !== 'replied') return;

    const reply = await prisma.message.findUniqueOrThrow({ where: { id: result.messageId } });
    expect(reply.authorType).toBe('AI');
    expect(reply.body.toLowerCase()).toContain('three business days');

    // The run is traceable to the version, the citations and the cost.
    const run = await prisma.aIRun.findUniqueOrThrow({
      where: { id: result.runId },
      include: { retrievals: true, usage: true, steps: true },
    });

    expect(run.decision).toBe('REPLY');
    expect(run.retrievals.length).toBeGreaterThan(0);
    expect(run.retrievals[0]!.documentTitle).toBe('refund-policy.txt');
    expect(run.usage).not.toBeNull();
    expect(run.steps.map((step) => step.kind)).toEqual(
      expect.arrayContaining(['CONTEXT', 'RETRIEVAL', 'GENERATION', 'DECISION']),
    );
  });

  it('escalates when the customer gets frustrated past the configured threshold', async () => {
    await deliver(
      'This is unacceptable! Third time I ask and nobody has helped. Terrible service — I want a manager now!',
    );

    const message = await prisma.message.findFirstOrThrow({
      where: { conversationId, authorType: 'CUSTOMER' },
      orderBy: { sentAt: 'desc' },
    });

    const scored = await escalationEngine.scoreTurn({
      organizationId,
      projectId,
      conversationId,
      messageId: message.id,
    });

    expect(scored.status).toBe('escalated');

    const score = await prisma.conversationScore.findFirstOrThrow({
      where: { conversationId },
      orderBy: { createdAt: 'desc' },
    });
    expect(score.frustration).toBeGreaterThanOrEqual(70);

    const escalation = await prisma.escalation.findFirstOrThrow({
      where: { conversationId },
      orderBy: { createdAt: 'desc' },
    });

    // The employee inheriting it gets a reason and a summary (plan §20.7).
    expect(escalation.reason).toContain('frustration');
    expect(escalation.summary).toBeTruthy();

    const conversation = await prisma.conversation.findUniqueOrThrow({
      where: { id: conversationId },
    });
    expect(conversation.mode).toBe('HUMAN');
    expect(conversation.status).toBe('PENDING');
  });

  it('stops the AI from replying once the conversation is human-handled', async () => {
    const before = await prisma.message.count({ where: { conversationId, authorType: 'AI' } });

    const message = await prisma.message.findFirstOrThrow({
      where: { conversationId, authorType: 'CUSTOMER' },
      orderBy: { sentAt: 'desc' },
    });

    const result = await orchestrator.run({
      organizationId,
      projectId,
      conversationId,
      messageId: message.id,
    });

    // The hard rule from plan §10: once HUMAN, the AI does not reply.
    expect(result.status).toBe('skipped');

    const after = await prisma.message.count({ where: { conversationId, authorType: 'AI' } });
    expect(after).toBe(before);
  });

  it('routes the escalation to an available employee', async () => {
    const escalation = await prisma.escalation.findFirstOrThrow({
      where: { conversationId },
      orderBy: { createdAt: 'desc' },
    });

    const result = await routing.route({
      organizationId,
      projectId,
      conversationId,
      escalationId: escalation.id,
    });

    expect(result.status).toBe('assigned');
    if (result.status !== 'assigned') return;
    expect(result.employeeId).toBe(employeeId);

    const conversation = await prisma.conversation.findUniqueOrThrow({
      where: { id: conversationId },
    });
    expect(conversation.assignedEmployeeId).toBe(employeeId);

    const assigned = await prisma.escalation.findUniqueOrThrow({ where: { id: escalation.id } });
    expect(assigned.status).toBe('ASSIGNED');

    // Workload is recounted, not incremented (see packages/routing).
    const employee = await prisma.employee.findUniqueOrThrow({ where: { id: employeeId } });
    expect(employee.activeConversationCount).toBe(1);
  });

  it('lets the employee reply, the customer answer, and the employee resolve', async () => {
    await prisma.message.create({
      data: {
        organizationId,
        projectId,
        conversationId,
        channel: 'MOCK',
        direction: 'OUTBOUND',
        authorType: 'EMPLOYEE',
        authorUserId: employeeUserId,
        body: 'I am sorry about this. I have refunded the order myself — it clears in three days.',
        deliveryStatus: 'SENT',
      },
    });

    await deliver('Thank you, that resolves it.');

    await prisma.conversation.update({
      where: { id: conversationId },
      data: { status: 'RESOLVED', resolvedAt: new Date() },
    });

    const conversation = await prisma.conversation.findUniqueOrThrow({
      where: { id: conversationId },
      include: { messages: true },
    });

    expect(conversation.status).toBe('RESOLVED');
    expect(conversation.messages.some((m) => m.authorType === 'AI')).toBe(true);
    expect(conversation.messages.some((m) => m.authorType === 'EMPLOYEE')).toBe(true);
  });

  it('leaves an observable trail across the whole scenario', async () => {
    // Give the timeline recorder a turn to flush.
    await new Promise((resolve) => setTimeout(resolve, 300));

    const timeline = await prisma.conversationEvent.findMany({
      where: { conversationId },
      orderBy: { occurredAt: 'asc' },
    });

    const types = timeline.map((event) => event.type);
    expect(types).toContain('CONVERSATION_CREATED');
    expect(types).toContain('MESSAGE_RECEIVED');
    expect(types).toContain('SCORE_UPDATED');
    expect(types).toContain('ESCALATED');
    expect(types).toContain('TAKEN_OVER');
    expect(types).toContain('ASSIGNED');

    // Message content never lands on the timeline.
    expect(JSON.stringify(timeline)).not.toContain('Terrible service');

    expect(published.map((event) => event.type)).toEqual(
      expect.arrayContaining([
        'conversation.created',
        'message.created',
        'conversation.scored',
        'conversation.escalated',
        'conversation.mode-changed',
        'conversation.assigned',
      ]),
    );
  });

  it('reflects the whole scenario in analytics', async () => {
    const [conversations, runs, usage, scores] = await Promise.all([
      prisma.conversation.count({ where: { projectId } }),
      prisma.aIRun.count({ where: { projectId } }),
      prisma.aIUsage.aggregate({ where: { projectId }, _sum: { inputTokens: true } }),
      prisma.conversationScore.count({ where: { projectId } }),
    ]);

    expect(conversations).toBe(1);
    expect(runs).toBeGreaterThan(0);
    expect(usage._sum.inputTokens ?? 0).toBeGreaterThan(0);
    expect(scores).toBeGreaterThan(0);

    const customer = await prisma.customer.findUniqueOrThrow({ where: { id: customerId } });
    expect(customer.displayName).toBe('نورة السالم');
  });
});

describe.skipIf(hasDatabase)('plan §17 acceptance scenario (skipped)', () => {
  it('needs PostgreSQL with pgvector — see docs/testing.md', () => {
    expect(hasDatabase).toBe(false);
  });
});
