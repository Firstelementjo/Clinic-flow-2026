import { isWithinWorkingHours, type AvailabilityWindow } from './working-hours';

/**
 * Candidate selection (plan §10).
 *
 * The pipeline is deterministic and stated in one place:
 *
 * ```
 * intent → department → required skill → availability status
 *   → working hours → workload headroom → strategy
 * ```
 *
 * Each stage is a filter with a name, so an unassignable escalation can
 * say *which* stage emptied the list. "No one is available" and "everyone
 * is at capacity" are different problems for an ops manager, and a routing
 * engine that cannot tell them apart is not much use at 9pm.
 */

export interface RoutingCandidate {
  employeeId: string;
  userId: string;
  fullName: string;
  department: string | null;
  availabilityStatus: 'ONLINE' | 'OFFLINE' | 'BUSY' | 'BREAK' | 'MEAL' | 'TRAINING' | 'MEETING';
  activeConversationCount: number;
  maxConcurrentConversations: number;
  skills: { skill: string; level: number }[];
  windows: AvailabilityWindow[];
}

export interface RoutingRequirements {
  department?: string | null;
  requiredSkill?: string | null;
  strategy: 'LEAST_LOADED' | 'ROUND_ROBIN';
}

export type RoutingStage =
  | 'MEMBERSHIP'
  | 'DEPARTMENT'
  | 'SKILL'
  | 'STATUS'
  | 'WORKING_HOURS'
  | 'WORKLOAD';

export interface RoutingOutcome {
  /** Null when nobody qualifies — the caller queues it instead. */
  candidate: RoutingCandidate | null;
  /** The stage that emptied the candidate list, when one did. */
  blockedAt: RoutingStage | null;
  considered: number;
  eligible: number;
}

export interface RoutingStrategyImpl {
  readonly name: string;
  pick(candidates: RoutingCandidate[]): RoutingCandidate | null;
}

/**
 * Ships first (plan §10). Fewest active conversations wins; ties break on
 * skill level, then on id so the same input always produces the same
 * assignment — a router that shuffles under a tie is untestable.
 */
export class LeastLoadedStrategy implements RoutingStrategyImpl {
  readonly name = 'LEAST_LOADED';

  constructor(private readonly requiredSkill?: string | null) {}

  pick(candidates: RoutingCandidate[]): RoutingCandidate | null {
    if (candidates.length === 0) return null;

    return [...candidates].sort((a, b) => {
      if (a.activeConversationCount !== b.activeConversationCount) {
        return a.activeConversationCount - b.activeConversationCount;
      }
      const levelDiff = skillLevel(b, this.requiredSkill) - skillLevel(a, this.requiredSkill);
      if (levelDiff !== 0) return levelDiff;
      return a.employeeId.localeCompare(b.employeeId);
    })[0]!;
  }
}

/**
 * Declared so the pluggable interface is real rather than aspirational.
 * Selecting it currently routes least-loaded — see docs/routing.md; it
 * needs a per-project cursor to be genuinely round-robin, and pretending
 * otherwise would be worse than saying so.
 */
export class RoundRobinStrategy implements RoutingStrategyImpl {
  readonly name = 'ROUND_ROBIN';

  pick(candidates: RoutingCandidate[]): RoutingCandidate | null {
    return new LeastLoadedStrategy().pick(candidates);
  }
}

export function createStrategy(
  strategy: RoutingRequirements['strategy'],
  requiredSkill?: string | null,
): RoutingStrategyImpl {
  return strategy === 'ROUND_ROBIN'
    ? new RoundRobinStrategy()
    : new LeastLoadedStrategy(requiredSkill);
}

/**
 * Runs the filter pipeline. Pure, so the whole routing decision is
 * testable without a database or a clock.
 */
export function selectAssignee(
  candidates: RoutingCandidate[],
  requirements: RoutingRequirements,
  now: Date = new Date(),
): RoutingOutcome {
  const considered = candidates.length;
  if (considered === 0) {
    return { candidate: null, blockedAt: 'MEMBERSHIP', considered, eligible: 0 };
  }

  let pool = candidates;
  let blockedAt: RoutingStage | null = null;

  const stage = (name: RoutingStage, next: RoutingCandidate[]): boolean => {
    if (next.length === 0) {
      blockedAt = name;
      return false;
    }
    pool = next;
    return true;
  };

  const byDepartment = requirements.department
    ? pool.filter((candidate) => candidate.department === requirements.department)
    : pool;
  if (!stage('DEPARTMENT', byDepartment)) {
    return { candidate: null, blockedAt, considered, eligible: 0 };
  }

  const bySkill = requirements.requiredSkill
    ? pool.filter((candidate) =>
        candidate.skills.some((entry) => entry.skill === requirements.requiredSkill),
      )
    : pool;
  if (!stage('SKILL', bySkill)) {
    return { candidate: null, blockedAt, considered, eligible: 0 };
  }

  // BUSY is a person mid-task, not one who has gone home: they stay
  // eligible if they have headroom, and the workload filter decides.
  // BREAK, MEAL, TRAINING and MEETING are all "not at the desk" — the
  // distinction between them is for reporting, not for routing.
  const byStatus = pool.filter(
    (candidate) =>
      candidate.availabilityStatus === 'ONLINE' || candidate.availabilityStatus === 'BUSY',
  );
  if (!stage('STATUS', byStatus)) {
    return { candidate: null, blockedAt, considered, eligible: 0 };
  }

  const byHours = pool.filter((candidate) => isWithinWorkingHours(candidate.windows, now));
  if (!stage('WORKING_HOURS', byHours)) {
    return { candidate: null, blockedAt, considered, eligible: 0 };
  }

  const byWorkload = pool.filter(
    (candidate) => candidate.activeConversationCount < candidate.maxConcurrentConversations,
  );
  if (!stage('WORKLOAD', byWorkload)) {
    return { candidate: null, blockedAt, considered, eligible: 0 };
  }

  const chosen = createStrategy(requirements.strategy, requirements.requiredSkill).pick(pool);

  return { candidate: chosen, blockedAt: null, considered, eligible: pool.length };
}

function skillLevel(candidate: RoutingCandidate, skill?: string | null): number {
  if (!skill) return 0;
  return candidate.skills.find((entry) => entry.skill === skill)?.level ?? 0;
}
