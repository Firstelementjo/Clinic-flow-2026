/**
 * Navigation helpers for CX ID and ticket number clicks.
 *
 * In the main window, these navigate via React Router.
 * In the popup window (inbox pop-out), these open the target in the
 * main browser window behind the popup, leaving the popup untouched.
 */

/** Returns true if the current window is the inbox popup. */
export function isPopup(): boolean {
  try {
    return window.name === 'firstelement-inbox' || window.location.pathname === '/inbox/pop';
  } catch {
    return false;
  }
}

/**
 * Navigate to a customer's CX profile in the Customer workspace.
 * - Main window: navigates via the provided callback
 * - Popup window: opens the URL in the opener/main window
 */
export function navigateToCxProfile(cxId: string, navigate?: (path: string) => void) {
  const url = `/app/customers?cxId=${encodeURIComponent(cxId)}`;
  if (isPopup() && window.opener) {
    window.opener.location.href = url;
  } else if (navigate) {
    navigate(url);
  }
}

/**
 * Navigate to a specific ticket in the Customer workspace.
 * - Main window: navigates via the provided callback
 * - Popup window: opens the URL in the opener/main window
 */
export function navigateToTicket(
  ticketNumber: string,
  navigate?: (path: string) => void,
  cxId?: string,
) {
  // Strip the leading # if present for the URL param
  const clean = ticketNumber.replace(/^#/, '');
  let url = `/app/customers?ticket=${encodeURIComponent(clean)}`;
  if (cxId) {
    const cleanCxId = cxId.replace(/^#/, '');
    url += `&cxId=${encodeURIComponent(cleanCxId)}`;
  }
  if (isPopup() && window.opener) {
    window.opener.location.href = url;
  } else if (navigate) {
    navigate(url);
  }
}
