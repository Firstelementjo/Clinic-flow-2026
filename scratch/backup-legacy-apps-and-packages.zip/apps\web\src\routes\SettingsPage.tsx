import { useQuery } from '@tanstack/react-query';
import { Panel, Spinner, StatusChip, useDirection } from '@firstelement/ui';
import type { SessionUser } from '@firstelement/shared';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import { useT } from '../lib/i18n';
import { useSession } from '../lib/session';

interface SystemHealth {
  status: 'ok' | 'degraded';
  environment: string;
  checks: {
    database: { status: string; latencyMs: number | null };
    redis: { status: string; latencyMs: number | null };
  };
  queues: { name: string; waiting: number; active: number; failed: number; delayed: number }[];
  providers: {
    ai: { configured: string[]; missing: string[] };
    embeddings: string;
    channels: { channel: string; connected: number; error: number }[];
  };
  stalledDocuments: number;
}

interface AuditEntry {
  id: string;
  action: string;
  actorType: string;
  actorName: string | null;
  resourceType: string;
  resourceId: string | null;
  createdAt: string;
}

/**
 * Administration: system health and the audit trail.
 *
 * Both are admin-only. The audit view is read-only by design — there is
 * no endpoint that edits or deletes an entry, because a trail somebody
 * can quietly rewrite is not one (plan §12).
 */
export function SettingsPage() {
  const t = useT();
  const { locale } = useDirection();
  const session = useSession();
  const isAdmin = (session.data as SessionUser | null)?.role === 'ADMIN';

  const health = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.get<SystemHealth>('/system/health'),
    enabled: isAdmin,
    refetchInterval: 30_000,
  });

  const audit = useQuery({
    queryKey: ['audit-logs'],
    queryFn: () => api.get<{ items: AuditEntry[] }>('/audit-logs'),
    enabled: isAdmin,
  });

  if (!isAdmin) {
    return (
      <Panel eyebrow={t('system.eyebrow')} title={t('nav.settings')}>
        <p className="text-sm text-slate">{t('common.error')}</p>
      </Panel>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <Panel
        eyebrow={t('system.eyebrow')}
        title={t('system.title')}
        actions={
          health.data && (
            <StatusChip tone={health.data.status === 'ok' ? 'human' : 'danger'}>
              {health.data.status}
            </StatusChip>
          )
        }
      >
        {health.isPending ? (
          <Spinner label={t('common.loading')} />
        ) : health.isError || !health.data ? (
          <p className="text-sm text-slate">{t('common.error')}</p>
        ) : (
          <div className="flex flex-col gap-4">
            <dl className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              <Fact
                label={t('system.database')}
                value={`${health.data.checks.database.status}${
                  health.data.checks.database.latencyMs !== null
                    ? ` · ${health.data.checks.database.latencyMs}ms`
                    : ''
                }`}
                tone={health.data.checks.database.status === 'up' ? 'ok' : 'bad'}
              />
              <Fact
                label={t('system.redis')}
                value={health.data.checks.redis.status}
                tone={health.data.checks.redis.status === 'down' ? 'bad' : 'ok'}
              />
              <Fact label="env" value={health.data.environment} tone="ok" />
              <Fact
                label={t('system.stalled')}
                value={String(health.data.stalledDocuments)}
                tone={health.data.stalledDocuments > 0 ? 'bad' : 'ok'}
              />
            </dl>

            {health.data.queues.length > 0 && (
              <div>
                <p className="fe-eyebrow mb-1.5">{t('system.queues')}</p>
                <ul className="flex flex-col gap-1">
                  {health.data.queues.map((queue) => (
                    <li key={queue.name} className="flex items-center gap-3 text-xs">
                      <span className="fe-mono w-44 text-slate" dir="ltr">
                        {queue.name}
                      </span>
                      {/* Waiting climbing while active sits at zero is the
                          earliest sign the worker has stopped. */}
                      <span className="fe-mono text-slate" dir="ltr">
                        {queue.waiting} {t('system.waiting')}
                      </span>
                      {queue.failed > 0 && (
                        <span className="fe-mono text-danger" dir="ltr">
                          {queue.failed} {t('system.failed')}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div>
              <p className="fe-eyebrow mb-1.5">{t('system.providers')}</p>
              <p className="text-xs text-slate">
                AI: {health.data.providers.ai.configured.join(', ')} · embeddings:{' '}
                {health.data.providers.embeddings}
              </p>
              <ul className="mt-1 flex flex-wrap gap-2">
                {health.data.providers.channels.map((channel) => (
                  <li key={channel.channel}>
                    <StatusChip tone={channel.error > 0 ? 'danger' : 'neutral'}>
                      {channel.channel} {channel.connected}
                    </StatusChip>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </Panel>

      <Panel eyebrow={t('system.eyebrow')} title={t('audit.title')} flush>
        {audit.isPending ? (
          <div className="p-4">
            <Spinner label={t('common.loading')} />
          </div>
        ) : !audit.data || audit.data.items.length === 0 ? (
          <p className="px-4 py-3 text-sm text-slate">{t('audit.empty')}</p>
        ) : (
          <ul className="divide-y divide-hairline">
            {audit.data.items.map((entry) => (
              <li key={entry.id} className="flex flex-wrap items-center gap-3 px-4 py-2 text-xs">
                <span className="fe-mono w-56 text-ink" dir="ltr">
                  {entry.action}
                </span>
                <span className="text-slate">{entry.actorName ?? entry.actorType}</span>
                <span className="fe-eyebrow">{entry.resourceType}</span>
                <span className="fe-mono ms-auto text-slate-soft" dir="ltr">
                  {formatDate(entry.createdAt, locale)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}

function Fact({ label, value, tone }: { label: string; value: string; tone: 'ok' | 'bad' }) {
  return (
    <div>
      <dt className="fe-eyebrow">{label}</dt>
      <dd className={['fe-mono text-sm', tone === 'bad' ? 'text-danger' : 'text-ink'].join(' ')} dir="ltr">
        {value}
      </dd>
    </div>
  );
}
