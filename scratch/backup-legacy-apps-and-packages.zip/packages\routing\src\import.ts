/**
 * Employee import (plan §10): upload → preview → map columns → validate →
 * show errors → confirm → import.
 *
 * The rule that shapes this file: **never blindly import malformed rows.**
 * A silent skip means an ops manager believes 40 agents exist when 37 do,
 * and discovers the gap when escalations start queueing. So every row is
 * either valid or carries a row-numbered reason, and the admin sees both
 * before anything is written.
 */

export interface ImportRow {
  /** 1-based row number as it appears in the file, header excluded. */
  rowNumber: number;
  values: Record<string, string>;
}

export interface ParsedSheet {
  headers: string[];
  rows: ImportRow[];
}

export interface EmployeeImportRecord {
  email: string;
  fullName: string;
  department?: string;
  maxConcurrentConversations?: number;
  skills: string[];
}

export interface ValidatedRow {
  rowNumber: number;
  record: EmployeeImportRecord | null;
  errors: string[];
  /** Set when the email already exists in this organization. */
  isDuplicate?: boolean;
}

export interface ImportPreview {
  headers: string[];
  totalRows: number;
  validRows: ValidatedRow[];
  invalidRows: ValidatedRow[];
  duplicateRows: ValidatedRow[];
}

/** Column aliases, so a file exported from a payroll system usually maps itself. */
export const COLUMN_ALIASES: Record<keyof EmployeeImportRecord, string[]> = {
  email: ['email', 'e-mail', 'mail', 'البريد', 'الايميل', 'البريد الإلكتروني'],
  fullName: ['fullname', 'full name', 'name', 'employee', 'الاسم', 'الاسم الكامل'],
  department: ['department', 'dept', 'team', 'القسم', 'الفريق'],
  maxConcurrentConversations: ['maxconversations', 'max conversations', 'capacity', 'limit', 'الحد'],
  skills: ['skills', 'skill', 'tags', 'المهارات'],
};

export type ColumnMapping = Partial<Record<keyof EmployeeImportRecord, string>>;

const MAX_IMPORT_ROWS = 5_000;

export function parseCsv(content: string): ParsedSheet {
  const lines = content.split(/\r?\n/).filter((line) => line.trim().length > 0);
  if (lines.length === 0) return { headers: [], rows: [] };

  const headers = splitCsvLine(lines[0]!);
  const rows = lines.slice(1, MAX_IMPORT_ROWS + 1).map((line, index) => {
    const values = splitCsvLine(line);
    return {
      rowNumber: index + 1,
      values: Object.fromEntries(headers.map((header, i) => [header, values[i] ?? ''])),
    };
  });

  return { headers, rows };
}

/** XLSX via exceljs, loaded on demand so CSV-only deployments do not pay for it. */
export async function parseXlsx(buffer: Buffer): Promise<ParsedSheet> {
  const ExcelJS = await import('exceljs');
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer as unknown as ArrayBuffer);

  const sheet = workbook.worksheets[0];
  if (!sheet) return { headers: [], rows: [] };

  const headers: string[] = [];
  sheet.getRow(1).eachCell((cell, columnNumber) => {
    headers[columnNumber - 1] = String(cell.value ?? '').trim();
  });

  const rows: ImportRow[] = [];
  sheet.eachRow((row, rowNumber) => {
    if (rowNumber === 1 || rows.length >= MAX_IMPORT_ROWS) return;

    const values: Record<string, string> = {};
    headers.forEach((header, index) => {
      const cell = row.getCell(index + 1).value;
      values[header] = cell === null || cell === undefined ? '' : String(cell).trim();
    });

    rows.push({ rowNumber: rowNumber - 1, values });
  });

  return { headers: headers.filter(Boolean), rows };
}

/** Best-effort column mapping the admin can then correct. */
export function suggestMapping(headers: string[]): ColumnMapping {
  const mapping: ColumnMapping = {};

  for (const [field, aliases] of Object.entries(COLUMN_ALIASES) as [
    keyof EmployeeImportRecord,
    string[],
  ][]) {
    const match = headers.find((header) =>
      aliases.includes(header.trim().toLowerCase().replace(/[_-]/g, ' ')),
    );
    if (match) mapping[field] = match;
  }

  return mapping;
}

export function validateRows(
  sheet: ParsedSheet,
  mapping: ColumnMapping,
  existingEmails: Set<string> = new Set(),
): ImportPreview {
  const seen = new Set<string>();
  const validated = sheet.rows.map((row) => validateRow(row, mapping, existingEmails, seen));

  return {
    headers: sheet.headers,
    totalRows: sheet.rows.length,
    validRows: validated.filter((row) => row.errors.length === 0 && !row.isDuplicate),
    invalidRows: validated.filter((row) => row.errors.length > 0),
    duplicateRows: validated.filter((row) => row.isDuplicate && row.errors.length === 0),
  };
}

function validateRow(
  row: ImportRow,
  mapping: ColumnMapping,
  existingEmails: Set<string>,
  seen: Set<string>,
): ValidatedRow {
  const errors: string[] = [];
  const read = (field: keyof EmployeeImportRecord): string => {
    const column = mapping[field];
    return column ? (row.values[column] ?? '').trim() : '';
  };

  const email = read('email').toLowerCase();
  const fullName = read('fullName');

  if (!email) errors.push('Email is required');
  else if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) errors.push(`"${email}" is not a valid email`);

  if (!fullName) errors.push('Full name is required');
  else if (fullName.length > 120) errors.push('Full name is longer than 120 characters');

  const rawCapacity = read('maxConcurrentConversations');
  let maxConcurrentConversations: number | undefined;
  if (rawCapacity) {
    const parsed = Number(rawCapacity);
    if (!Number.isInteger(parsed) || parsed < 1 || parsed > 200) {
      errors.push(`Capacity "${rawCapacity}" must be a whole number between 1 and 200`);
    } else {
      maxConcurrentConversations = parsed;
    }
  }

  const skills = read('skills')
    .split(/[;,|]/)
    .map((skill) => skill.trim())
    .filter(Boolean)
    .slice(0, 20);

  if (errors.length > 0) {
    return { rowNumber: row.rowNumber, record: null, errors };
  }

  // Duplicates are reported, not merged and not dropped: a file listing
  // the same person twice usually means two different intended records.
  const isDuplicate = existingEmails.has(email) || seen.has(email);
  seen.add(email);

  return {
    rowNumber: row.rowNumber,
    record: {
      email,
      fullName,
      department: read('department') || undefined,
      maxConcurrentConversations,
      skills,
    },
    errors: [],
    isDuplicate,
  };
}

function splitCsvLine(line: string): string[] {
  const values: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      values.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }

  values.push(current.trim());
  return values;
}
