import { describe, expect, it } from 'vitest';
import { LeastLoadedStrategy, selectAssignee, type RoutingCandidate } from './strategy';

const NOW = new Date('2026-08-16T06:00:00Z'); // Sunday 09:00 in Riyadh

function candidate(overrides: Partial<RoutingCandidate> = {}): RoutingCandidate {
  return {
    employeeId: 'e1',
    userId: 'u1',
    fullName: 'Layla',
    department: null,
    availabilityStatus: 'ONLINE',
    activeConversationCount: 0,
    maxConcurrentConversations: 5,
    skills: [],
    windows: [],
    ...overrides,
  };
}

const anyRequirements = { strategy: 'LEAST_LOADED' } as const;

describe('the filter pipeline', () => {
  it('reports no roster when nobody is a member of the project', () => {
    const outcome = selectAssignee([], anyRequirements, NOW);
    expect(outcome.candidate).toBeNull();
    expect(outcome.blockedAt).toBe('MEMBERSHIP');
  });

  it('filters by department when the rule requires one', () => {
    const pool = [
      candidate({ employeeId: 'a', department: 'billing' }),
      candidate({ employeeId: 'b', department: 'delivery' }),
    ];

    expect(selectAssignee(pool, { department: 'billing', strategy: 'LEAST_LOADED' }, NOW).candidate?.employeeId).toBe('a');
    expect(selectAssignee(pool, { department: 'legal', strategy: 'LEAST_LOADED' }, NOW).blockedAt).toBe('DEPARTMENT');
  });

  it('filters by required skill', () => {
    const pool = [
      candidate({ employeeId: 'a', skills: [{ skill: 'refunds', level: 3 }] }),
      candidate({ employeeId: 'b', skills: [] }),
    ];

    const outcome = selectAssignee(pool, { requiredSkill: 'refunds', strategy: 'LEAST_LOADED' }, NOW);
    expect(outcome.candidate?.employeeId).toBe('a');
  });

  it('excludes people on a break, in a meeting, or offline', () => {
    const pool = [
      candidate({ employeeId: 'a', availabilityStatus: 'BREAK' }),
      candidate({ employeeId: 'b', availabilityStatus: 'OFFLINE' }),
    ];
    expect(selectAssignee(pool, anyRequirements, NOW).blockedAt).toBe('STATUS');
  });

  it('keeps BUSY people eligible — busy is mid-task, not gone home', () => {
    const pool = [candidate({ availabilityStatus: 'BUSY', activeConversationCount: 1 })];
    expect(selectAssignee(pool, anyRequirements, NOW).candidate).not.toBeNull();
  });

  it('excludes people outside their working hours', () => {
    const pool = [
      candidate({
        windows: [{ dayOfWeek: 1, startMinute: 480, endMinute: 1020, timezone: 'Asia/Riyadh' }],
      }),
    ];
    expect(selectAssignee(pool, anyRequirements, NOW).blockedAt).toBe('WORKING_HOURS');
  });

  it('excludes people already at their conversation limit', () => {
    const pool = [candidate({ activeConversationCount: 5, maxConcurrentConversations: 5 })];
    expect(selectAssignee(pool, anyRequirements, NOW).blockedAt).toBe('WORKLOAD');
  });

  it('names the stage that emptied the list, because the fixes differ', () => {
    // "Nobody is on shift" and "everyone is at capacity" are different
    // problems for an ops manager at 9pm.
    const offShift = [
      candidate({ windows: [{ dayOfWeek: 3, startMinute: 0, endMinute: 60, timezone: 'Asia/Riyadh' }] }),
    ];
    const atCapacity = [candidate({ activeConversationCount: 9, maxConcurrentConversations: 9 })];

    expect(selectAssignee(offShift, anyRequirements, NOW).blockedAt).toBe('WORKING_HOURS');
    expect(selectAssignee(atCapacity, anyRequirements, NOW).blockedAt).toBe('WORKLOAD');
  });
});

describe('least-loaded selection', () => {
  it('picks the person with the fewest active conversations', () => {
    const pool = [
      candidate({ employeeId: 'busy', activeConversationCount: 4 }),
      candidate({ employeeId: 'free', activeConversationCount: 1 }),
      candidate({ employeeId: 'mid', activeConversationCount: 2 }),
    ];

    expect(selectAssignee(pool, anyRequirements, NOW).candidate?.employeeId).toBe('free');
  });

  it('breaks a load tie on skill level when a skill was required', () => {
    const pool = [
      candidate({ employeeId: 'junior', skills: [{ skill: 'refunds', level: 2 }] }),
      candidate({ employeeId: 'senior', skills: [{ skill: 'refunds', level: 5 }] }),
    ];

    const outcome = selectAssignee(pool, { requiredSkill: 'refunds', strategy: 'LEAST_LOADED' }, NOW);
    expect(outcome.candidate?.employeeId).toBe('senior');
  });

  it('is deterministic under a complete tie, so the same input routes the same way', () => {
    const pool = [candidate({ employeeId: 'bbb' }), candidate({ employeeId: 'aaa' })];

    expect(selectAssignee(pool, anyRequirements, NOW).candidate?.employeeId).toBe('aaa');
    expect(selectAssignee([...pool].reverse(), anyRequirements, NOW).candidate?.employeeId).toBe('aaa');
  });

  it('returns null for an empty pool rather than throwing', () => {
    expect(new LeastLoadedStrategy().pick([])).toBeNull();
  });
});

describe('outcome reporting', () => {
  it('reports how many were considered and how many survived', () => {
    const pool = [
      candidate({ employeeId: 'a', activeConversationCount: 0 }),
      candidate({ employeeId: 'b', activeConversationCount: 5, maxConcurrentConversations: 5 }),
      candidate({ employeeId: 'c', availabilityStatus: 'OFFLINE' }),
    ];

    const outcome = selectAssignee(pool, anyRequirements, NOW);
    expect(outcome.considered).toBe(3);
    expect(outcome.eligible).toBe(1);
    expect(outcome.candidate?.employeeId).toBe('a');
  });
});
