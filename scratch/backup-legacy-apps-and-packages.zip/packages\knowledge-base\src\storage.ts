import { randomUUID } from 'node:crypto';
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { dirname, join, resolve, sep } from 'node:path';

/**
 * Object storage for uploaded documents.
 *
 * Keys are generated here, never taken from the client: a filename is
 * user input, and user input on a filesystem path is a directory-traversal
 * bug waiting to happen. The original name is kept in the database as a
 * label, not as a location.
 */
export interface StorageDriver {
  put(key: string, data: Buffer): Promise<void>;
  get(key: string): Promise<Buffer>;
  delete(key: string): Promise<void>;
}

/** `projects/<projectId>/documents/<uuid>` — flat, opaque, and tenant-tagged. */
export function buildStorageKey(projectId: string): string {
  return `projects/${projectId}/documents/${randomUUID()}`;
}

export class LocalStorageDriver implements StorageDriver {
  constructor(private readonly root: string) {}

  async put(key: string, data: Buffer): Promise<void> {
    const path = this.resolveKey(key);
    await mkdir(dirname(path), { recursive: true });
    await writeFile(path, data);
  }

  async get(key: string): Promise<Buffer> {
    return readFile(this.resolveKey(key));
  }

  async delete(key: string): Promise<void> {
    await rm(this.resolveKey(key), { force: true });
  }

  /**
   * Second line of defence behind generated keys: even a key that somehow
   * contains `..` cannot escape the storage root.
   */
  private resolveKey(key: string): string {
    const root = resolve(this.root);
    const path = resolve(join(root, key));
    if (path !== root && !path.startsWith(root + sep)) {
      throw new Error('Refusing to access a path outside the storage root');
    }
    return path;
  }
}
