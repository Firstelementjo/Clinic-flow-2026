import { describe, expect, it } from 'vitest';
import { MockEmbeddingProvider } from './mock.provider';
import { EMBEDDING_DIMENSIONS, l2Normalize } from './types';

const provider = new MockEmbeddingProvider();

function cosine(a: number[], b: number[]): number {
  let sum = 0;
  for (let i = 0; i < a.length; i += 1) sum += (a[i] ?? 0) * (b[i] ?? 0);
  return sum;
}

describe('mock embeddings', () => {
  it('returns one vector per input, at the width of the pgvector column', async () => {
    const vectors = await provider.embed(['one', 'two', 'three']);
    expect(vectors).toHaveLength(3);
    for (const vector of vectors) expect(vector).toHaveLength(EMBEDDING_DIMENSIONS);
  });

  it('is deterministic — the same text always embeds identically', async () => {
    const [first] = await provider.embed(['refund policy']);
    const [second] = await provider.embed(['refund policy']);
    expect(first).toEqual(second);
  });

  it('returns unit vectors, which is what cosine distance assumes', async () => {
    const [vector] = await provider.embed(['some text here']);
    expect(cosine(vector!, vector!)).toBeCloseTo(1, 5);
  });

  it('places texts that share vocabulary closer than unrelated ones', async () => {
    // This is what makes retrieval genuinely testable without an API key:
    // a refund query must pull the refund document, not whatever sorts first.
    const [query, related, unrelated] = await provider.embed([
      'how long does a refund take',
      'a refund takes three business days',
      'our office in riyadh opens at nine',
    ]);

    expect(cosine(query!, related!)).toBeGreaterThan(cosine(query!, unrelated!));
  });

  it('does the same for Arabic, which is this product primary language', async () => {
    const [query, related, unrelated] = await provider.embed([
      'كم يستغرق الاسترجاع',
      'يستغرق الاسترجاع ثلاثة أيام عمل',
      'يفتح مكتبنا في الرياض الساعة التاسعة',
    ]);

    expect(cosine(query!, related!)).toBeGreaterThan(cosine(query!, unrelated!));
  });

  it('still produces a usable vector for empty text instead of NaN scores', async () => {
    const [vector] = await provider.embed(['']);
    expect(vector).toHaveLength(EMBEDDING_DIMENSIONS);
    expect(vector!.some((value) => Number.isNaN(value))).toBe(false);
    expect(cosine(vector!, vector!)).toBeCloseTo(1, 5);
  });
});

describe('l2Normalize', () => {
  it('leaves a zero vector alone rather than dividing by zero', () => {
    expect(l2Normalize([0, 0, 0])).toEqual([0, 0, 0]);
  });

  it('scales to unit length', () => {
    const normalized = l2Normalize([3, 4]);
    expect(normalized[0]).toBeCloseTo(0.6, 6);
    expect(normalized[1]).toBeCloseTo(0.8, 6);
  });
});
