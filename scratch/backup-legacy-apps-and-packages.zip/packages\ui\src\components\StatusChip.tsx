import clsx from 'clsx';
import type { ReactNode } from 'react';

/**
 * The product's colour legend, in one component.
 *
 * AI is indigo, human is teal, escalation is burnt orange — everywhere,
 * without exception, so the legend only has to be learned once (see
 * docs/design-system.md). Chips carry a text label as well as colour:
 * colour alone is not an accessible status.
 */
export type StatusTone = 'ai' | 'human' | 'escalated' | 'neutral' | 'danger' | 'default' | 'ok' | 'warn' | 'bad' | 'blue';

const TONES: Record<StatusTone, string> = {
  ai: 'bg-[var(--fe-agent-wash)] text-[var(--fe-agent)]',
  human: 'bg-[var(--fe-signal-wash)] text-[var(--fe-signal)]',
  escalated: 'bg-[var(--fe-warning-wash)] text-[var(--fe-warning)]',
  neutral: 'bg-[var(--fe-mist-deep)] text-[var(--fe-slate)] border border-[var(--fe-hairline)]',
  danger: 'bg-[var(--fe-danger-wash)] text-[var(--fe-danger)]',
  default: 'bg-[var(--fe-signal-wash)] text-[var(--fe-signal)]',
  ok: 'bg-[var(--fe-agent-wash)] text-[var(--fe-agent)]',
  warn: 'bg-[var(--fe-warning-wash)] text-[var(--fe-warning)]',
  bad: 'bg-[var(--fe-danger-wash)] text-[var(--fe-danger)]',
  blue: 'bg-[var(--fe-agent-wash)] text-[var(--fe-agent)]',
};

export function StatusChip({
  tone = 'neutral',
  children,
  className,
}: {
  tone?: StatusTone;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1 rounded-full px-[9px] py-[2px] text-[12px] font-medium',
        TONES[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

const RAILS: Record<StatusTone, string> = {
  ai: 'bg-[var(--fe-agent)]',
  human: 'bg-[var(--fe-signal)]',
  escalated: 'bg-[var(--fe-warning)]',
  neutral: 'bg-[var(--fe-hairline)]',
  danger: 'bg-[var(--fe-danger)]',
  default: 'bg-[var(--fe-signal)]',
  ok: 'bg-[var(--fe-agent)]',
  warn: 'bg-[var(--fe-warning)]',
  bad: 'bg-[var(--fe-danger)]',
  blue: 'bg-[var(--fe-agent)]',
};

/**
 * The flush-start rail on list rows and thread turns. Uses an inline-start
 * position so it lands on the correct edge in both LTR and RTL without a
 * second stylesheet.
 */
export function StatusRail({ tone = 'neutral' }: { tone?: StatusTone }) {
  return (
    <span
      aria-hidden="true"
      className={clsx('absolute inset-y-0 start-0 w-[var(--fe-rail-width)]', RAILS[tone])}
    />
  );
}
