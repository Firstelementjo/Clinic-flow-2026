import { describe, expect, it } from 'vitest';
import { ChannelType } from '@firstelement/shared';
import { MessengerConnector } from './meta/messenger.connector';
import { WhatsAppConnector } from './meta/whatsapp.connector';
import { TelegramConnector } from './telegram/telegram.connector';
import { ConnectorNotConfiguredError, ConnectorRegistry } from './registry';

const whatsapp = new WhatsAppConnector('conn-wa', {
  phoneNumberId: '123',
  accessToken: 'token',
  appSecret: 'secret',
  verifyToken: 'verify',
});

describe('WhatsApp normalization', () => {
  it('turns a text message into the shape the CRM sees', async () => {
    const [message] = await whatsapp.receiveWebhook({
      entry: [
        {
          changes: [
            {
              value: {
                contacts: [{ wa_id: '966500000001', profile: { name: 'نورة' } }],
                messages: [
                  {
                    id: 'wamid.ABC',
                    from: '966500000001',
                    timestamp: '1755300000',
                    type: 'text',
                    text: { body: 'أين طلبي؟' },
                  },
                ],
              },
            },
          ],
        },
      ],
    });

    expect(message).toBeDefined();
    expect(message!.channel).toBe(ChannelType.WHATSAPP);
    expect(message!.externalMessageId).toBe('wamid.ABC');
    expect(message!.text).toBe('أين طلبي؟');
    expect(message!.displayName).toBe('نورة');
    // WhatsApp identifies people by a phone number the platform vouches
    // for, so identity resolution may link on it (plan §7).
    expect(message!.phone).toBe('+966500000001');
    expect(message!.sentAt.getTime()).toBe(1_755_300_000_000);
  });

  it('ignores delivery-status callbacks, which share the webhook', async () => {
    const messages = await whatsapp.receiveWebhook({
      entry: [{ changes: [{ value: { statuses: [{ id: 'wamid.X', status: 'delivered' }] } }] }],
    });
    expect(messages).toEqual([]);
  });

  it('gives a media message a readable body instead of an empty one', async () => {
    const [message] = await whatsapp.receiveWebhook({
      entry: [
        {
          changes: [
            {
              value: {
                messages: [
                  {
                    id: 'wamid.IMG',
                    from: '966500000002',
                    timestamp: '1755300000',
                    type: 'image',
                    image: { id: 'media-1', mime_type: 'image/jpeg' },
                  },
                ],
              },
            },
          ],
        },
      ],
    });

    expect(message!.text).toBe('[image]');
    expect(message!.attachments[0]).toMatchObject({ type: 'image', url: 'media-1' });
  });

  it('prefers a caption over a placeholder when there is one', async () => {
    const [message] = await whatsapp.receiveWebhook({
      entry: [
        {
          changes: [
            {
              value: {
                messages: [
                  {
                    id: 'wamid.CAP',
                    from: '966500000003',
                    timestamp: '1755300000',
                    type: 'image',
                    image: { id: 'm', caption: 'This is the damaged item' },
                  },
                ],
              },
            },
          ],
        },
      ],
    });

    expect(message!.text).toBe('This is the damaged item');
  });

  it('reads a quick-reply button as the text the customer chose', async () => {
    const [message] = await whatsapp.receiveWebhook({
      entry: [
        {
          changes: [
            {
              value: {
                messages: [
                  {
                    id: 'wamid.BTN',
                    from: '966500000004',
                    timestamp: '1755300000',
                    type: 'interactive',
                    interactive: { button_reply: { title: 'Track my order' } },
                  },
                ],
              },
            },
          ],
        },
      ],
    });

    expect(message!.text).toBe('Track my order');
  });

  it('declares the 24-hour session window that governs replies', () => {
    expect(whatsapp.capabilities().sessionWindowHours).toBe(24);
    expect(whatsapp.capabilities().requiresTemplateOutsideSession).toBe(true);
  });
});

describe('Messenger and Instagram normalization', () => {
  const messenger = new MessengerConnector(ChannelType.MESSENGER, 'conn-fb', {
    pageId: 'page-1',
    pageAccessToken: 'token',
    appSecret: 'secret',
    verifyToken: 'verify',
  });

  it('normalizes a page-scoped sender into a message', async () => {
    const [message] = await messenger.receiveWebhook({
      entry: [
        {
          messaging: [
            {
              sender: { id: 'psid-1' },
              timestamp: 1_755_300_000_000,
              message: { mid: 'm_1', text: 'Hello' },
            },
          ],
        },
      ],
    });

    expect(message!.externalUserId).toBe('psid-1');
    expect(message!.text).toBe('Hello');
    // No phone or email: a page-scoped id is not a verified signal, so
    // identity resolution will not silently merge it with a customer.
    expect(message!.phone).toBeUndefined();
    expect(message!.email).toBeUndefined();
  });

  it('drops echoes of our own outbound messages', async () => {
    const messages = await messenger.receiveWebhook({
      entry: [
        {
          messaging: [
            {
              sender: { id: 'page-1' },
              message: { mid: 'm_2', text: 'Our reply', is_echo: true },
            },
          ],
        },
      ],
    });

    // Storing these would double every outbound message in the thread.
    expect(messages).toEqual([]);
  });

  it('ignores delivery and read events', async () => {
    const messages = await messenger.receiveWebhook({
      entry: [{ messaging: [{ sender: { id: 'psid-1' }, timestamp: 1 }] }],
    });
    expect(messages).toEqual([]);
  });

  it('describes an attachment-only message so the row is not blank', async () => {
    const [message] = await messenger.receiveWebhook({
      entry: [
        {
          messaging: [
            {
              sender: { id: 'psid-2' },
              message: { mid: 'm_3', attachments: [{ type: 'image', payload: { url: 'https://x' } }] },
            },
          ],
        },
      ],
    });

    expect(message!.text).toBe('[image]');
    expect(message!.attachments[0]).toMatchObject({ type: 'image' });
  });

  it('carries Instagram tighter text limit rather than assuming parity', () => {
    const instagram = new MessengerConnector(ChannelType.INSTAGRAM, 'conn-ig', {
      pageId: 'page-1',
      pageAccessToken: 'token',
      appSecret: 'secret',
      verifyToken: 'verify',
    });

    expect(instagram.capabilities().maxTextLength).toBeLessThan(
      messenger.capabilities().maxTextLength,
    );
  });
});

describe('Telegram', () => {
  const telegram = new TelegramConnector('conn-tg', {
    botToken: 'bot-token',
    webhookSecret: 'shared-secret',
  });

  it('verifies the secret token header', async () => {
    await expect(
      telegram.verifyWebhook({ headers: { 'x-telegram-bot-api-secret-token': 'shared-secret' } }),
    ).resolves.toBe(true);

    await expect(
      telegram.verifyWebhook({ headers: { 'x-telegram-bot-api-secret-token': 'wrong' } }),
    ).resolves.toBe(false);

    // Telegram does not sign payloads, so a missing header is the whole
    // authentication failing — never a pass-by-default.
    await expect(telegram.verifyWebhook({ headers: {} })).resolves.toBe(false);
  });

  it('normalizes an update and scopes the message id to its chat', async () => {
    const [message] = await telegram.receiveWebhook({
      update_id: 1,
      message: {
        message_id: 42,
        date: 1_755_300_000,
        chat: { id: 987654, type: 'private' },
        from: { first_name: 'Karim', last_name: 'Fadel' },
        text: 'Hello there',
      },
    });

    // Telegram message ids are unique per chat, not globally — the chat
    // id is part of what the idempotency constraint sees.
    expect(message!.externalMessageId).toBe('987654:42');
    expect(message!.externalUserId).toBe('987654');
    expect(message!.displayName).toBe('Karim Fadel');
    expect(message!.text).toBe('Hello there');
  });

  it('ignores an edited message rather than duplicating the turn', async () => {
    const messages = await telegram.receiveWebhook({
      update_id: 2,
      edited_message: {
        message_id: 42,
        date: 1_755_300_100,
        chat: { id: 987654, type: 'private' },
        text: 'Hello there (edited)',
      },
    });

    expect(messages).toEqual([]);
  });

  it('takes the largest photo size and gives the message a body', async () => {
    const [message] = await telegram.receiveWebhook({
      message: {
        message_id: 43,
        date: 1_755_300_000,
        chat: { id: 1, type: 'private' },
        photo: [{ file_id: 'small' }, { file_id: 'large' }],
      },
    });

    expect(message!.text).toBe('[photo]');
    expect(message!.attachments[0]!.url).toBe('large');
  });

  it('does not claim read receipts it cannot deliver', () => {
    expect(telegram.capabilities().markAsRead).toBe(false);
    expect(telegram.capabilities().editMessage).toBe(true);
  });
});

describe('registry', () => {
  const base = { id: 'c1', projectId: 'p1', isEnabled: true };

  it('builds a real connector when credentials are present', () => {
    const registry = new ConnectorRegistry();
    const connector = registry.get({
      ...base,
      channel: ChannelType.TELEGRAM,
      credentials: { botToken: 'x', webhookSecret: 'y' },
    });

    expect(connector.channel).toBe(ChannelType.TELEGRAM);
  });

  it('refuses a channel with no credentials rather than half-building it', () => {
    const registry = new ConnectorRegistry();
    expect(() => registry.get({ ...base, channel: ChannelType.WHATSAPP })).toThrowError(
      ConnectorNotConfiguredError,
    );
  });

  it('names the missing fields — and only the names', () => {
    const registry = new ConnectorRegistry();

    try {
      registry.get({
        ...base,
        channel: ChannelType.WHATSAPP,
        credentials: { phoneNumberId: '123', accessToken: 'secret-token-value' },
      });
      expect.unreachable('should have thrown');
    } catch (error) {
      const message = (error as Error).message;
      expect(message).toContain('appSecret');
      expect(message).toContain('verifyToken');
      // An error message is not a place to print a token.
      expect(message).not.toContain('secret-token-value');
    }
  });

  it('drops a cached instance when credentials are replaced', () => {
    const registry = new ConnectorRegistry();
    const connection = {
      ...base,
      channel: ChannelType.TELEGRAM,
      credentials: { botToken: 'x', webhookSecret: 'y' },
    };

    const first = registry.get(connection);
    registry.invalidate(connection.id);
    expect(registry.get(connection)).not.toBe(first);
  });
});
