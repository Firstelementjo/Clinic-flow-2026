import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Post,
  Put,
} from '@nestjs/common';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import {
  saveClassificationQuestionSchema,
  saveClassificationSchema,
  saveResolutionSchema,
  type SaveClassificationInput,
  type SaveClassificationQuestionInput,
  type SaveResolutionInput,
} from '@firstelement/shared';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { CasesService } from './cases.service';

@Controller()
export class CasesController {
  constructor(private readonly cases: CasesService) {}

  // --- question configuration (admin) ---------------------------------------

  @Get('projects/:projectId/classification-questions')
  @RequirePermissions(Permission.CONVERSATION_READ)
  listQuestions(@Tenant() ctx: TenantContext, @Param('projectId', ParseUUIDPipe) projectId: string) {
    return this.cases.listQuestions(ctx, projectId);
  }

  @Post('projects/:projectId/classification-questions')
  @RequirePermissions(Permission.ESCALATION_RULE_MANAGE)
  createQuestion(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Body(zodBody(saveClassificationQuestionSchema)) body: SaveClassificationQuestionInput,
  ) {
    return this.cases.saveQuestion(ctx, projectId, body);
  }

  @Put('projects/:projectId/classification-questions/:questionId')
  @RequirePermissions(Permission.ESCALATION_RULE_MANAGE)
  updateQuestion(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('questionId', ParseUUIDPipe) questionId: string,
    @Body(zodBody(saveClassificationQuestionSchema)) body: SaveClassificationQuestionInput,
  ) {
    return this.cases.saveQuestion(ctx, projectId, body, questionId);
  }

  @Delete('projects/:projectId/classification-questions/:questionId')
  @RequirePermissions(Permission.ESCALATION_RULE_MANAGE)
  @HttpCode(204)
  deleteQuestion(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('questionId', ParseUUIDPipe) questionId: string,
  ) {
    return this.cases.deleteQuestion(ctx, projectId, questionId);
  }

  // --- the agent's workspace -------------------------------------------------

  @Get('conversations/:conversationId/classification')
  @RequirePermissions(Permission.CONVERSATION_READ)
  getClassification(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
  ) {
    return this.cases.getClassification(ctx, conversationId);
  }

  /** Answering the questions also resolves the solution they point at. */
  @Put('conversations/:conversationId/classification')
  @RequirePermissions(Permission.CONVERSATION_REPLY)
  saveClassification(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Body(zodBody(saveClassificationSchema)) body: SaveClassificationInput,
  ) {
    return this.cases.saveClassification(ctx, conversationId, body);
  }

  @Get('conversations/:conversationId/resolution')
  @RequirePermissions(Permission.CONVERSATION_READ)
  getResolution(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
  ) {
    return this.cases.getResolution(ctx, conversationId);
  }

  @Put('conversations/:conversationId/resolution')
  @RequirePermissions(Permission.CONVERSATION_RESOLVE)
  saveResolution(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Body(zodBody(saveResolutionSchema)) body: SaveResolutionInput,
  ) {
    return this.cases.saveResolution(ctx, conversationId, body);
  }

  @Post('conversations/:conversationId/close')
  @RequirePermissions(Permission.CONVERSATION_RESOLVE)
  @HttpCode(200)
  close(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
  ) {
    return this.cases.setCaseState(ctx, conversationId, 'close');
  }

  @Post('conversations/:conversationId/reopen')
  @RequirePermissions(Permission.CONVERSATION_RESOLVE)
  @HttpCode(200)
  reopen(
    @Tenant() ctx: TenantContext,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
  ) {
    return this.cases.setCaseState(ctx, conversationId, 'reopen');
  }
}
