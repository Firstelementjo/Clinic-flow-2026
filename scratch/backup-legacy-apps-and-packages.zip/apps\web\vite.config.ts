import { fileURLToPath, URL } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      // The backend packages ship CommonJS, whose re-exports Rollup cannot
      // trace for named bindings. The browser build reads their TypeScript
      // source instead — same code, bundled as ESM, and no dual build to
      // keep in sync. Type resolution still goes through the package's
      // declaration output, so the two cannot drift.
      '@firstelement/shared': fileURLToPath(new URL('../../packages/shared/src', import.meta.url)),
    },
  },
  server: {
    port: Number(process.env.WEB_PORT ?? 5173),
    // Same-origin in dev so the session cookie behaves exactly as it does
    // in production behind one host — no SameSite surprises at deploy time.
    proxy: {
      '/api': {
        target: process.env.API_URL ?? 'http://localhost:4000',
        changeOrigin: true,
      },
    },
  },
});
