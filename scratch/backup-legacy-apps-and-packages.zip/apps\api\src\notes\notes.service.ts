import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import {
  accessibleProjectsScope,
  projectScope,
  type TenantContext,
} from '@firstelement/database';

@Injectable()
export class NotesService {
  constructor(private readonly prisma: PrismaService) {}

  async listForResource(ctx: TenantContext, resourceType: string, resourceId: string, projectId?: string) {
    return this.prisma.client.note.findMany({
      where: this.scopedWhere(ctx, projectId, { resourceType, resourceId }),
      select: {
        id: true,
        resourceType: true,
        resourceId: true,
        body: true,
        authorUserId: true,
        author: { select: { id: true, fullName: true } },
        createdAt: true,
        updatedAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /** All notes bound to a project (the CRM "Notes" workspace list). */
  async listProject(ctx: TenantContext, projectId: string) {
    return this.prisma.client.note.findMany({
      where: this.scopedWhere(ctx, projectId, {}),
      select: {
        id: true,
        projectId: true,
        resourceType: true,
        resourceId: true,
        body: true,
        authorUserId: true,
        author: { select: { id: true, fullName: true } },
        createdAt: true,
        updatedAt: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 500,
    });
  }

  async create(
    ctx: TenantContext,
    resourceType: string,
    resourceId: string,
    body: string,
    projectId: string,
  ) {
    // The project a note lands in comes from the checked scope, never from the
    // request body: `projectScope` rejects a project the caller is not a member
    // of before any row is written.
    const scope = projectScope(ctx, projectId);
    return this.prisma.client.note.create({
      data: {
        organizationId: scope.organizationId,
        projectId: scope.projectId,
        resourceType,
        resourceId,
        body,
        authorUserId: ctx.userId,
      },
      select: {
        id: true,
        resourceType: true,
        resourceId: true,
        body: true,
        authorUserId: true,
        projectId: true,
        createdAt: true,
      },
    });
  }

  async update(ctx: TenantContext, id: string, body: string, projectId?: string) {
    await this.assertOwned(ctx, id, projectId);
    return this.prisma.client.note.update({
      where: { id },
      data: { body },
      select: { id: true, body: true, updatedAt: true },
    });
  }

  async delete(ctx: TenantContext, id: string, projectId?: string) {
    await this.assertOwned(ctx, id, projectId);
    return this.prisma.client.note.delete({ where: { id }, select: { id: true } });
  }

  /**
   * A note is scoped like the record it decorates. `organizationId` always
   * rides along so a membership bug still cannot cross tenants.
   *
   * A caller-supplied `projectId` is a *request*, never an authorization, so
   * it goes through `projectScope`: that rejects a project the principal does
   * not hold membership of, and the rejection is rendered by
   * `HttpExceptionFilter` as the same 404 `Resource not found` used for a
   * project that does not exist at all — a denial must not disclose that the
   * project is there. This applies to the write paths too: `assertOwned`
   * builds its lookup with this helper, so update and delete are bounded by
   * membership before they touch a row.
   *
   * The route guards enforce the *permission* (`NOTE_READ`, `NOTE_UPDATE`, …)
   * and nothing else. They do not check membership.
   *
   * With no project supplied the scope is "every project I can see", never
   * "every project in the organization": a principal whose membership list is
   * empty must receive no notes rather than the whole tenant's.
   */
  private scopedWhere(
    ctx: TenantContext,
    projectId: string | undefined,
    extra: Record<string, unknown>,
  ) {
    const base = projectId ? projectScope(ctx, projectId) : accessibleProjectsScope(ctx);
    return { ...base, ...extra };
  }

  private async assertOwned(ctx: TenantContext, id: string, projectId?: string) {
    const where = this.scopedWhere(ctx, projectId, { id });
    const existing = await this.prisma.client.note.findFirst({
      where,
      select: { id: true },
    });

    if (!existing) {
      throw new NotFoundException({ code: 'NOT_FOUND', message: 'Note not found' });
    }
  }
}