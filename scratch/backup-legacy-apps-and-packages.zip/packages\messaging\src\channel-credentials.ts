import { decryptJson } from '@firstelement/auth';
import type { ChannelConnectionRecord } from '@firstelement/connectors';
import type { PrismaClient } from '@firstelement/database';
import type { ChannelType } from '@firstelement/shared';

/**
 * Loads a channel connection with its credentials decrypted.
 *
 * This is the only place ciphertext becomes plaintext, and it is
 * deliberately not inside the registry: building a connector should
 * require someone to have explicitly asked for decryption, so a stray
 * `registry.get(row)` on a row selected for an API response cannot
 * quietly hand credentials to a code path that then serializes them.
 *
 * Decryption failure is logged and treated as "not configured" rather
 * than thrown: a rotated ENCRYPTION_KEY should surface as a channel that
 * needs reconnecting, not as a crashed worker.
 */
export async function loadConnectionWithCredentials(
  prisma: PrismaClient,
  encryptionKey: string,
  where: { organizationId: string; projectId: string; channel: ChannelType },
  onError?: (error: unknown) => void,
): Promise<ChannelConnectionRecord | null> {
  const connection = await prisma.channelConnection.findFirst({
    where: { ...where, isEnabled: true },
    select: {
      id: true,
      projectId: true,
      channel: true,
      isEnabled: true,
      credentials: true,
    },
  });

  if (!connection) return null;

  return {
    id: connection.id,
    projectId: connection.projectId,
    channel: connection.channel,
    isEnabled: connection.isEnabled,
    credentials: decodeCredentials(connection.credentials, encryptionKey, onError),
  };
}

export async function loadConnectionById(
  prisma: PrismaClient,
  encryptionKey: string,
  connectionId: string,
  onError?: (error: unknown) => void,
): Promise<(ChannelConnectionRecord & { organizationId: string }) | null> {
  const connection = await prisma.channelConnection.findUnique({
    where: { id: connectionId },
    select: {
      id: true,
      organizationId: true,
      projectId: true,
      channel: true,
      isEnabled: true,
      credentials: true,
    },
  });

  if (!connection) return null;

  return {
    id: connection.id,
    organizationId: connection.organizationId,
    projectId: connection.projectId,
    channel: connection.channel,
    isEnabled: connection.isEnabled,
    credentials: decodeCredentials(connection.credentials, encryptionKey, onError),
  };
}

function decodeCredentials(
  ciphertext: string | null,
  encryptionKey: string,
  onError?: (error: unknown) => void,
): Record<string, unknown> | undefined {
  if (!ciphertext) return undefined;
  try {
    return decryptJson(ciphertext, encryptionKey);
  } catch (error) {
    onError?.(error);
    return undefined;
  }
}
