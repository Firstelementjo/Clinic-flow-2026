/**
 * A single donut gauge showing CSAT (satisfied) and DSAT (unsatisfied)
 * in two colour segments, with the neutral (unrated) portion invisible.
 *
 * Pure SVG — no external charting library.
 */
export function SatisfactionDonut({
  csat,
  dsat,
}: {
  /** 0–100 or null when no data. */
  csat: number | null;
  dsat: number | null;
}) {
  const satisfied = csat ?? 0;
  const unsatisfied = dsat ?? 0;
  const hasData = csat !== null && dsat !== null;

  const r = 42;
  const circumference = 2 * Math.PI * r;

  // CSAT arc fills clockwise from the top.
  const csatLength = (satisfied / 100) * circumference;
  // DSAT arc follows immediately after CSAT.
  const dsatLength = (unsatisfied / 100) * circumference;


  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative">
        <svg width="112" height="112" viewBox="0 0 112 112" className="-rotate-90">
          {/* Background track */}
          <circle
            cx="56"
            cy="56"
            r={r}
            fill="none"
            stroke="var(--fe-mist-deep)"
            strokeWidth="10"
          />
          {/* CSAT arc (green/teal) */}
          {hasData && csatLength > 0 && (
            <circle
              cx="56"
              cy="56"
              r={r}
              fill="none"
              stroke="var(--fe-signal)"
              strokeWidth="10"
              strokeLinecap="round"
              strokeDasharray={`${csatLength} ${circumference - csatLength}`}
              strokeDashoffset={0}
              className="transition-[stroke-dasharray] duration-700 ease-out"
            />
          )}
          {/* DSAT arc (orange/red) — starts after CSAT */}
          {hasData && dsatLength > 0 && (
            <circle
              cx="56"
              cy="56"
              r={r}
              fill="none"
              stroke="var(--fe-escalation)"
              strokeWidth="10"
              strokeLinecap="round"
              strokeDasharray={`${dsatLength} ${circumference - dsatLength}`}
              strokeDashoffset={-csatLength}
              className="transition-[stroke-dasharray] duration-700 ease-out"
            />
          )}
        </svg>
        {/* Centre text */}
        <span className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="fe-mono text-lg font-semibold text-ink" dir="ltr">
            {hasData ? `${satisfied}%` : '—'}
          </span>
        </span>
      </div>
      {/* Legend */}
      {hasData && (
        <div className="flex items-center gap-3 text-xs">
          <span className="flex items-center gap-1">
            <span className="inline-block h-2 w-2 rounded-full" style={{ background: 'var(--fe-signal)' }} />
            <span className="text-slate">CSAT {satisfied}%</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="inline-block h-2 w-2 rounded-full" style={{ background: 'var(--fe-escalation)' }} />
            <span className="text-slate">DSAT {unsatisfied}%</span>
          </span>
        </div>
      )}
      <span className="fe-eyebrow text-center text-xs">Satisfaction</span>
    </div>
  );
}
