import { useCallback, useRef, useState, type PointerEvent } from 'react';

/**
 * Hook for resizable columns within a flex container.
 *
 * All columns except the last have explicit pixel widths stored in state.
 * The last column uses `flex-1 min-w-0` to fill remaining space, so the
 * total always matches the container — no overflow.
 *
 * When a drag handle between columns i and i+1 is moved, the two
 * adjacent columns adjust: left absorbs +delta, right absorbs -delta.
 * If the right column of a pair is the last (flex) column, only the
 * left column changes — the flex column absorbs automatically.
 */
export function useResizableColumns(initial: number[]) {
  const [widths, setWidths] = useState(initial);
  const dragging = useRef<{ index: number; startX: number; startWidths: number[] } | null>(null);

  const onPointerDown = useCallback(
    (index: number) => (e: PointerEvent) => {
      e.preventDefault();
      // Capture on currentTarget (the handler element), not target
      // (which may be a child). This ensures pointermove fires on us.
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      dragging.current = { index, startX: e.clientX, startWidths: [...widths] };
    },
    [widths],
  );

  const onPointerMove = useCallback(
    (e: PointerEvent) => {
      if (!dragging.current) return;
      const { index, startX, startWidths } = dragging.current;
      const delta = e.clientX - startX;
      const MIN = 80;

      setWidths(() => {
        const next = [...startWidths];
        const left = startWidths[index] ?? MIN;
        const newLeft = Math.max(MIN, left + delta);
        const leftDiff = newLeft - left;
        next[index] = newLeft;

        // If the right column of the handle exists in state, shrink it
        // by the same amount so the total stays constant.  The last
        // column (flex-1) is NOT in state, so it absorbs on its own.
        if (index + 1 < next.length) {
          next[index + 1] = Math.max(MIN, (startWidths[index + 1] ?? MIN) - leftDiff);
        }

        return next;
      });
    },
    [],
  );

  const onPointerUp = useCallback(() => {
    dragging.current = null;
  }, []);

  return { widths, setWidths, onPointerDown, onPointerMove, onPointerUp };
}
