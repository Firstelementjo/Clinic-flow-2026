import { Injectable, Logger } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { DomainEventType, type ConversationAssignedEvent, type ConversationEscalatedEvent } from '@firstelement/events';
import { accessibleProjectsScope, type TenantContext } from '@firstelement/database';
import { PrismaService } from '../common/prisma.service';
import { RealtimeGateway } from './realtime.gateway';

export interface NotificationView {
  id: string;
  type: string;
  title: string;
  body: string | null;
  resourceType: string | null;
  resourceId: string | null;
  readAt: string | null;
  createdAt: string;
}

/**
 * In-app notifications (plan §11).
 *
 * Persisted first, pushed second. An agent who was offline when a
 * conversation was assigned still has to find it at the start of their
 * shift, and a realtime channel that drops a frame must not lose the
 * fact — so the row is the record and the push is an optimization.
 *
 * Notifications are created by subscribing to domain events rather than
 * by the routing and escalation services calling a notifier: those
 * services should not grow a dependency on how people are told (plan §8b).
 */
@Injectable()
export class NotificationsService {
  private readonly logger = new Logger(NotificationsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly realtime: RealtimeGateway,
  ) {}

  @OnEvent(DomainEventType.CONVERSATION_ASSIGNED)
  async onAssigned(event: ConversationAssignedEvent): Promise<void> {
    if (!event.payload.employeeId) return;

    const employee = await this.prisma.client.employee.findUnique({
      where: { id: event.payload.employeeId },
      select: { userId: true },
    });
    if (!employee) return;

    // Assigning a conversation to yourself does not need telling.
    if (employee.userId === event.actorUserId) return;

    await this.create({
      organizationId: event.organizationId,
      projectId: event.projectId,
      userId: employee.userId,
      type: 'CONVERSATION_ASSIGNED',
      title: 'A conversation was assigned to you',
      body:
        event.payload.reason === 'ROUTING'
          ? 'Routed to you automatically.'
          : 'Assigned by a colleague.',
      resourceType: 'Conversation',
      resourceId: event.aggregateId,
    });
  }

  /**
   * An escalation nobody could take is the one an ops manager must see.
   * Admins are told; the assigned agent already got their own
   * notification from the assignment event.
   */
  @OnEvent(DomainEventType.CONVERSATION_ESCALATED)
  async onEscalated(event: ConversationEscalatedEvent): Promise<void> {
    const admins = await this.prisma.client.user.findMany({
      where: { organizationId: event.organizationId, role: 'ADMIN', isActive: true },
      select: { id: true },
      take: 25,
    });

    for (const admin of admins) {
      await this.create({
        organizationId: event.organizationId,
        projectId: event.projectId,
        userId: admin.id,
        type: 'CONVERSATION_ESCALATED',
        title: 'A conversation was escalated',
        body: event.payload.reason,
        resourceType: 'Conversation',
        resourceId: event.aggregateId,
      });
    }
  }

  async create(input: {
    organizationId: string;
    projectId?: string | null;
    userId: string;
    type: string;
    title: string;
    body?: string | null;
    resourceType?: string | null;
    resourceId?: string | null;
  }): Promise<void> {
    try {
      const notification = await this.prisma.client.notification.create({
        data: {
          organizationId: input.organizationId,
          projectId: input.projectId ?? null,
          userId: input.userId,
          type: input.type as 'CONVERSATION_ASSIGNED',
          title: input.title,
          body: input.body ?? null,
          resourceType: input.resourceType ?? null,
          resourceId: input.resourceId ?? null,
        },
      });

      this.realtime.publishToUser(input.userId, {
        type: 'notification',
        payload: toView(notification),
      });
    } catch (error) {
      // Failing to notify must not roll back the assignment it describes.
      this.logger.error({
        message: 'Failed to create notification',
        userId: input.userId,
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  async list(ctx: TenantContext, onlyUnread: boolean): Promise<NotificationView[]> {
    const notifications = await this.prisma.client.notification.findMany({
      where: {
        userId: ctx.userId,
        organizationId: ctx.organizationId,
        ...(onlyUnread ? { readAt: null } : {}),
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    return notifications.map(toView);
  }

  async unreadCount(ctx: TenantContext): Promise<number> {
    return this.prisma.client.notification.count({
      where: { userId: ctx.userId, organizationId: ctx.organizationId, readAt: null },
    });
  }

  /** Scoped to the caller: a notification id is not a capability. */
  async markRead(ctx: TenantContext, notificationId: string): Promise<void> {
    await this.prisma.client.notification.updateMany({
      where: { id: notificationId, userId: ctx.userId },
      data: { readAt: new Date() },
    });
  }

  async markAllRead(ctx: TenantContext): Promise<{ updated: number }> {
    const result = await this.prisma.client.notification.updateMany({
      where: { userId: ctx.userId, organizationId: ctx.organizationId, readAt: null },
      data: { readAt: new Date() },
    });
    return { updated: result.count };
  }

  /** Used by the realtime stream to filter events to what a user may see. */
  accessibleScope(ctx: TenantContext) {
    return accessibleProjectsScope(ctx);
  }
}

function toView(notification: {
  id: string;
  type: string;
  title: string;
  body: string | null;
  resourceType: string | null;
  resourceId: string | null;
  readAt: Date | null;
  createdAt: Date;
}): NotificationView {
  return {
    id: notification.id,
    type: notification.type,
    title: notification.title,
    body: notification.body,
    resourceType: notification.resourceType,
    resourceId: notification.resourceId,
    readAt: notification.readAt?.toISOString() ?? null,
    createdAt: notification.createdAt.toISOString(),
  };
}
