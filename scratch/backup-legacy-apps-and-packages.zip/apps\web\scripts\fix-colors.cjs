const fs = require('fs');
const path = require('path');

const rootDir = 'c:\\Users\\adama\\OneDrive\\Desktop\\Clinec Flow\\saas-crm-main (2)\\saas-crm-main\\apps\\web\\src\\routes';

const files = [
  'DashboardPage.tsx',
  'PeoplePage.tsx',
  'DoctorSchedulesPage.tsx',
  'AppointmentsPage.tsx',
  'PublicConfirmPage.tsx',
  'FollowUpsPage.tsx'
];

function processFile(file) {
  const filePath = path.join(rootDir, file);
  let content = fs.readFileSync(filePath, 'utf-8');

  // Remove dark: classes for colors since tokens handle it
  content = content.replace(/dark:(text|bg|border)-[a-z]+-\d+(\/\d+)?\s?/g, '');
  
  // Replace colors with tokens
  // Agent (Teal/Emerald/Cyan)
  content = content.replace(/text-(emerald|teal|cyan)-\d+/g, 'text-agent');
  content = content.replace(/bg-(emerald|teal|cyan)-500\/[123]0/g, 'bg-agent-wash');
  content = content.replace(/bg-(emerald|teal|cyan)-[56]0\/[12345789]0/g, 'bg-agent-wash');
  content = content.replace(/bg-(emerald|teal|cyan)-50/g, 'bg-agent-wash');
  content = content.replace(/bg-(emerald|teal|cyan)-\d+/g, 'bg-agent');
  content = content.replace(/border-(emerald|teal|cyan)-\d+(\/\d+)?/g, 'border-agent');
  
  // Signal (Blue/Purple/Indigo)
  content = content.replace(/text-(blue|purple|indigo)-\d+/g, 'text-signal');
  content = content.replace(/bg-(blue|purple|indigo)-500\/[123]0/g, 'bg-signal-wash');
  content = content.replace(/bg-(blue|purple|indigo)-[56]0\/[12345789]0/g, 'bg-signal-wash');
  content = content.replace(/bg-(blue|purple|indigo)-50/g, 'bg-signal-wash');
  content = content.replace(/bg-(blue|purple|indigo)-\d+/g, 'bg-signal');
  content = content.replace(/border-(blue|purple|indigo)-\d+(\/\d+)?/g, 'border-signal');
  
  // Warning (Amber/Yellow/Orange)
  content = content.replace(/text-(amber|yellow|orange)-\d+/g, 'text-warning');
  content = content.replace(/bg-(amber|yellow|orange)-500\/[123]0/g, 'bg-warning-wash');
  content = content.replace(/bg-(amber|yellow|orange)-[56]0\/[12345789]0/g, 'bg-warning-wash');
  content = content.replace(/bg-(amber|yellow|orange)-50/g, 'bg-warning-wash');
  content = content.replace(/bg-(amber|yellow|orange)-\d+/g, 'bg-warning');
  content = content.replace(/border-(amber|yellow|orange)-\d+(\/\d+)?/g, 'border-warning');

  // Danger (Red/Rose)
  content = content.replace(/text-(red|rose)-\d+/g, 'text-danger');
  content = content.replace(/bg-(red|rose)-500\/[123]0/g, 'bg-danger-wash');
  content = content.replace(/bg-(red|rose)-[56]0\/[12345789]0/g, 'bg-danger-wash');
  content = content.replace(/bg-(red|rose)-50/g, 'bg-danger-wash');
  content = content.replace(/bg-(red|rose)-\d+/g, 'bg-danger');
  content = content.replace(/border-(red|rose)-\d+(\/\d+)?/g, 'border-danger');

  // Surface replacements (slate-100 / slate-800 to nav-dim / nav-raised)
  content = content.replace(/bg-slate-100/g, 'bg-nav-dim');
  content = content.replace(/bg-slate-300/g, 'bg-nav-raised');
  content = content.replace(/bg-slate-700/g, 'bg-nav-raised');
  content = content.replace(/bg-slate-800/g, 'bg-nav-dim');

  fs.writeFileSync(filePath, content);
  console.log(`Processed ${file}`);
}

files.forEach(processFile);
