import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Building2,
  CalendarClock,
  CircleDollarSign,
  ContactRound,
  MoreHorizontal,
  RotateCcw,
  Trophy,
  UserRound,
  XCircle,
} from 'lucide-react';
import { useDirection } from '@firstelement/ui';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useT } from '../lib/i18n';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import { CreateDealDrawer } from '../components/deal-form';
import { useCrmViews } from '../lib/views';
import {
  ListView,
  Menu,
  MenuItem,
  RecordAvatar,
  type ListColumn,
} from '../components/ListView';

interface DealRow {
  id: string;
  name: string;
  company: string | null;
  value: number;
  currency: string;
  pipeline: string;
  stage: string;
  closedWon: boolean;
  closedAt: string | null;
  expectedClose: string | null;
  createdById: string | null;
  createdBy: { id: string; fullName: string } | null;
  owner: { id: string; fullName: string } | null;
  createdAt: string;
}

const dealsKey = ['deals'] as const;

function useDeals(search: string) {
  const query = new URLSearchParams();
  if (search.trim()) query.set('search', search.trim());
  return useQuery({
    queryKey: ['deals', search.trim()],
    queryFn: () => api.get<DealRow[]>(`/deals?${query.toString()}`),
  });
}

export function DealsPage() {
  const t = useT();
  const dir = useDirection();
  const qc = useQueryClient();
  const views = useCrmViews('opportunity', { noun: t('opportunities.list.title'), defaultSort: 'createdAt' });
  const [createOpen, setCreateOpen] = useState(false);
  const location = useLocation();
  const nav = useNavigate();
  useEffect(() => {
    if (new URLSearchParams(location.search).get('new') === '1') {
      setCreateOpen(true);
      nav(location.pathname, { replace: true });
    }
  }, [location.search, nav]);

  const deals = useDeals(views.search);

  const rows = useMemo(() => {
    const list = [...(deals.data ?? [])];
    if (views.sort === 'value') list.sort((a, b) => b.value - a.value);
    else if (views.sort === 'close')
      list.sort((a, b) => (a.expectedClose ? new Date(a.expectedClose).getTime() : 0) - (b.expectedClose ? new Date(b.expectedClose).getTime() : 0));
    else list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return list;
  }, [deals.data, views.sort]);

  const invalidate = () => void qc.invalidateQueries({ queryKey: dealsKey });

  const moveStage = useMutation({
    mutationFn: ({ id, next }: { id: string; next: string }) =>
      api.patch<DealRow>(`/deals/${id}`, { stage: next }),
    onSuccess: invalidate,
  });

  const closeDeal = useMutation({
    mutationFn: ({ id, won }: { id: string; won: boolean }) =>
      api.post(`/deals/${id}/close`, { won }),
    onSuccess: invalidate,
  });

  const removeMany = useMutation({
    mutationFn: async (ids: string[]) => {
      await Promise.all(ids.map((id) => api.delete(`/deals/${id}`)));
    },
    onSuccess: invalidate,
  });

  const money = (value: number, currency: string) =>
    `${currency} ${value.toLocaleString('en-US', { maximumFractionDigits: 0 })}`;

  const nameCell = (deal: DealRow) => (
    <button type="button" tabIndex={-1} className="flex min-w-0 max-w-full items-center gap-2 text-start">
      <RecordAvatar name={deal.name} />
      <span className="truncate text-sm font-medium text-ink">{deal.name}</span>
    </button>
  );

  const columns: ListColumn<DealRow>[] = [
    { id: 'name', label: 'list.col.name', icon: Building2, size: 'minmax(11rem, 3fr)', render: nameCell },
    {
      id: 'amount',
      label: 'list.col.amount',
      icon: CircleDollarSign,
      size: 'minmax(6rem, 1.25fr)',
      render: (deal) => <span className="fe-mono text-xs font-medium text-ink">{money(deal.value, deal.currency)}</span>,
    },
    {
      id: 'createdBy',
      label: 'list.col.createdBy',
      icon: UserRound,
      size: 'minmax(6rem, 1.25fr)',
      render: (deal) => deal.createdBy?.fullName ?? null,
    },
    {
      id: 'expectedClose',
      label: 'list.col.close',
      icon: CalendarClock,
      size: '7rem',
      render: (deal) => (deal.expectedClose ? formatDate(deal.expectedClose, dir.locale) : null),
    },
    {
      id: 'company',
      label: 'list.col.company',
      icon: Building2,
      size: 'minmax(8rem, 1.75fr)',
      render: (deal) => deal.company,
    },
    {
      id: 'poc',
      label: 'list.col.pointOfContact',
      icon: ContactRound,
      size: 'minmax(7rem, 1.5fr)',
      render: (deal) => deal.owner?.fullName ?? null,
    },
  ];

  const footerCells = [
    {
      col: 'amount',
      render: (list: DealRow[]) => {
        if (list.length === 0) return null;
        const avg = list.reduce((sum, d) => sum + d.value, 0) / list.length;
        const currency = list[0]?.currency ?? 'USD';
        return `${t('list.footer.avg')} ${money(Math.round(avg), currency)}`;
      },
    },
    {
      col: 'expectedClose',
      render: (list: DealRow[]) => {
        const closes = list
          .map((d) => d.expectedClose)
          .filter((d): d is string => Boolean(d))
          .map((d) => new Date(d).getTime());
        if (closes.length === 0) return null;
        return `${t('list.footer.earliest')} ${formatDate(new Date(Math.min(...closes)).toISOString(), dir.locale)}`;
      },
    },
  ];

  return (
    <>
      <ListView<DealRow>
        title={t('opportunities.list.title')}
        eyebrow={t('opportunities.list.eyebrow')}
        addLabel={t('list.newOpportunity')}
        onAdd={() => setCreateOpen(true)}
        noun={t('opportunities.list.title')}
        objectType="opportunities"
        columns={columns}
        rows={rows}
        isPending={deals.isPending}
        isError={deals.isError}
        keyOf={(d) => d.id}
        viewSwitcher={views.switcher}
        filterValue={views.search}
        onFilter={views.setSearch}
        sortValue={views.sort}
        onSort={views.setSort}
        sortOptions={[
          { value: 'createdAt', label: t('list.col.created') },
          { value: 'value', label: t('list.col.amount') },
          { value: 'close', label: t('list.col.close') },
        ]}
        hiddenColumns={views.hidden}
        onHiddenColumnsChange={views.setHidden}
        onDeleteSelected={(ids) => removeMany.mutate(ids)}
        footerCells={footerCells}
        rowActions={(deal) => (
          <Menu
            button={
              <span
                aria-label={t('list.options')}
                role="img"
                className="flex h-6 w-6 items-center justify-center rounded text-slate-soft transition-colors hover:bg-mist hover:text-ink"
              >
                <MoreHorizontal className="h-4 w-4" />
              </span>
            }
          >
            <MenuItem
              icon={Trophy}
              label={t('deals.won')}
              onClick={() => closeDeal.mutate({ id: deal.id, won: true })}
            />
            <MenuItem
              danger
              icon={XCircle}
              label={t('deals.lost')}
              onClick={() => closeDeal.mutate({ id: deal.id, won: false })}
            />
            {(deal.closedAt || deal.stage === 'Won' || deal.stage === 'Lost') && (
              <MenuItem
                icon={RotateCcw}
                label={t('deals.reopen')}
                onClick={() => moveStage.mutate({ id: deal.id, next: 'Prospect' })}
              />
            )}
          </Menu>
        )}
      />
      <CreateDealDrawer open={createOpen} onClose={() => setCreateOpen(false)} />
    </>
  );
}