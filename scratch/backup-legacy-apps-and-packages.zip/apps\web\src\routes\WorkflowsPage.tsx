import { useState, useCallback, type FormEvent } from 'react';
import { Button, EmptyState, Panel, Spinner } from '@firstelement/ui';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useT } from '../lib/i18n';
import { controlCls, selectCls } from '../lib/ui';
import { useSession } from '../lib/session';
import type { RuleConditionInput, SaveEscalationRuleInput } from '@firstelement/shared';
import {
  createEscalationRule,
  deleteEscalationRule,
  updateEscalationRule,
  useEscalationRules,
} from '../lib/workflows';

const SIGNALS = [
  'frustration',
  'sentiment',
  'urgency',
  'risk',
  'intentConfidence',
  'aiConfidence',
  'aiTurnsWithoutResolution',
  'explicitHumanRequest',
] as const;

const OPERATORS = ['gte', 'lte', 'gt', 'lt', 'eq'] as const;

interface RuleDraft {
  name: string;
  description: string;
  department: string;
  priority: number;
  combinator: 'ALL' | 'ANY';
  isEnabled: boolean;
  conditions: RuleConditionInput[];
}

function ruleToDraft(rule: {
  name: string;
  description: string | null;
  department: string | null;
  priority: number;
  combinator: 'ALL' | 'ANY';
  isEnabled: boolean;
  conditions: RuleConditionInput[];
}): RuleDraft {
  return {
    name: rule.name,
    description: rule.description ?? '',
    department: rule.department ?? '',
    priority: rule.priority,
    combinator: rule.combinator,
    isEnabled: rule.isEnabled,
    conditions: rule.conditions.length ? rule.conditions : [{ signal: 'frustration', operator: 'gte', value: 80 }],
  };
}

function toInput(draft: RuleDraft): SaveEscalationRuleInput {
  return {
    name: draft.name,
    description: draft.description || undefined,
    department: draft.department || undefined,
    priority: draft.priority,
    combinator: draft.combinator,
    isEnabled: draft.isEnabled,
    conditions: draft.conditions.length ? draft.conditions : [{ signal: 'frustration', operator: 'gte', value: 80 }],
  };
}

export function WorkflowsPage() {
  const t = useT();
  const qc = useQueryClient();
  const session = useSession();
  const projectIds = session.data?.projectIds ?? [];
  const [selectedProject, setSelectedProject] = useState<string | undefined>(
    projectIds[0] ?? undefined,
  );
  const projectId = selectedProject ?? projectIds[0];

  const rules = useEscalationRules(projectId);
  const [newName, setNewName] = useState('');

  const invalidate = () =>
    void qc.invalidateQueries({ queryKey: ['escalation-rules', projectId ?? ''] });

  const saveRule = useMutation({
    mutationFn: ({ id, draft }: { id: string; draft: RuleDraft }) =>
      projectId ? updateEscalationRule(projectId, id, toInput(draft)) : Promise.reject(),
    onSuccess: invalidate,
  });

  const createRule = useMutation({
    mutationFn: () =>
      projectId
        ? createEscalationRule(projectId, toInput(ruleToDraft({
            name: newName || 'New rule',
            description: '',
            department: '',
            priority: (rules.data?.length ?? 0) + 1,
            combinator: 'ALL',
            isEnabled: true,
            conditions: [{ signal: 'frustration', operator: 'gte', value: 80 }],
          })))
        : Promise.reject(),
    onSuccess: () => {
      setNewName('');
      invalidate();
    },
  });

  const removeRule = useMutation({
    mutationFn: (id: string) =>
      projectId ? deleteEscalationRule(projectId, id) : Promise.reject(),
    onSuccess: invalidate,
  });

  const toggleRule = useMutation({
    mutationFn: (rule: RuleDraft & { id: string }) =>
      projectId
        ? updateEscalationRule(projectId, rule.id, toInput({ ...rule, isEnabled: !rule.isEnabled }))
        : Promise.reject(),
    onSuccess: invalidate,
  });

  const onSubmitNew = (e: FormEvent) => {
    e.preventDefault();
    if (newName.trim() && projectId) createRule.mutate();
  };

  const changeProject = useCallback((value: string) => {
    setSelectedProject(value);
  }, []);

  if (projectIds.length === 0) {
    return (
      <Panel eyebrow={t('workflows.eyebrow')} title={t('workflows.title')}>
        <p className="text-sm text-slate">{t('workflows.noProjects')}</p>
      </Panel>
    );
  }

  return (
    <Panel
      eyebrow={t('workflows.eyebrow')}
      title={t('workflows.title')}
      actions={
        <label className="flex items-center gap-2 text-xs">
          <span className="text-slate-soft">{t('workflows.selectProject')}</span>
          <select value={projectId ?? ''} onChange={(e) => changeProject(e.target.value)} className={selectCls}>
            {projectIds.map((id) => (
              <option key={id} value={id}>{id.slice(0, 8)}</option>
            ))}
          </select>
        </label>
      }
    >
      <p className="mb-4 text-sm text-slate">{t('workflows.body')}</p>

      <form onSubmit={onSubmitNew} className="mb-4 flex items-center gap-2">
        <input
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder={t('workflows.rule.add')}
          aria-label={t('workflows.rule.add')}
          className={controlCls}
        />
        <Button type="submit" size="sm" variant="secondary" loading={createRule.isPending} disabled={!newName.trim()}>
          {t('workflows.rule.add')}
        </Button>
      </form>

      {rules.isPending ? (
        <div className="p-4">
          <Spinner label={t('common.loading')} />
        </div>
      ) : rules.isError ? (
        <p className="text-sm text-slate">{t('common.error')}</p>
      ) : !rules.data || rules.data.length === 0 ? (
        <EmptyState title={t('workflows.empty')} body={t('workflows.body')} />
      ) : (
        <ul className="flex flex-col gap-3">
          {rules.data.map((rule) => {
            const draft = ruleToDraft(rule);
            return (
              <li key={rule.id} className="rounded-lg border border-hairline bg-surface p-4 shadow-panel">
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <input
                      value={draft.name}
                      onChange={(e) => saveRule.mutate({ id: rule.id, draft: { ...draft, name: e.target.value } })}
                      aria-label={t('workflows.rule.name')}
                      className="fe-mono w-full truncate bg-transparent text-sm font-medium text-ink focus:bg-mist/40 focus:px-1.5 focus:rounded"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="flex items-center gap-1.5 text-xs">
                      <input
                        type="checkbox"
                        checked={draft.isEnabled}
                        onChange={() => toggleRule.mutate({ ...draft, id: rule.id })}
                        className="accent-[var(--fe-signal)]"
                      />
                      <span className="text-slate-soft">{draft.isEnabled ? t('workflows.enabled') : t('workflows.disabled')}</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => removeRule.mutate(rule.id)}
                      disabled={removeRule.isPending}
                      className="text-xs font-medium text-danger hover:underline disabled:opacity-50"
                    >
                      {t('workflows.rule.delete')}
                    </button>
                  </div>
                </div>

                {draft.description && (
                  <p className="mt-1 text-xs text-slate-soft">{draft.description}</p>
                )}

                <RuleEditor draft={draft} onSave={(next) => saveRule.mutate({ id: rule.id, draft: next })} />
              </li>
            );
          })}
        </ul>
      )}
    </Panel>
  );
}

interface RuleEditorProps {
  draft: RuleDraft;
  onSave: (next: RuleDraft) => void;
}

function RuleEditor({ draft, onSave }: RuleEditorProps) {
  const t = useT();
  const setCondition = (index: number, patch: Partial<RuleConditionInput>) => {
    const conditions = draft.conditions.map((c, i) => (i === index ? { ...c, ...patch } : c));
    onSave({ ...draft, conditions });
  };
  const addCondition = () => {
    onSave({
      ...draft,
      conditions: [...draft.conditions, { signal: 'frustration', operator: 'gte', value: 80 }],
    });
  };
  const removeCondition = (index: number) => {
    onSave({ ...draft, conditions: draft.conditions.filter((_, i) => i !== index) });
  };

  return (
    <div className="mt-3 flex flex-col gap-2 border-t border-hairline pt-3">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
        <label className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-soft">{t('workflows.rule.combinator')}</span>
          <select
            value={draft.combinator}
            onChange={(e) => onSave({ ...draft, combinator: e.target.value as 'ALL' | 'ANY' })}
            className={selectCls}
          >
            <option value="ALL">ALL</option>
            <option value="ANY">ANY</option>
          </select>
        </label>
        <label className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-soft">{t('workflows.rule.priority')}</span>
          <input
            type="number"
            value={draft.priority}
            onChange={(e) => onSave({ ...draft, priority: Number(e.target.value) || 1 })}
            className={controlCls}
            style={{ width: 80 }}
          />
        </label>
        <label className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-soft">{t('workflows.rule.department')}</span>
          <input
            value={draft.department}
            onChange={(e) => onSave({ ...draft, department: e.target.value })}
            className={controlCls}
          />
        </label>
      </div>

      {draft.conditions.map((cond, i) => (
        <div key={i} className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="fe-eyebrow">{i + 1}</span>
          <select
            value={cond.signal}
            onChange={(e) => setCondition(i, { signal: e.target.value as RuleConditionInput['signal'] })}
            className={selectCls}
          >
            {SIGNALS.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          <select
            value={cond.operator}
            onChange={(e) => setCondition(i, { operator: e.target.value as RuleConditionInput['operator'] })}
            className={selectCls}
          >
            {OPERATORS.map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
          <input
            type="number"
            value={cond.value}
            onChange={(e) => setCondition(i, { value: Number(e.target.value) || 0 })}
            className={controlCls}
            style={{ width: 72 }}
          />
          <span className="flex items-center gap-1 ms-1">
            <button
              type="button"
              onClick={() => removeCondition(i)}
              disabled={draft.conditions.length <= 1}
              className="text-xs text-slate hover:underline disabled:opacity-40"
            >
              −
            </button>
            {i === draft.conditions.length - 1 && (
              <button type="button" onClick={addCondition} className="text-xs text-signal hover:underline">
                +
              </button>
            )}
          </span>
        </div>
      ))}
      <div className="flex gap-1.5">
        <Button type="button" size="sm" variant="ghost" onClick={() => onSave(draft)}>
          {t('workflows.rule.save')}
        </Button>
      </div>
    </div>
  );
}