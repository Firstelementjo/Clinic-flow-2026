import { useState, type ChangeEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button, EmptyState, Panel, Spinner, StatusChip } from '@firstelement/ui';
import {
  type StatusTotalsView,
  type EmployeeRoutingView,
  type ImportPreviewView,
  type ImportResultView,
  type SessionUser,
} from '@firstelement/shared';
import { api } from '../lib/api';
import { useT, type StringKey } from '../lib/i18n';
import { useSession } from '../lib/session';
import { EmployeeAdmin } from '../components/EmployeeAdmin';

interface EmployeeAnalyticsData {
  csat: number | null;
  dsat: number | null;
  resolveRate: number | null;
  casesResolved: number;
  averageHandlingMinutes: number | null;
  medianFirstResponseMinutes: number | null;
}

/**
 * The roster as routing sees it: who is on shift, what they can handle,
 * and how loaded they are. This is the screen an ops manager opens when
 * escalations start queueing — the answer is almost always visible here.
 */
export function TeamPage() {
  const t = useT();
  const session = useSession();
  const isAdmin = (session.data as SessionUser | null)?.role === 'ADMIN';

  const employees = useQuery({
    queryKey: ['team'],
    queryFn: () => api.get<EmployeeRoutingView[]>('/employees/routing'),
  });

  return (
    <div className="space-y-6">
      <div className="ph">
        <div>
          <h2>{t('team.title')}</h2>
          <p>{t('team.eyebrow')}</p>
        </div>
      </div>

      <StatusTotals />

      <div className="card table-responsive">
        <table className="fe-table w-full text-start">
          <thead>
            <tr>
              <th>Employee</th>
              <th>Department</th>
              <th className="hidden sm:table-cell">Skills</th>
              <th>Load</th>
              <th>Shift</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {employees.isPending ? (
              <tr>
                <td colSpan={7} className="p-4 text-center">
                  <Spinner label={t('common.loading')} />
                </td>
              </tr>
            ) : employees.isError ? (
              <tr>
                <td colSpan={7} className="p-4 text-sm text-slate-500 text-center">
                  {t('common.error')}
                </td>
              </tr>
            ) : employees.data.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-4 text-center">
                  <EmptyState title={t('team.empty.title')} body={t('team.empty.body')} />
                </td>
              </tr>
            ) : (
              employees.data.map((employee) => (
                <EmployeeRow key={employee.id} employee={employee} />
              ))
            )}
          </tbody>
        </table>
      </div>

      {isAdmin && <EmployeeAdmin />}
      {isAdmin && <ImportWizard />}
    </div>
  );
}

function EmployeeRow({ employee }: { employee: EmployeeRoutingView }) {
  const t = useT();
  const [expanded, setExpanded] = useState(false);

  const stats = useQuery({
    queryKey: ['employee-analytics', employee.id],
    queryFn: () => api.get<EmployeeAnalyticsData>(`/employees/${employee.id}/analytics?days=30`),
    enabled: expanded,
    retry: false,
  });

  return (
    <>
      <tr className="cursor-pointer" onClick={() => setExpanded(!expanded)}>
        <td>
          <p className="font-semibold text-[var(--fe-ink)] truncate">{employee.fullName}</p>
          <p className="font-mono text-[11px] text-[var(--fe-slate)]" dir="ltr">
            {employee.email}
          </p>
        </td>

        <td>
          {employee.department && <span className="text-[12px] text-[var(--fe-slate)]">{employee.department}</span>}
        </td>

        <td className="hidden sm:table-cell">
          <span className="text-[12px] text-[var(--fe-slate)]">
            {employee.skills.length > 0
              ? employee.skills.map((entry) => entry.skill).join(', ')
              : t('team.noSkills')}
          </span>
        </td>

        <td className="font-mono text-[12px] text-[var(--fe-ink)]" dir="ltr">
          {employee.activeConversationCount}/{employee.maxConcurrentConversations}
        </td>

        <td>
          <StatusChip tone={employee.isOnShift ? 'human' : 'neutral'}>
            {employee.isOnShift ? t('team.onShift') : t('team.offShift')}
          </StatusChip>
        </td>
        
        <td>
          <StatusChip
            tone={
              employee.availabilityStatus === 'ONLINE' || employee.availabilityStatus === 'BUSY'
                ? 'ai'
                : 'neutral'
            }
          >
            {t(`availability.${employee.availabilityStatus}` as StringKey)}
          </StatusChip>
        </td>

        <td className="text-end">
          <svg
            width="12"
            height="12"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className={`text-[var(--fe-slate)] transition-transform inline-block ${expanded ? 'rotate-180' : ''}`}
          >
            <path d="M6 9l6 6 6-6" />
          </svg>
        </td>
      </tr>

      {expanded && (
        <tr>
          <td colSpan={7} className="p-0 border-b border-[var(--fe-hairline)] bg-[var(--fe-surface-raised)]">
            <div className="p-5">
              {stats.isPending ? (
                <Spinner label={t('common.loading')} />
              ) : stats.isError || !stats.data ? (
                <p className="text-xs text-[var(--fe-slate)]">{t('common.error')}</p>
              ) : (
                <div className="flex flex-wrap gap-6 text-xs">
                  <StatItem label={t('analytics.csat')} value={stats.data.csat === null ? '—' : `${stats.data.csat}%`} />
                  <StatItem label={t('analytics.dsat')} value={stats.data.dsat === null ? '—' : `${stats.data.dsat}%`} />
                  <StatItem label={t('analytics.resolveRate')} value={stats.data.resolveRate === null ? '—' : `${stats.data.resolveRate}%`} />
                  <StatItem label={t('analytics.casesResolved')} value={stats.data.casesResolved} />
                  <StatItem
                    label={t('analytics.aht')}
                    value={
                      stats.data.averageHandlingMinutes === null
                        ? '—'
                        : stats.data.averageHandlingMinutes < 60
                          ? `${Math.round(stats.data.averageHandlingMinutes)} min`
                          : `${(stats.data.averageHandlingMinutes / 60).toFixed(1)}h`
                    }
                  />
                  <StatItem
                    label={t('analytics.firstResponse')}
                    value={
                      stats.data.medianFirstResponseMinutes === null
                        ? '—'
                        : stats.data.medianFirstResponseMinutes < 60
                          ? `${Math.round(stats.data.medianFirstResponseMinutes)} min`
                          : `${(stats.data.medianFirstResponseMinutes / 60).toFixed(1)}h`
                    }
                  />
                </div>
              )}
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

function StatItem({ label, value }: { label: string; value: string | number }) {
  return (
    <div>
      <p className="fe-eyebrow">{label}</p>
      <p className="fe-mono text-sm text-ink" dir="ltr">{value}</p>
    </div>
  );
}

/**
 * The agent's own status time (V1.2 §9 reporting).
 *
 * Changing status happens in the header, where the running timer lives.
 * This is the read side: where the shift actually went.
 */
function StatusTotals() {
  const t = useT();
  const session = useSession();
  const user = session.data as SessionUser | null;

  const totals = useQuery({
    queryKey: ['my-status-totals'],
    queryFn: () => api.get<StatusTotalsView>('/me/status/totals?days=7'),
    enabled: Boolean(user?.employeeId),
    retry: false,
  });

  if (!user?.employeeId || !totals.data || totals.data.totals.length === 0) return null;

  const visibleTotals = totals.data.totals.filter((entry) => entry.status !== 'OFFLINE');

  return (
    <div className="card p-[18px]">
      <div className="pb-[18px] mb-[18px] border-b border-[var(--fe-hairline)]">
        <h3 className="fe-display text-[var(--fe-ink)] text-lg">{t('status.totals')}</h3>
      </div>
      <ul className="flex flex-wrap gap-6">
        {visibleTotals.map((entry) => (
          <li key={entry.status}>
            <p className="sub">{t(`availability.${entry.status}` as StringKey)}</p>
            <p className="font-mono font-medium text-sm text-[var(--fe-ink)] mt-1" dir="ltr">
              {formatHours(entry.seconds)}
            </p>
          </li>
        ))}
      </ul>
    </div>
  );
}

function formatHours(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
}

/**
 * The import wizard (plan §10): upload → preview → errors → confirm.
 *
 * Nothing is written until the admin confirms, and invalid rows are shown
 * with their row numbers rather than dropped — an import that silently
 * skips rows is how a roster ends up quietly short.
 */
function ImportWizard() {
  const t = useT();
  const queryClient = useQueryClient();
  const [preview, setPreview] = useState<ImportPreviewView | null>(null);
  const [result, setResult] = useState<ImportResultView | null>(null);
  const [rows, setRows] = useState<ImportPreviewView['valid']>([]);

  const upload = useMutation({
    mutationFn: (file: File) => {
      const body = new FormData();
      body.append('file', file);
      return api.upload<ImportPreviewView>('/employees/import/preview', body);
    },
    onSuccess: (data) => {
      setPreview(data);
      setRows(data.valid);
      setResult(null);
    },
  });

  const commit = useMutation({
    mutationFn: () =>
      api.post<ImportResultView>('/employees/import', {
        employees: rows.map((row) => ({
          email: row.email,
          fullName: row.fullName,
          department: row.department,
          skills: [],
        })),
        projectIds: [],
      }),
    onSuccess: (data) => {
      setResult(data);
      setPreview(null);
      void queryClient.invalidateQueries({ queryKey: ['team'] });
    },
  });

  const onFile = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) upload.mutate(file);
  };

  return (
    <div className="card p-[18px]">
      <div className="pb-[18px] mb-[18px] border-b border-[var(--fe-hairline)]">
        <h3 className="fe-display text-[var(--fe-ink)] text-lg">{t('import.title')}</h3>
      </div>
      <p className="mb-3 max-w-xl text-sm text-[var(--fe-slate)]">{t('import.body')}</p>

      <input
        type="file"
        accept=".csv,.xlsx"
        aria-label={t('import.choose')}
        onChange={onFile}
        className="block w-full max-w-md text-sm text-[var(--fe-slate)] file:me-3 file:rounded file:border file:border-[var(--fe-hairline)] file:bg-[var(--fe-surface)] file:px-3 file:py-1.5 file:text-sm file:text-[var(--fe-ink)]"
      />

      {upload.isPending && <Spinner label={t('common.loading')} />}
      {upload.isError && (
        <p className="mt-2 text-xs text-[var(--fe-danger)]">{(upload.error as Error).message}</p>
      )}

      {preview && (
        <div className="mt-4 flex flex-col gap-3">
          <div className="flex gap-3 text-xs">
            <StatusChip tone="human">
              {t('import.valid')} {preview.valid.length}
            </StatusChip>
            {preview.invalid.length > 0 && (
              <StatusChip tone="danger">
                {t('import.invalid')} {preview.invalid.length}
              </StatusChip>
            )}
            {preview.duplicates.length > 0 && (
              <StatusChip tone="escalated">
                {t('import.duplicates')} {preview.duplicates.length}
              </StatusChip>
            )}
          </div>

          {preview.invalid.length > 0 && (
            <ul className="flex flex-col gap-1 rounded border border-[var(--fe-hairline)] p-2">
              {preview.invalid.slice(0, 20).map((row) => (
                <li key={row.rowNumber} className="text-xs text-[var(--fe-danger)]">
                  {t('import.row')} {row.rowNumber}: {row.errors.join('; ')}
                </li>
              ))}
            </ul>
          )}

          {preview.duplicates.length > 0 && (
            <ul className="flex flex-col gap-1 rounded border border-[var(--fe-hairline)] p-2">
              {preview.duplicates.slice(0, 20).map((row) => (
                <li key={row.rowNumber} className="fe-mono text-xs text-[var(--fe-slate)]" dir="ltr">
                  {t('import.row')} {row.rowNumber}: {row.email}
                </li>
              ))}
            </ul>
          )}

          <div className="flex items-center gap-3 mt-2">
            <Button
              variant="primary"
              loading={commit.isPending}
              disabled={rows.length === 0}
              onClick={() => commit.mutate()}
            >
              {t('import.confirm')} ({rows.length})
            </Button>
            <span className="text-xs text-[var(--fe-slate)]">{t('import.passwordNote')}</span>
          </div>
        </div>
      )}

      {result && (
        <p className="mt-3 text-sm text-signal">
          {t('import.done')}: {result.created}
        </p>
      )}
    </div>
  );
}
