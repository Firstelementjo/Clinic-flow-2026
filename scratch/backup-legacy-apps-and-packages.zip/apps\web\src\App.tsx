import { Navigate, Route, Routes } from 'react-router-dom';
import { DirectionProvider, Spinner } from '@firstelement/ui';
import { useLocale } from './lib/locale';
import { useSession } from './lib/session';
import { LoginPage } from './routes/LoginPage';
import { AppShell } from './routes/AppShell';
import { DashboardPage } from './routes/DashboardPage';
import { InboxPage } from './routes/InboxPage';
import { FollowUpsPage } from './routes/FollowUpsPage';
import { AppointmentsPage } from './routes/AppointmentsPage';
import { DoctorSchedulesPage } from './routes/DoctorSchedulesPage';
import { AiReceptionistPage } from './routes/AiReceptionistPage';
import { PublicConfirmPage } from './routes/PublicConfirmPage';
import { PeoplePage } from './routes/PeoplePage';
import { TasksPage } from './routes/TasksPage';
import { NotesPage } from './routes/NotesPage';
import { TeamPage } from './routes/TeamPage';
import { SettingsPage } from './routes/SettingsPage';
import { PopoutInboxPage } from './routes/PopoutInboxPage';

export function App() {
  const { locale } = useLocale();
  const session = useSession();

  return (
    <DirectionProvider locale={locale}>
      {session.isPending ? (
        <div className="flex h-full items-center justify-center">
          <Spinner />
        </div>
      ) : (
        <Routes>
          <Route
            path="/login"
            element={session.data ? <Navigate to="/app/dashboard" replace /> : <LoginPage />}
          />
          {/*
            Client-side protection is UX only — every one of these routes is
            enforced again server-side (plan §5). A user who edits the URL
            gets an empty screen, not someone else's data.
          */}
          <Route
            path="/app"
            element={session.data ? <AppShell user={session.data} /> : <Navigate to="/login" replace />}
          >
            <Route index element={<Navigate to="/app/dashboard" replace />} />
            <Route path="dashboard" element={<DashboardPage />} />
            <Route path="inbox" element={<InboxPage />} />
            <Route path="appointments" element={<AppointmentsPage />} />
            <Route path="doctors" element={<DoctorSchedulesPage />} />
            <Route path="ai-receptionist" element={<AiReceptionistPage />} />
            <Route path="ai-simulator" element={<Navigate to="/app/ai-receptionist" replace />} />
            <Route path="companies" element={<Navigate to="/app/dashboard" replace />} />
            <Route path="people" element={<PeoplePage />} />
            <Route path="follow-ups" element={<FollowUpsPage />} />
            <Route path="leads" element={<Navigate to="/app/follow-ups" replace />} />
            <Route path="deals" element={<Navigate to="/app/dashboard" replace />} />
            <Route path="opportunities" element={<Navigate to="/app/dashboard" replace />} />
            <Route path="tasks" element={<TasksPage />} />
            <Route path="notes" element={<NotesPage />} />
            <Route path="team" element={<TeamPage />} />
            <Route path="workflows" element={<Navigate to="/app/dashboard" replace />} />
            <Route path="settings" element={<SettingsPage />} />
          </Route>
          {/* Popout inbox opens in a separate browser window (Salesforce-style). */}
          <Route
            path="/inbox/pop"
            element={session.data ? <PopoutInboxPage /> : <Navigate to="/login" replace />}
          />
          {/* Public Patient 1-Click Confirmation Landing Pages */}
          <Route path="/confirm/:token" element={<PublicConfirmPage />} />
          <Route path="/appointment-confirmation/:token" element={<PublicConfirmPage />} />

          <Route path="*" element={<Navigate to={session.data ? '/app/dashboard' : '/login'} replace />} />
        </Routes>
      )}
    </DirectionProvider>
  );
}
