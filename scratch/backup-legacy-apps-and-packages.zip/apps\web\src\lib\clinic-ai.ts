import { useMutation, useQuery } from '@tanstack/react-query';
import { api } from './api';

export interface SimulatorChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  suggestedSlots?: string[];
  createdAppointment?: {
    id: string;
    title: string;
    appointmentDate: string;
    status: string;
    service?: string;
    doctorName?: string;
  };
  ticketNumber?: string;
  toolExecutions?: ToolExecutionRecord[];
}

export interface ToolExecutionRecord {
  toolName: string;
  status: 'SUCCESS' | 'WARNING' | 'ERROR';
  description: string;
  input: Record<string, any>;
  output: Record<string, any>;
  executionTimeMs: number;
}

export interface SimulatorChatRequest {
  message: string;
  conversationHistory?: Array<{ role: 'user' | 'assistant'; content: string }>;
  locale?: 'en' | 'ar';
  projectId?: string;
  customerId?: string;
  patientName?: string;
  patientPhone?: string;
  preferredDoctorId?: string;
  preferredProcedureId?: string;
}

export interface SimulatorChatResponse {
  reply: string;
  intent: 'BOOK_APPOINTMENT' | 'CHECK_AVAILABILITY' | 'RESCHEDULE' | 'CANCEL' | 'GENERAL_INQUIRY';
  entities: {
    doctorName?: string;
    doctorId?: string;
    procedureName?: string;
    procedureId?: string;
    targetDateStr?: string;
    targetTimeStr?: string;
    targetIsoDateTime?: string;
  };
  toolExecutions: ToolExecutionRecord[];
  suggestedSlots?: string[];
  createdAppointment?: any;
  ticketNumber?: string;
  locale: 'en' | 'ar';
}

export interface DoctorOption {
  id: string;
  name: string;
  specialty: string;
  workingDays: number[];
  workingHours: string;
  slotDuration: number;
}

export interface ProcedureOption {
  id: string;
  name: string;
  specialty: string;
  durationMinutes: number;
  price: number;
}

export function useClinicDoctors() {
  return useQuery({
    queryKey: ['clinic', 'doctors'],
    queryFn: () => api.get<DoctorOption[]>('/clinic/doctors'),
  });
}

export function useClinicProcedures() {
  return useQuery({
    queryKey: ['clinic', 'procedures'],
    queryFn: () => api.get<ProcedureOption[]>('/clinic/procedures'),
  });
}

export function useSendSimulatorMessage() {
  return useMutation({
    mutationFn: (data: SimulatorChatRequest) =>
      api.post<SimulatorChatResponse>('/clinic/ai-simulator/chat', data),
  });
}
