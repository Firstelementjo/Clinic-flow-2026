import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { Subject, filter, map, type Observable } from 'rxjs';
import type { DomainEvent } from '@firstelement/events';

export interface RealtimeFrame {
  type: string;
  payload: unknown;
  /** Set for user-targeted frames (notifications). */
  userId?: string;
  /** Set for project-scoped frames (conversation updates). */
  projectId?: string;
  organizationId?: string;
}

/**
 * Realtime fan-out over Server-Sent Events (plan §11).
 *
 * SSE rather than WebSockets: every event in this product flows
 * server→client, browsers reconnect automatically, and it rides the
 * existing cookie auth and CORS setup instead of needing a second
 * authentication path. Nothing here needs client→server frames — the
 * client has a REST API for that.
 *
 * One process holds one in-memory subject. That is correct for a single
 * API instance and is the known limit: with several instances behind a
 * load balancer, a client connected to instance A misses events published
 * on instance B, and this needs a Redis pub/sub bridge. Documented in
 * docs/deployment.md rather than quietly assumed away.
 */
@Injectable()
export class RealtimeGateway {
  private readonly frames = new Subject<RealtimeFrame>();

  publishToUser(userId: string, frame: Omit<RealtimeFrame, 'userId'>): void {
    this.frames.next({ ...frame, userId });
  }

  publishToProject(
    organizationId: string,
    projectId: string,
    frame: Omit<RealtimeFrame, 'projectId' | 'organizationId'>,
  ): void {
    this.frames.next({ ...frame, organizationId, projectId });
  }

  /**
   * Mirrors conversation-level domain events onto the stream so open
   * inboxes update without polling.
   *
   * Payloads carry ids and states, never message content — a browser tab
   * left open in a shared office is not a place to push customer text
   * that the viewer may not be scoped to read.
   */
  @OnEvent('conversation.*')
  onConversationEvent(event: DomainEvent): void {
    this.publishToProject(event.organizationId, event.projectId, {
      type: event.type,
      payload: { conversationId: event.aggregateId, occurredAt: event.occurredAt },
    });
  }

  @OnEvent('message.created')
  onMessage(event: DomainEvent): void {
    this.publishToProject(event.organizationId, event.projectId, {
      type: event.type,
      payload: { messageId: event.aggregateId, occurredAt: event.occurredAt },
    });
  }

  /**
   * The stream one viewer sees: their own user-targeted frames, plus
   * project frames for projects they can access. Filtering happens here,
   * server-side — the client is never sent something it must be trusted
   * to ignore.
   */
  streamFor(viewer: {
    userId: string;
    organizationId: string;
    projectIds: readonly string[];
  }): Observable<{ data: string }> {
    const projects = new Set(viewer.projectIds);

    return this.frames.pipe(
      filter((frame) => {
        if (frame.userId) return frame.userId === viewer.userId;
        if (frame.organizationId !== viewer.organizationId) return false;
        return frame.projectId ? projects.has(frame.projectId) : true;
      }),
      map((frame) => ({
        data: JSON.stringify({ type: frame.type, payload: frame.payload }),
      })),
    );
  }
}
