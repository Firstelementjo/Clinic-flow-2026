import 'reflect-metadata';
import { Logger, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import cookieParser from 'cookie-parser';
import { json, type NextFunction, type Request, type Response } from 'express';
import helmet from 'helmet';
import type { RawBodyRequest } from './channels/webhook.types';
import { getConfig } from '@firstelement/config';
import { AppModule } from './app.module';

async function bootstrap(): Promise<void> {
  // Fails fast on a bad environment rather than at the first request.
  const config = getConfig();

  const app = await NestFactory.create(AppModule, {
    logger: config.isProduction ? ['error', 'warn', 'log'] : ['error', 'warn', 'log', 'debug'],
  });

  app.setGlobalPrefix('api');
  
  if (config.isProduction) {
    // Redirect HTTP to HTTPS in production
    app.use((req: Request, res: Response, next: NextFunction) => {
      if (req.header('x-forwarded-proto') !== 'https' && !req.secure) {
        res.redirect(`https://${req.hostname}${req.originalUrl}`);
      } else {
        next();
      }
    });
  }

  app.use(helmet({
    hsts: config.isProduction ? { maxAge: 31536000, includeSubDomains: true, preload: true } : false,
  }));
  app.use(cookieParser(config.SESSION_SECRET));

  // Webhook signatures are computed over the bytes as sent. Verifying a
  // re-serialized JSON.parse result produces a different digest — key
  // order and whitespace differ — so the raw body is kept for the
  // signature check (see packages/connectors/src/meta/signature.ts).
  app.use(
    json({
      limit: '1mb',
      verify: (request, _response, buffer) => {
        (request as RawBodyRequest).rawBody = Buffer.from(buffer);
      },
    }),
  );
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  // Cookie auth demands an explicit origin allowlist — `*` with
  // credentials is both invalid and a CSRF footgun.
  app.enableCors({
    origin: [config.WEB_ORIGIN],
    credentials: true,
  });

  app.enableShutdownHooks();

  await app.listen(config.API_PORT);
  new Logger('Bootstrap').log(`FirstElement API listening on port ${config.API_PORT}`);
}

void bootstrap();
