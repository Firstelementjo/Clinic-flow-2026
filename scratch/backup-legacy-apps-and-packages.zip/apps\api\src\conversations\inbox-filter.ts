import type { Prisma } from '@firstelement/database';
import { InboxFilter, type ChannelType } from '@firstelement/shared';

/**
 * Translates a saved inbox view into a query fragment (plan §14).
 *
 * Kept as a pure function, separate from the service, because these
 * are the definitions an operator's whole day depends on — "unassigned"
 * must mean the same thing in the list, the counts and the analytics —
 * and a pure function is testable without a database.
 *
 * The caller always spreads a tenant scope alongside the result; this
 * function never returns tenant columns and must never be used alone.
 */
export function buildInboxWhere(params: {
  filter: InboxFilter;
  /** Used by ASSIGNED_TO_ME: assignment points at an Employee, not a User. */
  userId: string;
  channel?: ChannelType;
  search?: string;
}): Prisma.ConversationWhereInput {
  const where: Prisma.ConversationWhereInput = {};

  switch (params.filter) {
    case InboxFilter.ASSIGNED_TO_ME:
      // Active conversations assigned to this employee OR where they were the last human replier
      where.AND = [
        { status: { in: ['OPEN', 'PENDING'] } },
        { OR: [
          { assignedEmployee: { is: { userId: params.userId } } },
          { lastReplierUserId: params.userId },
        ]},
      ];
      break;
    case InboxFilter.HISTORY:
      // Resolved/closed conversations where this employee was involved
      where.AND = [
        { status: { in: ['RESOLVED', 'CLOSED'] } },
        { OR: [
          { assignedEmployee: { is: { userId: params.userId } } },
          { lastReplierUserId: params.userId },
        ]},
      ];
      break;
  }

  if (params.channel) where.channel = params.channel;

  const search = params.search?.trim();
  if (search) {
    const searchOR: Prisma.ConversationWhereInput[] = [
      { ticketNumber: { contains: search, mode: 'insensitive' } },
      { subject: { contains: search, mode: 'insensitive' } },
      { customer: { is: { cxId: { contains: search, mode: 'insensitive' } } } },
      { messages: { some: { body: { contains: search, mode: 'insensitive' } } } },
    ];
    if (where.AND) {
      (where.AND as Prisma.ConversationWhereInput[]).push({ OR: searchOR });
    } else {
      where.OR = searchOR;
    }
  }

  return where;
}
