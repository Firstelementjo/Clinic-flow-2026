import { Global, Module } from '@nestjs/common';
import { KnowledgeModule } from '../knowledge/knowledge.module';
import { AIOrchestratorProvider, EscalationEngineProvider } from './ai.providers';
import { AgentsService } from './agents.service';
import { AgentsController } from './agents.controller';
import { AIRunsController } from './ai-runs.controller';

@Global()
@Module({
  imports: [KnowledgeModule],
  controllers: [AgentsController, AIRunsController],
  providers: [AIOrchestratorProvider, EscalationEngineProvider, AgentsService],
  exports: [AIOrchestratorProvider, EscalationEngineProvider, AgentsService],
})
export class AIModule {}
