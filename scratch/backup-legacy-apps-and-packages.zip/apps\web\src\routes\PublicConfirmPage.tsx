import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import {
  Calendar,
  Check,
  Clock,
  HeartPulse,
  MapPin,
  RefreshCw,
  ShieldCheck,
  Stethoscope,
  X,
  Phone,
  CheckCircle2,
} from 'lucide-react';
import { Spinner } from '@firstelement/ui';

interface PublicAppointmentData {
  id: string;
  title: string;
  patientName?: string | null;
  patientPhone?: string | null;
  doctorName?: string | null;
  service?: string | null;
  appointmentDate: string;
  durationMinutes: number;
  status: string;
  reminderStatus: string;
  actionToken: string;
}

export function PublicConfirmPage() {
  const { token } = useParams<{ token: string }>();
  const [submittedAction, setSubmittedAction] = useState<string | null>(null);

  const { data: appointment, isPending, isError } = useQuery<PublicAppointmentData>({
    queryKey: ['public', 'appointment', token],
    queryFn: async () => {
      const res = await fetch(`/api/public/appointments/${token}`);
      if (!res.ok) throw new Error('Appointment link invalid or expired');
      return res.json();
    },
    enabled: !!token,
  });

  const respondMutation = useMutation({
    mutationFn: async (action: 'CONFIRM' | 'RESCHEDULE' | 'CANCEL') => {
      const res = await fetch(`/api/public/appointments/${token}/respond`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      if (!res.ok) throw new Error('Failed to record response');
      return res.json();
    },
    onSuccess: (data, action) => {
      setSubmittedAction(action);
    },
  });

  if (isPending) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <Spinner label="Loading your appointment details..." />
      </div>
    );
  }

  if (isError || !appointment) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full rounded-2xl bg-white p-8 text-center shadow-lg border border-slate-200 space-y-4">
          <div className="h-12 w-12 rounded-full bg-danger-wash text-danger flex items-center justify-center mx-auto">
            <X className="h-6 w-6" />
          </div>
          <h2 className="text-lg font-bold text-slate-900">Appointment Link Expired or Not Found</h2>
          <p className="text-xs text-slate-500">
            This confirmation link may have expired or was already updated. Please contact the clinic directly.
          </p>
        </div>
      </div>
    );
  }

  const apptDate = new Date(appointment.appointmentDate);
  const formattedDate = apptDate.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
  const formattedTime = apptDate.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0f5b4c]/10 via-slate-50 to-slate-100 flex items-center justify-center p-4 font-sans text-slate-800">
      <div className="max-w-md w-full rounded-3xl bg-white shadow-xl border border-slate-200/80 overflow-hidden">
        {/* Brand Banner */}
        <div className="bg-[#0f5b4c] text-white p-6 text-center space-y-2">
          <div className="h-12 w-12 rounded-2xl bg-white/15 backdrop-blur-xs flex items-center justify-center mx-auto text-white">
            <HeartPulse className="h-6 w-6" />
          </div>
          <h1 className="text-lg font-bold">Clinic Flow Care</h1>
          <p className="text-xs text-agent">Patient Appointment Confirmation Portal</p>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6">
          {submittedAction ? (
            <div className="text-center py-6 space-y-3 animate-in fade-in duration-300">
              <div className="h-14 w-14 rounded-full bg-agent-wash text-agent flex items-center justify-center mx-auto">
                <CheckCircle2 className="h-8 w-8" />
              </div>
              <h2 className="text-lg font-bold text-slate-900">
                {submittedAction === 'CONFIRM'
                  ? 'Attendance Confirmed!'
                  : submittedAction === 'RESCHEDULE'
                  ? 'Reschedule Request Received'
                  : 'Appointment Cancelled'}
              </h2>
              <p className="text-xs text-slate-600 max-w-xs mx-auto leading-relaxed">
                {submittedAction === 'CONFIRM'
                  ? 'Thank you for confirming. Your clinician has been notified and your slot is guaranteed.'
                  : submittedAction === 'RESCHEDULE'
                  ? 'Our AI clinic coordinator will reach out shortly with alternative available time slots.'
                  : 'Your booking has been cancelled and the time slot was released. Feel free to re-book anytime.'}
              </p>
            </div>
          ) : (
            <>
              {/* Patient & Doctor Greeting */}
              <div>
                <p className="text-xs text-slate-500">Hello,</p>
                <h2 className="text-base font-bold text-slate-900">
                  {appointment.patientName || 'Valued Patient'}
                </h2>
                <p className="text-xs text-slate-600 mt-1">
                  Please review your upcoming clinic appointment and confirm your attendance below:
                </p>
              </div>

              {/* Consultation Details Card */}
              <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 space-y-3 text-xs">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-xl bg-[#0f5b4c]/10 text-[#0f5b4c] flex items-center justify-center shrink-0">
                    <Stethoscope className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-semibold">Doctor & Specialty</span>
                    <span className="font-bold text-slate-900 text-sm">
                      {appointment.doctorName || 'Dr. Sarah Al-Ahmad'}
                    </span>
                  </div>
                </div>

                <div className="border-t border-slate-200 pt-3 grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Procedure</span>
                    <span className="font-semibold text-slate-800">
                      {appointment.service || appointment.title}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Duration</span>
                    <span className="font-semibold text-slate-800">
                      {appointment.durationMinutes} Minutes
                    </span>
                  </div>
                </div>

                <div className="border-t border-slate-200 pt-3 space-y-1.5 text-xs">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Calendar className="h-4 w-4 text-[#0f5b4c] shrink-0" />
                    <span className="font-medium">{formattedDate}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <Clock className="h-4 w-4 text-[#0f5b4c] shrink-0" />
                    <span className="font-medium">{formattedTime}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                    <MapPin className="h-4 w-4 text-slate-400 shrink-0" />
                    <span>Clinic Flow Medical Tower, Suite 402</span>
                  </div>
                </div>
              </div>

              {/* 1-Click Action Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  disabled={respondMutation.isPending}
                  onClick={() => respondMutation.mutate('CONFIRM')}
                  className="w-full py-3 px-4 rounded-xl bg-[#0f5b4c] hover:bg-[#0c4a3e] active:scale-[0.99] text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <Check className="h-4 w-4" />
                  <span>Confirm My Attendance</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={respondMutation.isPending}
                    onClick={() => respondMutation.mutate('RESCHEDULE')}
                    className="py-2.5 px-3 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw className="h-3.5 w-3.5 text-warning" />
                    <span>Request Reschedule</span>
                  </button>

                  <button
                    type="button"
                    disabled={respondMutation.isPending}
                    onClick={() => respondMutation.mutate('CANCEL')}
                    className="py-2.5 px-3 rounded-xl border border-danger bg-danger-wash hover:bg-danger text-danger font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    <X className="h-3.5 w-3.5" />
                    <span>Cancel Booking</span>
                  </button>
                </div>
              </div>
            </>
          )}

          {/* Clinic Help / Phone */}
          <div className="border-t border-slate-100 pt-4 text-center text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
            <Phone className="h-3.5 w-3.5" />
            <span>Need help? Call Reception: +966 11 456 7890</span>
          </div>
        </div>
      </div>
    </div>
  );
}
