import { Body, Controller, Get, Param, ParseUUIDPipe, Patch, Post, Put, Req } from '@nestjs/common';
import type { Request } from 'express';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import {
  createChannelConnectionSchema,
  setChannelCredentialsSchema,
  updateChannelConnectionSchema,
  type CreateChannelConnectionInput,
  type SetChannelCredentialsInput,
  type UpdateChannelConnectionInput,
} from '@firstelement/shared';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { ChannelsService } from './channels.service';

@Controller('projects/:projectId/channels')
export class ChannelsController {
  constructor(private readonly channels: ChannelsService) {}

  @Get()
  @RequirePermissions(Permission.CHANNEL_READ)
  list(@Tenant() ctx: TenantContext, @Param('projectId', ParseUUIDPipe) projectId: string) {
    return this.channels.list(ctx, projectId);
  }

  @Post()
  @RequirePermissions(Permission.CHANNEL_MANAGE)
  create(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Body(zodBody(createChannelConnectionSchema)) body: CreateChannelConnectionInput,
    @Req() request: Request,
  ) {
    return this.channels.create(ctx, projectId, body, request.ip);
  }

  /**
   * Stores credentials. Write-only by design: there is no GET that
   * returns them, and the response is the same public view as everywhere
   * else.
   */
  @Put(':connectionId/credentials')
  @RequirePermissions(Permission.CHANNEL_MANAGE)
  setCredentials(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('connectionId', ParseUUIDPipe) connectionId: string,
    @Body(zodBody(setChannelCredentialsSchema)) body: SetChannelCredentialsInput,
    @Req() request: Request,
  ) {
    return this.channels.setCredentials(
      ctx,
      projectId,
      connectionId,
      body.credentials,
      request.ip,
    );
  }

  @Patch(':connectionId')
  @RequirePermissions(Permission.CHANNEL_MANAGE)
  update(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('connectionId', ParseUUIDPipe) connectionId: string,
    @Body(zodBody(updateChannelConnectionSchema)) body: UpdateChannelConnectionInput,
    @Req() request: Request,
  ) {
    return this.channels.update(ctx, projectId, connectionId, body, request.ip);
  }
}
