import { useState, type FormEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button, Field, Panel, Spinner, StatusChip } from '@firstelement/ui';
import { UserRole, type CreateEmployeeInput } from '@firstelement/shared';
import { api, ApiError } from '../lib/api';
import { useT } from '../lib/i18n';

interface EmployeeRow {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
  isActive: boolean;
  employee: {
    department: string | null;
    maxConcurrentConversations: number;
    activeConversationCount: number;
  } | null;
  memberships: { projectId: string }[];
}

interface ProjectRow {
  id: string;
  name: string;
}

/**
 * Employee administration (V1.2 §1, §4, §5).
 *
 * Everything the spec asks an admin to do without touching the database:
 * create the account and its credentials, activate or deactivate it,
 * assign and reassign projects, and set each agent's conversation limit.
 */
export function EmployeeAdmin() {
  const t = useT();
  const [creating, setCreating] = useState(false);

  const employees = useQuery({
    queryKey: ['employees'],
    queryFn: () => api.get<EmployeeRow[]>('/employees'),
  });

  const projects = useQuery({
    queryKey: ['projects'],
    queryFn: () => api.get<ProjectRow[]>('/projects'),
  });

  return (
    <div className="flex flex-col gap-4">
      <Panel
        eyebrow={t('team.eyebrow')}
        title={t('admin.employees')}
        flush
        actions={
          !creating && (
            <Button size="sm" variant="primary" onClick={() => setCreating(true)}>
              {t('admin.newEmployee')}
            </Button>
          )
        }
      >
        {employees.isPending ? (
          <div className="p-4">
            <Spinner label={t('common.loading')} />
          </div>
        ) : employees.isError ? (
          <p className="p-4 text-sm text-slate">{t('common.error')}</p>
        ) : (
          <ul className="divide-y divide-hairline">
            {employees.data.map((employee) => (
              <EmployeeRowEditor
                key={employee.id}
                employee={employee}
                projects={projects.data ?? []}
              />
            ))}
          </ul>
        )}
      </Panel>

      {creating && (
        <CreateEmployee projects={projects.data ?? []} onDone={() => setCreating(false)} />
      )}
    </div>
  );
}

function EmployeeRowEditor({
  employee,
  projects,
}: {
  employee: EmployeeRow;
  projects: ProjectRow[];
}) {
  const t = useT();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [limit, setLimit] = useState(employee.employee?.maxConcurrentConversations ?? 5);
  const [projectIds, setProjectIds] = useState(employee.memberships.map((m) => m.projectId));

  const update = useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      api.patch<EmployeeRow>(`/employees/${employee.id}`, body),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['employees'] });
      void queryClient.invalidateQueries({ queryKey: ['team'] });
    },
  });

  const remove = useMutation({
    mutationFn: () => api.delete(`/employees/${employee.id}`),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['employees'] });
      void queryClient.invalidateQueries({ queryKey: ['team'] });
    },
  });

  return (
    <li className="flex flex-col gap-2 px-4 py-2.5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm text-ink">{employee.fullName}</p>
          <p className="fe-mono text-xs text-slate" dir="ltr">
            {employee.email}
          </p>
        </div>

        <StatusChip tone={employee.role === 'ADMIN' ? 'human' : 'neutral'}>
          {employee.role}
        </StatusChip>
        <StatusChip tone={employee.isActive ? 'ai' : 'danger'}>
          {employee.isActive ? t('admin.active') : t('admin.inactive')}
        </StatusChip>

        {/* Load against the configured ceiling — the §5 limit in context. */}
        <span className="fe-mono text-xs text-slate" dir="ltr">
          {employee.employee?.activeConversationCount ?? 0}/
          {employee.employee?.maxConcurrentConversations ?? 0}
        </span>

        <Button size="sm" variant="ghost" onClick={() => setOpen(!open)}>
          {open ? t('case.hide') : t('admin.manage')}
        </Button>
      </div>

      {open && (
        <div className="flex flex-col gap-3 rounded border border-hairline bg-mist/30 p-3">
          <div className="flex flex-wrap items-end gap-3">
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium text-ink-soft">{t('admin.limit')}</span>
              <input
                type="number"
                min={1}
                max={200}
                value={limit}
                onChange={(e) => setLimit(Number(e.target.value))}
                className="h-8 w-24 rounded border border-hairline bg-surface px-2 text-xs text-ink"
                dir="ltr"
              />
            </label>

            <Button
              size="sm"
              variant="primary"
              loading={update.isPending}
              onClick={() => update.mutate({ maxConcurrentConversations: limit })}
            >
              {t('admin.saveLimit')}
            </Button>

            <Button
              size="sm"
              variant={employee.isActive ? 'danger' : 'secondary'}
              loading={update.isPending}
              onClick={() => update.mutate({ isActive: !employee.isActive })}
            >
              {employee.isActive ? t('admin.deactivate') : t('admin.activate')}
            </Button>

            {!employee.isActive && (
              <Button
                size="sm"
                variant="danger"
                loading={remove.isPending}
                onClick={() => {
                  if (window.confirm(t('admin.deleteConfirm'))) remove.mutate();
                }}
              >
                {t('admin.delete')}
              </Button>
            )}
          </div>

          <div>
            <p className="fe-eyebrow mb-1.5">{t('admin.projects')}</p>
            <ul className="flex flex-wrap gap-3">
              {projects.map((project) => (
                <li key={project.id}>
                  <label className="flex items-center gap-1.5 text-xs text-ink">
                    <input
                      type="checkbox"
                      checked={projectIds.includes(project.id)}
                      onChange={(e) =>
                        setProjectIds(
                          e.target.checked
                            ? [...projectIds, project.id]
                            : projectIds.filter((id) => id !== project.id),
                        )
                      }
                    />
                    {project.name}
                  </label>
                </li>
              ))}
            </ul>

            <Button
              size="sm"
              variant="secondary"
              className="mt-2"
              loading={update.isPending}
              onClick={() => update.mutate({ projectIds })}
            >
              {t('admin.saveProjects')}
            </Button>
          </div>

          {update.isError && (
            <p className="text-xs text-danger">{(update.error as Error).message}</p>
          )}
        </div>
      )}
    </li>
  );
}

function CreateEmployee({ projects, onDone }: { projects: ProjectRow[]; onDone: () => void }) {
  const t = useT();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({
    email: '',
    fullName: '',
    password: '',
    role: UserRole.EMPLOYEE as UserRole,
    department: '',
    projectIds: [] as string[],
  });

  const create = useMutation({
    mutationFn: () =>
      api.post<EmployeeRow>('/employees', {
        ...form,
        department: form.department || undefined,
      } satisfies Partial<CreateEmployeeInput>),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['employees'] });
      void queryClient.invalidateQueries({ queryKey: ['team'] });
      onDone();
    },
  });

  const fieldErrors = create.error instanceof ApiError ? create.error.fieldErrors : {};

  return (
    <Panel eyebrow={t('team.eyebrow')} title={t('admin.newEmployee')}>
      <form
        onSubmit={(event: FormEvent) => {
          event.preventDefault();
          create.mutate();
        }}
        className="flex max-w-xl flex-col gap-3"
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <Field
            label={t('login.email')}
            value={form.email}
            dir="ltr"
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            error={fieldErrors.email?.[0]}
            required
          />
          <Field
            label={t('admin.fullName')}
            value={form.fullName}
            onChange={(e) => setForm({ ...form, fullName: e.target.value })}
            error={fieldErrors.fullName?.[0]}
            required
          />
          <Field
            label={t('login.password')}
            type="password"
            autoComplete="new-password"
            value={form.password}
            dir="ltr"
            hint={t('admin.passwordHint')}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            error={fieldErrors.password?.[0]}
            required
          />
          <Field
            label={t('team.department')}
            value={form.department}
            onChange={(e) => setForm({ ...form, department: e.target.value })}
          />
        </div>

        <label className="flex flex-col gap-1">
          <span className="text-xs font-medium text-ink-soft">{t('admin.role')}</span>
          <select
            value={form.role}
            onChange={(e) => setForm({ ...form, role: e.target.value as UserRole })}
            className="h-8 w-40 rounded border border-hairline bg-surface px-2 text-xs text-ink"
          >
            {Object.values(UserRole).map((role) => (
              <option key={role} value={role}>
                {role}
              </option>
            ))}
          </select>
        </label>

        <div>
          <p className="fe-eyebrow mb-1.5">{t('admin.projects')}</p>
          <ul className="flex flex-wrap gap-3">
            {projects.map((project) => (
              <li key={project.id}>
                <label className="flex items-center gap-1.5 text-xs text-ink">
                  <input
                    type="checkbox"
                    checked={form.projectIds.includes(project.id)}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        projectIds: e.target.checked
                          ? [...form.projectIds, project.id]
                          : form.projectIds.filter((id) => id !== project.id),
                      })
                    }
                  />
                  {project.name}
                </label>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex items-center gap-2">
          <Button type="submit" variant="primary" loading={create.isPending}>
            {t('admin.create')}
          </Button>
          <Button type="button" variant="ghost" onClick={onDone}>
            {t('projects.cancel')}
          </Button>
          {create.isError && Object.keys(fieldErrors).length === 0 && (
            <span className="text-xs text-danger">{(create.error as Error).message}</span>
          )}
        </div>
      </form>
    </Panel>
  );
}
