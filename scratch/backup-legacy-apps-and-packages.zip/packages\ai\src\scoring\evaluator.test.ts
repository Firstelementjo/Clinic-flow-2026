import { describe, expect, it } from 'vitest';
import { HeuristicEvaluator, type TurnToScore } from './evaluator';

const evaluator = new HeuristicEvaluator();

function turn(overrides: Partial<TurnToScore> = {}): TurnToScore {
  return {
    text: '',
    previousCustomerTexts: [],
    aiTurnsWithoutResolution: 0,
    lastAIFailed: false,
    locale: 'en',
    ...overrides,
  };
}

describe('normalization', () => {
  it('keeps every signal inside 0–100, so one threshold means one thing', async () => {
    const extreme = await evaluator.evaluate(
      turn({
        text: 'THIS IS ABSOLUTELY UNACCEPTABLE!!! I WANT A MANAGER NOW! REFUND! FRAUD!',
        previousCustomerTexts: ['This is unacceptable', 'This is unacceptable'],
        aiTurnsWithoutResolution: 9,
        lastAIFailed: true,
      }),
    );

    for (const value of [
      extreme.frustration,
      extreme.sentiment,
      extreme.urgency,
      extreme.risk,
      extreme.intentConfidence,
    ]) {
      expect(value).toBeGreaterThanOrEqual(0);
      expect(value).toBeLessThanOrEqual(100);
    }
  });

  it('is deterministic — the same turn always scores the same', async () => {
    const input = turn({ text: 'Where is my order? This is the third time I ask.' });
    const first = await evaluator.evaluate(input);
    const second = await evaluator.evaluate(input);
    expect(first).toEqual(second);
  });
});

describe('frustration', () => {
  it('stays low for a neutral first question', async () => {
    const scores = await evaluator.evaluate(turn({ text: 'How long does delivery take?' }));
    expect(scores.frustration).toBeLessThan(30);
  });

  it('rises for explicit anger', async () => {
    const scores = await evaluator.evaluate(
      turn({ text: 'This is unacceptable and your service is terrible.' }),
    );
    expect(scores.frustration).toBeGreaterThanOrEqual(40);
  });

  it('rises when the customer demands a manager', async () => {
    const calm = await evaluator.evaluate(turn({ text: 'I would like to check my order.' }));
    const demanding = await evaluator.evaluate(
      turn({ text: 'I want to speak to your manager and file a complaint.' }),
    );
    expect(demanding.frustration).toBeGreaterThan(calm.frustration);
  });

  it('climbs with repeated unanswered AI turns, not just with wording', async () => {
    const text = 'I still need help with my order.';
    const early = await evaluator.evaluate(turn({ text, aiTurnsWithoutResolution: 0 }));
    const late = await evaluator.evaluate(turn({ text, aiTurnsWithoutResolution: 4 }));

    // The shape of a customer about to give up is the trend, not the words.
    expect(late.frustration).toBeGreaterThan(early.frustration);
  });

  it('counts a repeated complaint as a stronger signal than a new one', async () => {
    const text = 'My package never arrived and nobody has helped me with this problem';
    const fresh = await evaluator.evaluate(turn({ text }));
    const repeated = await evaluator.evaluate(
      turn({ text, previousCustomerTexts: [text, text] }),
    );
    expect(repeated.frustration).toBeGreaterThan(fresh.frustration);
  });

  it('falls when the customer is thankful', async () => {
    const scores = await evaluator.evaluate(turn({ text: 'Thanks, that was really helpful!' }));
    expect(scores.frustration).toBeLessThan(20);
    expect(scores.sentiment).toBeGreaterThan(60);
  });

  it('reads Arabic anger, not only English', async () => {
    const scores = await evaluator.evaluate(
      turn({ text: 'هذا غير مقبول إطلاقًا! أريد مشرف الآن، تعبت منكم', locale: 'ar' }),
    );
    expect(scores.frustration).toBeGreaterThanOrEqual(50);
  });
});

describe('urgency and risk', () => {
  it('flags urgency from explicit time pressure in both languages', async () => {
    const english = await evaluator.evaluate(turn({ text: 'I need this fixed urgently, today.' }));
    const arabic = await evaluator.evaluate(turn({ text: 'الموضوع عاجل وأحتاجه اليوم', locale: 'ar' }));

    expect(english.urgency).toBeGreaterThan(30);
    expect(arabic.urgency).toBeGreaterThan(30);
  });

  it('raises risk for chargebacks and account closure, not for ordinary questions', async () => {
    const ordinary = await evaluator.evaluate(turn({ text: 'What are your opening hours?' }));
    const risky = await evaluator.evaluate(
      turn({ text: 'I will file a chargeback and close my account — this looks like fraud.' }),
    );

    expect(ordinary.risk).toBeLessThan(20);
    expect(risky.risk).toBeGreaterThan(50);
  });
});

describe('intent', () => {
  it.each([
    ['I want a refund for my order', 'refund'],
    ['Where is my delivery?', 'delivery'],
    ['I was charged twice on my invoice', 'billing'],
    ['The app is not working, I get an error', 'technical'],
    ['وين طلبي؟', 'delivery'],
    ['أريد استرجاع المبلغ', 'refund'],
  ])('classifies %s as %s', async (text, expected) => {
    const scores = await evaluator.evaluate(turn({ text }));
    expect(scores.intent).toBe(expected);
  });

  it('reports low confidence when it recognizes nothing, so a rule can catch it', async () => {
    const scores = await evaluator.evaluate(turn({ text: 'Hmm ok' }));
    expect(scores.intent).toBeNull();
    expect(scores.intentConfidence).toBeLessThan(50);
  });
});

describe('explainability', () => {
  it('records which cues fired, so a score is defensible after the fact', async () => {
    const scores = await evaluator.evaluate(
      turn({ text: 'This is ridiculous, I want a manager!', aiTurnsWithoutResolution: 2 }),
    );

    expect(scores.signals).toMatchObject({ demandsHuman: true, aiTurnsWithoutResolution: 2 });
    expect(scores.evaluator).toBe('heuristic');
  });
});
