import { UserRole } from '@firstelement/shared';

/**
 * RBAC as a first-class module (plan §5).
 *
 * Every capability in the product has a name here, and every guard asks
 * `can()` rather than testing `user.role === 'ADMIN'` inline. Two reasons:
 * a new capability is a one-line change in one file, and the permission
 * matrix is directly testable without booting the API.
 *
 * Role is only half the decision. The other half is project membership,
 * which is why `can()` takes a resource: an EMPLOYEE may read a
 * conversation in a project they belong to and not one they don't, and
 * an ADMIN's reach stops at their own organization.
 */

export const Permission = {
  // organization
  ORGANIZATION_READ: 'organization:read',
  ORGANIZATION_UPDATE: 'organization:update',

  // projects
  PROJECT_READ: 'project:read',
  PROJECT_CREATE: 'project:create',
  PROJECT_UPDATE: 'project:update',
  PROJECT_DELETE: 'project:delete',
  PROJECT_ARCHIVE: 'project:archive',

  // people
  EMPLOYEE_READ: 'employee:read',
  EMPLOYEE_CREATE: 'employee:create',
  EMPLOYEE_UPDATE: 'employee:update',
  EMPLOYEE_DELETE: 'employee:delete',
  EMPLOYEE_IMPORT: 'employee:import',
  EMPLOYEE_SET_OWN_AVAILABILITY: 'employee:set-own-availability',

  // crm
  CUSTOMER_READ: 'customer:read',
  CUSTOMER_UPDATE: 'customer:update',

  // accounts (companies)
  ACCOUNT_READ: 'account:read',
  ACCOUNT_CREATE: 'account:create',
  ACCOUNT_UPDATE: 'account:update',
  ACCOUNT_DELETE: 'account:delete',

  // notes
  NOTE_READ: 'note:read',
  NOTE_CREATE: 'note:create',
  NOTE_UPDATE: 'note:update',
  NOTE_DELETE: 'note:delete',

  // saved list views (the views a workspace keeps per object type)
  VIEW_READ: 'view:read',
  VIEW_MANAGE: 'view:manage',

  // sales pipeline
  LEAD_READ: 'lead:read',
  LEAD_CREATE: 'lead:create',
  LEAD_UPDATE: 'lead:update',
  LEAD_CONVERT: 'lead:convert',
  LEAD_DELETE: 'lead:delete',
  DEAL_READ: 'deal:read',
  DEAL_CREATE: 'deal:create',
  DEAL_UPDATE: 'deal:update',
  DEAL_CLOSE: 'deal:close',
  DEAL_DELETE: 'deal:delete',
  TASK_READ: 'task:read',
  TASK_CREATE: 'task:create',
  TASK_UPDATE: 'task:update',
  TASK_DELETE: 'task:delete',

  // clinic — clinician roster (`apps/api/src/clinic/**`).
  //
  // Every member below is derived from a route that exists, not from a wish list.
  // The mapping is asserted in
  // `backend/crm-core/src/test/legacy-notes-project-scope/clinic-permissions.test.ts`,
  // which fails if a clinic handler changes its permission or if a handler is added
  // with none at all.
  //
  // Split by what each route actually discloses, not by object. `GET /clinic/doctors`
  // returns name, specialty and working hours — what a booking form needs. `GET
  // /clinic/doctors/manage` additionally returns the clinician's email and phone
  // and a count of their appointments, which is contact data plus a workload
  // aggregate. Collapsing the two into one `DOCTOR_READ` would put contact details
  // behind the booking-form grant, so they are separate members.
  DOCTOR_READ: 'doctor:read',
  DOCTOR_READ_MANAGEMENT: 'doctor:read-management',
  DOCTOR_CREATE: 'doctor:create',
  DOCTOR_UPDATE: 'doctor:update',
  DOCTOR_DELETE: 'doctor:delete',

  // clinic — procedure catalog. `PROCEDURE_READ` covers the bookable list and a
  // single procedure's duration; `PROCEDURE_READ_MANAGEMENT` additionally counts
  // the appointments booked against each procedure.
  PROCEDURE_READ: 'procedure:read',
  PROCEDURE_READ_MANAGEMENT: 'procedure:read-management',
  PROCEDURE_CREATE: 'procedure:create',
  PROCEDURE_UPDATE: 'procedure:update',
  PROCEDURE_DELETE: 'procedure:delete',

  // clinic — booking availability. Reading free slots necessarily reveals a
  // clinician's working days and hours and how busy they already are, so it is
  // named for what it authorizes rather than folded into the roster read.
  SCHEDULE_AVAILABILITY_READ: 'schedule:read-availability',

  // clinic — the appointment lifecycle. Cancel is not an update: it releases the
  // slot, appends a cancellation reason to the patient's notes and is what the
  // patient and the reminder chain react to. Reschedule moves the row and returns
  // it to PENDING. They are separate grants because the blast radius is.
  APPOINTMENT_CREATE: 'appointment:create',
  APPOINTMENT_RESCHEDULE: 'appointment:reschedule',
  APPOINTMENT_CANCEL: 'appointment:cancel',

  // clinic — reminders. `REMINDER_READ` returns patient names and phone numbers.
  // `REMINDER_SEND` leaves the building: it is the route that messages a patient.
  // `REMINDER_RECORD_RESPONSE` is the staff-side counterpart to the patient's
  // token link — it writes a CONFIRMED / RESCHEDULE_REQUESTED / CANCELLED status
  // onto an appointment on the patient's behalf.
  REMINDER_READ: 'reminder:read',
  REMINDER_SEND: 'reminder:send',
  REMINDER_RECORD_RESPONSE: 'reminder:record-response',

  // clinic — the AI receptionist simulator. It reads the roster and the catalog
  // and, on a booking intent, **creates an appointment**, so it is booked on the
  // simulator grant *and* on `APPOINTMENT_CREATE`. A grant that could book without
  // saying so would be exactly the mislabelled grant ADR 0010 §2 forbids.
  CLINIC_AI_SIMULATE: 'clinic:simulate-ai',

  // conversations
  CONVERSATION_READ: 'conversation:read',
  CONVERSATION_REPLY: 'conversation:reply',
  CONVERSATION_TAKE_OVER: 'conversation:take-over',
  CONVERSATION_RETURN_TO_AI: 'conversation:return-to-ai',
  CONVERSATION_ASSIGN: 'conversation:assign',
  CONVERSATION_RESOLVE: 'conversation:resolve',

  // ai + knowledge
  AI_AGENT_READ: 'ai-agent:read',
  AI_AGENT_CONFIGURE: 'ai-agent:configure',
  AI_RUN_READ: 'ai-run:read',
  KNOWLEDGE_READ: 'knowledge:read',
  KNOWLEDGE_MANAGE: 'knowledge:manage',

  // channels + rules
  CHANNEL_READ: 'channel:read',
  CHANNEL_MANAGE: 'channel:manage',
  ESCALATION_RULE_READ: 'escalation-rule:read',
  ESCALATION_RULE_MANAGE: 'escalation-rule:manage',
  ROUTING_RULE_MANAGE: 'routing-rule:manage',

  // oversight
  ANALYTICS_READ_PROJECT: 'analytics:read-project',
  ANALYTICS_READ_ORGANIZATION: 'analytics:read-organization',
  AUDIT_LOG_READ: 'audit-log:read',
  SYSTEM_HEALTH_READ: 'system-health:read',
} as const;
export type Permission = (typeof Permission)[keyof typeof Permission];

/**
 * The clinic permissions an `EMPLOYEE` holds, and — more usefully — the ones it
 * does not. Exported so the grant is a testable statement rather than a list buried
 * in an array literal.
 *
 * <h3>What is granted, and why</h3>
 *
 * <p>The clinic surface is a **front desk**. Reading the bookable roster and the
 * procedure catalog, checking a slot, booking, rescheduling and cancelling, and
 * reading or sending reminders is the whole job. An employee who cannot book an
 * appointment cannot work, so denying all of it is not a safe default here — it is an
 * outage wearing a security costume.
 *
 * <h3>What is withheld, and why</h3>
 *
 * <ul>
 *   <li>{@code DOCTOR_READ_MANAGEMENT}, {@code PROCEDURE_READ_MANAGEMENT} — the
 *       management views add clinician email and phone and appointment counts. Contact
 *       data and workload, for a role that does not administer the roster.</li>
 *   <li>{@code DOCTOR_CREATE/UPDATE/DELETE}, {@code PROCEDURE_CREATE/UPDATE/DELETE} —
 *       <b>every</b> roster mutation. A booking clerk edits slots; a clinician
 *       leaving the practice is a clinic-configuration decision with clinical
 *       consequences, and deleting a doctor whose appointments still exist is not a
 *       self-service action.</li>
 *   <li>{@code CLINIC_AI_SIMULATE} — the simulator <em>creates appointments</em>. It
 *       is gated on {@code APPOINTMENT_CREATE} as well, and belongs to a role that
 *       explicitly opted into letting an unreviewed model write to the schedule.</li>
 * </ul>
 *
 * <p>Every withheld permission is ADMIN by construction, because
 * {@code ROLE_PERMISSIONS[ADMIN]} is {@code Object.values(Permission)}.
 */
export const CLINIC_EMPLOYEE_GRANT: readonly Permission[] = [
  Permission.DOCTOR_READ,
  Permission.PROCEDURE_READ,
  Permission.SCHEDULE_AVAILABILITY_READ,
  Permission.APPOINTMENT_CREATE,
  Permission.APPOINTMENT_RESCHEDULE,
  Permission.APPOINTMENT_CANCEL,
  Permission.REMINDER_READ,
  Permission.REMINDER_SEND,
  Permission.REMINDER_RECORD_RESPONSE,
];

/** The clinic permissions held by ADMIN alone. The security-sensitive half. */
export const CLINIC_ADMIN_ONLY: readonly Permission[] = [
  Permission.DOCTOR_READ_MANAGEMENT,
  Permission.PROCEDURE_READ_MANAGEMENT,
  Permission.DOCTOR_CREATE,
  Permission.DOCTOR_UPDATE,
  Permission.DOCTOR_DELETE,
  Permission.PROCEDURE_CREATE,
  Permission.PROCEDURE_UPDATE,
  Permission.PROCEDURE_DELETE,
  Permission.CLINIC_AI_SIMULATE,
];

/**
 * The clinic permissions a `CLINIC_STAFF` principal holds.
 *
 * <h3>What it holds, and why</h3>
 *
 * <p>The booking desk, and only the booking desk: read the bookable roster, read the
 * catalog, check a slot, book, reschedule, cancel, and work the reminder chain. That
 * is {@link CLINIC_EMPLOYEE_GRANT}, unchanged — the front-desk half of an employee's
 * grant is the whole job, so a role that could not book could not work.
 *
 * <h3>What makes the role exist rather than a rename</h3>
 *
 * <p>The point is what it does <em>not</em> hold. {@code EMPLOYEE} holds this same
 * nine <em>plus</em> {@code NOTE_READ}, {@code CUSTOMER_READ}, {@code CONVERSATION_READ},
 * {@code DEAL_READ}, {@code TASK_READ} and the rest of the CRM surface, so before this
 * role the only way to employ a receptionist was to hand a person who books
 * appointments the ability to read every clinical note, customer record and
 * conversation in the organization. Separation is the whole point of the role: a
 * booking clerk must not administer the roster, and must not read clinical notes
 * they have no case for.
 *
 * <p>Concretely, a `CLINIC_STAFF` principal holds <b>none</b> of the CRM read
 * permissions. It is a strict subset of the employee grant, and the assertion
 * {@code clinic-role-grant.test.ts} makes that explicit rather than leaving it to a
 * reader: the grant is the nine, and the nine are all clinic permissions.
 *
 * <h3>What it deliberately withholds</h3>
 *
 * <ul>
 *   <li>Every one of {@link CLINIC_ADMIN_ONLY} — all roster mutation, both management
 *       views, and the AI simulator. A clinician leaving the practice is a
 *       clinic-configuration decision with clinical consequences.</li>
 *   <li>The entire CRM surface. That is the separation, not an oversight.</li>
 * </ul>
 *
 * <p>{@code ADMIN} still holds everything by construction, because
 * {@code ROLE_PERMISSIONS[ADMIN]} is {@code Object.values(Permission)} — so this grant
 * is strictly narrower than {@code EMPLOYEE}, never wider.
 */
export const CLINIC_STAFF_GRANT: readonly Permission[] = [...CLINIC_EMPLOYEE_GRANT];

const EMPLOYEE_PERMISSIONS: readonly Permission[] = [
  Permission.ORGANIZATION_READ,
  Permission.PROJECT_READ,
  Permission.EMPLOYEE_READ,
  Permission.EMPLOYEE_SET_OWN_AVAILABILITY,
  Permission.CUSTOMER_READ,
  Permission.CUSTOMER_UPDATE,
  Permission.ACCOUNT_READ,
  Permission.ACCOUNT_CREATE,
  Permission.ACCOUNT_UPDATE,
  Permission.ACCOUNT_DELETE,
  Permission.NOTE_READ,
  Permission.NOTE_CREATE,
  Permission.NOTE_UPDATE,
  Permission.NOTE_DELETE,
  Permission.VIEW_READ,
  Permission.VIEW_MANAGE,
  Permission.LEAD_READ,
  Permission.LEAD_CREATE,
  Permission.LEAD_UPDATE,
  Permission.LEAD_CONVERT,
  Permission.LEAD_DELETE,
  Permission.DEAL_READ,
  Permission.DEAL_CREATE,
  Permission.DEAL_UPDATE,
  Permission.DEAL_CLOSE,
  Permission.DEAL_DELETE,
  Permission.TASK_READ,
  Permission.TASK_CREATE,
  Permission.TASK_UPDATE,
  Permission.TASK_DELETE,
  Permission.CONVERSATION_READ,
  Permission.CONVERSATION_REPLY,
  Permission.CONVERSATION_TAKE_OVER,
  Permission.CONVERSATION_RETURN_TO_AI,
  Permission.CONVERSATION_ASSIGN,
  Permission.CONVERSATION_RESOLVE,
  Permission.AI_RUN_READ,
  Permission.KNOWLEDGE_READ,
  Permission.ANALYTICS_READ_PROJECT,

  // The clinic front desk. The set, and everything this deliberately withholds, are
  // declared above as CLINIC_EMPLOYEE_GRANT / CLINIC_ADMIN_ONLY so the grant can be
  // asserted in a test instead of read as a comment.
  ...CLINIC_EMPLOYEE_GRANT,
];

const ADMIN_PERMISSIONS: readonly Permission[] = Object.values(Permission);

// The clinic front desk, and nothing else. Strictly narrower than EMPLOYEE: a
// receptionist who can book an appointment must not also be handed every note,
// customer and conversation in the organization. See CLINIC_STAFF_GRANT.
const CLINIC_STAFF_PERMISSIONS: readonly Permission[] = CLINIC_STAFF_GRANT;

export const ROLE_PERMISSIONS: Record<UserRole, readonly Permission[]> = {
  [UserRole.ADMIN]: ADMIN_PERMISSIONS,
  [UserRole.EMPLOYEE]: EMPLOYEE_PERMISSIONS,
  [UserRole.CLINIC_STAFF]: CLINIC_STAFF_PERMISSIONS,
};

export interface PolicyActor {
  userId: string;
  organizationId: string;
  role: UserRole;
  /** Resolved server-side. For ADMIN, every project in the organization. */
  projectIds: readonly string[];
}

export interface PolicyResource {
  organizationId?: string;
  projectId?: string;
  /** For self-service permissions such as setting your own availability. */
  ownerUserId?: string;
}

export function roleHasPermission(role: UserRole, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role].includes(permission);
}

export function can(
  actor: PolicyActor,
  permission: Permission,
  resource: PolicyResource = {},
): boolean {
  if (!roleHasPermission(actor.role, permission)) return false;

  // Organization boundary: no role crosses it, ever.
  if (resource.organizationId && resource.organizationId !== actor.organizationId) {
    return false;
  }

  // Project boundary: membership is required even for an ADMIN, whose
  // membership list simply covers the whole organization.
  if (resource.projectId && !actor.projectIds.includes(resource.projectId)) {
    return false;
  }

  if (permission === Permission.EMPLOYEE_SET_OWN_AVAILABILITY && resource.ownerUserId) {
    return resource.ownerUserId === actor.userId || actor.role === UserRole.ADMIN;
  }

  return true;
}

export class PermissionDeniedError extends Error {
  readonly code = 'FORBIDDEN' as const;

  constructor(
    readonly permission: Permission,
    readonly actor: PolicyActor,
    readonly resource: PolicyResource,
  ) {
    super(`Permission denied: ${permission}`);
    this.name = 'PermissionDeniedError';
  }
}

export function assertCan(
  actor: PolicyActor,
  permission: Permission,
  resource: PolicyResource = {},
): void {
  if (!can(actor, permission, resource)) {
    throw new PermissionDeniedError(permission, actor, resource);
  }
}
