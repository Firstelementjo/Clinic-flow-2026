import { describe, expect, it } from 'vitest';
import { formatWindow, isWithinWorkingHours, toLocalMoment } from './working-hours';

/** 2026-08-16 is a Sunday — the start of the Gulf working week. */
const SUNDAY_0900_RIYADH = new Date('2026-08-16T06:00:00Z');
const SUNDAY_2000_RIYADH = new Date('2026-08-16T17:00:00Z');

const riyadh = (dayOfWeek: number, startMinute: number, endMinute: number) => ({
  dayOfWeek,
  startMinute,
  endMinute,
  timezone: 'Asia/Riyadh',
});

describe('toLocalMoment', () => {
  it('converts an instant into the employee own weekday and minute', () => {
    expect(toLocalMoment(SUNDAY_0900_RIYADH, 'Asia/Riyadh')).toEqual({
      dayOfWeek: 0,
      minuteOfDay: 9 * 60,
    });
  });

  it('gives different answers for different zones at the same instant', () => {
    const riyadhMoment = toLocalMoment(SUNDAY_0900_RIYADH, 'Asia/Riyadh');
    const londonMoment = toLocalMoment(SUNDAY_0900_RIYADH, 'Europe/London');
    expect(riyadhMoment.minuteOfDay).not.toBe(londonMoment.minuteOfDay);
  });

  it('handles a zone that observes daylight saving without a hand-rolled offset', () => {
    // Beirut is UTC+3 in August and UTC+2 in January. Getting this wrong
    // is how working hours quietly break every October.
    const summer = toLocalMoment(new Date('2026-08-16T06:00:00Z'), 'Asia/Beirut');
    const winter = toLocalMoment(new Date('2026-01-18T06:00:00Z'), 'Asia/Beirut');
    expect(summer.minuteOfDay).toBe(9 * 60);
    expect(winter.minuteOfDay).toBe(8 * 60);
  });
});

describe('isWithinWorkingHours', () => {
  it('treats no configured windows as always available', () => {
    // An organization that has not set schedules yet must still receive
    // escalations — the alternative looks like a broken queue.
    expect(isWithinWorkingHours([], SUNDAY_0900_RIYADH)).toBe(true);
  });

  it('matches a window on the right day and time', () => {
    expect(isWithinWorkingHours([riyadh(0, 8 * 60, 17 * 60)], SUNDAY_0900_RIYADH)).toBe(true);
  });

  it('rejects the same window on the wrong day', () => {
    expect(isWithinWorkingHours([riyadh(1, 8 * 60, 17 * 60)], SUNDAY_0900_RIYADH)).toBe(false);
  });

  it('rejects a time outside the window', () => {
    expect(isWithinWorkingHours([riyadh(0, 8 * 60, 17 * 60)], SUNDAY_2000_RIYADH)).toBe(false);
  });

  it('treats the end minute as exclusive, so 17:00–20:00 starts where 08:00–17:00 ends', () => {
    const at1700 = new Date('2026-08-16T14:00:00Z');
    expect(isWithinWorkingHours([riyadh(0, 8 * 60, 17 * 60)], at1700)).toBe(false);
    expect(isWithinWorkingHours([riyadh(0, 17 * 60, 20 * 60)], at1700)).toBe(true);
  });

  it('accepts any of several windows, so a split shift works', () => {
    const windows = [riyadh(0, 8 * 60, 12 * 60), riyadh(0, 16 * 60, 21 * 60)];
    expect(isWithinWorkingHours(windows, SUNDAY_0900_RIYADH)).toBe(true);
    expect(isWithinWorkingHours(windows, SUNDAY_2000_RIYADH)).toBe(true);
    // 14:00 local falls in the gap between the two.
    expect(isWithinWorkingHours(windows, new Date('2026-08-16T11:00:00Z'))).toBe(false);
  });

  it('handles a night shift that crosses midnight', () => {
    const nightShift = [riyadh(0, 22 * 60, 6 * 60)];

    // Sunday 23:00 local — inside the first half.
    expect(isWithinWorkingHours(nightShift, new Date('2026-08-16T20:00:00Z'))).toBe(true);
    // Monday 02:00 local — the tail of Sunday night's shift.
    expect(isWithinWorkingHours(nightShift, new Date('2026-08-16T23:00:00Z'))).toBe(true);
    // Monday 09:00 local — well outside.
    expect(isWithinWorkingHours(nightShift, new Date('2026-08-17T06:00:00Z'))).toBe(false);
  });

  it('respects each window own timezone, not the server clock', () => {
    // The same instant is 09:00 in Riyadh but 07:00 in London (BST), so a
    // 09:00–17:00 London window has not opened yet.
    const londonWindow = [
      { dayOfWeek: 0, startMinute: 9 * 60, endMinute: 17 * 60, timezone: 'Europe/London' },
    ];
    const riyadhWindow = [riyadh(0, 9 * 60, 17 * 60)];

    expect(isWithinWorkingHours(riyadhWindow, SUNDAY_0900_RIYADH)).toBe(true);
    expect(isWithinWorkingHours(londonWindow, SUNDAY_0900_RIYADH)).toBe(false);
  });
});

describe('formatWindow', () => {
  it('renders a window as a readable range', () => {
    expect(formatWindow(riyadh(0, 9 * 60, 17 * 60 + 30))).toBe('09:00–17:30');
  });
});
