import { getConfig, type AppConfig } from '@firstelement/config';
import { AnthropicProvider } from './anthropic.provider';
import { MockAIProvider } from './mock.provider';
import { OpenAIProvider } from './openai.provider';
import { FailoverProvider } from './failover';
import { AIProviderError, type AIProvider, type AIProviderKind } from './types';

export interface AgentProviderConfig {
  provider: AIProviderKind;
  model?: string | null;
  failoverChain?: AIProviderKind[];
}

/**
 * Builds the provider stack for one agent version.
 *
 * API keys are read from server-side configuration, never from agent
 * configuration: an admin editing an agent must not be able to type a key
 * into a field that ends up in an API response (plan §12).
 */
export function createChatProvider(
  agent: AgentProviderConfig,
  config: AppConfig = getConfig(),
): AIProvider {
  const primary = buildProvider(agent.provider, agent.model ?? undefined, config);
  const fallbacks = (agent.failoverChain ?? [])
    .filter((kind) => kind !== agent.provider)
    .map((kind) => tryBuildProvider(kind, config))
    .filter((provider): provider is AIProvider => provider !== null);

  return fallbacks.length > 0 ? new FailoverProvider([primary, ...fallbacks]) : primary;
}

function buildProvider(
  kind: AIProviderKind,
  model: string | undefined,
  config: AppConfig,
): AIProvider {
  switch (kind) {
    case 'MOCK':
      return new MockAIProvider();

    case 'OPENAI':
      if (!config.OPENAI_API_KEY) {
        throw new AIProviderError('OPENAI', 'OPENAI_API_KEY is not configured', false);
      }
      return new OpenAIProvider(config.OPENAI_API_KEY, { model });

    case 'ANTHROPIC':
      if (!config.ANTHROPIC_API_KEY) {
        throw new AIProviderError('ANTHROPIC', 'ANTHROPIC_API_KEY is not configured', false);
      }
      return new AnthropicProvider(config.ANTHROPIC_API_KEY, { model });

    case 'OPENAI_COMPATIBLE':
      if (!config.OPENAI_COMPATIBLE_BASE_URL) {
        throw new AIProviderError(
          'OPENAI_COMPATIBLE',
          'OPENAI_COMPATIBLE_BASE_URL is not configured',
          false,
        );
      }
      return new OpenAIProvider(config.OPENAI_API_KEY ?? 'not-required', {
        model,
        baseUrl: config.OPENAI_COMPATIBLE_BASE_URL,
        kind: 'OPENAI_COMPATIBLE',
      });

    case 'LOCAL':
      if (!config.LOCAL_AI_BASE_URL) {
        throw new AIProviderError('LOCAL', 'LOCAL_AI_BASE_URL is not configured', false);
      }
      return new OpenAIProvider('local', {
        model,
        baseUrl: config.LOCAL_AI_BASE_URL,
        kind: 'LOCAL',
      });

    case 'GEMINI':
      throw new AIProviderError('GEMINI', 'Gemini is not implemented in this build', false);

    default:
      throw new AIProviderError('MOCK', `Unknown provider ${String(kind)}`, false);
  }
}

/**
 * A fallback that cannot be built is dropped from the chain rather than
 * failing the agent: an unconfigured backup should not stop the primary
 * from answering.
 */
function tryBuildProvider(kind: AIProviderKind, config: AppConfig): AIProvider | null {
  try {
    return buildProvider(kind, undefined, config);
  } catch {
    return null;
  }
}
