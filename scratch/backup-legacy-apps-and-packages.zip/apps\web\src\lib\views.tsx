import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { CrmObjectType } from '@firstelement/shared';
import { api } from './api';
import { useSession } from './session';
import { ViewSwitcher } from '../components/ViewSwitcher';

/**
 * A saved view is any JSON snapshot the object grid already understands —
 * `filters` is the text search, `sort` is `{ field, direction }` and
 * `columnConfig` is `{ hidden: string[] }` — so nothing here needs to know
 * what a company, person or task are. The wire types mirror the API.
 */
export interface CrmViewSnapshot {
  filters?: { search?: string };
  sort?: { field?: string };
  columnConfig?: { hidden?: string[] };
}

export interface CrmView {
  id: string;
  objectType: string;
  name: string;
  type: string;
  isDefault: boolean;
  isFavorite: boolean;
  filters: CrmViewSnapshot['filters'] | null;
  sort: CrmViewSnapshot['sort'] | null;
  columnConfig: CrmViewSnapshot['columnConfig'] | null;
  createdById: string | null;
  createdAt: string;
  updatedAt: string;
}

function storageKey(projectId: string, objectType: string) {
  return `fe:crm-view:${projectId}:${objectType}`;
}

function visibleHidden(hidden: Record<string, boolean>): string[] {
  return Object.keys(hidden).filter((key) => hidden[key]);
}

/**
 * The view state a list page binds to: it owns search, sort and the hidden
 * columns, applies a view's snapshot when the active view changes (the
 * default view is always the empty, whole-table state), and auto-saves the
 * live configuration back to the active custom view — debounced, and only
 * when it actually differs. Favorites pin next to the locked default.
 */
export function useCrmViews(objectType: CrmObjectType, options: { noun: string; defaultSort: string }) {
  const session = useSession();
  const projectId = session.data?.projectIds?.[0];
  const queryClient = useQueryClient();

  const [activeViewId, setActiveViewId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState(options.defaultSort);
  const [hidden, setHidden] = useState<Record<string, boolean>>({});

  const viewsKey = ['views', objectType, projectId ?? ''] as const;

  const viewsQuery = useQuery({
    queryKey: viewsKey,
    queryFn: () => api.get<CrmView[]>(`/objects/${objectType}/views?projectId=${projectId}`),
    enabled: Boolean(projectId),
    staleTime: 30_000,
  });
  const views = viewsQuery.data ?? [];

  const key = projectId ? storageKey(projectId, objectType) : null;

  const savedViewId = useMemo(() => {
    if (!key) return null;
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }, [key]);

  const defaultView = useMemo(() => views.find((v) => v.isDefault) ?? null, [views]);
  const activeView =
    views.find((v) => v.id === activeViewId) ??
    (savedViewId ? (views.find((v) => v.id === savedViewId) ?? null) : null) ??
    views.find((v) => v.isFavorite) ??
    defaultView ??
    null;

  // Keep the active selection consistent with what exists, and remember it.
  useEffect(() => {
    if (!activeView || !key) return;
    if (activeViewId !== activeView.id) setActiveViewId(activeView.id);
    try {
      localStorage.setItem(key, activeView.id);
    } catch {
      // Storage may be unavailable (private mode) — the selection still works for this session.
    }
  }, [activeView?.id, activeViewId, key]);

  // Applying a view's snapshot to the toolbar state. Keyed on the id so a
  // refetch that returns the same view does not clobber mid-edit state.
  useEffect(() => {
    if (!activeView) return;
    if (activeView.isDefault) {
      setSearch('');
      setSort(options.defaultSort);
      setHidden({});
    } else {
      setSearch(activeView.filters?.search ?? '');
      setSort(activeView.sort?.field ?? options.defaultSort);
      setHidden(Object.fromEntries((activeView.columnConfig?.hidden ?? []).map((h) => [h, true])));
    }
  }, [activeView?.id, options.defaultSort]);

  const currentSnapshot = (): CrmViewSnapshot => ({
    filters: search.trim() ? { search: search.trim() } : undefined,
    sort: { field: sort },
    columnConfig: { hidden: visibleHidden(hidden) },
  });

  const mergeView = (updated: CrmView) => {
    queryClient.setQueryData<CrmView[]>(viewsKey, (old) => {
      const list = old ?? [];
      return list.some((v) => v.id === updated.id)
        ? list.map((v) => (v.id === updated.id ? updated : v))
        : [...list, updated];
    });
  };

  const saveView = useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: CrmViewSnapshot }) =>
      api.patch<CrmView>(`/views/${id}`, patch),
    onSuccess: mergeView,
  });

  // Debounced auto-save of the live configuration to the active custom view.
  useEffect(() => {
    if (!activeView || activeView.isDefault || !projectId) return;
    const patch = currentSnapshot();
    const stored = JSON.stringify({
      filters: activeView.filters ?? {},
      sort: activeView.sort ?? {},
      columnConfig: activeView.columnConfig ?? {},
    });
    if (stored === JSON.stringify(patch)) return;
    const timer = setTimeout(() => {
      saveView.mutate({ id: activeView.id, patch });
    }, 700);
    return () => clearTimeout(timer);
  }, [search, sort, hidden, activeView?.id, projectId, key]);

  const createView = useMutation({
    mutationFn: (name: string) =>
      api.post<CrmView>(`/objects/${objectType}/views?projectId=${projectId}`, {
        name,
        type: 'table',
        ...currentSnapshot(),
      }),
    onSuccess: (created) => {
      mergeView(created);
      selectView(created.id);
    },
  });

  const renameView = useMutation({
    mutationFn: ({ id, name }: { id: string; name: string }) =>
      api.patch<CrmView>(`/views/${id}`, { name }),
    onSuccess: mergeView,
  });

  const toggleFavorite = useMutation({
    mutationFn: ({ id, favorite }: { id: string; favorite: boolean }) =>
      api.patch<CrmView>(`/views/${id}`, { isFavorite: favorite }),
    onSuccess: mergeView,
  });

  const deleteView = useMutation({
    mutationFn: (id: string) => api.delete<{ id: string }>(`/views/${id}`),
    onSuccess: (_res, id) => {
      queryClient.setQueryData<CrmView[]>(viewsKey, (old) => (old ?? []).filter((v) => v.id !== id));
      if (key) {
        try {
          localStorage.removeItem(key);
        } catch {
          // Ignore — the reconcile effect falls back to the default view.
        }
      }
    },
  });

  function selectView(id: string) {
    setActiveViewId(id);
    if (key) {
      try {
        localStorage.setItem(key, id);
      } catch {
        // Same as above; the selection still applies for this session.
      }
    }
  }

  const switcher: ReactNode = (
    <ViewSwitcher
      views={views}
      activeViewId={activeView?.id ?? null}
      noun={options.noun}
      onSelect={selectView}
      onCreate={(name) => createView.mutate(name)}
      onRename={(id, name) => renameView.mutate({ id, name })}
      onDelete={(id) => deleteView.mutate(id)}
      onToggleFavorite={(id, favorite) => toggleFavorite.mutate({ id, favorite })}
      busy={createView.isPending}
    />
  );

  return {
    switcher,
    activeView,
    viewsPending: viewsQuery.isPending,
    viewsError: viewsQuery.isError,
    search,
    setSearch,
    sort,
    setSort,
    hidden,
    setHidden,
    selectView,
  };
}
