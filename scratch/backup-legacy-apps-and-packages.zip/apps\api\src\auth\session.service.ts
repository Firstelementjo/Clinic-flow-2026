import { Injectable } from '@nestjs/common';
import { createSessionToken, hashSessionToken } from '@firstelement/auth';
import type { SessionUser } from '@firstelement/shared';
import { getConfig } from '@firstelement/config';
import { PrismaService } from '../common/prisma.service';

export interface IssuedSession {
  token: string;
  sessionId: string;
  expiresAt: Date;
}

export interface ResolvedSession {
  sessionId: string;
  user: SessionUser;
}

@Injectable()
export class SessionService {
  constructor(private readonly prisma: PrismaService) {}

  async issue(params: {
    userId: string;
    organizationId: string;
    userAgent?: string;
    ipAddress?: string;
  }): Promise<IssuedSession> {
    const { token, tokenHash } = createSessionToken();
    const expiresAt = new Date(Date.now() + getConfig().SESSION_TTL_HOURS * 60 * 60 * 1000);

    const session = await this.prisma.client.session.create({
      data: {
        organizationId: params.organizationId,
        userId: params.userId,
        tokenHash,
        userAgent: params.userAgent?.slice(0, 500),
        ipAddress: params.ipAddress,
        expiresAt,
      },
    });

    return { token, sessionId: session.id, expiresAt };
  }

  /**
   * Resolves a raw cookie token to a live session and a fully-hydrated
   * `SessionUser`.
   *
   * The accessible project list is computed here, server-side, on every
   * request — not stored in the cookie. Revoking a membership takes effect
   * on the next request instead of whenever a stale token happens to
   * expire (plan §6).
   */
  async resolve(token: string): Promise<ResolvedSession | null> {
    const tokenHash = hashSessionToken(token);

    const session = await this.prisma.client.session.findUnique({
      where: { tokenHash },
      include: {
        user: {
          include: {
            organization: { select: { id: true, name: true, isActive: true } },
            memberships: { select: { projectId: true } },
            employee: { select: { id: true } },
          },
        },
      },
    });

    if (!session || session.revokedAt || session.expiresAt <= new Date()) return null;
    if (!session.user.isActive || !session.user.organization.isActive) return null;

    const projectIds =
      session.user.role === 'ADMIN'
        ? (
            // Archived projects stay accessible to admins — otherwise an
            // archive would be a one-way door with no way to read or undo it.
            await this.prisma.client.project.findMany({
              where: { organizationId: session.user.organizationId },
              select: { id: true },
            })
          ).map((p) => p.id)
        : session.user.memberships.map((m) => m.projectId);

    return {
      sessionId: session.id,
      user: {
        id: session.user.id,
        email: session.user.email,
        fullName: session.user.fullName,
        role: session.user.role,
        locale: session.user.locale,
        organizationId: session.user.organizationId,
        organizationName: session.user.organization.name,
        employeeId: session.user.employee?.id ?? null,
        projectIds,
      },
    };
  }

  async touch(sessionId: string): Promise<void> {
    await this.prisma.client.session.update({
      where: { id: sessionId },
      data: { lastSeenAt: new Date() },
    });
  }

  async revoke(sessionId: string): Promise<void> {
    await this.prisma.client.session.updateMany({
      where: { id: sessionId, revokedAt: null },
      data: { revokedAt: new Date() },
    });
  }

  /** Used when an admin deactivates a user — all their sessions die at once. */
  async revokeAllForUser(userId: string): Promise<void> {
    await this.prisma.client.session.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt: new Date() },
    });
  }
}
