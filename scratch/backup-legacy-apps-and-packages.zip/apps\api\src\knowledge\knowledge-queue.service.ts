import { Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import { Queue } from 'bullmq';
import IORedis from 'ioredis';
import { getConfig } from '@firstelement/config';
import { DEFAULT_JOB_OPTIONS, QueueName } from '@firstelement/messaging';
import { IngestionPipelineProvider } from './knowledge.providers';

export interface DocumentProcessingJob {
  organizationId: string;
  projectId: string;
  documentId: string;
}

/**
 * Hands document processing to the worker (plan §11).
 *
 * Separate from `MessageQueueService` rather than a method on it: the
 * knowledge module owns the ingestion pipeline, and putting this method
 * there would make the messaging module depend on the knowledge module for
 * a queue name it does not use.
 */
@Injectable()
export class KnowledgeQueueService implements OnModuleDestroy {
  private readonly logger = new Logger(KnowledgeQueueService.name);
  private readonly driver = getConfig().QUEUE_DRIVER;
  private connection?: IORedis;
  private queue?: Queue;

  constructor(private readonly pipeline: IngestionPipelineProvider) {}

  async enqueue(job: DocumentProcessingJob): Promise<void> {
    if (this.driver === 'inline') {
      // Development without Redis. Detached on purpose: even inline, the
      // upload response must not wait on parsing and embedding.
      void this.pipeline
        .process(job.documentId)
        .then((result) => {
          if (result.status === 'FAILED') {
            this.logger.warn({
              message: 'Inline document processing failed',
              documentId: job.documentId,
              reason: result.failureReason,
            });
          }
        })
        .catch((error) => {
          this.logger.error({
            message: 'Inline document processing threw',
            documentId: job.documentId,
            error: error instanceof Error ? error.message : String(error),
          });
        });
      return;
    }

    this.connection ??= new IORedis(getConfig().REDIS_URL, { maxRetriesPerRequest: null });
    this.queue ??= new Queue(QueueName.DOCUMENT_PROCESSING, { connection: this.connection });

    await this.queue.add('process-document', job, {
      ...DEFAULT_JOB_OPTIONS,
      // Re-processing the same document replaces the queued job rather
      // than stacking a second one behind it.
      jobId: `document:${job.documentId}`,
    });
  }

  async onModuleDestroy(): Promise<void> {
    await this.queue?.close();
    await this.connection?.quit();
  }
}
