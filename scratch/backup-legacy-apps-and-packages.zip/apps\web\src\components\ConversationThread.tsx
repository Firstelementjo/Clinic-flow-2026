import { useEffect, useRef, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, StatusChip, useDirection } from '@firstelement/ui';
import type { ConversationDetail, MessageView, SessionUser } from '@firstelement/shared';
import { formatTime } from '../lib/format';
import { useT, type StringKey } from '../lib/i18n';
import { useAssign, useReply, useUpdateConversation } from '../lib/inbox';
import { navigateToCxProfile, navigateToTicket } from '../lib/navigate-cx';
import { ConversationSignals } from './ConversationSignals';
import { ReturningCustomerBanner } from './ReturningCustomerBanner';

export function ConversationThread({
  conversation,
  user,
}: {
  conversation: ConversationDetail;
  user: SessionUser;
}) {
  const t = useT();
  const navigate = useNavigate();
  const reply = useReply(conversation.id);
  const assign = useAssign(conversation.id);
  const update = useUpdateConversation(conversation.id);
  const [draft, setDraft] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end' });
  }, [conversation.messages.length, conversation.id]);

  const onSend = (event: FormEvent) => {
    event.preventDefault();
    const body = draft.trim();
    if (!body) return;
    reply.mutate({ body }, { onSuccess: () => setDraft('') });
  };

  const isMine = conversation.assignedEmployee?.id === user.employeeId;
  const isResolved = conversation.status === 'RESOLVED' || conversation.status === 'CLOSED';

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex shrink-0 flex-wrap items-center gap-2 border-b border-hairline px-4 py-2.5">
        <div className="min-w-0">
          <p className="truncate text-sm font-medium text-ink">
            <button
              type="button"
              onClick={() => navigateToTicket(conversation.ticketNumber, navigate, conversation.customer.cxId)}
              className="underline-offset-2 hover:underline hover:text-ink"
            >
              {conversation.ticketNumber}
            </button>
            <button
              type="button"
              onClick={() => navigateToCxProfile(conversation.customer.cxId, navigate)}
              className="ms-2 text-xs text-slate-soft underline-offset-2 hover:underline hover:text-ink"
            >
              {conversation.customer.cxId}
            </button>
          </p>
          <p className="fe-eyebrow">
            {conversation.projectName} · {conversation.channel}
          </p>
        </div>

        <div className="ms-auto flex flex-wrap items-center gap-1.5">
          <StatusChip tone={conversation.mode === 'AI' ? 'ai' : 'human'}>
            {t(`mode.${conversation.mode}` as StringKey)}
          </StatusChip>
          <StatusChip tone={isResolved ? 'neutral' : 'ok'}>
            {t(`status.${conversation.status}` as StringKey)}
          </StatusChip>

          {assign.isError && (
            <span className="text-xs text-signal">
              {assign.error instanceof Error ? assign.error.message : 'Assignment failed'}
            </span>
          )}

          {user.employeeId && !isMine && (
            <Button
              size="sm"
              loading={assign.isPending}
              onClick={() => assign.mutate({ employeeId: user.employeeId })}
            >
              {t('thread.assignToMe')}
            </Button>
          )}
          {isMine && (
            <Button size="sm" variant="ghost" loading={assign.isPending} onClick={() => assign.mutate({ employeeId: null })}>
              {t('thread.unassign')}
            </Button>
          )}
          <Button
            size="sm"
            variant={isResolved ? 'secondary' : 'primary'}
            loading={update.isPending}
            onClick={() => update.mutate({ status: isResolved ? 'OPEN' : 'RESOLVED' })}
          >
            {isResolved ? t('thread.reopen') : t('thread.resolve')}
          </Button>
        </div>
      </header>

      <div className="shrink-0 border-b border-hairline px-4 py-2">
        <ConversationSignals conversationId={conversation.id} />
      </div>

      <ReturningCustomerBanner customerId={conversation.customer.id} />

      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4 msgs">
        {conversation.messages.map((message) => (
          <Turn key={message.id} message={message} />
        ))}
        <div ref={endRef} />
      </div>

      <form onSubmit={onSend} className="flex shrink-0 items-end gap-2 border-t border-hairline p-3">
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            // Enter sends, Shift+Enter breaks the line: this is a queue,
            // and reaching for the mouse on every reply is the cost.
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              onSend(e);
            }
          }}
          rows={2}
          placeholder={t('thread.reply')}
          className="min-h-[2.5rem] flex-1 resize-y rounded-lg border border-[var(--fe-hairline)] bg-[var(--fe-surface)] px-3 py-2 text-sm text-[var(--fe-ink)] placeholder:text-[var(--fe-slate)]"
        />
        <Button type="submit" variant="primary" loading={reply.isPending} disabled={!draft.trim()}>
          {t('thread.send')}
        </Button>
      </form>
    </div>
  );
}

function Turn({ message }: { message: MessageView }) {
  const t = useT();
  const { locale } = useDirection();
  const isCustomer = message.authorType === 'CUSTOMER';

  return (
    <div
      className={[
        'm',
        !isCustomer ? 'me2' : ''
      ].join(' ')}
    >
      {message.body}
      <small dir="ltr">
        {formatTime(message.sentAt, locale)}
        {message.authorType !== 'CUSTOMER' ? ` · ${message.authorName ?? t(`author.${message.authorType}` as StringKey)}` : ''}
        {message.deliveryStatus === 'FAILED' ? ` · ${message.failureReason ?? 'FAILED'}` : ''}
      </small>
    </div>
  );
}
