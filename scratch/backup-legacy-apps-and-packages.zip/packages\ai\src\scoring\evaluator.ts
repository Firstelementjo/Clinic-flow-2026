/**
 * Scoring engine (plan §10).
 *
 * Produces normalized 0–100 signals per turn. Normalization is the point:
 * an admin setting "escalate at 70" must mean the same thing for
 * frustration as for risk, and analytics must be able to compare them.
 *
 * The default evaluator is deterministic and lexical rather than
 * model-based, for three reasons: it costs nothing on every turn (scoring
 * a model call with another model call doubles spend on the busiest path),
 * it is reproducible so an escalation can be explained after the fact, and
 * it cannot be talked out of its own numbers by a customer's text. Its
 * weakness is the mirror of that: it reads words, not meaning, and will
 * miss politely-worded fury. The interface exists so a model-based
 * evaluator can be added per project later without touching the rules.
 */

export interface TurnToScore {
  /** The customer's latest message. */
  text: string;
  /** Earlier customer messages, oldest first — trend beats a single line. */
  previousCustomerTexts: string[];
  /** How many AI replies have gone by without the customer's issue moving. */
  aiTurnsWithoutResolution: number;
  /** Whether the last AI run failed or produced nothing. */
  lastAIFailed: boolean;
  locale: 'ar' | 'en';
}

export interface TurnScores {
  frustration: number;
  sentiment: number;
  urgency: number;
  risk: number;
  intentConfidence: number;
  aiConfidence: number | null;
  intent: string | null;
  evaluator: string;
  /** Which cues fired, so a score is explainable rather than a bare number. */
  signals: Record<string, unknown>;
}

export interface ConversationEvaluator {
  readonly name: string;
  evaluate(turn: TurnToScore): Promise<TurnScores>;
}

/** Bilingual cue lists. Arabic is first-class here, not a translation. */
const FRUSTRATION_CUES = [
  /\b(angry|furious|unacceptable|ridiculous|terrible|awful|worst|useless|scam|fed up)\b/i,
  /\b(again|still|third time|no one|nobody)\s+(has\s+)?(not|n't|answered|replied|helped)?/i,
  /(غاضب|غير مقبول|سخيف|سيء|أسوأ|مافي فايدة|محتال|نصب|زهقت|تعبت منكم)/,
  /(مرة ثانية|للمرة الثالثة|ما حد|محد|ولا واحد)/,
];

const ESCALATION_DEMANDS = [
  /\b(supervisor|manager|complaint|legal|lawyer|sue|consumer protection)\b/i,
  /(مشرف|مدير|شكوى|قانوني|محامي|حماية المستهلك|أرفع قضية)/,
];

const URGENCY_CUES = [
  /\b(urgent|asap|immediately|right now|emergency|today)\b/i,
  /(عاجل|فورا|فوراً|حالا|حالاً|ضروري|اليوم|طارئ)/,
];

const RISK_CUES = [
  /\b(refund|chargeback|cancel my|close my account|fraud|stolen|unauthorized|data breach)\b/i,
  /(استرجاع|إلغاء|أغلق حسابي|احتيال|مسروق|غير مصرح|تسريب)/,
];

const POSITIVE_CUES = [
  /\b(thanks|thank you|great|perfect|appreciate|helpful)\b/i,
  /(شكرا|شكراً|ممتاز|رائع|تسلم|جزاك الله)/,
];

const INTENTS: { intent: string; patterns: RegExp[] }[] = [
  { intent: 'refund', patterns: [/\b(refund|money back|reimburse)\b/i, /(استرجاع|استرداد|فلوسي)/] },
  { intent: 'delivery', patterns: [/\b(deliver|shipping|track|order status|where is my)\b/i, /(توصيل|شحن|طلبي|وين طلبي|تتبع)/] },
  { intent: 'billing', patterns: [/\b(charge|invoice|billing|payment|double.?charg)\b/i, /(فاتورة|دفع|خصم|سحب مرتين)/] },
  { intent: 'technical', patterns: [/\b(not working|error|broken|bug|cannot log ?in)\b/i, /(ما يشتغل|خطأ|معطل|ما أقدر أدخل)/] },
  { intent: 'complaint', patterns: [...ESCALATION_DEMANDS] },
  { intent: 'cancellation', patterns: [/\b(cancel|unsubscribe|close account)\b/i, /(إلغاء|إيقاف الاشتراك|إغلاق الحساب)/] },
];

export class HeuristicEvaluator implements ConversationEvaluator {
  readonly name = 'heuristic';

  async evaluate(turn: TurnToScore): Promise<TurnScores> {
    const text = turn.text ?? '';
    const signals: Record<string, unknown> = {};

    const frustrationCues = countMatches(text, FRUSTRATION_CUES);
    const demandsHuman = ESCALATION_DEMANDS.some((pattern) => pattern.test(text));
    const urgencyCues = countMatches(text, URGENCY_CUES);
    const riskCues = countMatches(text, RISK_CUES);
    const positiveCues = countMatches(text, POSITIVE_CUES);

    const shouting = shoutingRatio(text);
    const exclamations = Math.min(3, (text.match(/[!؟]/g) ?? []).length);
    const repetition = repeatedComplaint(text, turn.previousCustomerTexts);

    signals.frustrationCues = frustrationCues;
    signals.demandsHuman = demandsHuman;
    signals.shouting = Number(shouting.toFixed(2));
    signals.exclamations = exclamations;
    signals.repetition = repetition;
    signals.aiTurnsWithoutResolution = turn.aiTurnsWithoutResolution;

    // Frustration climbs with the conversation, not just the sentence:
    // three unanswered turns is the shape of a customer about to give up.
    const frustration = clamp(
      frustrationCues * 22 +
        (demandsHuman ? 30 : 0) +
        shouting * 25 +
        exclamations * 5 +
        repetition * 15 +
        turn.aiTurnsWithoutResolution * 12 +
        (turn.lastAIFailed ? 15 : 0) -
        positiveCues * 20,
    );

    const sentiment = clamp(50 + positiveCues * 20 - frustrationCues * 18 - shouting * 20);
    const urgency = clamp(urgencyCues * 35 + (demandsHuman ? 20 : 0) + frustration * 0.2);
    const risk = clamp(riskCues * 30 + (demandsHuman ? 25 : 0) + frustration * 0.25);

    const intent = classifyIntent(text);
    // Confidence is deliberately modest: a lexical match is evidence, not
    // certainty, and a rule that escalates on low intent confidence should
    // fire when this evaluator is genuinely unsure.
    const intentConfidence = intent ? 70 : 25;

    return {
      frustration,
      sentiment,
      urgency,
      risk,
      intentConfidence,
      aiConfidence: null,
      intent,
      evaluator: this.name,
      signals,
    };
  }
}

/**
 * Counts cue *occurrences*, not how many patterns fired.
 *
 * "Unacceptable and terrible" is angrier than "unacceptable", and both
 * match the same pattern — counting patterns would score them identically.
 * Each pattern is capped so one repeated word cannot dominate the score.
 */
function countMatches(text: string, patterns: RegExp[]): number {
  const PER_PATTERN_CAP = 3;

  return patterns.reduce((total, pattern) => {
    const global = new RegExp(pattern.source, `${pattern.flags.replace('g', '')}g`);
    const hits = text.match(global)?.length ?? 0;
    return total + Math.min(PER_PATTERN_CAP, hits);
  }, 0);
}

/** Proportion of letters typed in capitals — only meaningful for Latin script. */
function shoutingRatio(text: string): number {
  const letters = text.match(/[A-Za-z]/g) ?? [];
  if (letters.length < 8) return 0;
  const upper = letters.filter((char) => char === char.toUpperCase()).length;
  const ratio = upper / letters.length;
  return ratio > 0.6 ? ratio : 0;
}

/**
 * Whether the customer is asking the same thing again. Repetition is the
 * strongest signal that the agent is not helping, and it is invisible to
 * any evaluator that only reads the latest message.
 */
function repeatedComplaint(text: string, previous: string[]): number {
  if (previous.length === 0) return 0;
  const current = tokenSet(text);
  if (current.size < 3) return 0;

  let repeats = 0;
  for (const earlier of previous.slice(-3)) {
    const overlap = intersectionSize(current, tokenSet(earlier));
    if (overlap / current.size > 0.5) repeats += 1;
  }
  return repeats;
}

function tokenSet(text: string): Set<string> {
  return new Set((text.toLowerCase().match(/[\p{L}\p{N}]{3,}/gu) ?? []).slice(0, 40));
}

function intersectionSize(a: Set<string>, b: Set<string>): number {
  let count = 0;
  for (const token of a) if (b.has(token)) count += 1;
  return count;
}

function classifyIntent(text: string): string | null {
  for (const { intent, patterns } of INTENTS) {
    if (patterns.some((pattern) => pattern.test(text))) return intent;
  }
  return null;
}

function clamp(value: number): number {
  return Math.max(0, Math.min(100, Math.round(value)));
}
