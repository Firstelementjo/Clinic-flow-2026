import { Injectable, Logger } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import type { DomainEvent } from '@firstelement/events';
import { recordTimelineEvent } from '@firstelement/messaging';
import { PrismaService } from '../common/prisma.service';

/**
 * Writes the append-only conversation timeline (plan §7) for events
 * published inside the API process.
 *
 * The mapping itself lives in `@firstelement/messaging` because the worker
 * records the same timeline for inbound messages without Nest in the
 * picture. This class is the subscription, not the logic.
 */
@Injectable()
export class ConversationTimelineSubscriber {
  private readonly logger = new Logger(ConversationTimelineSubscriber.name);

  constructor(private readonly prisma: PrismaService) {}

  @OnEvent('conversation.*')
  @OnEvent('message.*')
  async onDomainEvent(event: DomainEvent): Promise<void> {
    try {
      await recordTimelineEvent(this.prisma.client, event);
    } catch (error) {
      // A timeline write must never roll back the action it describes.
      this.logger.error({
        message: 'Failed to record conversation event',
        type: event.type,
        aggregateId: event.aggregateId,
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }
}
