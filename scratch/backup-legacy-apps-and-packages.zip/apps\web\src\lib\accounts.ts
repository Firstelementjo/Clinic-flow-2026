import { useQuery } from '@tanstack/react-query';
import { api } from './api';

export interface AccountRow {
  id: string;
  name: string;
  companyType: string | null;
  industry: string | null;
  website: string | null;
  size: string | null;
  phone: string | null;
  email: string | null;
  linkedin: string | null;
  country: string | null;
  city: string | null;
  address: string | null;
  postalCode: string | null;
  description: string | null;
  ownerId: string | null;
  createdById: string | null;
  createdBy: { id: string; fullName: string } | null;
  owner: { id: string; fullName: string } | null;
  status: string | null;
  leadSource: string | null;
  priority: string | null;
  tags: string[];
  notes: string | null;
  createdAt: string;
}

export function useAccounts(search: string) {
  const query = new URLSearchParams();
  if (search.trim()) query.set('search', search.trim());

  return useQuery({
    queryKey: ['accounts', search.trim()],
    queryFn: () => api.get<AccountRow[]>(`/accounts?${query.toString()}`),
  });
}

export function useAccount(accountId: string | undefined) {
  return useQuery({
    queryKey: ['account', accountId],
    queryFn: () => api.get<AccountRow>(`/accounts/${accountId}`),
    enabled: Boolean(accountId),
  });
}