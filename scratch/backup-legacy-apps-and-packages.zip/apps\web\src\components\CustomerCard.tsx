import { useNavigate } from 'react-router-dom';
import { Spinner, StatusChip, useDirection } from '@firstelement/ui';
import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import { useT, type StringKey } from '../lib/i18n';
import { navigateToCxProfile, navigateToTicket } from '../lib/navigate-cx';
import type { CustomerDetail } from '../lib/customers';

/**
 * The third pane. It answers "who is this?" without a navigation, which is
 * the whole reason it is pinned rather than a click away.
 */
export function CustomerCard({ customerId }: { customerId: string }) {
  const t = useT();
  const { locale } = useDirection();
  const navigate = useNavigate();

  const customer = useQuery({
    queryKey: ['customer', customerId],
    queryFn: () => api.get<CustomerDetail>(`/customers/${customerId}`),
  });

  if (customer.isPending) {
    return (
      <div className="p-4">
        <Spinner label={t('common.loading')} />
      </div>
    );
  }

  if (customer.isError || !customer.data) {
    return <p className="p-4 text-sm text-slate">{t('common.error')}</p>;
  }

  const data = customer.data;

  return (
    <div className="flex flex-col gap-4 p-[18px]">
      <div>
        <h3 className="fe-display text-[var(--fe-ink)] text-lg">{t('customer.title')}</h3>
        <p className="sub mb-2">Shown when a conversation is open</p>
        <button
          type="button"
          onClick={() => navigateToCxProfile(data.cxId, navigate)}
          className="fe-display text-lg text-[var(--fe-ink)] underline-offset-2 hover:underline font-bold"
        >
          {data.cxId}
        </button>
        {(data.primaryPhone || data.primaryEmail) && (
          <p className="fe-mono mt-1 text-xs text-[var(--fe-slate)]" dir="ltr">
            {data.primaryPhone ?? data.primaryEmail}
          </p>
        )}
      </div>

      <div>
        <p className="fe-eyebrow mb-1.5 text-[var(--fe-slate)]">{t('customer.identities')}</p>
        <ul className="flex flex-col gap-1.5">
          {data.identities.map((identity) => (
            <li key={identity.id} className="flex items-center gap-2">
              <span className="fe-eyebrow text-[var(--fe-slate)]">{identity.platform}</span>
              <span className="fe-mono truncate text-xs text-[var(--fe-slate)]" dir="ltr">
                {identity.externalId}
              </span>
              <StatusChip tone={identity.isVerified ? 'ok' : 'neutral'} className="ms-auto">
                {identity.isVerified ? t('customer.verified') : t('customer.unverified')}
              </StatusChip>
            </li>
          ))}
        </ul>
      </div>

      <dl className="grid grid-cols-2 gap-2 text-xs">
        <div>
          <dt className="fe-eyebrow text-[var(--fe-slate)]">{t('customer.firstSeen')}</dt>
          <dd className="fe-mono text-[var(--fe-slate)]" dir="ltr">
            {formatDate(data.firstSeenAt, locale)}
          </dd>
        </div>
        <div>
          <dt className="fe-eyebrow text-[var(--fe-slate)]">{t('customer.lastSeen')}</dt>
          <dd className="fe-mono text-[var(--fe-slate)]" dir="ltr">
            {formatDate(data.lastSeenAt, locale)}
          </dd>
        </div>
      </dl>

      <div>
        <p className="fe-eyebrow mb-1.5 text-[var(--fe-slate)]">{t('customer.conversations')}</p>
        <ul className="flex flex-col gap-1">
          {data.conversations.slice(0, 8).map((conversation) => (
            <li key={conversation.id} className="flex items-center gap-2 text-xs">
              <button
                type="button"
                onClick={() => navigateToTicket(conversation.ticketNumber, navigate, data.cxId)}
                className="font-medium text-[var(--fe-ink)] underline-offset-2 hover:underline"
              >
                {conversation.ticketNumber}
              </button>
              <span className="fe-eyebrow text-[var(--fe-slate)]">{conversation.channel}</span>
              <span className="text-[var(--fe-slate)]">{t(`status.${conversation.status}` as StringKey)}</span>
              {conversation.assignedAgent && (
                <span className="text-[var(--fe-slate)] ms-auto">{conversation.assignedAgent}</span>
              )}
              <span className="fe-mono text-[var(--fe-slate)]" dir="ltr">
                {formatDate(conversation.lastMessageAt, locale)}
              </span>
            </li>
          ))}
        </ul>
      </div>

      {data.notes && (
        <div>
          <p className="fe-eyebrow mb-1">{t('customer.notes')}</p>
          <p className="whitespace-pre-wrap text-xs text-slate">{data.notes}</p>
        </div>
      )}
    </div>
  );
}
