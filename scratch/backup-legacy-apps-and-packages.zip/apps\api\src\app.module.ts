import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { APP_FILTER, APP_GUARD } from '@nestjs/core';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { PrismaModule } from './common/prisma.module';
import { HttpExceptionFilter } from './common/http-exception.filter';
import { requestContextMiddleware } from './common/request-context';
import { AuditModule } from './audit/audit.module';
import { EventsModule } from './events/events.module';
import { MessagingModule } from './messaging/messaging.module';
import { ChannelsModule } from './channels/channels.module';
import { KnowledgeModule } from './knowledge/knowledge.module';
import { AIModule } from './ai/ai.module';
import { EscalationModule } from './escalation/escalation.module';
import { RoutingModule } from './routing/routing.module';
import { NotificationsModule } from './notifications/notifications.module';
import { AnalyticsModule } from './analytics/analytics.module';
import { CasesModule } from './cases/cases.module';
import { CustomersModule } from './customers/customers.module';
import { AccountsModule } from './accounts/accounts.module';
import { NotesModule } from './notes/notes.module';
import { ViewsModule } from './views/views.module';
import { LeadsModule } from './leads/leads.module';
import { DealsModule } from './deals/deals.module';
import { TasksModule } from './tasks/tasks.module';
import { AppointmentsModule } from './appointments/appointments.module';
import { ClinicModule } from './clinic/clinic.module';
import { ConversationsModule } from './conversations/conversations.module';
import { AuthModule } from './auth/auth.module';
import { AuthGuard } from './auth/auth.guard';
import { PermissionsGuard } from './auth/permissions.guard';
import { OrganizationsModule } from './organizations/organizations.module';
import { ProjectsModule } from './projects/projects.module';
import { EmployeesModule } from './employees/employees.module';
import { HealthModule } from './health/health.module';

@Module({
  imports: [
    // In-process domain event bus (plan §8b). Modules publish; routing,
    // notifications, analytics and audit subscribe — no direct service
    // calls between them.
    EventEmitterModule.forRoot({ wildcard: true, delimiter: '.' }),
    ThrottlerModule.forRoot([{ name: 'default', ttl: 60_000, limit: 300 }]),
    PrismaModule,
    AuditModule,
    EventsModule,
    AuthModule,
    OrganizationsModule,
    ProjectsModule,
    EmployeesModule,
    MessagingModule,
    CustomersModule,
    AccountsModule,
    NotesModule,
    ViewsModule,
    LeadsModule,
    DealsModule,
    TasksModule,
    ConversationsModule,
    ChannelsModule,
    KnowledgeModule,
    AIModule,
    EscalationModule,
    RoutingModule,
    NotificationsModule,
    AnalyticsModule,
    CasesModule,
    AppointmentsModule,
    ClinicModule,
    HealthModule,
  ],
  providers: [
    // Order matters: authenticate, then authorize, then rate-limit.
    { provide: APP_GUARD, useClass: AuthGuard },
    { provide: APP_GUARD, useClass: PermissionsGuard },
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_FILTER, useClass: HttpExceptionFilter },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(requestContextMiddleware).forRoutes('*');
  }
}
