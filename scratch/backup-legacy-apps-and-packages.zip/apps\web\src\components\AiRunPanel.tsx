import { useQuery } from '@tanstack/react-query';
import { Spinner, StatusChip } from '@firstelement/ui';
import type { AIRunSummaryView, AIRunTraceView } from '@firstelement/shared';
import { useState } from 'react';
import { api } from '../lib/api';
import { useT, type StringKey } from '../lib/i18n';

/**
 * AI transparency panel (plan §48).
 *
 * Shows the employee inheriting a conversation what the agent decided,
 * which documents it answered from, which tools it used, and what the turn
 * cost. Source citations are operational metadata and safe to surface —
 * the model's reasoning is not, and is never sent to the client at all.
 */
export function AiRunPanel({ conversationId }: { conversationId: string }) {
  const t = useT();
  const [openRunId, setOpenRunId] = useState<string | null>(null);

  const runs = useQuery({
    queryKey: ['ai-runs', conversationId],
    queryFn: () => api.get<AIRunSummaryView[]>(`/ai-runs?conversationId=${conversationId}`),
  });

  if (runs.isPending) {
    return (
      <div className="border-t border-hairline p-4">
        <Spinner label={t('common.loading')} />
      </div>
    );
  }

  return (
    <div className="border-t border-hairline p-4">
      <p className="fe-eyebrow mb-2">{t('runs.title')}</p>

      {!runs.data || runs.data.length === 0 ? (
        <p className="text-xs text-slate">{t('runs.none')}</p>
      ) : (
        <ul className="flex flex-col gap-2">
          {runs.data.slice(0, 5).map((run) => (
            <li key={run.id}>
              <button
                type="button"
                onClick={() => setOpenRunId(openRunId === run.id ? null : run.id)}
                className="flex w-full items-center gap-2 rounded border border-hairline px-2 py-1.5 text-start hover:bg-mist/60"
              >
                <StatusChip
                  tone={
                    run.decision === 'ESCALATE'
                      ? 'escalated'
                      : run.status === 'FAILED'
                        ? 'danger'
                        : 'ai'
                  }
                >
                  {run.decision ? t(`decision.${run.decision}` as StringKey) : run.status}
                </StatusChip>
                <span className="fe-mono ms-auto text-2xs text-slate-soft" dir="ltr">
                  v{run.agentVersion} · {run.latencyMs ?? '—'}ms
                </span>
              </button>

              {openRunId === run.id && <RunTrace runId={run.id} />}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function RunTrace({ runId }: { runId: string }) {
  const t = useT();
  const trace = useQuery({
    queryKey: ['ai-run', runId],
    queryFn: () => api.get<AIRunTraceView>(`/ai-runs/${runId}`),
  });

  if (trace.isPending) {
    return (
      <div className="p-2">
        <Spinner />
      </div>
    );
  }
  if (!trace.data) return null;

  const data = trace.data;
  const deniedTools = data.toolCalls.filter((call) => !call.authorized);

  return (
    <div className="mt-1.5 flex flex-col gap-2 rounded border border-hairline bg-mist/40 p-2 text-xs">
      {data.decisionReason && <p className="text-slate">{data.decisionReason}</p>}

      <div>
        <p className="fe-eyebrow">{t('runs.sources')}</p>
        {data.retrievals.length === 0 ? (
          <p className="text-slate-soft">{t('runs.noSources')}</p>
        ) : (
          <ul className="flex flex-col gap-0.5">
            {data.retrievals.map((retrieval) => (
              <li key={retrieval.documentId + retrieval.score} className="flex items-baseline gap-2">
                <span className="truncate text-slate">{retrieval.documentTitle}</span>
                <span className="fe-mono ms-auto text-2xs text-slate-soft" dir="ltr">
                  {retrieval.score.toFixed(2)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {data.toolCalls.length > 0 && (
        <div>
          <p className="fe-eyebrow">{t('runs.tools')}</p>
          <p className="text-slate">
            {data.toolCalls.map((call) => call.toolName).join(', ')}
            {deniedTools.length > 0 && (
              <span className="text-escalation">
                {' '}
                ({deniedTools.length} {t('runs.denied')})
              </span>
            )}
          </p>
        </div>
      )}

      {data.usage && (
        <dl className="flex gap-4">
          <div>
            <dt className="fe-eyebrow">{t('runs.cost')}</dt>
            <dd className="fe-mono text-slate" dir="ltr">
              ${data.usage.estimatedCost.toFixed(4)}
            </dd>
          </div>
          <div>
            <dt className="fe-eyebrow">{t('runs.latency')}</dt>
            <dd className="fe-mono text-slate" dir="ltr">
              {data.usage.latencyMs}ms
            </dd>
          </div>
          <div>
            <dt className="fe-eyebrow">tokens</dt>
            <dd className="fe-mono text-slate" dir="ltr">
              {data.usage.inputTokens}/{data.usage.outputTokens}
            </dd>
          </div>
        </dl>
      )}
    </div>
  );
}
