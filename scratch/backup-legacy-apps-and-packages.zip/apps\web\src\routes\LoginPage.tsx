import { useState, useEffect, useId, type FormEvent } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { z } from 'zod';
import { useLocale } from '../lib/locale';
import { sessionQueryKey } from '../lib/session';
import '../login-theme.css';

const CLINIC_NAME = "Clinic Flow";

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

const copy = {
  en: {
    languageName: "العربية",
    languageLabel: "Switch language to Arabic",
    title: `Welcome to ${CLINIC_NAME}`,
    subtitle: "Sign in to manage appointments and patient records.",
    email: "Email address",
    emailPlaceholder: "name@clinic.com",
    password: "Password",
    passwordPlaceholder: "Enter your password",
    forgot: "Forgot password?",
    showPassword: "Show password",
    hidePassword: "Hide password",
    submit: "Sign in",
    submitting: "Signing in",
    emailRequired: "Enter your email address.",
    emailInvalid: "Enter a valid email address, such as name@clinic.com.",
    passwordRequired: "Enter your password.",
    wrongCredentials:
      "The email or password does not match our records. Check both fields and try again.",
    serverError:
      "Could not connect to the clinic portal. Check your connection and try again.",
    panelTitle: "Care, organized.",
    panelBody:
      "A focused place for your team to coordinate schedules and patient care.",
    panelNote: "For authorized clinic staff",
  },
  ar: {
    languageName: "English",
    languageLabel: "تغيير اللغة إلى الإنجليزية",
    title: `مرحباً بكم في ${CLINIC_NAME}`,
    subtitle: "سجّل الدخول لإدارة المواعيد وسجلات المرضى.",
    email: "البريد الإلكتروني",
    emailPlaceholder: "name@clinic.com",
    password: "كلمة المرور",
    passwordPlaceholder: "أدخل كلمة المرور",
    forgot: "هل نسيت كلمة المرور؟",
    showPassword: "إظهار كلمة المرور",
    hidePassword: "إخفاء كلمة المرور",
    submit: "تسجيل الدخول",
    submitting: "جارٍ تسجيل الدخول",
    emailRequired: "أدخل بريدك الإلكتروني.",
    emailInvalid: "أدخل بريداً إلكترونياً صالحاً، مثل name@clinic.com.",
    passwordRequired: "أدخل كلمة المرور.",
    wrongCredentials:
      "البريد الإلكتروني أو كلمة المرور غير مطابقين لسجلاتنا. تحقق من الحقلين وحاول مرة أخرى.",
    serverError:
      "تعذّر الاتصال ببوابة العيادة. تحقق من اتصالك وحاول مرة أخرى.",
    panelTitle: "رعاية منظّمة.",
    panelBody:
      "مكان واضح لفريقك لتنسيق المواعيد ورعاية المرضى.",
    panelNote: "لموظفي العيادة المصرّح لهم",
  },
} as const;

/* ── Inline SVG components (from the design file) ─────────────── */

function LogoMark() {
  return (
    <svg
      aria-hidden="true"
      className="size-9 text-[var(--login-accent)]"
      fill="none"
      viewBox="0 0 40 40"
    >
      <path
        d="M13.8 7.6c2.4 0 4 1.6 6.2 1.6s3.8-1.6 6.2-1.6c4.4 0 7.4 3.6 7.1 8.2-.3 4.1-2.3 6.4-3.1 10.7-.7 3.8-1.8 6-4 6-2.6 0-2.5-6.3-6.2-6.3s-3.6 6.3-6.2 6.3c-2.2 0-3.3-2.2-4-6-.8-4.3-2.8-6.6-3.1-10.7-.3-4.6 2.7-8.2 7.1-8.2Z"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
      />
    </svg>
  );
}

function EyeIcon({ hidden }: { hidden: boolean }) {
  return (
    <svg aria-hidden="true" className="size-5" fill="none" viewBox="0 0 24 24">
      <path
        d={
          hidden
            ? "M3 3l18 18M10.6 10.7a2 2 0 002.8 2.8M9.9 4.2A10.8 10.8 0 0112 4c5.5 0 9 6 9 6a16 16 0 01-2.2 2.9M6.6 6.6C4.3 8.1 3 10 3 10s3.5 6 9 6c1 0 1.9-.2 2.7-.5"
            : "M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6Zm9 2.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5Z"
        }
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.75"
      />
    </svg>
  );
}

/* ── Page component ───────────────────────────────────────────── */

export function LoginPage() {
  const { locale, toggle } = useLocale();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const t = copy[locale] || copy.en;
  const emailId = useId();
  const passwordId = useId();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<{ email?: string; password?: string }>({});

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = locale === 'ar' ? 'rtl' : 'ltr';
  }, [locale]);

  const loginMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password }),
        credentials: 'include',
      });
      if (!res.ok) {
        const error = new Error('Login failed');
        (error as any).status = res.status;
        throw error;
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(sessionQueryKey, data.user);
      navigate('/', { replace: true });
    },
  });

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setFieldErrors({});

    const result = loginSchema.safeParse({ email: email.trim(), password });
    if (!result.success) {
      const errors: { email?: string; password?: string } = {};
      result.error.errors.forEach((err) => {
        if (err.path[0] === 'email') errors.email = t.emailRequired;
        if (err.path[0] === 'password') errors.password = t.passwordRequired;
      });
      setFieldErrors(errors);

      // Focus the first invalid field
      const firstField = errors.email ? emailId : errors.password ? passwordId : null;
      if (firstField) {
        document.getElementById(firstField)?.focus();
      }
      return;
    }

    loginMutation.mutate();
  };

  const serverError = loginMutation.isError
    ? ((loginMutation.error as any).status === 401 ||
       (loginMutation.error as any).status === 400)
      ? t.wrongCredentials
      : t.serverError
    : null;

  return (
    <main className="grid min-h-dvh bg-[var(--login-background)] font-readex lg:grid-cols-2"
          style={{ paddingTop: 'max(1.5rem, env(safe-area-inset-top))',
                   paddingRight: 'max(1.5rem, env(safe-area-inset-right))',
                   paddingBottom: 'max(1.5rem, env(safe-area-inset-bottom))',
                   paddingLeft: 'max(1.5rem, env(safe-area-inset-left))' }}>

      {/* ── Left: form ─────────────────────────────────────────── */}
      <section className="flex min-h-full items-center justify-center py-8 lg:py-12">
        <div className="w-full max-w-md text-[var(--login-ink)]">

          {/* Header */}
          <header className="mb-8 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <LogoMark />
              <p className="m-0 text-base font-semibold text-[var(--login-ink)]">
                {CLINIC_NAME}
              </p>
            </div>
            <button
              aria-label={t.languageLabel}
              className="login-focus-ring min-h-12 rounded-xl border border-[var(--login-line)] bg-transparent px-4 text-sm font-medium text-[var(--login-ink)] hover:bg-[var(--login-panel)]"
              onClick={toggle}
              type="button"
            >
              {t.languageName}
            </button>
          </header>

          {/* Title block */}
          <div className="mb-8">
            <h1 className="m-0 text-3xl font-semibold tracking-tight text-[var(--login-ink)] sm:text-4xl">
              {t.title}
            </h1>
            <p className="m-0 mt-3 max-w-sm text-base leading-7 text-[var(--login-muted)]">
              {t.subtitle}
            </p>
          </div>

          {/* Card */}
          <div className="login-card-shadow rounded-2xl border border-[var(--login-line)] bg-[var(--login-surface)] p-6 sm:p-8">

            {/* Server error alert */}
            {serverError && (
              <div
                className="mb-6 rounded-xl border border-[var(--login-danger)] bg-[var(--login-danger-soft)] p-4 text-sm leading-6 text-[var(--login-danger)]"
                role="alert"
              >
                {serverError}
              </div>
            )}

            <form noValidate onSubmit={handleSubmit}>
              {/* Email */}
              <div className="mb-5">
                <label
                  className="mb-2 block text-sm font-medium text-[var(--login-ink)]"
                  htmlFor={emailId}
                >
                  {t.email}
                </label>
                <div
                  className="login-field-wrap flex min-h-12 items-center rounded-xl border border-[var(--login-line)] bg-[var(--login-field)]"
                  data-invalid={Boolean(fieldErrors.email)}
                >
                  <input
                    aria-describedby={fieldErrors.email ? `${emailId}-error` : undefined}
                    aria-invalid={Boolean(fieldErrors.email)}
                    autoComplete="email"
                    className="min-h-12 w-full rounded-xl border-0 bg-transparent px-4 text-start text-base text-[var(--login-ink)] outline-none placeholder:text-[var(--login-muted)]"
                    dir="ltr"
                    id={emailId}
                    inputMode="email"
                    name="email"
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (fieldErrors.email)
                        setFieldErrors((c) => ({ ...c, email: undefined }));
                    }}
                    placeholder={t.emailPlaceholder}
                    type="email"
                    value={email}
                  />
                </div>
                {fieldErrors.email && (
                  <p className="m-0 mt-2 text-sm text-[var(--login-danger)]" id={`${emailId}-error`}>
                    {fieldErrors.email}
                  </p>
                )}
              </div>

              {/* Password */}
              <div className="mb-3 flex items-center justify-between gap-4">
                <label
                  className="text-sm font-medium text-[var(--login-ink)]"
                  htmlFor={passwordId}
                >
                  {t.password}
                </label>
                <a
                  className="login-focus-ring rounded text-sm font-medium text-[var(--login-accent)] underline decoration-transparent underline-offset-4 hover:decoration-current"
                  href="/forgot-password"
                >
                  {t.forgot}
                </a>
              </div>
              <div
                className="login-field-wrap flex min-h-12 items-center rounded-xl border border-[var(--login-line)] bg-[var(--login-field)]"
                data-invalid={Boolean(fieldErrors.password)}
              >
                <input
                  aria-describedby={fieldErrors.password ? `${passwordId}-error` : undefined}
                  aria-invalid={Boolean(fieldErrors.password)}
                  autoComplete="current-password"
                  className="min-h-12 min-w-0 flex-1 rounded-xl border-0 bg-transparent ps-4 text-start text-base text-[var(--login-ink)] outline-none placeholder:text-[var(--login-muted)]"
                  dir="ltr"
                  id={passwordId}
                  name="password"
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (fieldErrors.password)
                      setFieldErrors((c) => ({ ...c, password: undefined }));
                  }}
                  placeholder={t.passwordPlaceholder}
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                />
                <button
                  aria-label={showPassword ? t.hidePassword : t.showPassword}
                  aria-pressed={showPassword}
                  className="login-focus-ring me-1 flex size-12 shrink-0 items-center justify-center rounded-xl text-[var(--login-muted)] hover:bg-[var(--login-panel)] hover:text-[var(--login-ink)]"
                  onClick={() => setShowPassword((c) => !c)}
                  type="button"
                >
                  <EyeIcon hidden={showPassword} />
                </button>
              </div>
              {fieldErrors.password && (
                <p className="m-0 mt-2 text-sm text-[var(--login-danger)]" id={`${passwordId}-error`}>
                  {fieldErrors.password}
                </p>
              )}

              {/* Submit */}
              <button
                className="login-focus-ring mt-6 flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-[var(--login-accent)] px-5 text-base font-semibold text-[var(--login-on-accent)] hover:bg-[var(--login-accent-hover)] disabled:cursor-not-allowed disabled:opacity-70"
                disabled={loginMutation.isPending}
                type="submit"
              >
                {loginMutation.isPending && (
                  <span
                    aria-hidden="true"
                    className="size-5 animate-spin rounded-full border-2 border-current border-e-transparent"
                  />
                )}
                <span>
                  {loginMutation.isPending ? t.submitting : t.submit}
                  {loginMutation.isPending && <span className="sr-only">…</span>}
                </span>
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* ── Right: panel ───────────────────────────────────────── */}
      <aside className="relative hidden min-h-full overflow-hidden rounded-3xl bg-[var(--login-panel)] lg:flex lg:items-center lg:justify-center">
        <div className="relative z-10 max-w-md p-12">
          <h2 className="m-0 text-4xl font-semibold tracking-tight text-[var(--login-ink)]">
            {t.panelTitle}
          </h2>
          <p className="m-0 mt-4 text-lg leading-8 text-[var(--login-muted)]">
            {t.panelBody}
          </p>
          <div className="mt-10 h-px w-16 bg-[var(--login-accent)]" />
          <p className="m-0 mt-4 text-sm text-[var(--login-muted)]">
            {t.panelNote}
          </p>
        </div>

        {/* Decorative tooth contour */}
        <svg
          aria-hidden="true"
          className="absolute -bottom-24 -end-24 h-3/4 w-3/4 text-[var(--login-accent)] opacity-20"
          fill="none"
          viewBox="0 0 500 500"
        >
          <path
            className="tooth-line"
            d="M174 52c29 0 49 19 76 19s47-19 76-19c55 0 90 44 87 101-3 51-29 79-38 132-9 47-22 74-49 74-32 0-31-78-76-78s-44 78-76 78c-27 0-40-27-49-74-9-53-35-81-38-132-3-57 32-101 87-101Z"
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
          <path
            className="tooth-line"
            d="M174 95c24 0 48 13 76 13s52-13 76-13"
            stroke="currentColor"
            strokeLinecap="round"
            strokeWidth="2"
          />
        </svg>
      </aside>
    </main>
  );
}
