import type { ToolDefinition } from '../providers/types';

/**
 * The complete tool surface (plan §9).
 *
 * Explicit schemas only — there is no path from a model's output to
 * arbitrary backend execution. A tool that is not in this file cannot be
 * called, a tool not enabled on the agent version is denied, and every
 * attempt is recorded either way.
 *
 * `isImplemented: false` marks tools whose backing data does not exist in
 * this build. They stay in the catalogue because the agent needs a way to
 * say "I cannot look that up" rather than inventing an answer — and
 * because faking success would be worse than saying so (plan §15).
 */

export interface FirstElementTool extends ToolDefinition {
  /** Reads may run freely; writes change customer data and are audited. */
  mutates: boolean;
  isImplemented: boolean;
}

export const TOOLS: Record<string, FirstElementTool> = {
  get_customer: {
    name: 'get_customer',
    description:
      'Look up the customer of the current conversation: display name, contact details, locale, tags and linked channel handles.',
    mutates: false,
    isImplemented: true,
    parameters: { type: 'object', properties: {}, additionalProperties: false },
  },

  search_knowledge_base: {
    name: 'search_knowledge_base',
    description:
      "Search this project's knowledge base for business information. Use this before answering any question about policy, pricing, hours or process.",
    mutates: false,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'The question to look up, in the customer language' },
      },
      required: ['query'],
      additionalProperties: false,
    },
  },

  get_business_hours: {
    name: 'get_business_hours',
    description: 'Get the working hours and timezone configured for this project.',
    mutates: false,
    isImplemented: true,
    parameters: { type: 'object', properties: {}, additionalProperties: false },
  },

  update_customer: {
    name: 'update_customer',
    description:
      'Update the current customer contact details when they provide them. Only email, phone and preferred language may be changed.',
    mutates: true,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        primaryEmail: { type: 'string' },
        primaryPhone: { type: 'string' },
        locale: { type: 'string', enum: ['ar', 'en'] },
      },
      additionalProperties: false,
    },
  },

  add_tag: {
    name: 'add_tag',
    description: 'Add a short tag to the current customer, for example "vip" or "billing-issue".',
    mutates: true,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: { tag: { type: 'string', maxLength: 40 } },
      required: ['tag'],
      additionalProperties: false,
    },
  },

  request_human: {
    name: 'request_human',
    description:
      'Hand the conversation to a human colleague. Use when the customer asks for a person, when you cannot answer from the knowledge base, or when the situation needs judgement.',
    mutates: true,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        reason: { type: 'string', description: 'Why a person is needed, in one sentence' },
      },
      required: ['reason'],
      additionalProperties: false,
    },
  },

  resolve_conversation: {
    name: 'resolve_conversation',
    description:
      'Close this conversation when the customer issue is fully resolved and no further assistance is needed. Use after confirming the customer has no more questions.',
    mutates: true,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        reason: { type: 'string', description: 'Brief summary of how the issue was resolved' },
      },
      required: ['reason'],
      additionalProperties: false,
    },
  },

  // --- Clinic Flow Scheduling Tools ------------------------------------

  get_doctors: {
    name: 'get_doctors',
    description:
      'Retrieve the list of clinic doctors, their specialties, working days, and working hours. Can filter by specialty.',
    mutates: false,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        specialty: {
          type: 'string',
          description: 'Optional medical specialty filter, e.g. "Dental", "Dermatology", "General"',
        },
      },
      additionalProperties: false,
    },
  },

  get_procedures: {
    name: 'get_procedures',
    description:
      'Retrieve clinic procedures and services, standard durations in minutes, buffer times, and prices. Can filter by specialty.',
    mutates: false,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        specialty: {
          type: 'string',
          description: 'Optional medical specialty filter',
        },
      },
      additionalProperties: false,
    },
  },

  get_procedure_duration: {
    name: 'get_procedure_duration',
    description:
      'Get the exact duration in minutes, buffer time, and price for a specific procedure ID.',
    mutates: false,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        procedure_id: { type: 'string', description: 'The unique ID of the procedure' },
      },
      required: ['procedure_id'],
      additionalProperties: false,
    },
  },

  check_availability: {
    name: 'check_availability',
    description:
      'Check if a doctor is available at the requested date and time for a specific procedure. Returns whether the slot is valid or conflicts exist, along with alternative slots/doctors if unavailable.',
    mutates: false,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        doctor_id: { type: 'string', description: 'The doctor ID' },
        datetime: {
          type: 'string',
          description: 'Requested appointment ISO datetime (e.g. 2026-10-08T10:00:00Z)',
        },
        procedure_id: { type: 'string', description: 'The procedure ID' },
      },
      required: ['doctor_id', 'datetime', 'procedure_id'],
      additionalProperties: false,
    },
  },

  find_available_slots: {
    name: 'find_available_slots',
    description:
      'Find all collision-free available time slots for a doctor on a specific date for a given procedure.',
    mutates: false,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        doctor_id: { type: 'string', description: 'The doctor ID' },
        date: { type: 'string', description: 'Target date in YYYY-MM-DD format' },
        procedure_id: { type: 'string', description: 'The procedure ID' },
      },
      required: ['doctor_id', 'date', 'procedure_id'],
      additionalProperties: false,
    },
  },

  create_appointment: {
    name: 'create_appointment',
    description:
      'Book and confirm a new appointment for the patient. Validates availability deterministically and prevents collisions.',
    mutates: true,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        doctor_id: { type: 'string', description: 'The doctor ID' },
        procedure_id: { type: 'string', description: 'The procedure ID' },
        datetime: { type: 'string', description: 'Confirmed appointment datetime in ISO format' },
        patient_id: {
          type: 'string',
          description: 'Optional patient customer ID (defaults to current customer if omitted)',
        },
        notes: { type: 'string', description: 'Optional patient notes or reason for visit' },
      },
      required: ['doctor_id', 'procedure_id', 'datetime'],
      additionalProperties: false,
    },
  },

  reschedule_appointment: {
    name: 'reschedule_appointment',
    description:
      'Reschedule an existing appointment to a new validated date and time.',
    mutates: true,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        appointment_id: {
          type: 'string',
          description: 'The ID of the existing appointment to reschedule',
        },
        new_datetime: { type: 'string', description: 'New requested datetime in ISO format' },
        reason: { type: 'string', description: 'Optional reason for rescheduling' },
      },
      required: ['appointment_id', 'new_datetime'],
      additionalProperties: false,
    },
  },

  cancel_appointment: {
    name: 'cancel_appointment',
    description: 'Cancel an existing scheduled appointment and record the reason.',
    mutates: true,
    isImplemented: true,
    parameters: {
      type: 'object',
      properties: {
        appointment_id: { type: 'string', description: 'The ID of the appointment to cancel' },
        reason: { type: 'string', description: 'Reason for cancelling the appointment' },
      },
      required: ['appointment_id'],
      additionalProperties: false,
    },
  },

  // --- catalogued, not backed by data in this build -----------------------

  get_customer_orders: {
    name: 'get_customer_orders',
    description: "Look up the customer's recent orders.",
    mutates: false,
    isImplemented: false,
    parameters: {
      type: 'object',
      properties: { limit: { type: 'integer', minimum: 1, maximum: 20 } },
      additionalProperties: false,
    },
  },

  get_product: {
    name: 'get_product',
    description: 'Look up a product by name or SKU.',
    mutates: false,
    isImplemented: false,
    parameters: {
      type: 'object',
      properties: { query: { type: 'string' } },
      required: ['query'],
      additionalProperties: false,
    },
  },

  create_ticket: {
    name: 'create_ticket',
    description: 'Create a support ticket in the external ticketing system.',
    mutates: true,
    isImplemented: false,
    parameters: {
      type: 'object',
      properties: {
        subject: { type: 'string' },
        description: { type: 'string' },
      },
      required: ['subject'],
      additionalProperties: false,
    },
  },
};

export const TOOL_NAMES = Object.keys(TOOLS);

/** Sensible starting set for a new agent: read-only plus the handover and clinic scheduling. */
export const DEFAULT_ENABLED_TOOLS = [
  'search_knowledge_base',
  'get_customer',
  'get_business_hours',
  'request_human',
  'resolve_conversation',
  'get_doctors',
  'get_procedures',
  'get_procedure_duration',
  'check_availability',
  'find_available_slots',
  'create_appointment',
  'reschedule_appointment',
  'cancel_appointment',
];

export function toolDefinitionsFor(enabled: string[]): ToolDefinition[] {
  return enabled
    .map((name) => TOOLS[name])
    .filter((tool): tool is FirstElementTool => Boolean(tool))
    .map((tool) => ({
      name: tool.name,
      description: tool.isImplemented
        ? tool.description
        : `${tool.description} (Not available in this deployment — calling it returns an explanation, not data.)`,
      parameters: tool.parameters,
    }));
}
