import type { PrismaClient } from '@firstelement/database';
import type { ToolCallRequest } from '../providers/types';
import { TOOLS } from './definitions';
import {
  getClinicDoctors,
  getClinicProcedures,
  getProcedureDuration,
  checkDoctorAvailability,
  findDoctorAvailableSlots,
  createAppointmentValidated,
  rescheduleAppointmentValidated,
  cancelAppointmentValidated,
} from './clinic-scheduling';

export interface ToolContext {
  organizationId: string;
  projectId: string;
  conversationId: string;
  customerId: string;
  /** Tool names this agent version may call. */
  enabledTools: string[];
  /** Injected so the executor does not depend on the knowledge package. */
  searchKnowledge: (query: string) => Promise<{ title: string; content: string; score: number }[]>;
}

export interface ToolOutcome {
  name: string;
  arguments: Record<string, unknown>;
  result: Record<string, unknown>;
  authorized: boolean;
  isError: boolean;
  errorMessage?: string;
  latencyMs: number;
  /** Set by request_human; the orchestrator turns it into an escalation. */
  requestsHuman?: boolean;
  /** Set by resolve_conversation; the orchestrator closes the conversation. */
  requestsResolve?: boolean;
}

/**
 * Executes tool calls under the same authorization the rest of the API
 * uses (plan §9).
 *
 * Three rules hold regardless of what the model asked for:
 *
 * 1. A tool not enabled on the agent version is denied — and the denial is
 *    recorded, because a model repeatedly reaching for a tool it cannot
 *    use is exactly the signal a prompt-injection investigation needs.
 * 2. The *tenant and project* columns always come from this context, never
 *    from tool arguments. A model cannot choose which tenant a tool reads.
 *    It can, however, name a row id (`doctor_id`, `procedure_id`,
 *    `patient_id`, `appointment_id`), so every clinic helper re-checks that
 *    the named row belongs to `ctx.organizationId` / `ctx.projectId` before
 *    returning it. An earlier version of this comment claimed "there is no
 *    argument through which to name one" — that was false, and the clinic
 *    tools were the proof: an injected model could name another tenant's
 *    doctor, procedure or customer.
 * 3. Writes touch a fixed set of fields. `update_customer` cannot change a
 *    tag list, a project, or anything else the schema would otherwise allow.
 */
export class ToolExecutor {
  constructor(private readonly prisma: PrismaClient) {}

  async execute(call: ToolCallRequest, ctx: ToolContext): Promise<ToolOutcome> {
    const startedAt = Date.now();
    const definition = TOOLS[call.name];

    if (!definition) {
      return this.deny(call, startedAt, `Unknown tool "${call.name}"`);
    }
    if (!ctx.enabledTools.includes(call.name)) {
      return this.deny(call, startedAt, `Tool "${call.name}" is not enabled for this agent`);
    }

    try {
      const result = await this.run(call, ctx);
      return {
        name: call.name,
        arguments: call.arguments,
        result: result.result,
        authorized: true,
        isError: false,
        latencyMs: Date.now() - startedAt,
        requestsHuman: result.requestsHuman,
      };
    } catch (error) {
      return {
        name: call.name,
        arguments: call.arguments,
        result: {},
        authorized: true,
        isError: true,
        errorMessage: error instanceof Error ? error.message : String(error),
        latencyMs: Date.now() - startedAt,
      };
    }
  }

  private async run(
    call: ToolCallRequest,
    ctx: ToolContext,
  ): Promise<{ result: Record<string, unknown>; requestsHuman?: boolean; requestsResolve?: boolean }> {
    switch (call.name) {
      case 'get_customer': {
        const customer = await this.prisma.customer.findFirst({
          where: {
            id: ctx.customerId,
            organizationId: ctx.organizationId,
            projectId: ctx.projectId,
          },
          select: {
            displayName: true,
            primaryEmail: true,
            primaryPhone: true,
            locale: true,
            tags: true,
            firstSeenAt: true,
            identities: { select: { platform: true, isVerified: true } },
          },
        });
        return { result: { customer: customer ?? null } };
      }

      case 'search_knowledge_base': {
        const query = String(call.arguments.query ?? '').slice(0, 500);
        const results = await ctx.searchKnowledge(query);
        return {
          result: {
            results: results.map((item) => ({
              title: item.title,
              content: item.content,
              score: Number(item.score.toFixed(3)),
            })),
            // The model must be told plainly when there is nothing, so it
            // asks or escalates instead of filling the gap itself.
            found: results.length > 0,
          },
        };
      }

      case 'get_business_hours': {
        const project = await this.prisma.project.findFirst({
          where: { id: ctx.projectId, organizationId: ctx.organizationId },
          select: { timezone: true, defaultLocale: true },
        });
        return {
          result: {
            timezone: project?.timezone ?? null,
            // Working-hours schedules arrive with routing in slice 7.
            hours: null,
            note: 'Working hours are not configured for this project yet.',
          },
        };
      }

      case 'update_customer': {
        const data: Record<string, string> = {};
        const email = call.arguments.primaryEmail;
        const phone = call.arguments.primaryPhone;
        const locale = call.arguments.locale;

        if (typeof email === 'string' && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
          data.primaryEmail = email.toLowerCase();
        }
        if (typeof phone === 'string' && /^\+?[0-9\s-]{6,20}$/.test(phone)) {
          data.primaryPhone = phone;
        }
        if (locale === 'ar' || locale === 'en') data.locale = locale;

        if (Object.keys(data).length === 0) {
          return { result: { updated: false, reason: 'No valid fields to update' } };
        }

        await this.prisma.customer.updateMany({
          where: {
            id: ctx.customerId,
            organizationId: ctx.organizationId,
            projectId: ctx.projectId,
          },
          data,
        });
        return { result: { updated: true, fields: Object.keys(data) } };
      }

      case 'add_tag': {
        const tag = String(call.arguments.tag ?? '')
          .trim()
          .slice(0, 40);
        if (!tag) return { result: { added: false, reason: 'Empty tag' } };

        const customer = await this.prisma.customer.findFirst({
          where: {
            id: ctx.customerId,
            organizationId: ctx.organizationId,
            projectId: ctx.projectId,
          },
          select: { tags: true },
        });
        if (!customer) return { result: { added: false, reason: 'Customer not found' } };
        if (customer.tags.includes(tag)) return { result: { added: false, reason: 'Already tagged' } };

        await this.prisma.customer.updateMany({
          where: { id: ctx.customerId, projectId: ctx.projectId },
          data: { tags: [...customer.tags, tag].slice(0, 30) },
        });
        return { result: { added: true, tag } };
      }

      case 'request_human': {
        const reason = String(call.arguments.reason ?? 'Not specified').slice(0, 300);
        // The tool records the intent; the orchestrator performs the
        // handover, so the mode change stays in one place (plan §10).
        return { result: { acknowledged: true, reason }, requestsHuman: true };
      }

      case 'resolve_conversation': {
        const reason = String(call.arguments.reason ?? 'Resolved').slice(0, 300);
        // The tool records the intent; the orchestrator performs the
        // close, so the status change stays in one place.
        return { result: { acknowledged: true, reason }, requestsResolve: true };
      }

      case 'get_doctors': {
        const specialty = typeof call.arguments.specialty === 'string' ? call.arguments.specialty : undefined;
        const doctors = await getClinicDoctors(
          this.prisma,
          ctx.organizationId,
          ctx.projectId,
          specialty,
        );
        return { result: { doctors, count: doctors.length } };
      }

      case 'get_procedures': {
        const specialty = typeof call.arguments.specialty === 'string' ? call.arguments.specialty : undefined;
        const procedures = await getClinicProcedures(
          this.prisma,
          ctx.organizationId,
          ctx.projectId,
          specialty,
        );
        return { result: { procedures, count: procedures.length } };
      }

      case 'get_procedure_duration': {
        const procedureId = String(call.arguments.procedure_id ?? '');
        const info = await getProcedureDuration(
          this.prisma,
          ctx.organizationId,
          ctx.projectId,
          procedureId,
        );
        return { result: info as Record<string, unknown> };
      }

      case 'check_availability': {
        const doctorId = String(call.arguments.doctor_id ?? '');
        const procedureId = String(call.arguments.procedure_id ?? '');
        const rawDatetime = String(call.arguments.datetime ?? '');
        const requestedDate = new Date(rawDatetime);
        if (isNaN(requestedDate.getTime())) {
          return {
            result: {
              available: false,
              reason: 'Invalid datetime format. Please provide ISO 8601 (e.g. 2026-10-08T10:00:00Z)',
            },
          };
        }
        const check = await checkDoctorAvailability(
          this.prisma,
          ctx.organizationId,
          ctx.projectId,
          doctorId,
          requestedDate,
          procedureId,
        );
        return { result: check as unknown as Record<string, unknown> };
      }

      case 'find_available_slots': {
        const doctorId = String(call.arguments.doctor_id ?? '');
        const procedureId = String(call.arguments.procedure_id ?? '');
        const dateStr = String(call.arguments.date ?? '');
        const slotsRes = await findDoctorAvailableSlots(
          this.prisma,
          ctx.organizationId,
          ctx.projectId,
          doctorId,
          dateStr,
          procedureId,
        );
        return { result: slotsRes as unknown as Record<string, unknown> };
      }

      case 'create_appointment': {
        const doctorId = String(call.arguments.doctor_id ?? '');
        const procedureId = String(call.arguments.procedure_id ?? '');
        const rawDatetime = String(call.arguments.datetime ?? '');
        const patientId =
          typeof call.arguments.patient_id === 'string' && call.arguments.patient_id
            ? call.arguments.patient_id
            : ctx.customerId;
        const notes = typeof call.arguments.notes === 'string' ? call.arguments.notes : undefined;
        const requestedDate = new Date(rawDatetime);
        if (isNaN(requestedDate.getTime())) {
          return {
            result: {
              booked: false,
              reason: 'Invalid datetime format. Please provide ISO 8601 (e.g. 2026-10-08T10:00:00Z)',
            },
          };
        }
        const outcome = await createAppointmentValidated(this.prisma, {
          organizationId: ctx.organizationId,
          projectId: ctx.projectId,
          customerId: patientId,
          doctorId,
          procedureId,
          requestedDate,
          notes,
        });
        return { result: outcome as Record<string, unknown> };
      }

      case 'reschedule_appointment': {
        const appointmentId = String(call.arguments.appointment_id ?? '');
        const rawDatetime = String(call.arguments.new_datetime ?? '');
        const reason = typeof call.arguments.reason === 'string' ? call.arguments.reason : undefined;
        const newDate = new Date(rawDatetime);
        if (isNaN(newDate.getTime())) {
          return {
            result: {
              rescheduled: false,
              reason: 'Invalid datetime format. Please provide ISO 8601 (e.g. 2026-10-08T10:00:00Z)',
            },
          };
        }
        const outcome = await rescheduleAppointmentValidated(this.prisma, {
          organizationId: ctx.organizationId,
          projectId: ctx.projectId,
          appointmentId,
          newDate,
          reason,
        });
        return { result: outcome as Record<string, unknown> };
      }

      case 'cancel_appointment': {
        const appointmentId = String(call.arguments.appointment_id ?? '');
        const reason = typeof call.arguments.reason === 'string' ? call.arguments.reason : undefined;
        const outcome = await cancelAppointmentValidated(this.prisma, {
          organizationId: ctx.organizationId,
          projectId: ctx.projectId,
          appointmentId,
          reason,
        });
        return { result: outcome as Record<string, unknown> };
      }

      default: {
        const definition = TOOLS[call.name];
        return {
          result: {
            available: false,
            reason: `${call.name} is not connected in this deployment. Tell the customer you cannot look this up, and offer a human colleague.`,
            tool: definition?.name ?? call.name,
          },
        };
      }
    }
  }

  private deny(call: ToolCallRequest, startedAt: number, reason: string): ToolOutcome {
    return {
      name: call.name,
      arguments: call.arguments,
      result: { denied: true, reason },
      authorized: false,
      isError: false,
      latencyMs: Date.now() - startedAt,
    };
  }
}
