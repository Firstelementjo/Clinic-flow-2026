import { atom, useAtom } from 'jotai';

export type Theme = 'light' | 'dark';

const STORAGE_KEY = 'fe.theme.v2';

function initialTheme(): Theme {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored === 'light' || stored === 'dark') return stored;
  if (typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches) return 'dark';
  return 'light';
}

/**
 * Applies `data-theme` to <html>, which the design tokens read to flip the
 * whole app (see tokens.css). Mutates the DOM element directly rather than a
 * React tree so the setting survives until unmount and matches how the UI
 * package interprets direction from locale.
 */
function apply(theme: Theme) {
  document.documentElement.dataset.theme = theme;
}

/**
 * Theme is genuine client state (a per-device preference), so it lives in
 * Jotai like the locale does. It seeds from the saved theme (or the OS
 * preference on first visit) and is the user's to override afterwards.
 */
const themeAtom = atom<Theme>(initialTheme());

export function useTheme() {
  const [theme, setThemeState] = useAtom(themeAtom);

  const setTheme = (next: Theme) => {
    localStorage.setItem(STORAGE_KEY, next);
    apply(next);
    setThemeState(next);
  };

  return {
    theme,
    setTheme,
    toggle: () => setTheme(theme === 'dark' ? 'light' : 'dark'),
  };
}

/** Called once before the app mounts so the first paint is already themed. */
export function initTheme() {
  apply(initialTheme());
}