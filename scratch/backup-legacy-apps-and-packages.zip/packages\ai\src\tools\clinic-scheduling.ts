import type { PrismaClient } from '@firstelement/database';

/**
 * Tenant scope for every clinic lookup in this file.
 *
 * <h2>Why this exists</h2>
 *
 * <p>These functions run behind the AI tool executor, and the executor passes a
 * model-supplied {@code doctor_id}, {@code procedure_id} or {@code patient_id}
 * straight through. An id from a model is a <em>claim</em>, not a fact Ã¢â‚¬â€ and a
 * customer message is untrusted input, so a prompt injection decides those ids.
 * Resolving them with {@code findUnique({ where: { id } })} let an injected model
 * read another tenant's doctors, procedures and customer contact details.
 *
 * <p>Every lookup below therefore carries {@code organizationId} and
 * {@code projectId} from the tool context. A row outside that scope is reported
 * with the <em>same</em> "not found" result the function already returned for a
 * genuinely nonexistent id, so a denial discloses nothing Ã¢â‚¬â€ there is no distinct
 * "not yours" outcome for a caller to distinguish.
 */
export interface ClinicScope {
  organizationId: string;
  projectId: string;
}

function scope(organizationId: string, projectId: string): ClinicScope {
  return { organizationId, projectId };
}

export interface DoctorResult {
  id: string;
  name: string;
  specialty: string;
  workingDays: number[];
  workingHours: string;
  slotDuration: number;
}

export interface ProcedureResult {
  id: string;
  name: string;
  specialty: string;
  durationMinutes: number;
  bufferMinutes: number;
  price: number;
}

export interface AvailabilityResult {
  available: boolean;
  code?: 'VALID' | 'DOCTOR_UNAVAILABLE_ON_DATE' | 'OUTSIDE_WORKING_HOURS' | 'SLOT_OCCUPIED' | 'NOT_FOUND';
  reason?: string;
  doctorId: string;
  doctorName?: string;
  procedureName?: string;
  requestedDateTime: string;
  durationMinutes?: number;
  availableAlternatives?: string[];
  alternativeDoctors?: Array<{
    doctorId: string;
    doctorName: string;
    specialty: string;
  }>;
}

export interface AvailableSlotsResult {
  doctorId: string;
  doctorName: string;
  procedureId: string;
  procedureName: string;
  durationMinutes: number;
  date: string;
  isWorkingDay: boolean;
  slots: string[];
  reason?: string;
}

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function parseTimeToMinutes(timeStr: string): number {
  const parts = timeStr.split(':').map(Number);
  const h = parts[0] ?? 9;
  const m = parts[1] ?? 0;
  return h * 60 + m;
}

export async function getClinicDoctors(
  prisma: PrismaClient,
  organizationId: string,
  projectId: string,
  specialty?: string,
): Promise<DoctorResult[]> {
  // `organizationId` rides along with `projectId`. Project ids are UUIDs, so the
  // project filter alone would usually be enough Ã¢â‚¬â€ but a missing tenant column is
  // exactly what let a roster read cross a boundary, and this is the second line.
  const where = { organizationId, projectId, isActive: true } as Record<string, unknown>;
  if (specialty) {
    where.specialty = { contains: specialty, mode: 'insensitive' };
  }

  const doctors = await prisma.doctor.findMany({
    where,
    orderBy: { name: 'asc' },
  });

  return doctors.map((d) => ({
    id: d.id,
    name: d.name,
    specialty: d.specialty,
    workingDays: d.workingDays,
    workingHours: `${d.startHour} - ${d.endHour}`,
    slotDuration: d.slotDuration,
  }));
}

export async function getClinicProcedures(
  prisma: PrismaClient,
  organizationId: string,
  projectId: string,
  specialty?: string,
): Promise<ProcedureResult[]> {
  const where = { organizationId, projectId, isActive: true } as Record<string, unknown>;
  if (specialty) {
    where.specialty = { contains: specialty, mode: 'insensitive' };
  }

  const procedures = await prisma.procedure.findMany({
    where,
    orderBy: { name: 'asc' },
  });

  return procedures.map((p) => ({
    id: p.id,
    name: p.name,
    specialty: p.specialty,
    durationMinutes: p.durationMinutes,
    bufferMinutes: p.bufferMinutes,
    price: Number(p.price),
  }));
}

export async function getProcedureDuration(
  prisma: PrismaClient,
  organizationId: string,
  projectId: string,
  procedureId: string,
) {
  const procedure = await prisma.procedure.findFirst({
    where: { id: procedureId, ...scope(organizationId, projectId) },
  });

  if (!procedure) {
    return { error: `Procedure with ID "${procedureId}" not found` };
  }

  return {
    procedureId: procedure.id,
    name: procedure.name,
    specialty: procedure.specialty,
    durationMinutes: procedure.durationMinutes,
    bufferMinutes: procedure.bufferMinutes,
    totalOccupiedMinutes: procedure.durationMinutes + procedure.bufferMinutes,
    price: Number(procedure.price),
  };
}

export async function findDoctorAvailableSlots(
  prisma: PrismaClient,
  organizationId: string,
  projectId: string,
  doctorId: string,
  dateStr: string,
  procedureId: string,
): Promise<AvailableSlotsResult> {
  const doctor = await prisma.doctor.findFirst({
    where: { id: doctorId, ...scope(organizationId, projectId) },
  });
  const procedure = await prisma.procedure.findFirst({
    where: { id: procedureId, ...scope(organizationId, projectId) },
  });

  if (!doctor) {
    return {
      doctorId,
      doctorName: 'Unknown',
      procedureId,
      procedureName: 'Unknown',
      durationMinutes: 30,
      date: dateStr,
      isWorkingDay: false,
      slots: [],
      reason: 'Doctor not found',
    };
  }

  const targetDate = new Date(`${dateStr}T00:00:00.000Z`);
  const dayOfWeek = targetDate.getUTCDay();
  const procedureDuration = (procedure?.durationMinutes || 30) + (procedure?.bufferMinutes || 0);

  if (!doctor.workingDays.includes(dayOfWeek)) {
    const dayName = DAY_NAMES[dayOfWeek] || 'that day';
    return {
      doctorId,
      doctorName: doctor.name,
      procedureId,
      procedureName: procedure?.name || 'Consultation',
      durationMinutes: procedureDuration,
      date: dateStr,
      isWorkingDay: false,
      slots: [],
      reason: `${doctor.name} does not work on ${dayName}s. Working days are Sunday through Thursday.`,
    };
  }

  const dayStartMinutes = parseTimeToMinutes(doctor.startHour);
  const dayEndMinutes = parseTimeToMinutes(doctor.endHour);

  // Fetch appointments for this doctor on that date (excluding CANCELLED)
  const startOfDay = new Date(`${dateStr}T00:00:00.000Z`);
  const endOfDay = new Date(`${dateStr}T23:59:59.999Z`);

  const existingAppointments = await prisma.appointment.findMany({
    where: {
      doctorId,
      ...scope(organizationId, projectId),
      appointmentDate: { gte: startOfDay, lte: endOfDay },
      status: { notIn: ['CANCELLED', 'NO_SHOW'] },
    },
    select: { appointmentDate: true, durationMinutes: true },
  });

  const busyIntervals = existingAppointments.map((a) => {
    const d = new Date(a.appointmentDate);
    const start = d.getUTCHours() * 60 + d.getUTCMinutes();
    return { start, end: start + a.durationMinutes };
  });

  const validSlots: string[] = [];
  const step = 30; // standard 30 min intervals

  for (let slotStart = dayStartMinutes; slotStart + procedureDuration <= dayEndMinutes; slotStart += step) {
    const slotEnd = slotStart + procedureDuration;
    const collides = busyIntervals.some((b) => slotStart < b.end && slotEnd > b.start);

    if (!collides) {
      const hh = String(Math.floor(slotStart / 60)).padStart(2, '0');
      const mm = String(slotStart % 60).padStart(2, '0');
      validSlots.push(`${hh}:${mm}`);
    }
  }

  return {
    doctorId,
    doctorName: doctor.name,
    procedureId,
    procedureName: procedure?.name || 'Consultation',
    durationMinutes: procedureDuration,
    date: dateStr,
    isWorkingDay: true,
    slots: validSlots,
    reason: validSlots.length === 0 ? 'Fully booked for this date' : undefined,
  };
}

export async function checkDoctorAvailability(
  prisma: PrismaClient,
  organizationId: string,
  projectId: string,
  doctorId: string,
  requestedDate: Date,
  procedureId: string,
): Promise<AvailabilityResult> {
  const doctor = await prisma.doctor.findFirst({
    where: { id: doctorId, ...scope(organizationId, projectId) },
  });
  const procedure = await prisma.procedure.findFirst({
    where: { id: procedureId, ...scope(organizationId, projectId) },
  });

  const dateStr = requestedDate.toISOString().slice(0, 10);
  const timeStr = requestedDate.toISOString().slice(11, 16);

  if (!doctor) {
    return {
      available: false,
      code: 'NOT_FOUND',
      reason: `Doctor with ID "${doctorId}" not found`,
      doctorId,
      requestedDateTime: requestedDate.toISOString(),
    };
  }

  const procedureDuration = (procedure?.durationMinutes || 30) + (procedure?.bufferMinutes || 0);
  const dayOfWeek = requestedDate.getUTCDay();

  // 1. Working Day Check
  if (!doctor.workingDays.includes(dayOfWeek)) {
    const dayName = DAY_NAMES[dayOfWeek] || 'that day';
    const altSlots = await findNextAlternativeSlots(
      prisma,
      organizationId,
      projectId,
      doctorId,
      procedureId,
      dateStr,
    );
    return {
      available: false,
      code: 'DOCTOR_UNAVAILABLE_ON_DATE',
      reason: `${doctor.name} is not available on ${dayName}s.`,
      doctorId,
      doctorName: doctor.name,
      procedureName: procedure?.name,
      requestedDateTime: requestedDate.toISOString(),
      durationMinutes: procedureDuration,
      availableAlternatives: altSlots,
    };
  }

  // 2. Working Hours Check
  const dayStartMinutes = parseTimeToMinutes(doctor.startHour);
  const dayEndMinutes = parseTimeToMinutes(doctor.endHour);
  const reqStartMinutes = requestedDate.getUTCHours() * 60 + requestedDate.getUTCMinutes();
  const reqEndMinutes = reqStartMinutes + procedureDuration;

  if (reqStartMinutes < dayStartMinutes || reqEndMinutes > dayEndMinutes) {
    const avail = await findDoctorAvailableSlots(
      prisma,
      organizationId,
      projectId,
      doctorId,
      dateStr,
      procedureId,
    );
    return {
      available: false,
      code: 'OUTSIDE_WORKING_HOURS',
      reason: `Requested time ${timeStr} is outside ${doctor.name}'s working hours (${doctor.startHour} - ${doctor.endHour}).`,
      doctorId,
      doctorName: doctor.name,
      procedureName: procedure?.name,
      requestedDateTime: requestedDate.toISOString(),
      durationMinutes: procedureDuration,
      availableAlternatives: avail.slots.map((s) => `${dateStr}T${s}:00Z`),
    };
  }

  // 3. Collision Check
  const startOfDay = new Date(`${dateStr}T00:00:00.000Z`);
  const endOfDay = new Date(`${dateStr}T23:59:59.999Z`);

  const existing = await prisma.appointment.findMany({
    where: {
      doctorId,
      ...scope(organizationId, projectId),
      appointmentDate: { gte: startOfDay, lte: endOfDay },
      status: { notIn: ['CANCELLED', 'NO_SHOW'] },
    },
    select: { appointmentDate: true, durationMinutes: true },
  });

  const collision = existing.find((a) => {
    const d = new Date(a.appointmentDate);
    const aStart = d.getUTCHours() * 60 + d.getUTCMinutes();
    const aEnd = aStart + a.durationMinutes;
    return reqStartMinutes < aEnd && reqEndMinutes > aStart;
  });

  if (collision) {
    const avail = await findDoctorAvailableSlots(
      prisma,
      organizationId,
      projectId,
      doctorId,
      dateStr,
      procedureId,
    );
    const altDoctors = await findAlternativeDoctors(
      prisma,
      organizationId,
      projectId,
      procedureId,
      requestedDate,
      doctorId,
    );

    return {
      available: false,
      code: 'SLOT_OCCUPIED',
      reason: `${doctor.name} already has an appointment booked at ${timeStr}.`,
      doctorId,
      doctorName: doctor.name,
      procedureName: procedure?.name,
      requestedDateTime: requestedDate.toISOString(),
      durationMinutes: procedureDuration,
      availableAlternatives: avail.slots.map((s) => `${dateStr}T${s}:00Z`),
      alternativeDoctors: altDoctors,
    };
  }

  return {
    available: true,
    code: 'VALID',
    doctorId,
    doctorName: doctor.name,
    procedureName: procedure?.name,
    requestedDateTime: requestedDate.toISOString(),
    durationMinutes: procedureDuration,
  };
}

async function findNextAlternativeSlots(
  prisma: PrismaClient,
  organizationId: string,
  projectId: string,
  doctorId: string,
  procedureId: string,
  fromDateStr: string,
): Promise<string[]> {
  const alternatives: string[] = [];
  const baseDate = new Date(`${fromDateStr}T00:00:00.000Z`);

  for (let offset = 1; offset <= 5; offset++) {
    const nextDate = new Date(baseDate.getTime() + offset * 86400000);
    const nextDateStr = nextDate.toISOString().slice(0, 10);
    const res = await findDoctorAvailableSlots(
      prisma,
      organizationId,
      projectId,
      doctorId,
      nextDateStr,
      procedureId,
    );
    if (res.slots.length > 0) {
      alternatives.push(...res.slots.slice(0, 3).map((s) => `${nextDateStr}T${s}:00Z`));
      if (alternatives.length >= 4) break;
    }
  }

  return alternatives;
}

async function findAlternativeDoctors(
  prisma: PrismaClient,
  organizationId: string,
  projectId: string,
  procedureId: string,
  requestedDate: Date,
  excludeDoctorId: string,
): Promise<Array<{ doctorId: string; doctorName: string; specialty: string }>> {
  const procedure = await prisma.procedure.findFirst({
    where: { id: procedureId, ...scope(organizationId, projectId) },
  });
  if (!procedure) return [];

  // Scoped to the caller's own tenant and project. This previously matched every
  // active doctor with the same specialty across *every* tenant and offered them
  // to the model, which then told the customer they existed.
  const allPeers = await prisma.doctor.findMany({
    where: {
      ...scope(organizationId, projectId),
      specialty: { equals: procedure.specialty, mode: 'insensitive' },
      isActive: true,
    },
  });

  const peers = allPeers.filter((p) => p.id !== excludeDoctorId);
  const availablePeers: Array<{ doctorId: string; doctorName: string; specialty: string }> = [];

  const dayOfWeek = requestedDate.getUTCDay();
  const dateStr = requestedDate.toISOString().slice(0, 10);
  const reqStart = requestedDate.getUTCHours() * 60 + requestedDate.getUTCMinutes();
  const reqEnd = reqStart + procedure.durationMinutes + (procedure.bufferMinutes || 0);

  const startOfDay = new Date(`${dateStr}T00:00:00.000Z`);
  const endOfDay = new Date(`${dateStr}T23:59:59.999Z`);

  for (const peer of peers) {
    if (!peer.workingDays.includes(dayOfWeek)) continue;
    const pStart = parseTimeToMinutes(peer.startHour);
    const pEnd = parseTimeToMinutes(peer.endHour);
    if (reqStart < pStart || reqEnd > pEnd) continue;

    const existing = await prisma.appointment.findMany({
      where: {
        doctorId: peer.id,
        ...scope(organizationId, projectId),
        appointmentDate: { gte: startOfDay, lte: endOfDay },
        status: { notIn: ['CANCELLED', 'NO_SHOW'] },
      },
      select: { appointmentDate: true, durationMinutes: true },
    });

    const hasCollision = existing.some((a) => {
      const d = new Date(a.appointmentDate);
      const aStart = d.getUTCHours() * 60 + d.getUTCMinutes();
      const aEnd = aStart + a.durationMinutes;
      return reqStart < aEnd && reqEnd > aStart;
    });

    if (!hasCollision) {
      availablePeers.push({
        doctorId: peer.id,
        doctorName: peer.name,
        specialty: peer.specialty,
      });
    }
  }

  return availablePeers;
}

export async function createAppointmentValidated(
  prisma: PrismaClient,
  params: {
    organizationId: string;
    projectId: string;
    customerId: string;
    doctorId: string;
    procedureId: string;
    requestedDate: Date;
    notes?: string;
  },
) {
  // Deterministic validation
  const validation = await checkDoctorAvailability(
    prisma,
    params.organizationId,
    params.projectId,
    params.doctorId,
    params.requestedDate,
    params.procedureId,
  );

  if (!validation.available) {
    return {
      booked: false,
      reason: validation.reason,
      code: validation.code,
      availableAlternatives: validation.availableAlternatives,
      alternativeDoctors: validation.alternativeDoctors,
    };
  }

  // Every one of these ids came from the model. Resolving them by bare id copied
  // another tenant's customer display name, phone and email into this tenant's
  // appointment row *and* into the audit metadata Ã¢â‚¬â€ a cross-tenant read that the
  // caller could then read back through their own appointment.
  const doctor = await prisma.doctor.findFirst({
    where: { id: params.doctorId, ...scope(params.organizationId, params.projectId) },
  });
  const procedure = await prisma.procedure.findFirst({
    where: { id: params.procedureId, ...scope(params.organizationId, params.projectId) },
  });
  const customer = await prisma.customer.findFirst({
    where: { id: params.customerId, ...scope(params.organizationId, params.projectId) },
  });

  // A patient_id the model supplied that is not this tenant's customer must not
  // fall through to a booked appointment with no patient on it, and must not be
  // distinguishable from an id that does not exist.
  if (!customer) {
    return {
      booked: false,
      reason: `Customer with ID "${params.customerId}" not found`,
      code: 'NOT_FOUND',
    };
  }

  const duration = procedure?.durationMinutes || 30;
  const title = `${procedure?.name || 'Procedure'} with ${doctor?.name || 'Doctor'}`;

  const appointment = await prisma.appointment.create({
    data: {
      organizationId: params.organizationId,
      projectId: params.projectId,
      customerId: params.customerId,
      doctorId: params.doctorId,
      procedureId: params.procedureId,
      title,
      notes: params.notes || null,
      patientName: customer?.displayName || null,
      patientPhone: customer?.primaryPhone || null,
      patientEmail: customer?.primaryEmail || null,
      doctorName: doctor?.name || null,
      service: procedure?.name || null,
      appointmentDate: params.requestedDate,
      durationMinutes: duration,
      // DEC-006: the AI PROPOSES, a human approves. Writing APPROVED here made the booking
      // self-approving - DEC-003 has seven statuses and APPROVED was never one of them.
      status: 'PENDING',
      isAiProposed: false,
    },
  });

  // Audit log
  await prisma.auditLog.create({
    data: {
      organizationId: params.organizationId,
      projectId: params.projectId,
      actorType: 'AI_AGENT',
      action: 'create_appointment',
      resourceType: 'appointment',
      resourceId: appointment.id,
      metadata: {
        appointmentId: appointment.id,
        patientName: customer?.displayName || 'Customer',
        doctorName: doctor?.name,
        procedureName: procedure?.name,
        appointmentDate: params.requestedDate.toISOString(),
        durationMinutes: duration,
      },
    },
  });

  return {
    booked: true,
    appointmentId: appointment.id,
    doctorName: doctor?.name,
    procedureName: procedure?.name,
    patientName: customer?.displayName,
    appointmentDate: params.requestedDate.toISOString(),
    durationMinutes: duration,
    // DEC-006: the AI PROPOSES, a human approves. APPROVED was never one of
       // DEC-003's seven statuses; writing it made the booking self-approving.
    status: 'PENDING',
  };
}

export async function rescheduleAppointmentValidated(
  prisma: PrismaClient,
  params: {
    organizationId: string;
    projectId: string;
    appointmentId: string;
    newDate: Date;
    reason?: string;
  },
) {
  const existing = await prisma.appointment.findFirst({
    where: {
      id: params.appointmentId,
      organizationId: params.organizationId,
      projectId: params.projectId,
    },
    include: { doctor: true, procedure: true },
  });

  if (!existing) {
    return { rescheduled: false, reason: 'Appointment not found' };
  }

  if (!existing.doctorId || !existing.procedureId) {
    return { rescheduled: false, reason: 'Appointment is missing doctor or procedure details' };
  }

  // Validate the new slot
  const validation = await checkDoctorAvailability(
    prisma,
    params.organizationId,
    params.projectId,
    existing.doctorId,
    params.newDate,
    existing.procedureId,
  );

  if (!validation.available) {
    return {
      rescheduled: false,
      reason: validation.reason,
      code: validation.code,
      availableAlternatives: validation.availableAlternatives,
    };
  }

  const updated = await prisma.appointment.update({
    where: { id: params.appointmentId },
    data: {
      appointmentDate: params.newDate,
      // DEC-006: the AI PROPOSES, a human approves. Writing APPROVED here made the booking
      // self-approving - DEC-003 has seven statuses and APPROVED was never one of them.
      status: 'PENDING',
    },
  });

  // Audit log
  await prisma.auditLog.create({
    data: {
      organizationId: params.organizationId,
      projectId: params.projectId,
      actorType: 'AI_AGENT',
      action: 'reschedule_appointment',
      resourceType: 'appointment',
      resourceId: updated.id,
      metadata: {
        appointmentId: updated.id,
        previousDate: existing.appointmentDate.toISOString(),
        newDate: params.newDate.toISOString(),
        reason: params.reason || 'Requested by patient via AI',
      },
    },
  });

  return {
    rescheduled: true,
    appointmentId: updated.id,
    doctorName: existing.doctor?.name,
    procedureName: existing.procedure?.name,
    newAppointmentDate: params.newDate.toISOString(),
    // DEC-006: the AI PROPOSES, a human approves. APPROVED was never one of
       // DEC-003's seven statuses; writing it made the booking self-approving.
    status: 'PENDING',
  };
}

export async function cancelAppointmentValidated(
  prisma: PrismaClient,
  params: {
    organizationId: string;
    projectId: string;
    appointmentId: string;
    reason?: string;
  },
) {
  const existing = await prisma.appointment.findFirst({
    where: {
      id: params.appointmentId,
      organizationId: params.organizationId,
      projectId: params.projectId,
    },
    include: { doctor: true, procedure: true },
  });

  if (!existing) {
    return { cancelled: false, reason: 'Appointment not found' };
  }

  const updated = await prisma.appointment.update({
    where: { id: params.appointmentId },
    data: {
      status: 'CANCELLED',
      notes: params.reason ? `Cancelled: ${params.reason}` : existing.notes,
    },
  });

  // Audit log
  await prisma.auditLog.create({
    data: {
      organizationId: params.organizationId,
      projectId: params.projectId,
      actorType: 'AI_AGENT',
      action: 'cancel_appointment',
      resourceType: 'appointment',
      resourceId: updated.id,
      metadata: {
        appointmentId: updated.id,
        doctorName: existing.doctor?.name,
        procedureName: existing.procedure?.name,
        cancellationReason: params.reason || 'Cancelled by patient via AI',
      },
    },
  });

  return {
    cancelled: true,
    appointmentId: updated.id,
    doctorName: existing.doctor?.name,
    status: 'CANCELLED',
    reason: params.reason || 'Cancelled by patient',
  };
}
