import type { EmbeddingProvider } from '@firstelement/ai';
import { Prisma, type PrismaClient } from '@firstelement/database';
import { toVectorLiteral } from './ingestion';

export interface RetrievalQuery {
  organizationId: string;
  projectId: string;
  /** Optional narrowing. Omitted means every knowledge base in the project. */
  knowledgeBaseIds?: string[];
  query: string;
  limit?: number;
  /**
   * Cosine similarity floor (0–1). Below it, a chunk is treated as noise:
   * a weak match is worse than no match, because the agent will answer
   * confidently from an irrelevant document.
   */
  minScore?: number;
  /** Set when the query came from a conversation, for knowledge-gap records. */
  conversationId?: string;
}

export interface RetrievedChunk {
  chunkId: string;
  documentId: string;
  knowledgeBaseId: string;
  documentTitle: string;
  chunkIndex: number;
  content: string;
  /** Cosine similarity in [0, 1]; higher is closer. */
  score: number;
}

export interface RetrievalResult {
  chunks: RetrievedChunk[];
  /** True when nothing cleared `minScore` — the agent must not invent an answer. */
  isGap: boolean;
  bestScore: number | null;
}

const DEFAULT_LIMIT = 6;
const DEFAULT_MIN_SCORE = 0.25;

interface ChunkRow {
  id: string;
  documentId: string;
  knowledgeBaseId: string;
  chunkIndex: number;
  content: string;
  documentTitle: string;
  distance: number;
}

/**
 * Project-scoped RAG retrieval (plan §6, §9).
 *
 * The rule this exists to enforce: **the project filter runs before the
 * similarity search, not after.** Filtering afterwards would rank one
 * tenant's chunks against another's and merely hide the losers — a
 * top-k that silently dropped the correct answer, and a query plan that
 * touched data it had no right to read. Here `organizationId` and
 * `projectId` are in the WHERE clause, so PostgreSQL restricts the
 * candidate set first and orders only what the caller may see.
 */
export class KnowledgeRetriever {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly embeddings: EmbeddingProvider,
  ) {}

  async retrieve(query: RetrievalQuery): Promise<RetrievalResult> {
    const text = query.query.trim();
    if (!text) return { chunks: [], isGap: true, bestScore: null };

    const limit = query.limit ?? DEFAULT_LIMIT;
    const minScore = query.minScore ?? DEFAULT_MIN_SCORE;

    const [vector] = await this.embeddings.embed([text]);
    if (!vector) return { chunks: [], isGap: true, bestScore: null };

    const literal = toVectorLiteral(vector);
    const knowledgeBaseFilter =
      query.knowledgeBaseIds && query.knowledgeBaseIds.length > 0
        ? Prisma.sql`AND c."knowledgeBaseId" = ANY(${query.knowledgeBaseIds}::uuid[])`
        : Prisma.empty;

    const rows = await this.prisma.$queryRaw<ChunkRow[]>`
      SELECT
        c.id,
        c."documentId",
        c."knowledgeBaseId",
        c."chunkIndex",
        c.content,
        d.title AS "documentTitle",
        (c.embedding <=> ${literal}::vector) AS distance
      FROM document_chunks c
      JOIN documents d ON d.id = c."documentId"
      WHERE c."organizationId" = ${query.organizationId}::uuid
        AND c."projectId" = ${query.projectId}::uuid
        AND d.status = 'READY'
        ${knowledgeBaseFilter}
      ORDER BY c.embedding <=> ${literal}::vector
      LIMIT ${limit}
    `;

    const scored = rows.map((row) => ({
      chunkId: row.id,
      documentId: row.documentId,
      knowledgeBaseId: row.knowledgeBaseId,
      documentTitle: row.documentTitle,
      chunkIndex: row.chunkIndex,
      content: row.content,
      // pgvector's `<=>` is cosine distance; similarity is 1 - distance.
      score: 1 - Number(row.distance),
    }));

    const bestScore = scored.length > 0 ? (scored[0]?.score ?? null) : null;
    const chunks = scored.filter((chunk) => chunk.score >= minScore);

    return { chunks, isGap: chunks.length === 0, bestScore };
  }

  /**
   * Records what the knowledge base could not answer (plan §9/§70).
   *
   * This is the backlog that tells an admin which documents are missing,
   * and it is the reason an unanswerable question is a data point rather
   * than just an escalation.
   */
  async recordGap(query: RetrievalQuery, result: RetrievalResult): Promise<void> {
    await this.prisma.knowledgeGap.create({
      data: {
        organizationId: query.organizationId,
        projectId: query.projectId,
        conversationId: query.conversationId ?? null,
        query: query.query.slice(0, 1_000),
        bestScore: result.bestScore,
        retrievedCount: result.chunks.length,
      },
    });
  }
}
