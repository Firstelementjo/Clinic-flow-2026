import { Controller, Get, Logger } from '@nestjs/common';
import { Queue } from 'bullmq';
import IORedis from 'ioredis';
import { Permission } from '@firstelement/auth';
import { getConfig } from '@firstelement/config';
import { QueueName } from '@firstelement/messaging';
import { PrismaService } from '../common/prisma.service';
import { RequirePermissions } from '../auth/decorators';

export interface SystemHealthView {
  status: 'ok' | 'degraded';
  environment: string;
  checks: {
    database: { status: 'up' | 'down'; latencyMs: number | null };
    redis: { status: 'up' | 'down' | 'not-configured'; latencyMs: number | null };
  };
  queues: { name: string; waiting: number; active: number; failed: number; delayed: number }[];
  providers: {
    ai: { configured: string[]; missing: string[] };
    embeddings: string;
    /** Channels with stored credentials, by type — never the credentials. */
    channels: { channel: string; connected: number; error: number }[];
  };
  /** Documents stuck mid-processing, which usually means a dead worker. */
  stalledDocuments: number;
}

/**
 * The operator's view of the system (plan §11).
 *
 * Deliberately separate from the public `/health` probe: this one is
 * admin-authenticated because it reports queue depths, provider
 * configuration and failure counts — useful to an operator, and a map for
 * anyone else. The public probe stays a bare up/down.
 */
@Controller('system')
export class SystemHealthController {
  private readonly logger = new Logger(SystemHealthController.name);
  private readonly config = getConfig();

  constructor(private readonly prisma: PrismaService) {}

  @Get('health')
  @RequirePermissions(Permission.SYSTEM_HEALTH_READ)
  async health(): Promise<SystemHealthView> {
    const [database, redis] = await Promise.all([this.checkDatabase(), this.checkRedis()]);
    const queues = await this.queueDepths();

    const aiConfigured: string[] = ['MOCK'];
    const aiMissing: string[] = [];
    for (const [name, key] of [
      ['OPENAI', this.config.OPENAI_API_KEY],
      ['ANTHROPIC', this.config.ANTHROPIC_API_KEY],
      ['GEMINI', this.config.GEMINI_API_KEY],
    ] as const) {
      // Presence only. Whether a key exists is operational; its value is not.
      (key ? aiConfigured : aiMissing).push(name);
    }

    const channels = await this.prisma.client.channelConnection.groupBy({
      by: ['channel', 'status'],
      _count: { _all: true },
    });

    const byChannel = new Map<string, { connected: number; error: number }>();
    for (const row of channels) {
      const entry = byChannel.get(row.channel) ?? { connected: 0, error: 0 };
      if (row.status === 'CONNECTED') entry.connected += row._count._all;
      if (row.status === 'ERROR') entry.error += row._count._all;
      byChannel.set(row.channel, entry);
    }

    // Anything left PROCESSING or INDEXING for an hour is not slow, it is
    // orphaned — the worker that owned it is gone.
    const stalledDocuments = await this.prisma.client.document.count({
      where: {
        status: { in: ['PROCESSING', 'INDEXING'] },
        updatedAt: { lt: new Date(Date.now() - 60 * 60 * 1000) },
      },
    });

    return {
      status: database.status === 'up' && redis.status !== 'down' ? 'ok' : 'degraded',
      environment: this.config.NODE_ENV,
      checks: { database, redis },
      queues,
      providers: {
        ai: { configured: aiConfigured, missing: aiMissing },
        embeddings: this.config.EMBEDDING_PROVIDER,
        channels: [...byChannel.entries()].map(([channel, counts]) => ({ channel, ...counts })),
      },
      stalledDocuments,
    };
  }

  private async checkDatabase(): Promise<{ status: 'up' | 'down'; latencyMs: number | null }> {
    const started = Date.now();
    try {
      await this.prisma.client.$queryRaw`SELECT 1`;
      return { status: 'up', latencyMs: Date.now() - started };
    } catch {
      return { status: 'down', latencyMs: null };
    }
  }

  private async checkRedis(): Promise<{
    status: 'up' | 'down' | 'not-configured';
    latencyMs: number | null;
  }> {
    if (this.config.QUEUE_DRIVER === 'inline') {
      // Development without Redis is a supported configuration, not a fault.
      return { status: 'not-configured', latencyMs: null };
    }

    const started = Date.now();
    const connection = new IORedis(this.config.REDIS_URL, {
      maxRetriesPerRequest: 1,
      lazyConnect: true,
      connectTimeout: 2_000,
    });

    try {
      await connection.connect();
      await connection.ping();
      return { status: 'up', latencyMs: Date.now() - started };
    } catch {
      return { status: 'down', latencyMs: null };
    } finally {
      connection.disconnect();
    }
  }

  /**
   * Queue depth is the earliest signal that the worker has stopped:
   * `waiting` climbing while `active` sits at zero means messages are
   * arriving and nothing is processing them.
   */
  private async queueDepths(): Promise<SystemHealthView['queues']> {
    if (this.config.QUEUE_DRIVER === 'inline') return [];

    const connection = new IORedis(this.config.REDIS_URL, {
      maxRetriesPerRequest: 1,
      lazyConnect: true,
      connectTimeout: 2_000,
    });

    try {
      await connection.connect();

      const names = [
        QueueName.INCOMING_MESSAGE,
        QueueName.AI_RESPONSE,
        QueueName.SCORING,
        QueueName.ESCALATION_ROUTING,
        QueueName.OUTBOUND_SEND,
        QueueName.DOCUMENT_PROCESSING,
      ];

      return await Promise.all(
        names.map(async (name) => {
          const queue = new Queue(name, { connection });
          const counts = await queue.getJobCounts('waiting', 'active', 'failed', 'delayed');
          await queue.close();
          return {
            name,
            waiting: counts.waiting ?? 0,
            active: counts.active ?? 0,
            failed: counts.failed ?? 0,
            delayed: counts.delayed ?? 0,
          };
        }),
      );
    } catch (error) {
      this.logger.warn({
        message: 'Could not read queue depths',
        error: error instanceof Error ? error.message : String(error),
      });
      return [];
    } finally {
      connection.disconnect();
    }
  }
}
