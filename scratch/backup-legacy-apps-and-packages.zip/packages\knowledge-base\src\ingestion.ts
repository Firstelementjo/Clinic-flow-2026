import type { EmbeddingProvider } from '@firstelement/ai';
import type { PrismaClient } from '@firstelement/database';
import { chunkText, type ChunkOptions } from './chunking';
import { parseDocument } from './parsers';
import type { StorageDriver } from './storage';

export interface IngestionResult {
  documentId: string;
  status: 'READY' | 'FAILED';
  chunkCount: number;
  failureReason?: string;
}

/** Embedding calls are batched; providers charge and rate-limit per request. */
const EMBED_BATCH_SIZE = 64;

/**
 * Document processing (plan §9): parse → clean → chunk → embed → store →
 * index.
 *
 * Runs in the worker because embedding a 40-page PDF is not something an
 * HTTP request should wait on (plan §11). Status moves
 * UPLOADED → PROCESSING → INDEXING → READY/FAILED, and the UI shows every
 * step, because "nothing happened yet" and "this failed" look identical
 * otherwise.
 *
 * Safe to re-run: a retried job deletes the chunks it wrote before
 * writing them again, so a partial failure cannot leave a document half
 * indexed and answering with fragments.
 */
export class DocumentIngestionPipeline {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly storage: StorageDriver,
    private readonly embeddings: EmbeddingProvider,
    private readonly chunkOptions: Partial<ChunkOptions> = {},
  ) {}

  async process(documentId: string): Promise<IngestionResult> {
    const document = await this.prisma.document.findUnique({
      where: { id: documentId },
      select: {
        id: true,
        organizationId: true,
        projectId: true,
        knowledgeBaseId: true,
        title: true,
        storageKey: true,
        mimeType: true,
        sourceType: true,
      },
    });

    if (!document) {
      return { documentId, status: 'FAILED', chunkCount: 0, failureReason: 'Document not found' };
    }

    try {
      await this.prisma.document.update({
        where: { id: documentId },
        data: { status: 'PROCESSING', failureReason: null },
      });

      if (!document.storageKey || !document.mimeType) {
        throw new Error('Document has no stored file to process');
      }

      const raw = await this.storage.get(document.storageKey);
      const parsed = await parseDocument(raw, document.mimeType, document.title);
      const chunks = chunkText(parsed.text, this.chunkOptions);

      if (chunks.length === 0) {
        throw new Error('No readable text found in this file');
      }

      await this.prisma.document.update({
        where: { id: documentId },
        data: { status: 'INDEXING' },
      });

      // Re-running must not duplicate chunks.
      await this.prisma.documentChunk.deleteMany({ where: { documentId } });

      for (let offset = 0; offset < chunks.length; offset += EMBED_BATCH_SIZE) {
        const batch = chunks.slice(offset, offset + EMBED_BATCH_SIZE);
        const vectors = await this.embeddings.embed(batch.map((chunk) => chunk.content));

        for (const [index, chunk] of batch.entries()) {
          const vector = vectors[index];
          if (!vector) throw new Error('Embedding provider returned fewer vectors than requested');

          // Prisma cannot write the pgvector column, so this is raw SQL —
          // parameterized, never string-built (see docs/database.md).
          await this.prisma.$executeRaw`
            INSERT INTO document_chunks (
              id, "organizationId", "projectId", "knowledgeBaseId", "documentId",
              "chunkIndex", content, "tokenCount", metadata, embedding, "createdAt"
            ) VALUES (
              gen_random_uuid(),
              ${document.organizationId}::uuid,
              ${document.projectId}::uuid,
              ${document.knowledgeBaseId}::uuid,
              ${document.id}::uuid,
              ${chunk.index},
              ${chunk.content},
              ${chunk.estimatedTokens},
              ${JSON.stringify({ ...parsed.metadata, documentTitle: document.title })}::jsonb,
              ${toVectorLiteral(vector)}::vector,
              now()
            )
          `;
        }
      }

      await this.prisma.document.update({
        where: { id: documentId },
        data: {
          status: 'READY',
          chunkCount: chunks.length,
          processedAt: new Date(),
          failureReason: null,
        },
      });

      return { documentId, status: 'READY', chunkCount: chunks.length };
    } catch (error) {
      const failureReason = error instanceof Error ? error.message : String(error);

      await this.prisma.document.update({
        where: { id: documentId },
        data: { status: 'FAILED', failureReason: failureReason.slice(0, 500), chunkCount: 0 },
      });

      return { documentId, status: 'FAILED', chunkCount: 0, failureReason };
    }
  }
}

/** pgvector's text input format: `[0.1,0.2,...]`. */
export function toVectorLiteral(vector: number[]): string {
  return `[${vector.join(',')}]`;
}
