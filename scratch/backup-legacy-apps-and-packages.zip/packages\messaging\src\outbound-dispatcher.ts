import {
  ConnectorRegistry,
  checkOutboundText,
  type MessagingConnector,
} from '@firstelement/connectors';
import type { PrismaClient } from '@firstelement/database';
import { loadConnectionWithCredentials } from './channel-credentials';

export interface OutboundJob {
  organizationId: string;
  projectId: string;
  conversationId: string;
  messageId: string;
}

export type OutboundResult =
  | { status: 'sent'; externalMessageId?: string }
  | { status: 'failed'; reason: string; retryable: boolean }
  | { status: 'skipped'; reason: string };

/**
 * Delivers a already-persisted message to the customer's channel.
 *
 * Persist-then-send, never send-then-persist: a send that succeeds while
 * the database write fails leaves a customer holding a reply the CRM has
 * no record of, and the agent repeats themselves. The row exists first;
 * this stage moves it from PENDING to SENT or FAILED, and a failure is
 * shown on the message rather than swallowed (plan §15).
 */
export class OutboundDispatcher {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly registry: ConnectorRegistry,
    /** Needed to decrypt connector credentials for the real channels. */
    private readonly encryptionKey: string,
  ) {}

  async dispatch(job: OutboundJob): Promise<OutboundResult> {
    const message = await this.prisma.message.findFirst({
      where: {
        id: job.messageId,
        organizationId: job.organizationId,
        projectId: job.projectId,
      },
      select: {
        id: true,
        body: true,
        channel: true,
        deliveryStatus: true,
        conversation: { select: { customerId: true } },
      },
    });

    if (!message) return { status: 'skipped', reason: 'Message no longer exists' };
    // A retried job must not send the same reply twice.
    if (message.deliveryStatus === 'SENT' || message.deliveryStatus === 'DELIVERED') {
      return { status: 'skipped', reason: 'Already delivered' };
    }

    const connection = await loadConnectionWithCredentials(this.prisma, this.encryptionKey, {
      organizationId: job.organizationId,
      projectId: job.projectId,
      channel: message.channel,
    });

    if (!connection) {
      return this.fail(
        message.id,
        `No enabled ${message.channel} connection for this project`,
        false,
      );
    }

    const identity = await this.prisma.customerIdentity.findFirst({
      where: {
        projectId: job.projectId,
        customerId: message.conversation.customerId,
        platform: message.channel,
      },
      select: { externalId: true },
      orderBy: { createdAt: 'asc' },
    });

    if (!identity) {
      return this.fail(message.id, `Customer has no ${message.channel} handle`, false);
    }

    let connector: MessagingConnector;
    try {
      connector = this.registry.get(connection);
    } catch (error) {
      return this.fail(message.id, errorMessage(error), false);
    }

    // Ask the channel before acting rather than assuming parity (plan §8).
    const allowed = checkOutboundText(connector.capabilities(), message.body);
    if (!allowed.ok) return this.fail(message.id, allowed.reason, false);

    const result = await connector.sendText({
      externalUserId: identity.externalId,
      text: message.body,
      messageId: message.id,
    });

    if (!result.ok) {
      return this.fail(message.id, result.error ?? 'Send failed', result.retryable ?? true);
    }

    await this.prisma.message.update({
      where: { id: message.id },
      data: {
        deliveryStatus: 'SENT',
        externalMessageId: result.externalMessageId ?? null,
        failureReason: null,
      },
    });

    return { status: 'sent', externalMessageId: result.externalMessageId };
  }

  private async fail(messageId: string, reason: string, retryable: boolean): Promise<OutboundResult> {
    await this.prisma.message.update({
      where: { id: messageId },
      data: { deliveryStatus: 'FAILED', failureReason: reason.slice(0, 500) },
    });
    return { status: 'failed', reason, retryable };
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
