import { ChannelType } from '@firstelement/shared';
import { MockConnector } from './mock.connector';
import { MessengerConnector, type MessengerCredentials } from './meta/messenger.connector';
import { WhatsAppConnector, type WhatsAppCredentials } from './meta/whatsapp.connector';
import { TelegramConnector, type TelegramCredentials } from './telegram/telegram.connector';
import type { MessagingConnector } from './types';

export interface ChannelConnectionRecord {
  id: string;
  projectId: string;
  channel: ChannelType;
  isEnabled: boolean;
  /**
   * Decrypted credentials for this connection. Absent for the mock
   * channel, required for every real one — the registry never reads the
   * database or the encryption key itself, so a connector cannot be built
   * without someone having deliberately decrypted for it.
   */
  credentials?: Record<string, unknown>;
}

export class ConnectorNotConfiguredError extends Error {
  readonly code = 'CONNECTOR_NOT_CONFIGURED' as const;

  constructor(
    readonly channel: ChannelType,
    detail?: string,
  ) {
    // Plan §15: say plainly that a channel is not wired up in this
    // environment rather than faking a successful send.
    super(detail ?? `${channel} is not configured for this project`);
    this.name = 'ConnectorNotConfiguredError';
  }
}

/**
 * Builds connector instances from stored channel connections, and keeps
 * one instance per connection so a connector may hold state (the mock's
 * outbox; rate-limiters and sockets later).
 */
export class ConnectorRegistry {
  private readonly instances = new Map<string, MessagingConnector>();

  get(connection: ChannelConnectionRecord): MessagingConnector {
    const existing = this.instances.get(connection.id);
    if (existing) return existing;

    const connector = this.create(connection);
    this.instances.set(connection.id, connector);
    return connector;
  }

  /** Drop a cached instance after its credentials change. */
  invalidate(connectionId: string): void {
    this.instances.delete(connectionId);
  }

  /** Test/dev inspection of an already-built connector. */
  peek(connectionId: string): MessagingConnector | undefined {
    return this.instances.get(connectionId);
  }

  private create(connection: ChannelConnectionRecord): MessagingConnector {
    switch (connection.channel) {
      case ChannelType.MOCK:
        return new MockConnector(connection.id);

      case ChannelType.WHATSAPP: {
        const credentials = require_(connection, [
          'phoneNumberId',
          'accessToken',
          'appSecret',
          'verifyToken',
        ]) as unknown as WhatsAppCredentials;
        return new WhatsAppConnector(connection.id, credentials);
      }

      case ChannelType.INSTAGRAM:
      case ChannelType.MESSENGER: {
        const credentials = require_(connection, [
          'pageId',
          'pageAccessToken',
          'appSecret',
          'verifyToken',
        ]) as unknown as MessengerCredentials;
        return new MessengerConnector(connection.channel, connection.id, credentials);
      }

      case ChannelType.TELEGRAM: {
        const credentials = require_(connection, [
          'botToken',
          'webhookSecret',
        ]) as unknown as TelegramCredentials;
        return new TelegramConnector(connection.id, credentials);
      }

      default:
        throw new ConnectorNotConfiguredError(connection.channel);
    }
  }
}

/**
 * Fails with the *names* of the missing fields — never their values, and
 * never a partially-configured connector that would fail later against
 * the platform with an error nobody can act on.
 */
function require_(
  connection: ChannelConnectionRecord,
  fields: string[],
): Record<string, unknown> {
  const credentials = connection.credentials;
  if (!credentials) {
    throw new ConnectorNotConfiguredError(
      connection.channel,
      `${connection.channel} has no stored credentials`,
    );
  }

  const missing = fields.filter((field) => {
    const value = credentials[field];
    return typeof value !== 'string' || value.trim().length === 0;
  });

  if (missing.length > 0) {
    throw new ConnectorNotConfiguredError(
      connection.channel,
      `${connection.channel} is missing: ${missing.join(', ')}`,
    );
  }

  return credentials;
}
