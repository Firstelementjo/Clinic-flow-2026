import { useId } from 'react';
import { useDirection } from '../direction';

export interface SparklinePoint {
  value: number;
  label?: string;
}

/**
 * The signature element from the design brief: a conversation's frustration
 * history, drawn small enough to sit in a header.
 *
 * It answers the question an operator asks before reading a single
 * message — "is this getting worse?" — which a single current score cannot.
 * Two identical scores of 62 mean opposite things depending on whether the
 * previous turn was 20 or 90.
 *
 * The threshold line is the escalation rule made visible: you can see how
 * close a conversation came to handing over, not just whether it did.
 *
 * Direction: the line is data over time, so it always reads left-to-right
 * even in Arabic — mirroring it would reverse chronology, which is the one
 * thing RTL must not do to a chart.
 */
export function Sparkline({
  points,
  threshold,
  height = 28,
  width = 120,
  label,
}: {
  points: SparklinePoint[];
  /** Draws the escalation threshold, if the project has one. */
  threshold?: number;
  height?: number;
  width?: number;
  label: string;
}) {
  const gradientId = useId();
  const { locale } = useDirection();

  if (points.length === 0) return null;

  const max = 100;
  const stepX = points.length > 1 ? width / (points.length - 1) : 0;
  const toY = (value: number) => height - (Math.max(0, Math.min(max, value)) / max) * height;

  const line = points
    .map((point, index) => `${index === 0 ? 'M' : 'L'} ${index * stepX} ${toY(point.value)}`)
    .join(' ');

  const area = `${line} L ${(points.length - 1) * stepX} ${height} L 0 ${height} Z`;
  const latest = points[points.length - 1]!.value;
  const crossed = threshold !== undefined && latest >= threshold;

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      role="img"
      aria-label={`${label}: ${latest}`}
      lang={locale}
      // Chronology is not mirrored — see the note above. SVG has no `dir`
      // attribute, so the direction is reset on the wrapper instead.
      className="overflow-visible [direction:ltr]"
    >
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
          <stop
            offset="0%"
            stopColor={crossed ? 'var(--fe-escalation)' : 'var(--fe-agent)'}
            stopOpacity="0.28"
          />
          <stop offset="100%" stopColor="transparent" stopOpacity="0" />
        </linearGradient>
      </defs>

      {threshold !== undefined && (
        <line
          x1="0"
          x2={width}
          y1={toY(threshold)}
          y2={toY(threshold)}
          stroke="var(--fe-escalation)"
          strokeWidth="1"
          strokeDasharray="2 3"
          opacity="0.5"
        />
      )}

      <path d={area} fill={`url(#${gradientId})`} />
      <path
        d={line}
        fill="none"
        stroke={crossed ? 'var(--fe-escalation)' : 'var(--fe-agent)'}
        strokeWidth="1.5"
        strokeLinejoin="round"
        strokeLinecap="round"
      />

      {/* The latest turn is the one being acted on, so it gets the dot. */}
      <circle
        cx={(points.length - 1) * stepX}
        cy={toY(latest)}
        r="2.5"
        fill={crossed ? 'var(--fe-escalation)' : 'var(--fe-agent)'}
      />
    </svg>
  );
}
