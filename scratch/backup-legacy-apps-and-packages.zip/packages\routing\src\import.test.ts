import { describe, expect, it } from 'vitest';
import { parseCsv, suggestMapping, validateRows } from './import';

const CSV = [
  'Email,Full Name,Department,Capacity,Skills',
  'layla@example.com,Layla Haddad,billing,8,"refunds;billing"',
  'omar@example.com,Omar Nasser,delivery,,delivery',
].join('\n');

describe('parsing', () => {
  it('reads headers and rows, numbering rows as the admin sees them', () => {
    const sheet = parseCsv(CSV);
    expect(sheet.headers).toEqual(['Email', 'Full Name', 'Department', 'Capacity', 'Skills']);
    expect(sheet.rows).toHaveLength(2);
    // Row 1 is the first data row, not the header.
    expect(sheet.rows[0]!.rowNumber).toBe(1);
  });

  it('handles quoted fields containing separators', () => {
    const sheet = parseCsv('Email,Name\n"a@b.com","Haddad, Layla"');
    expect(sheet.rows[0]!.values.Name).toBe('Haddad, Layla');
  });

  it('ignores blank lines rather than emitting empty rows', () => {
    const sheet = parseCsv('Email,Name\n\na@b.com,A\n\n');
    expect(sheet.rows).toHaveLength(1);
  });
});

describe('column mapping', () => {
  it('guesses common English headers', () => {
    expect(suggestMapping(['Email', 'Full Name', 'Department'])).toMatchObject({
      email: 'Email',
      fullName: 'Full Name',
      department: 'Department',
    });
  });

  it('guesses Arabic headers, since the files come from Arabic systems', () => {
    const mapping = suggestMapping(['البريد الإلكتروني', 'الاسم الكامل', 'القسم']);
    expect(mapping.email).toBe('البريد الإلكتروني');
    expect(mapping.fullName).toBe('الاسم الكامل');
  });

  it('leaves unknown columns unmapped for the admin to resolve', () => {
    expect(suggestMapping(['col1', 'col2']).email).toBeUndefined();
  });
});

describe('validation', () => {
  const sheet = parseCsv(CSV);
  const mapping = suggestMapping(sheet.headers);

  it('accepts well-formed rows and parses their fields', () => {
    const preview = validateRows(sheet, mapping);
    expect(preview.validRows).toHaveLength(2);

    const first = preview.validRows[0]!.record!;
    expect(first.email).toBe('layla@example.com');
    expect(first.maxConcurrentConversations).toBe(8);
    expect(first.skills).toEqual(['refunds', 'billing']);
  });

  it('reports a bad email with its row number instead of skipping it', () => {
    // Silently skipping is how an ops manager ends up believing they
    // imported 40 agents when they imported 37.
    const bad = parseCsv('Email,Full Name\nnot-an-email,Someone');
    const preview = validateRows(bad, suggestMapping(bad.headers));

    expect(preview.validRows).toHaveLength(0);
    expect(preview.invalidRows).toHaveLength(1);
    expect(preview.invalidRows[0]!.rowNumber).toBe(1);
    expect(preview.invalidRows[0]!.errors[0]).toContain('not a valid email');
  });

  it('requires a name', () => {
    const bad = parseCsv('Email,Full Name\na@b.com,');
    const preview = validateRows(bad, suggestMapping(bad.headers));
    expect(preview.invalidRows[0]!.errors).toContain('Full name is required');
  });

  it('rejects a non-numeric capacity with the offending value quoted', () => {
    const bad = parseCsv('Email,Full Name,Capacity\na@b.com,A,many');
    const preview = validateRows(bad, suggestMapping(bad.headers));
    expect(preview.invalidRows[0]!.errors[0]).toContain('"many"');
  });

  it('flags an email that already exists rather than overwriting the account', () => {
    const preview = validateRows(sheet, mapping, new Set(['layla@example.com']));
    expect(preview.duplicateRows).toHaveLength(1);
    expect(preview.validRows).toHaveLength(1);
  });

  it('flags a file that lists the same person twice', () => {
    const repeated = parseCsv('Email,Full Name\na@b.com,A\na@b.com,A again');
    const preview = validateRows(repeated, suggestMapping(repeated.headers));

    expect(preview.validRows).toHaveLength(1);
    expect(preview.duplicateRows).toHaveLength(1);
  });

  it('counts every row so the admin can reconcile against their file', () => {
    const preview = validateRows(sheet, mapping);
    expect(preview.totalRows).toBe(
      preview.validRows.length + preview.invalidRows.length + preview.duplicateRows.length,
    );
  });
});
