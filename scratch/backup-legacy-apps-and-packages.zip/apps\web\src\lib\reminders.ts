import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from './api';

export interface ReminderRecord {
  id: string;
  appointmentId: string;
  patientName: string;
  patientPhone: string;
  doctorName: string;
  procedureName: string;
  appointmentDate: string;
  channel: 'WHATSAPP' | 'SMS';
  type: '24H' | '2H' | 'MANUAL';
  status: 'SENT' | 'DELIVERED' | 'CONFIRMED' | 'RESCHEDULE_REQUESTED' | 'CANCELLED';
  sentAt: string;
  responseAt?: string;
  actionToken: string;
}

export interface ReminderStats {
  upcomingNext48h: number;
  remindersSent: number;
  confirmedCount: number;
  confirmationRatePercent: number;
  noShowRiskCount: number;
}

export interface ReminderSummaryResponse {
  stats: ReminderStats;
  recentReminders: ReminderRecord[];
}

export function useReminderSummary() {
  return useQuery({
    queryKey: ['clinic', 'reminders', 'summary'],
    queryFn: () => api.get<ReminderSummaryResponse>('/clinic/reminders'),
    refetchInterval: 10000,
  });
}

export function useRunBatchReminders() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () =>
      api.post<{ sent24hCount: number; sent2hCount: number; records: ReminderRecord[] }>(
        '/clinic/reminders/send-batch',
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clinic', 'reminders'] });
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
    },
  });
}

export function useSendSingleReminder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ appointmentId, channel }: { appointmentId: string; channel?: 'WHATSAPP' | 'SMS' }) =>
      api.post<ReminderRecord>(`/clinic/reminders/send/${appointmentId}`, { channel }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clinic', 'reminders'] });
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
    },
  });
}

export function usePatientReminderAction() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: {
      appointmentId: string;
      action: 'CONFIRM' | 'RESCHEDULE' | 'CANCEL';
      reason?: string;
    }) => api.post('/clinic/reminders/respond', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clinic', 'reminders'] });
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
    },
  });
}
