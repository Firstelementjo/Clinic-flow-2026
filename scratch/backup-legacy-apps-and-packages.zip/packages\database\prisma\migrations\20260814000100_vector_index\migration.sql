-- Vector index for RAG retrieval.
--
-- Prisma's schema language cannot express pgvector index operators, so
-- this migration is hand-written and must be kept alongside the generated
-- one. Without it, every retrieval is a sequential scan over the whole
-- chunk table — fine for a demo, unusable once a project has real
-- documents.
--
-- HNSW over cosine distance: the embedding providers here return
-- L2-normalized vectors, and `vector_cosine_ops` matches the `<=>`
-- operator the retrieval query orders by. HNSW rather than IVFFlat
-- because it does not need a training step and stays correct as rows are
-- added continuously, which is how documents actually arrive.
--
-- The index only accelerates ordering. Tenant isolation is enforced by
-- the WHERE clause on organization_id/project_id, which PostgreSQL
-- applies before the ordering (plan §6) — the index is never the thing
-- keeping one project's knowledge out of another's answers.
CREATE INDEX IF NOT EXISTS "document_chunks_embedding_hnsw_idx"
  ON "document_chunks"
  USING hnsw ("embedding" vector_cosine_ops);

-- Supports the pre-filter that runs ahead of similarity ordering.
CREATE INDEX IF NOT EXISTS "document_chunks_tenant_idx"
  ON "document_chunks" ("organizationId", "projectId", "knowledgeBaseId");
