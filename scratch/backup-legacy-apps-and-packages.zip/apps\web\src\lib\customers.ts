import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type {
  ChannelType,
  ConversationMode,
  ConversationPriority,
  ConversationStatus,
  Locale,
} from '@firstelement/shared';
import { api } from './api';

export interface CustomerTicketSummary {
  id: string;
  ticketNumber: string;
  createdAt: string;
  status: ConversationStatus;
  subject?: string | null;
}

export interface CustomerFollowUpSummary {
  id: string;
  name: string;
  status: string;
  priority: string | null;
  ticketNumber: string | null;
  ticketDate: string | null;
  followUpDate: string | null;
  createdAt: string;
}

export interface CustomerAppointmentSummary {
  id: string;
  title: string;
  appointmentDate: string;
  durationMinutes: number;
  status: string;
  service: string | null;
  doctorName: string | null;
  notes?: string | null;
  ticketNumber?: string | null;
  ticketDate?: string | null;
  createdAt?: string;
}

export interface PatientMedicalProfile {
  bloodType?: string;
  allergies?: string[];
  chronicConditions?: string[];
  medications?: string[];
  emergencyContact?: {
    name: string;
    relationship: string;
    phone: string;
  };
  insurance?: {
    provider: string;
    policyNumber: string;
    memberId: string;
    networkClass: string;
    copayPercentage: number;
    expiryDate: string;
    status: 'ACTIVE' | 'EXPIRED' | 'PENDING_VERIFICATION';
  };
  intake?: {
    intakeCompleted: boolean;
    lastIntakeDate?: string;
    chiefComplaint?: string;
    preExistingSurgeries?: string;
    smokingStatus?: 'NON_SMOKER' | 'SMOKER' | 'OCCASIONAL';
    clinicalNotes?: string;
  };
}

export interface CustomerListRow {
  id: string;
  projectId: string;
  projectName: string;
  cxId: string;
  displayName: string;
  primaryEmail: string | null;
  primaryPhone: string | null;
  locale: Locale;
  tags: string[];
  metadata?: {
    medical?: PatientMedicalProfile;
    [key: string]: any;
  } | null;
  conversationCount: number;
  lastSeenAt: string;
  createdAt: string;
  latestTicket?: CustomerTicketSummary | null;
  followUps?: CustomerFollowUpSummary[];
  appointments?: CustomerAppointmentSummary[];
}

export interface CustomerDetail {
  id: string;
  projectId: string;
  projectName: string;
  cxId: string;
  displayName: string;
  primaryEmail: string | null;
  primaryPhone: string | null;
  locale: Locale;
  tags: string[];
  notes: string | null;
  metadata?: {
    medical?: PatientMedicalProfile;
    [key: string]: any;
  } | null;
  firstSeenAt: string;
  lastSeenAt: string;
  identities: {
    id: string;
    platform: ChannelType;
    externalId: string;
    displayName: string | null;
    isVerified: boolean;
    createdAt: string;
  }[];
  conversations: {
    id: string;
    ticketNumber: string;
    channel: ChannelType;
    status: ConversationStatus;
    mode: ConversationMode;
    priority: ConversationPriority;
    subject: string | null;
    messageCount: number;
    lastMessageAt: string;
    createdAt: string;
    assignedAgent: string | null;
  }[];
  leads?: CustomerFollowUpSummary[];
  appointments?: CustomerAppointmentSummary[];
}

export function useCustomers(search: string) {
  const query = new URLSearchParams();
  if (search.trim()) query.set('search', search.trim());

  return useQuery({
    queryKey: ['customers', search.trim()],
    queryFn: () =>
      api.get<{ items: CustomerListRow[]; nextCursor: string | null }>(
        `/customers?${query.toString()}`,
      ),
  });
}

export function useCustomer(customerId: string | undefined) {
  return useQuery({
    queryKey: ['customer', customerId],
    queryFn: () => api.get<CustomerDetail>(`/customers/${customerId}`),
    enabled: Boolean(customerId),
  });
}

export function useCustomerByCxId(cxId: string | undefined) {
  return useQuery({
    queryKey: ['customer', 'cx', cxId],
    queryFn: () => api.get<CustomerDetail>(`/customers/cx/${cxId}`),
    enabled: Boolean(cxId),
  });
}

export function useUpdateCustomerMedical() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({
      customerId,
      tags,
      medical,
    }: {
      customerId: string;
      tags?: string[];
      medical: PatientMedicalProfile;
    }) => {
      const payload: Record<string, any> = {
        metadata: { medical },
      };
      if (tags) payload.tags = tags;
      return api.patch<CustomerDetail>(`/customers/${customerId}`, payload);
    },
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ['customer', vars.customerId] });
      qc.invalidateQueries({ queryKey: ['customers'] });
    },
  });
}
