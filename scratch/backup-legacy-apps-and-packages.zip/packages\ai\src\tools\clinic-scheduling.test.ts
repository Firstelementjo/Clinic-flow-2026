import { describe, expect, it, vi, type Mock } from 'vitest';
import type { PrismaClient } from '@firstelement/database';
import {
  getClinicDoctors,
  getClinicProcedures,
  getProcedureDuration,
  checkDoctorAvailability,
  findDoctorAvailableSlots,
  createAppointmentValidated,
  rescheduleAppointmentValidated,
  cancelAppointmentValidated,
  type DoctorResult,
} from './clinic-scheduling';
import { ToolExecutor, type ToolContext } from './executor';

/**
 * The clinic AI tools.
 *
 * <p>Every id these functions resolve â€” `doctor_id`, `procedure_id`,
 * `patient_id` â€” arrives as a **model argument**, and a model is steered by
 * untrusted customer text. The fakes below are deliberately tenant-aware so a
 * cross-tenant lookup returns nothing rather than a row; a fake that ignored the
 * scope would make every negative assertion here vacuous.
 *
 * <h2>Why the types are explicit</h2>
 *
 * <p>This file is the evidence for a tenant-isolation fix on a
 * prompt-injection surface. A value typed `any` can be anything, so a wrong
 * assertion can pass by accident: `toHaveLength(1)` on an `any[]` is satisfied by
 * a value of the wrong shape entirely. The doubles are therefore typed to the
 * clinic rows they stand in for, and the inspection handles (`appointments`,
 * `auditLogs`) are exposed on a typed return value rather than reached through
 * `as any` casts â€” the "nothing was written" assertions are the load-bearing ones
 * and they read the recorded rows directly.
 */

// ---------------------------------------------------------------------------
// Row shapes
// ---------------------------------------------------------------------------

/** The tenant columns every clinic row carries. */
interface TenantRow {
  id: string;
  organizationId: string;
  projectId: string;
}

interface DoctorRow extends TenantRow {
  name: string;
  specialty: string;
  workingDays: number[];
  startHour: string;
  endHour: string;
  slotDuration: number;
  isActive: boolean;
}

interface ProcedureRow extends TenantRow {
  name: string;
  specialty: string;
  durationMinutes: number;
  bufferMinutes: number;
  price: number;
  isActive: boolean;
}

interface CustomerRow extends TenantRow {
  displayName: string;
  primaryPhone: string;
  primaryEmail?: string | null;
}

interface AppointmentRow extends TenantRow {
  customerId?: string | null;
  doctorId?: string | null;
  procedureId?: string | null;
  appointmentDate: Date;
  durationMinutes?: number;
  status?: string;
  title?: string;
  notes?: string | null;
  patientName?: string | null;
  patientPhone?: string | null;
  patientEmail?: string | null;
  doctorName?: string | null;
  service?: string | null;
  isAiProposed?: boolean;
  /** Populated by the `include` on the reschedule/cancel lookups. */
  doctor?: DoctorRow;
  procedure?: ProcedureRow;
}

interface AuditLogRow {
  organizationId: string;
  projectId: string;
  action: string;
  actorType: string;
  resourceType: string;
  resourceId: string;
  metadata: Record<string, unknown>;
}

/**
 * The `where` fragment the doubles match on. `id` and the tenant columns are
 * optional because a Prisma `where` carries only what the caller supplied, and
 * `doctorId` is how the appointment queries filter.
 */
interface ScopeWhere {
  id?: string;
  organizationId?: string;
  projectId?: string;
  doctorId?: string | null;
  isActive?: boolean;
}

/**
 * What `makeFakePrisma` hands back. The Prisma-shaped client is separated from
 * the recorded rows so a test can assert on what was written without casting
 * through `PrismaClient`.
 */
interface FakePrisma {
  /** The client the tool functions accept. */
  prisma: PrismaClient;
  /** Every appointment row held or written, for before/after comparison. */
  appointments: AppointmentRow[];
  /** Every audit row written, so "wrote nothing" is measurable. */
  auditLogs: AuditLogRow[];
  /** The write and predicate mocks, for "never called" and "emitted `where`". */
  mocks: {
    doctorFindMany: Mock;
    appointmentCreate: Mock;
    appointmentUpdate: Mock;
    auditLogCreate: Mock;
  };
}

describe('Clinic Scheduling Engine & AI Tools', () => {
  const ORG = 'org-1';
  const OTHER_ORG = 'org-2';
  const PROJECT = 'proj-1';
  const OTHER_PROJECT = 'proj-2';

  const fakeDoctor: DoctorRow = {
    id: 'doc-1',
    organizationId: ORG,
    projectId: PROJECT,
    name: 'Dr. Sarah Al-Ahmad',
    specialty: 'Dental',
    workingDays: [0, 1, 2, 3, 4], // Sun - Thu
    startHour: '09:00',
    endHour: '17:00',
    slotDuration: 30,
    isActive: true,
  };

  const fakeProcedure: ProcedureRow = {
    id: 'proc-1',
    organizationId: ORG,
    projectId: PROJECT,
    name: 'Dental Cleaning',
    specialty: 'Dental',
    durationMinutes: 60,
    bufferMinutes: 10,
    price: 350,
    isActive: true,
  };

  const fakeCustomer: CustomerRow = {
    id: 'cust-1',
    organizationId: ORG,
    projectId: PROJECT,
    displayName: 'Fatima Al-Mansoor',
    primaryPhone: '+966501234567',
  };

  /** A doctor, procedure and customer that belong to a different tenant. */
  const foreignDoctor: DoctorRow = {
    ...fakeDoctor,
    id: 'doc-foreign',
    organizationId: OTHER_ORG,
    projectId: OTHER_PROJECT,
    name: 'Dr. Foreign Tenant',
  };
  const foreignProcedure: ProcedureRow = {
    ...fakeProcedure,
    id: 'proc-foreign',
    organizationId: OTHER_ORG,
    projectId: OTHER_PROJECT,
  };
  const foreignCustomer: CustomerRow = {
    ...fakeCustomer,
    id: 'cust-foreign',
    organizationId: OTHER_ORG,
    projectId: OTHER_PROJECT,
    displayName: 'Foreign Patient',
    primaryPhone: '+966509999999',
  };

  /**
   * Prisma doubles that honour `organizationId` / `projectId`, so an out-of-scope
   * id resolves to nothing exactly as it would in PostgreSQL.
   */
  function makeFakePrisma(existingAppointments: AppointmentRow[] = []): FakePrisma {
    const appointments: AppointmentRow[] = [...existingAppointments];
    const auditLogs: AuditLogRow[] = [];
    const doctors = [fakeDoctor, foreignDoctor];
    const procedures = [fakeProcedure, foreignProcedure];
    const customers = [fakeCustomer, foreignCustomer];

    const inScope = (row: TenantRow, where: ScopeWhere): boolean =>
      (!where.organizationId || row.organizationId === where.organizationId) &&
      (!where.projectId || row.projectId === where.projectId);

    const double = {
      doctor: {
        findFirst: vi.fn().mockImplementation(async ({ where }: { where: ScopeWhere }) => {
          return doctors.find((d) => d.id === where.id && inScope(d, where)) ?? null;
        }),
        findMany: vi.fn().mockImplementation(async ({ where }: { where: ScopeWhere }) => {
          return doctors.filter((d) => inScope(d, where));
        }),
      },
      procedure: {
        findFirst: vi.fn().mockImplementation(async ({ where }: { where: ScopeWhere }) => {
          return procedures.find((p) => p.id === where.id && inScope(p, where)) ?? null;
        }),
        findMany: vi.fn().mockImplementation(async ({ where }: { where: ScopeWhere }) => {
          return procedures.filter((p) => inScope(p, where));
        }),
      },
      customer: {
        findFirst: vi.fn().mockImplementation(async ({ where }: { where: ScopeWhere }) => {
          return customers.find((c) => c.id === where.id && inScope(c, where)) ?? null;
        }),
      },
      appointment: {
        findMany: vi.fn().mockImplementation(async ({ where }: { where: ScopeWhere }) => {
          return appointments.filter(
            (a) =>
              a.doctorId === where.doctorId &&
              inScope(a, where) &&
              a.status !== 'CANCELLED',
          );
        }),
        findFirst: vi.fn().mockImplementation(async ({ where }: { where: ScopeWhere }) => {
          return appointments.find((a) => a.id === where.id && inScope(a, where)) || null;
        }),
        create: vi.fn().mockImplementation(async ({ data }: { data: AppointmentRow }) => {
          const created: AppointmentRow = { ...data, id: `appt-${appointments.length + 1}` };
          appointments.push(created);
          return created;
        }),
        update: vi.fn().mockImplementation(
          async ({ where, data }: { where: { id: string }; data: Partial<AppointmentRow> }) => {
            const idx = appointments.findIndex((a) => a.id === where.id);
            const existing = idx === -1 ? undefined : appointments[idx];
            if (!existing) {
              // Prisma's `update` on a missing row throws; so does this. The old
              // double invented a row instead, which would have let a scoped
              // write appear to succeed on a row that was never in scope.
              throw new Error(`fake prisma: appointment.update on a missing row ${where.id}`);
            }
            // A partial update can only add fields to a row that is already
            // complete. `appointmentDate` is spelled out because a partial update
            // legitimately omits it and the merge must not drop it.
            const merged: AppointmentRow = {
              ...existing,
              ...data,
              appointmentDate: existing.appointmentDate,
            };
            appointments[idx] = merged;
            return merged;
          },
        ),
      },
      auditLog: {
        create: vi.fn().mockImplementation(async ({ data }: { data: AuditLogRow }) => {
          auditLogs.push(data);
          return data;
        }),
      },
    };

    return {
      prisma: double as unknown as PrismaClient,
      appointments,
      auditLogs,
      mocks: {
        doctorFindMany: double.doctor.findMany,
        appointmentCreate: double.appointment.create,
        appointmentUpdate: double.appointment.update,
        auditLogCreate: double.auditLog.create,
      },
    };
  }

  it('retrieves active clinic doctors and procedures', async () => {
    const fake = makeFakePrisma();
    const doctors = await getClinicDoctors(fake.prisma, ORG, PROJECT);
    expect(doctors).toHaveLength(1);
    expect(doctors[0]?.name).toBe('Dr. Sarah Al-Ahmad');
    expect(doctors[0]?.workingHours).toBe('09:00 - 17:00');

    const procedures = await getClinicProcedures(fake.prisma, ORG, PROJECT);
    expect(procedures).toHaveLength(1);
    expect(procedures[0]?.durationMinutes).toBe(60);
  });

  it('retrieves procedure duration with buffer and price', async () => {
    const fake = makeFakePrisma();
    const duration = await getProcedureDuration(fake.prisma, ORG, PROJECT, 'proc-1');
    expect(duration.durationMinutes).toBe(60);
    expect(duration.bufferMinutes).toBe(10);
    expect(duration.totalOccupiedMinutes).toBe(70);
    expect(duration.price).toBe(350);
  });

  it('validates available slots on a working day', async () => {
    const fake = makeFakePrisma();
    // 2026-10-04 is a Sunday (UTC day 0)
    const result = await checkDoctorAvailability(
      fake.prisma,
      ORG,
      PROJECT,
      'doc-1',
      new Date('2026-10-04T10:00:00.000Z'),
      'proc-1',
    );
    expect(result.available).toBe(true);
    expect(result.code).toBe('VALID');
  });

  it('rejects booking on doctor non-working day (e.g. Friday) and provides alternative dates', async () => {
    const fake = makeFakePrisma();
    // 2026-10-09 is a Friday (UTC day 5)
    const result = await checkDoctorAvailability(
      fake.prisma,
      ORG,
      PROJECT,
      'doc-1',
      new Date('2026-10-09T10:00:00.000Z'),
      'proc-1',
    );
    expect(result.available).toBe(false);
    expect(result.code).toBe('DOCTOR_UNAVAILABLE_ON_DATE');
    expect(result.reason).toContain('is not available on Fridays');
  });

  it('rejects booking outside doctor working hours', async () => {
    const fake = makeFakePrisma();
    // 2026-10-04 at 07:00 UTC (working hours are 09:00 - 17:00)
    const result = await checkDoctorAvailability(
      fake.prisma,
      ORG,
      PROJECT,
      'doc-1',
      new Date('2026-10-04T07:00:00.000Z'),
      'proc-1',
    );
    expect(result.available).toBe(false);
    expect(result.code).toBe('OUTSIDE_WORKING_HOURS');
  });

  it('prevents collision/double-booking and offers alternatives', async () => {
    const existing: AppointmentRow[] = [
      {
        id: 'appt-exist-1',
        organizationId: ORG,
        projectId: PROJECT,
        doctorId: 'doc-1',
        appointmentDate: new Date('2026-10-04T10:00:00.000Z'),
        durationMinutes: 60,
        status: 'PENDING', // DEC-006: the tool proposes, it does not approve
      },
    ];
    const fake = makeFakePrisma(existing);

    // Requesting 10:30 which overlaps with [10:00, 11:00]
    const result = await checkDoctorAvailability(
      fake.prisma,
      ORG,
      PROJECT,
      'doc-1',
      new Date('2026-10-04T10:30:00.000Z'),
      'proc-1',
    );
    expect(result.available).toBe(false);
    expect(result.code).toBe('SLOT_OCCUPIED');
    expect(result.availableAlternatives).toBeDefined();
  });

  it('creates an appointment with validation and logs audit record', async () => {
    const fake = makeFakePrisma();
    const result = await createAppointmentValidated(fake.prisma, {
      organizationId: ORG,
      projectId: PROJECT,
      customerId: 'cust-1',
      doctorId: 'doc-1',
      procedureId: 'proc-1',
      requestedDate: new Date('2026-10-04T11:00:00.000Z'),
    });

    expect(result.booked).toBe(true);
    expect(result.status).toBe('PENDING');

      // DEC-006: the AI proposes and a human approves. A booking that arrives already
      // APPROVED is the defect DEC-017 recorded.
    expect(fake.mocks.appointmentCreate).toHaveBeenCalled();
    expect(fake.mocks.auditLogCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          action: 'create_appointment',
          actorType: 'AI_AGENT',
        }),
      }),
    );
  });

  it('reschedules an appointment with validation and logs audit', async () => {
    const existing: AppointmentRow[] = [
      {
        id: 'appt-1',
        organizationId: ORG,
        projectId: PROJECT,
        doctorId: 'doc-1',
        procedureId: 'proc-1',
        appointmentDate: new Date('2026-10-04T11:00:00.000Z'),
        durationMinutes: 60,
        status: 'PENDING', // DEC-006: the tool proposes, it does not approve
        doctor: fakeDoctor,
        procedure: fakeProcedure,
      },
    ];
    const fake = makeFakePrisma(existing);

    const result = await rescheduleAppointmentValidated(fake.prisma, {
      organizationId: ORG,
      projectId: PROJECT,
      appointmentId: 'appt-1',
      newDate: new Date('2026-10-04T14:00:00.000Z'),
      reason: 'Patient has a flight in the morning',
    });

    expect(result.rescheduled).toBe(true);
    expect(result.newAppointmentDate).toContain('14:00:00');
    expect(fake.mocks.auditLogCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          action: 'reschedule_appointment',
          actorType: 'AI_AGENT',
        }),
      }),
    );
  });

  it('cancels an appointment and records audit log', async () => {
    const existing: AppointmentRow[] = [
      {
        id: 'appt-1',
        organizationId: ORG,
        projectId: PROJECT,
        doctorId: 'doc-1',
        procedureId: 'proc-1',
        appointmentDate: new Date('2026-10-04T11:00:00.000Z'),
        status: 'PENDING', // DEC-006: the tool proposes, it does not approve
        doctor: fakeDoctor,
        procedure: fakeProcedure,
      },
    ];
    const fake = makeFakePrisma(existing);

    const result = await cancelAppointmentValidated(fake.prisma, {
      organizationId: ORG,
      projectId: PROJECT,
      appointmentId: 'appt-1',
      reason: 'Patient recovered',
    });

    expect(result.cancelled).toBe(true);
    expect(result.status).toBe('CANCELLED');
    expect(fake.mocks.auditLogCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          action: 'cancel_appointment',
          actorType: 'AI_AGENT',
        }),
      }),
    );
  });

  it('executes via ToolExecutor seamlessly', async () => {
    const fake = makeFakePrisma();
    const executor = new ToolExecutor(fake.prisma);

    const context: ToolContext = {
      organizationId: ORG,
      projectId: PROJECT,
      conversationId: 'conv-1',
      customerId: 'cust-1',
      enabledTools: [
        'get_doctors',
        'get_procedures',
        'check_availability',
        'create_appointment',
      ],
      searchKnowledge: async () => [],
    };

    const outcome = await executor.execute(
      {
        id: 'call-1',
        name: 'get_doctors',
        arguments: {},
      },
      context,
    );

    expect(outcome.authorized).toBe(true);
    expect(outcome.isError).toBe(false);
    expect(outcome.result.doctors as DoctorResult[]).toHaveLength(1);
  });

  // -------------------------------------------------------------------------
  // Cross-tenant: a model-supplied id is a claim, not a fact
  // -------------------------------------------------------------------------

  /**
   * Non-disclosure here means: the response reveals nothing the caller did not
   * already supply. These tools echo the id back in the "not found" text, and
   * that is safe â€” the caller chose it. What must not appear is any fact about
   * the row: another tenant's name, price, phone number or availability.
   *
   * So a denial is compared against the response for an id that exists nowhere,
   * with the caller's own id normalised out of both.
   */
  function normaliseId(value: unknown, id: string): string {
    return JSON.stringify(value).split(id).join('<requested-id>');
  }

  describe('a model-supplied id cannot reach another tenant', () => {
    it('get_doctors returns only this tenant roster', async () => {
      const fake = makeFakePrisma();
      const doctors = await getClinicDoctors(fake.prisma, ORG, PROJECT);

      expect(doctors.map((d) => d.name)).toEqual(['Dr. Sarah Al-Ahmad']);
      expect(JSON.stringify(doctors)).not.toContain('Foreign Tenant');
    });

    it('get_procedures returns only this tenant catalogue', async () => {
      const fake = makeFakePrisma();
      const procedures = await getClinicProcedures(fake.prisma, ORG, PROJECT);

      expect(procedures).toHaveLength(1);
      expect(procedures[0]?.name).toBe('Dental Cleaning');
    });

    it('get_procedure_duration refuses another tenant procedure', async () => {
      const fake = makeFakePrisma();
      const outcome = await getProcedureDuration(fake.prisma, ORG, PROJECT, 'proc-foreign');
      const nonexistent = await getProcedureDuration(fake.prisma, ORG, PROJECT, 'proc-nope');

      // Identical to an id that does not exist anywhere, once the caller's own
      // id is normalised out of the echo.
      expect(normaliseId(outcome, 'proc-foreign')).toEqual(normaliseId(nonexistent, 'proc-nope'));
      expect(JSON.stringify(outcome)).not.toContain('350');
    });

    it('check_availability refuses another tenant doctor', async () => {
      const fake = makeFakePrisma();
      const denied = await checkDoctorAvailability(
        fake.prisma,
        ORG,
        PROJECT,
        'doc-foreign',
        new Date('2026-10-04T10:00:00.000Z'),
        'proc-1',
      );
      const nonexistent = await checkDoctorAvailability(
        fake.prisma,
        ORG,
        PROJECT,
        'doc-nope',
        new Date('2026-10-04T10:00:00.000Z'),
        'proc-1',
      );

      expect(denied.available).toBe(false);
      expect(normaliseId(denied, 'doc-foreign')).toEqual(normaliseId(nonexistent, 'doc-nope'));
      expect(JSON.stringify(denied)).not.toContain('Foreign Tenant');
    });

    it('find_available_slots refuses another tenant doctor', async () => {
      const fake = makeFakePrisma();
      const denied = await findDoctorAvailableSlots(
        fake.prisma,
        ORG,
        PROJECT,
        'doc-foreign',
        '2026-10-04',
        'proc-1',
      );
      const nonexistent = await findDoctorAvailableSlots(
        fake.prisma,
        ORG,
        PROJECT,
        'doc-nope',
        '2026-10-04',
        'proc-1',
      );

      expect(normaliseId(denied, 'doc-foreign')).toEqual(normaliseId(nonexistent, 'doc-nope'));
      expect(JSON.stringify(denied)).not.toContain('Foreign Tenant');
    });

    it('create_appointment refuses another tenant doctor and writes nothing', async () => {
      const fake = makeFakePrisma();
      const before = fake.appointments.length;

      const outcome = await createAppointmentValidated(fake.prisma, {
        organizationId: ORG,
        projectId: PROJECT,
        customerId: 'cust-1',
        doctorId: 'doc-foreign',
        procedureId: 'proc-1',
        requestedDate: new Date('2026-10-04T11:00:00.000Z'),
      });

      expect(outcome.booked).toBe(false);
      expect(fake.appointments).toHaveLength(before);
      expect(fake.mocks.appointmentCreate).not.toHaveBeenCalled();
      expect(fake.auditLogs).toHaveLength(0);
      expect(JSON.stringify(outcome)).not.toContain('Foreign Tenant');
    });

    it('create_appointment never copies another tenant customer into the row or the audit log', async () => {
      const fake = makeFakePrisma();
      const before = fake.appointments.length;

      const outcome = await createAppointmentValidated(fake.prisma, {
        organizationId: ORG,
        projectId: PROJECT,
        // The model named a patient_id belonging to another tenant.
        customerId: 'cust-foreign',
        doctorId: 'doc-1',
        procedureId: 'proc-1',
        requestedDate: new Date('2026-10-04T11:00:00.000Z'),
      });

      expect(outcome.booked).toBe(false);
      expect(fake.appointments).toHaveLength(before);
      const written = JSON.stringify([...fake.appointments, ...fake.auditLogs]);
      expect(written).not.toContain('Foreign Patient');
      expect(written).not.toContain('+966509999999');
    });

    it('reschedule_appointment refuses another tenant appointment', async () => {
      const existing: AppointmentRow[] = [
        {
          id: 'appt-foreign',
          organizationId: OTHER_ORG,
          projectId: OTHER_PROJECT,
          doctorId: 'doc-foreign',
          procedureId: 'proc-foreign',
          appointmentDate: new Date('2026-10-04T11:00:00.000Z'),
          status: 'PENDING', // DEC-006: the tool proposes, it does not approve
          doctor: foreignDoctor,
          procedure: foreignProcedure,
        },
      ];
      const fake = makeFakePrisma(existing);
      const before = fake.appointments.length;

      const outcome = await rescheduleAppointmentValidated(fake.prisma, {
        organizationId: ORG,
        projectId: PROJECT,
        appointmentId: 'appt-foreign',
        newDate: new Date('2026-10-04T14:00:00.000Z'),
      });

      expect(outcome.rescheduled).toBe(false);
      expect(fake.appointments).toHaveLength(before);
      expect(fake.mocks.appointmentUpdate).not.toHaveBeenCalled();
    });

    it('cancel_appointment refuses another tenant appointment', async () => {
      const existing: AppointmentRow[] = [
        {
          id: 'appt-foreign',
          organizationId: OTHER_ORG,
          projectId: OTHER_PROJECT,
          doctorId: 'doc-foreign',
          procedureId: 'proc-foreign',
          appointmentDate: new Date('2026-10-04T11:00:00.000Z'),
          status: 'PENDING', // DEC-006: the tool proposes, it does not approve
          doctor: foreignDoctor,
          procedure: foreignProcedure,
        },
      ];
      const fake = makeFakePrisma(existing);
      const before = fake.appointments.length;

      const outcome = await cancelAppointmentValidated(fake.prisma, {
        organizationId: ORG,
        projectId: PROJECT,
        appointmentId: 'appt-foreign',
      });

      expect(outcome.cancelled).toBe(false);
      expect(fake.appointments).toHaveLength(before);
      expect(fake.mocks.appointmentUpdate).not.toHaveBeenCalled();
    });

    it('every clinic lookup carries the organization, not just the project', async () => {
      const fake = makeFakePrisma();
      await getClinicDoctors(fake.prisma, ORG, PROJECT);
      // `mock.calls` is an array of *argument tuples*, so `calls[i][j]` is the j-th
      // argument of the i-th call. The double's own signature is
      // `{ where: ScopeWhere }`, so this restates what the double was declared to
      // receive rather than inventing a shape.
      const calls = fake.mocks.doctorFindMany.mock.calls as unknown as Array<
        Array<{ where: ScopeWhere }>
      >;
      expect(calls).toHaveLength(1);
      expect(calls[0]?.[0]?.where.organizationId).toBe(ORG);
      expect(calls[0]?.[0]?.where.projectId).toBe(PROJECT);
    });

    it('the ToolExecutor path is closed too, end to end', async () => {
      const fake = makeFakePrisma();
      const executor = new ToolExecutor(fake.prisma);
      const context: ToolContext = {
        organizationId: ORG,
        projectId: PROJECT,
        conversationId: 'conv-1',
        customerId: 'cust-1',
        enabledTools: ['get_procedure_duration', 'check_availability', 'create_appointment'],
        searchKnowledge: async () => [],
      };

      const duration = await executor.execute(
        { id: 'c1', name: 'get_procedure_duration', arguments: { procedure_id: 'proc-foreign' } },
        context,
      );
      expect(JSON.stringify(duration.result)).not.toContain('Dental Cleaning');
      expect(duration.result.error).toContain('not found');

      const availability = await executor.execute(
        {
          id: 'c2',
          name: 'check_availability',
          arguments: { doctor_id: 'doc-foreign', procedure_id: 'proc-1', datetime: '2026-10-04T10:00:00Z' },
        },
        context,
      );
      expect(availability.result.available).toBe(false);
      expect(JSON.stringify(availability.result)).not.toContain('Foreign Tenant');

      const booking = await executor.execute(
        {
          id: 'c3',
          name: 'create_appointment',
          arguments: {
            doctor_id: 'doc-1',
            procedure_id: 'proc-1',
            datetime: '2026-10-04T11:00:00Z',
            patient_id: 'cust-foreign',
          },
        },
        context,
      );
      expect(booking.result.booked).toBe(false);
      expect(fake.mocks.appointmentCreate).not.toHaveBeenCalled();
    });
  });

  /**
   * The fixture can actually detect the defect.
   *
   * The fix changed these functions' *signatures* â€” every one now takes
   * `organizationId` â€” so a byte-for-byte pre-fix run cannot be called correctly
   * from these tests: the old `getClinicDoctors(prisma, projectId)` and the new
   * `getClinicDoctors(prisma, organizationId, projectId)` are different functions,
   * and a red run that fails on argument shuffling proves less than it appears to.
   * A pre-fix run did fail 17 of 21, but 8 of those were legitimate-path tests
   * failing on the signature rather than on a leak.
   *
   * So non-vacuity is established at the predicate level, as the notes and clinic
   * suites did it: the pre-fix `where` construction is reproduced against the same
   * fixture and shown reaching the foreign rows, while the fixed one carries the
   * tenant and does not.
   */
  describe('the fixture can detect the defect', () => {
    it('the pre-fix predicate reaches another tenant and the fixed one does not', async () => {
      // Pre-fix, verbatim: `const where: any = { isActive: true }` with `projectId`
      // attached only when truthy â€” no tenant column at all. `Record<string,
      // unknown>` is the honest type for that builder: it really did build a
      // dictionary, and typing it as such is what makes the missing tenant column
      // visible rather than hidden behind a cast.
      const preFixWhere = (projectId: string): Record<string, unknown> => {
        const where: Record<string, unknown> = { isActive: true };
        if (projectId) where.projectId = projectId;
        return where;
      };

      const doctors: DoctorRow[] = [fakeDoctor, foreignDoctor];
      const inScope = (row: TenantRow, where: Record<string, unknown>): boolean =>
        (!where.organizationId || row.organizationId === where.organizationId) &&
        (!where.projectId || row.projectId === where.projectId);

      // A pre-fix read of another tenant project id returns their doctor...
      expect(doctors.filter((d) => inScope(d, preFixWhere(OTHER_PROJECT)))).toHaveLength(1);
      // ...and with no project id at all, every doctor in every tenant.
      expect(doctors.filter((d) => inScope(d, preFixWhere('')))).toHaveLength(2);

      // The fixed predicate carries the organization, so the same request returns nothing.
      expect(
        doctors.filter((d) =>
          inScope(d, { organizationId: ORG, projectId: OTHER_PROJECT, isActive: true }),
        ),
      ).toHaveLength(0);

      // And the real function emits a predicate scoped to the caller's own tenant.
      const fake = makeFakePrisma();
      const real = await getClinicDoctors(fake.prisma, ORG, PROJECT);
      expect(real.map((d) => d.id)).not.toContain('doc-foreign');
    });

    it('a pre-fix customer lookup would have copied a foreign patient into the row', async () => {
      // Pre-fix, verbatim: `customer.findUnique({ where: { id: params.customerId } })`.
      const customers: CustomerRow[] = [fakeCustomer, foreignCustomer];
      const preFixCustomer = (id: string): CustomerRow | null =>
        customers.find((c) => c.id === id) ?? null;

      expect(preFixCustomer('cust-foreign')?.displayName).toBe('Foreign Patient');
      expect(preFixCustomer('cust-foreign')?.primaryPhone).toBe('+966509999999');

      // The fixed lookup adds the scope, so the same id resolves to nothing and the
      // booking is refused before any row or audit record is written.
      const fake = makeFakePrisma();
      const outcome = await createAppointmentValidated(fake.prisma, {
        organizationId: ORG,
        projectId: PROJECT,
        customerId: 'cust-foreign',
        doctorId: 'doc-1',
        procedureId: 'proc-1',
        requestedDate: new Date('2026-10-04T11:00:00.000Z'),
      });
      expect(outcome.booked).toBe(false);
      expect(fake.appointments).toHaveLength(0);
      expect(fake.auditLogs).toHaveLength(0);
    });
  });
});
