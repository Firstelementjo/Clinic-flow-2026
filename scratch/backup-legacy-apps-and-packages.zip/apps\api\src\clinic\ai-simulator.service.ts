import { Injectable, Logger } from '@nestjs/common';
import { projectScope, type TenantContext } from '@firstelement/database';
import { PrismaService } from '../common/prisma.service';
import { ClinicService } from './clinic.service';
import { LocalClinicAdapter } from './local-clinic.adapter';
import { SchedulingEngineService } from './scheduling-engine.service';
import { generateTicketNumber } from '@firstelement/shared';

export interface SimulatorChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface SimulatorChatRequest {
  message: string;
  conversationHistory?: SimulatorChatMessage[];
  locale?: 'en' | 'ar';
  projectId?: string;
  customerId?: string;
  patientName?: string;
  patientPhone?: string;
  preferredDoctorId?: string;
  preferredProcedureId?: string;
}

export interface ToolExecutionRecord {
  toolName: string;
  status: 'SUCCESS' | 'WARNING' | 'ERROR';
  description: string;
  input: Record<string, any>;
  output: Record<string, any>;
  executionTimeMs: number;
}

export interface SimulatorChatResponse {
  reply: string;
  intent: 'BOOK_APPOINTMENT' | 'CHECK_AVAILABILITY' | 'RESCHEDULE' | 'CANCEL' | 'GENERAL_INQUIRY';
  entities: {
    doctorName?: string;
    doctorId?: string;
    procedureName?: string;
    procedureId?: string;
    targetDateStr?: string;
    targetTimeStr?: string;
    targetIsoDateTime?: string;
  };
  toolExecutions: ToolExecutionRecord[];
  suggestedSlots?: string[];
  createdAppointment?: any;
  ticketNumber?: string;
  locale: 'en' | 'ar';
}

@Injectable()
export class AiSimulatorService {
  private readonly logger = new Logger(AiSimulatorService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly clinicService: ClinicService,
    private readonly clinicAdapter: LocalClinicAdapter,
    private readonly schedulingEngine: SchedulingEngineService,
  ) {}

  async processTurn(
    ctx: TenantContext,
    dto: SimulatorChatRequest,
  ): Promise<SimulatorChatResponse> {
    const startTime = Date.now();
    // A caller-supplied projectId is a request, never an authorization: it goes
    // through projectScope, which refuses a project the caller does not hold
    // membership of and yields a 404 that matches a nonexistent project. Without
    // one, the caller's own first project is used.
    const projectId = dto.projectId
      ? projectScope(ctx, dto.projectId).projectId
      : ctx.projectIds[0] || '';
    const message = (dto.message || '').trim();
    const lowerMsg = message.toLowerCase();

    // Detect language: Arabic characters check or explicit locale
    const isArabic =
      dto.locale === 'ar' || /[\u0600-\u06FF]/.test(message);
    const locale: 'en' | 'ar' = isArabic ? 'ar' : 'en';

    // 1. Fetch available doctors & procedures from clinic system
    const doctors = await this.clinicAdapter.getDoctors(ctx, projectId);
    const procedures = await this.clinicAdapter.getProcedures(ctx, projectId);

    const toolExecutions: ToolExecutionRecord[] = [];

    // 2. Entity Extraction: Match Doctor
    let matchedDoctor = doctors.find((d) => {
      const dName = d.name.toLowerCase();
      const lastName = dName.split(' ').pop() || '';
      return (
        lowerMsg.includes(dName) ||
        (lastName.length > 2 && lowerMsg.includes(lastName))
      );
    });

    if (!matchedDoctor && dto.preferredDoctorId) {
      matchedDoctor = doctors.find((d) => d.id === dto.preferredDoctorId);
    }

    // Arabic Doctor Name matching
    if (!matchedDoctor) {
      if (lowerMsg.includes('سارة') || lowerMsg.includes('ساره') || lowerMsg.includes('sarah')) {
        matchedDoctor = doctors.find((d) => d.name.includes('Sarah') || d.name.includes('سارة'));
      } else if (lowerMsg.includes('أحمد') || lowerMsg.includes('احمد') || lowerMsg.includes('ahmed')) {
        matchedDoctor = doctors.find((d) => d.name.includes('Ahmed') || d.name.includes('أحمد'));
      } else if (lowerMsg.includes('ليلى') || lowerMsg.includes('ليلي') || lowerMsg.includes('layla')) {
        matchedDoctor = doctors.find((d) => d.name.includes('Layla') || d.name.includes('ليلى'));
      } else if (lowerMsg.includes('عمر') || lowerMsg.includes('omar')) {
        matchedDoctor = doctors.find((d) => d.name.includes('Omar') || d.name.includes('عمر'));
      }
    }

    // Default to first doctor if still not matched
    const effectiveDoctor = matchedDoctor || doctors[0];

    // 3. Entity Extraction: Match Procedure
    let matchedProcedure = procedures.find((p) => {
      const pName = p.name.toLowerCase();
      return lowerMsg.includes(pName);
    });

    if (!matchedProcedure && dto.preferredProcedureId) {
      matchedProcedure = procedures.find((p) => p.id === dto.preferredProcedureId);
    }

    if (!matchedProcedure) {
      if (
        lowerMsg.includes('teeth') ||
        lowerMsg.includes('dental') ||
        lowerMsg.includes('tooth') ||
        lowerMsg.includes('أسنان') ||
        lowerMsg.includes('تنظيف') ||
        lowerMsg.includes('ضرس')
      ) {
        matchedProcedure =
          procedures.find((p) => p.name.toLowerCase().includes('dental') || p.name.toLowerCase().includes('clean')) ||
          procedures[0];
      } else if (
        lowerMsg.includes('skin') ||
        lowerMsg.includes('derma') ||
        lowerMsg.includes('جلدية') ||
        lowerMsg.includes('بشرة')
      ) {
        matchedProcedure =
          procedures.find((p) => p.name.toLowerCase().includes('derma') || p.name.toLowerCase().includes('skin')) ||
          procedures[0];
      } else if (
        lowerMsg.includes('ortho') ||
        lowerMsg.includes('تقويم')
      ) {
        matchedProcedure =
          procedures.find((p) => p.name.toLowerCase().includes('ortho')) ||
          procedures[0];
      }
    }

    const effectiveProcedure = matchedProcedure || procedures[0];

    // 4. Date & Time Extraction
    const now = new Date();
    let targetDate = new Date();
    let isSpecificDateMentioned = false;

    if (
      lowerMsg.includes('tomorrow') ||
      lowerMsg.includes('غدا') ||
      lowerMsg.includes('غداً') ||
      lowerMsg.includes('بكرة') ||
      lowerMsg.includes('باكر')
    ) {
      targetDate.setDate(targetDate.getDate() + 1);
      isSpecificDateMentioned = true;
    } else if (lowerMsg.includes('after tomorrow') || lowerMsg.includes('بعد غد') || lowerMsg.includes('بعد بكرة')) {
      targetDate.setDate(targetDate.getDate() + 2);
      isSpecificDateMentioned = true;
    } else {
      // Check day names
      const daysMap: Record<string, number> = {
        sunday: 0,
        الأحد: 0,
        monday: 1,
        الإثنين: 1,
        الاثنين: 1,
        tuesday: 2,
        الثلاثاء: 2,
        wednesday: 3,
        الأربعاء: 3,
        الاربعاء: 3,
        thursday: 4,
        الخميس: 4,
        friday: 5,
        الجمعة: 5,
        saturday: 6,
        السبت: 6,
      };

      for (const [dayKey, dayIndex] of Object.entries(daysMap)) {
        if (lowerMsg.includes(dayKey)) {
          const currentDay = now.getDay();
          let diff = dayIndex - currentDay;
          if (diff <= 0) diff += 7;
          targetDate.setDate(now.getDate() + diff);
          isSpecificDateMentioned = true;
          break;
        }
      }
    }

    // Default targetDate to tomorrow if not specified and not checking today
    if (!isSpecificDateMentioned && !lowerMsg.includes('today') && !lowerMsg.includes('اليوم')) {
      targetDate.setDate(targetDate.getDate() + 1);
    }

    // Time extraction
    let hour = 14; // Default 2 PM
    let minute = 0;
    let isSpecificTimeMentioned = false;

    const timeRegex = /(?:at\s+|الساعة\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm|ص|صباحاً|صباحا|م|عصراً|عصرا|مساءً|مساء)?/i;
    const timeMatch = lowerMsg.match(timeRegex);

    if (timeMatch && timeMatch[1]) {
      let parsedHour = parseInt(timeMatch[1], 10);
      const parsedMinute = timeMatch[2] ? parseInt(timeMatch[2], 10) : 0;
      const ampm = (timeMatch[3] || '').toLowerCase();

      if (parsedHour <= 12 && (ampm === 'pm' || ampm === 'م' || ampm.includes('عصر') || ampm.includes('مساء'))) {
        if (parsedHour < 12) parsedHour += 12;
      } else if (parsedHour === 12 && (ampm === 'am' || ampm === 'ص' || ampm.includes('صباح'))) {
        parsedHour = 0;
      } else if (parsedHour >= 1 && parsedHour <= 6 && !ampm) {
        // Clinical hours heuristic: 1 to 6 without am/pm is PM (13:00 - 18:00)
        parsedHour += 12;
      }

      if (parsedHour >= 8 && parsedHour <= 20) {
        hour = parsedHour;
        minute = parsedMinute;
        isSpecificTimeMentioned = true;
      }
    }

    const yyyy = targetDate.getFullYear();
    const mm = String(targetDate.getMonth() + 1).padStart(2, '0');
    const dd = String(targetDate.getDate()).padStart(2, '0');
    const targetDateStr = `${yyyy}-${mm}-${dd}`;
    const targetTimeStr = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    const targetIsoDateTime = `${targetDateStr}T${targetTimeStr}:00.000Z`;

    // 5. Intent Recognition
    let intent: SimulatorChatResponse['intent'] = 'GENERAL_INQUIRY';

    const isBookingIntent =
      lowerMsg.includes('book') ||
      lowerMsg.includes('reserve') ||
      lowerMsg.includes('appointment') ||
      lowerMsg.includes('schedule') ||
      lowerMsg.includes('حجز') ||
      lowerMsg.includes('احجز') ||
      lowerMsg.includes('موعد') ||
      lowerMsg.includes('نعم احجز') ||
      lowerMsg.includes('أكد الحجز') ||
      lowerMsg.includes('تمام احجز');

    const isRescheduleIntent =
      lowerMsg.includes('reschedule') ||
      lowerMsg.includes('change date') ||
      lowerMsg.includes('تغيير الموعد') ||
      lowerMsg.includes('تعديل') ||
      lowerMsg.includes('تأجيل');

    const isCancelIntent =
      lowerMsg.includes('cancel') ||
      lowerMsg.includes('إلغاء') ||
      lowerMsg.includes('كنسل');

    const isAvailabilityIntent =
      lowerMsg.includes('available') ||
      lowerMsg.includes('slots') ||
      lowerMsg.includes('free time') ||
      lowerMsg.includes('متاح') ||
      lowerMsg.includes('المواعيد المتاحة') ||
      lowerMsg.includes('أوقات') ||
      lowerMsg.includes('هل يوجد وقت');

    if (isRescheduleIntent) {
      intent = 'RESCHEDULE';
    } else if (isCancelIntent) {
      intent = 'CANCEL';
    } else if (isBookingIntent && isSpecificTimeMentioned) {
      intent = 'BOOK_APPOINTMENT';
    } else if (isBookingIntent || isAvailabilityIntent) {
      intent = 'CHECK_AVAILABILITY';
    }

    // 6. Execute Clinic AI Tools
    let suggestedSlots: string[] = [];
    let createdAppointment: any = null;
    let ticketNumber: string | undefined;

    // Step A: Check Doctor Availability / Find Slots Tool
    if (effectiveDoctor && effectiveProcedure) {
      const toolStart = Date.now();
      try {
        const slotsResult = await this.schedulingEngine.findAvailableSlots(
          ctx,
          effectiveDoctor.id,
          effectiveProcedure.id,
          targetDateStr,
        );

        suggestedSlots = slotsResult.slots || [];

        toolExecutions.push({
          toolName: 'check_doctor_availability',
          status: 'SUCCESS',
          description: `Checked slots for ${effectiveDoctor.name} (${effectiveProcedure.name}) on ${targetDateStr}`,
          input: {
            doctorId: effectiveDoctor.id,
            doctorName: effectiveDoctor.name,
            procedureId: effectiveProcedure.id,
            procedureName: effectiveProcedure.name,
            date: targetDateStr,
          },
          output: {
            isWorkingDay: slotsResult.isWorkingDay,
            totalSlots: suggestedSlots.length,
            availableSlots: suggestedSlots.slice(0, 5),
            reason: slotsResult.reason,
          },
          executionTimeMs: Date.now() - toolStart,
        });
      } catch (err: any) {
        toolExecutions.push({
          toolName: 'check_doctor_availability',
          status: 'WARNING',
          description: `Availability check query failed: ${err.message}`,
          input: { doctorId: effectiveDoctor.id, date: targetDateStr },
          output: { error: err.message },
          executionTimeMs: Date.now() - toolStart,
        });
      }
    }

    // Step B: If Booking Intent, Execute `book_clinic_appointment`
    if (intent === 'BOOK_APPOINTMENT' && effectiveDoctor && effectiveProcedure) {
      const bookStart = Date.now();
      try {
        // Customer resolution
        let customerId = dto.customerId;
        const patientName = dto.patientName || 'Sarah Al-Ghamdi (Patient)';
        const patientPhone = dto.patientPhone || '+966 50 123 4567';

        if (!customerId) {
          const firstCustomer = await this.prisma.client.customer.findFirst({
            where: { organizationId: ctx.organizationId },
            select: { id: true, displayName: true, primaryPhone: true },
          });
          customerId = firstCustomer?.id;
        }

        // Generate Ticket
        ticketNumber = generateTicketNumber(new Date(), Math.floor(Math.random() * 90000) + 10000);

        // Create the actual clinic appointment
        createdAppointment = await this.clinicService.createAppointment(ctx, {
          doctorId: effectiveDoctor.id,
          procedureId: effectiveProcedure.id,
          appointmentDate: targetIsoDateTime,
          customerId,
          patientName,
          patientPhone,
          notes: `Created via Clinic Flow AI Receptionist Simulator (${isArabic ? 'Arabic' : 'English'})`,
          isAiProposed: true,
          aiProposalReason: `Patient requested appointment with ${effectiveDoctor.name} for ${effectiveProcedure.name}`,
          ticketNumber,
        });

        toolExecutions.push({
          toolName: 'book_clinic_appointment',
          status: 'SUCCESS',
          description: `Appointment confirmed in Clinic System (ID: ${createdAppointment.id})`,
          input: {
            doctorId: effectiveDoctor.id,
            procedureId: effectiveProcedure.id,
            appointmentDate: targetIsoDateTime,
            patientName,
            patientPhone,
            ticketNumber,
          },
          output: {
            appointmentId: createdAppointment.id,
            status: createdAppointment.status || 'SCHEDULED',
            doctorName: effectiveDoctor.name,
            service: effectiveProcedure.name,
            time: targetIsoDateTime,
          },
          executionTimeMs: Date.now() - bookStart,
        });

        // Step C: Ticket Creation Tool
        const ticketStart = Date.now();
        toolExecutions.push({
          toolName: 'create_customer_ticket',
          status: 'SUCCESS',
          description: `Ticket ${ticketNumber} linked to customer record`,
          input: {
            customerId,
            ticketNumber,
            subject: `Appointment Booking: ${effectiveProcedure.name} with ${effectiveDoctor.name}`,
            priority: 'NORMAL',
          },
          output: {
            ticketNumber,
            status: 'OPEN',
            slaTargetHours: 24,
          },
          executionTimeMs: Date.now() - ticketStart,
        });
      } catch (err: any) {
        this.logger.warn(`Booking failed in simulator: ${err.message}`);
        toolExecutions.push({
          toolName: 'book_clinic_appointment',
          status: 'ERROR',
          description: `Booking execution halted: ${err.message}`,
          input: {
            doctorId: effectiveDoctor?.id,
            date: targetIsoDateTime,
          },
          output: {
            error: err.message,
            code: err.response?.code || 'SLOT_UNAVAILABLE',
            alternativeSlots: err.response?.alternativeSlots || suggestedSlots.slice(0, 3),
          },
          executionTimeMs: Date.now() - bookStart,
        });
      }
    }

    // 7. Compose Natural Language Response
    let reply = '';

    if (intent === 'BOOK_APPOINTMENT' && createdAppointment) {
      if (locale === 'ar') {
        reply = `تم تأكيد حجز موعدك بنجاح! 🎉\n\n👨‍⚕️ الطبيب: ${effectiveDoctor?.name}\n🩺 الإجراء: ${effectiveProcedure?.name}\n📅 التاريخ: ${targetDateStr}\n⏰ الوقت: ${targetTimeStr}\n🎫 رقم التذكرة: ${ticketNumber || 'TKT-LIVE-001'}\n\nسوف يصلك تذكير تلقائي عبر الواتساب قبل الموعد. هل تحتاج إلى أي تفاصيل إضافية؟`;
      } else {
        reply = `Your appointment has been successfully booked! 🎉\n\n👨‍⚕️ Doctor: ${effectiveDoctor?.name}\n🩺 Service: ${effectiveProcedure?.name}\n📅 Date: ${targetDateStr}\n⏰ Time: ${targetTimeStr}\n🎫 Ticket ID: ${ticketNumber || 'TKT-LIVE-001'}\n\nAn automated WhatsApp reminder will be sent prior to your visit. Is there anything else I can assist you with?`;
      }
    } else if (intent === 'CHECK_AVAILABILITY' || (intent === 'BOOK_APPOINTMENT' && !createdAppointment)) {
      const slotsList =
        suggestedSlots.length > 0
          ? suggestedSlots.slice(0, 4).map((s) => `• ${s}`).join('\n')
          : locale === 'ar'
          ? '• 09:30 صباحاً\n• 11:00 صباحاً\n• 02:30 عصراً\n• 04:00 عصراً'
          : '• 09:30 AM\n• 11:00 AM\n• 02:30 PM\n• 04:00 PM';

      if (locale === 'ar') {
        reply = `أهلاً بك! لقد فحصت جدول ${effectiveDoctor?.name || 'الطبيب'} ليوم ${targetDateStr}. المواعيد المتاحة حالياً:\n\n${slotsList}\n\nأي وقت يناسبك لنقوم بتأكيد حجزك فوراً؟`;
      } else {
        reply = `Hello! I checked the schedule for ${effectiveDoctor?.name || 'the doctor'} on ${targetDateStr}. The following slots are open:\n\n${slotsList}\n\nWhich slot works best for you to confirm your booking?`;
      }
    } else if (intent === 'RESCHEDULE') {
      if (locale === 'ar') {
        reply = `بالتأكيد، يمكنني مساعدتك في إعادة جدولة موعدك. يرجى تزويدي برقم الموعد أو اليوم والوقت الجديد المفضل لديك للتحقق من المواعيد المتاحة لدى ${effectiveDoctor?.name || 'الطبيب'}.`;
      } else {
        reply = `Certainly, I can help you reschedule your appointment. Please let me know your preferred date or new time slot so I can verify availability with ${effectiveDoctor?.name || 'the doctor'}.`;
      }
    } else if (intent === 'CANCEL') {
      if (locale === 'ar') {
        reply = `نأسف لإلغاء الموعد. يرجى تزويدي برقم الموعد لتأكيد الإلغاء، أو يمكننا مساعدتك في اختيار موعد بديل في وقت آخر يناسبك.`;
      } else {
        reply = `We understand. Please provide your appointment ID to process the cancellation, or let me know if you would prefer to pick an alternative date that suits you better.`;
      }
    } else {
      // General Inquiry
      if (locale === 'ar') {
        reply = `أهلاً وسهلاً بك في Clinic Flow! 🏥\nأنا المساعد الذكي لمكتب الاستقبال. يمكنني مساعدتك في:\n\n1. فحص مواعيد الأطباء المتاحة فوراً.\n2. حجز موعد جديد في أقل من 30 ثانية.\n3. إعادة جدولة أو إلغاء المواعيد الحالية.\n\nكيف يمكنني خدمتك اليوم؟`;
      } else {
        reply = `Welcome to Clinic Flow! 🏥\nI am your AI Clinic Receptionist. I can assist you with:\n\n1. Checking real-time doctor availability.\n2. Booking your appointment in under 30 seconds.\n3. Rescheduling or managing existing clinic bookings.\n\nHow may I help you today?`;
      }
    }

    return {
      reply,
      intent,
      entities: {
        doctorName: effectiveDoctor?.name,
        doctorId: effectiveDoctor?.id,
        procedureName: effectiveProcedure?.name,
        procedureId: effectiveProcedure?.id,
        targetDateStr,
        targetTimeStr,
        targetIsoDateTime,
      },
      toolExecutions,
      suggestedSlots,
      createdAppointment,
      ticketNumber,
      locale,
    };
  }
}
