import { useState, type FormEvent } from 'react';
import { Button, Spinner } from '@firstelement/ui';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useT } from '../lib/i18n';
import { api } from '../lib/api';
import { controlCls } from '../lib/ui';
import { useNotes, type NoteRow } from '../lib/notes';

interface NotesSectionProps {
  resourceType: string;
  resourceId: string | undefined;
  projectId: string | undefined;
}

/**
 * Notes attach to any project-scoped record. The API is polymorphic —
 * `resourceType` names the kind of record and `resourceId` the row — so the
 * same section is reused for people, deals, leads, tasks and companies.
 */
export function NotesSection({ resourceType, resourceId, projectId }: NotesSectionProps) {
  const t = useT();
  const qc = useQueryClient();
  const [draft, setDraft] = useState('');

  const enabled = Boolean(resourceId) && Boolean(projectId);
  const notes = useNotes(resourceType, resourceId, projectId);

  const invalidate = () =>
    void qc.invalidateQueries({
      queryKey: ['notes', resourceType, resourceId, projectId ?? ''],
    });

  const create = useMutation({
    mutationFn: () =>
      api.post<NoteRow>('/notes', {
        resourceType,
        resourceId,
        projectId,
        body: draft.trim(),
      }),
    onSuccess: () => {
      setDraft('');
      invalidate();
    },
  });

  const remove = useMutation({
    mutationFn: (noteId: string) => api.delete(`/notes/${noteId}`),
    onSuccess: invalidate,
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (draft.trim() && projectId) create.mutate();
  };

  return (
    <div className="border-t border-hairline px-4 py-3">
      <p className="fe-eyebrow mb-2">{t('notes.title')}</p>

      <form onSubmit={onSubmit} className="flex items-center gap-2">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={t('notes.placeholder')}
          aria-label={t('notes.title')}
          className={controlCls}
          style={{ flex: 1 }}
        />
        <Button type="submit" size="sm" variant="secondary" loading={create.isPending} disabled={!draft.trim()}>
          {t('notes.add')}
        </Button>
      </form>

      {!enabled ? null : notes.isPending ? (
        <div className="mt-3">
          <Spinner label={t('common.loading')} />
        </div>
      ) : notes.isError ? (
        <p className="mt-3 text-xs text-slate">{t('common.error')}</p>
      ) : !notes.data || notes.data.length === 0 ? (
        <p className="mt-3 text-xs text-slate-soft">{t('notes.empty')}</p>
      ) : (
        <ul className="mt-3 flex flex-col gap-2">
          {notes.data.map((note) => (
            <li key={note.id} className="rounded border border-hairline bg-surface p-2.5">
              <p className="whitespace-pre-wrap text-xs text-ink">{note.body}</p>
              <div className="mt-1.5 flex items-center justify-between">
                <span className="fe-mono text-[11px] text-slate-soft">
                  {new Date(note.createdAt).toLocaleString()}
                </span>
                <button
                  type="button"
                  onClick={() => remove.mutate(note.id)}
                  disabled={remove.isPending}
                  className="text-[11px] font-medium text-danger hover:underline disabled:opacity-50"
                >
                  {t('notes.delete')}
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}