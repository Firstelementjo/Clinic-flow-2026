import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import {
  ArrowDownNarrowWide,
  ArrowLeft,
  ArrowUpDown,
  Check,
  ChevronDown,
  CirclePlus,
  EyeOff,
  Filter,
  List as ListIcon,
  MoreHorizontal,
  Plus,
  Sigma,
  Trash2,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Button } from '@firstelement/ui';
import { useT, type StringKey } from '../lib/i18n';
import { AddFieldMenu, getAvailableFields } from './AddFieldMenu';

/**
 * One list view for every CRM object — Companies, People, Opportunities,
 * Tasks, Notes. The shape matches the Middle Workspace spec: a dark sheet
 * with a narrow toolbar of quiet text controls, a typed column header (a
 * field-type icon and a label), compact data rows, an in-table "Add new"
 * row, and a "Calculate" footer whose aggregates line up under the columns
 * they describe.
 *
 * A column's `render` returns a plain value (string / number), `null` or
 * `undefined` for empty (drawn as a muted skeleton bar — never "N/A"), or
 * a full element for rich cells (avatar + name, status pill, dates, …).
 */

export type CellValue = ReactNode;

export interface ListColumn<T> {
  id: string;
  label: StringKey | string;
  icon: LucideIcon;
  /** Grid track for this column, e.g. `minmax(10rem, 3fr)` or `6rem`. */
  size: string;
  render: (row: T) => CellValue;
}

export interface FooterCell<T> {
  col: string;
  render: (rows: T[]) => CellValue;
}

export type BadgeTone = 'neutral' | 'signal' | 'agent' | 'escalation' | 'danger' | 'warning';

const BADGE_TONE: Record<BadgeTone, string> = {
  neutral: 'bg-mist text-slate',
  signal: 'bg-signal-wash text-signal',
  agent: 'bg-agent-wash text-agent',
  escalation: 'bg-escalation-wash text-escalation',
  danger: 'bg-danger-wash text-danger',
  warning: 'bg-warning-wash text-warning',
};

/** Colored pill used for status fields — never plain text. */
export function ListBadge({ tone = 'neutral', children }: { tone?: BadgeTone; children: ReactNode }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border border-hairline px-2 py-0.5 text-[11px] font-medium leading-4 ${BADGE_TONE[tone]}`}
    >
      {children}
    </span>
  );
}

/** Status pill that still lets the operator flip the value inline. */
export function ListBadgeSelect<T extends string>({
  value,
  options,
  toneFor,
  onChange,
  ariaLabel,
}: {
  value: T;
  options: { value: T; label: string }[];
  toneFor: (value: T) => BadgeTone;
  onChange: (value: T) => void;
  ariaLabel: string;
}) {
  const tone = toneFor(value);
  return (
    <span className="relative inline-flex">
      <span className="pointer-events-none absolute inset-0 flex items-center justify-end rounded-full border border-hairline pe-1.5">
        <ChevronDown aria-hidden="true" className="h-3 w-3 text-current" />
      </span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as T)}
        aria-label={ariaLabel}
        className={`appearance-none rounded-full border border-hairline pe-6 ps-2 py-0.5 text-[11px] font-medium leading-4 ${BADGE_TONE[tone]}`}
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </span>
  );
}

/** Deterministic token-based initial avatar; a hash picks the hue. */
export function RecordAvatar({ name, size = 'h-6 w-6 text-[11px]' }: { name: string; size?: string }) {
  const hash = [...name].reduce((acc, ch) => acc + ch.charCodeAt(0), 0) + name.length * 7919;
  const H = [
    ['bg-signal-wash', 'text-signal'],
    ['bg-agent-wash', 'text-agent'],
    ['bg-escalation-wash', 'text-escalation'],
    ['bg-danger-wash', 'text-danger'],
    ['bg-mist-deep', 'text-slate'],
  ] as const;
  const [bg, text] = H[hash % H.length] ?? H[0];
  const initials =
    name
      .trim()
      .split(/\s+/)
      .map((part) => part[0])
      .slice(0, 2)
      .join('')
      .toUpperCase() || '?';

  return (
    <span dir="ltr" className={`${bg} ${text} ${size} inline-flex shrink-0 select-none items-center justify-center rounded font-semibold`}>
      {initials}
    </span>
  );
}

/** Muted placeholder bar for an empty cell — blank, never "N/A". */
export function SkeletonBar({ className = '' }: { className?: string }) {
  return <span className={`block h-2.5 w-14 rounded-sm bg-mist ${className}`} aria-hidden="true" />;
}

/** Small popover menu (row overflow, Options). */
export function Menu({ button, children, align = 'end' }: { button: ReactNode; children: ReactNode; align?: 'start' | 'end' }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-haspopup="menu" aria-expanded={open}>
        {button}
      </button>
      {open && (
        <>
          <button
            type="button"
            aria-hidden="true"
            tabIndex={-1}
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-20 cursor-default"
          />
          <div
            role="menu"
            className={`absolute z-30 mt-1 min-w-44 rounded-lg border border-hairline bg-surface p-1 shadow-pop ${
              align === 'end' ? 'end-0' : 'start-0'
            }`}
          >
            {children}
          </div>
        </>
      )}
    </div>
  );
}

export function MenuItem({
  onClick,
  icon,
  label,
  danger,
  disabled,
}: {
  onClick: () => void;
  icon?: LucideIcon;
  label: string;
  danger?: boolean;
  disabled?: boolean;
}) {
  const Icon = icon;
  return (
    <button
      type="button"
      role="menuitem"
      onClick={onClick}
      disabled={disabled}
      className={`flex w-full items-center gap-2 rounded px-2.5 py-1.5 text-start text-xs transition-colors hover:bg-mist disabled:cursor-not-allowed disabled:opacity-45 disabled:hover:bg-transparent ${
        danger ? 'font-medium text-danger hover:text-danger' : 'text-ink'
      }`}
    >
      {Icon ? <Icon aria-hidden="true" className="h-3.5 w-3.5 shrink-0" /> : null}
      {label}
    </button>
  );
}

interface ListViewProps<T> {
  title: string;
  eyebrow?: string;
  addLabel: string;
  onAdd: () => void;
  noun: string;
  columns: ListColumn<T>[];
  rows: T[] | null | undefined;
  isPending?: boolean;
  isError?: boolean;
  keyOf: (row: T) => string;
  rowActions?: (row: T) => ReactNode;
  footerCells?: FooterCell<T>[];
  footer?: boolean;
  filterValue?: string;
  onFilter?: (value: string) => void;
  sortValue?: string;
  onSort?: (value: string) => void;
  sortOptions?: { value: string; label: string }[];
  /**
   * Saved-view switcher rendered in the toolbar in place of the static
   * "All {noun}" label (the ViewSwitcher brings its own icon and chevron).
   */
  viewSwitcher?: ReactNode;
  /**
   * Controlled hidden-column set. When omitted the list keeps its own local
   * state; pages that persist column layout per saved view pass both props.
   */
  hiddenColumns?: Record<string, boolean>;
  onHiddenColumnsChange?: (next: Record<string, boolean>) => void;
  selectable?: boolean;
  onSelectionChange?: (selected: string[]) => void;
  /**
   * Bulk delete for the checkbox selection. When provided, the toolbar
   * Options menu gains a "Delete selected (n)" item; ListView clears the
   * selection after invoking it.
   */
  onDeleteSelected?: (ids: string[]) => void;
  emptyTitle?: string;
  emptyBody?: string;
  /** Object type for Add Field menu (people/companies/opportunities/tasks/notes) */
  objectType?: string;
}

export function ListView<T>({
  title,
  eyebrow,
  addLabel,
  onAdd,
  noun,
  columns,
  rows,
  isPending,
  isError,
  keyOf,
  rowActions,
  footerCells = [],
  footer = true,
  filterValue = '',
  onFilter,
  sortValue,
  onSort,
  sortOptions = [],
  viewSwitcher,
  hiddenColumns,
  onHiddenColumnsChange,
  selectable = true,
  onSelectionChange,
  onDeleteSelected,
  emptyTitle,
  emptyBody,
  objectType,
}: ListViewProps<T>) {
  const t = useT();
  const [filterOpen, setFilterOpen] = useState(false);
  const [sortOpen, setSortOpen] = useState(false);
  const [localHidden, setLocalHidden] = useState<Record<string, boolean>>({});
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [headerMenu, setHeaderMenu] = useState<{ id: string; top: number; left: number } | null>(null);
  const [columnOrder, setColumnOrder] = useState<string[] | null>(null);
  const [columnSizes, setColumnSizes] = useState<Record<string, string>>({});
  const [resizing, setResizing] = useState<{ id: string; startX: number; startWidth: number } | null>(null);
  const colRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const hidden = hiddenColumns ?? localHidden;
  const updateHidden = (next: Record<string, boolean>) => {
    if (onHiddenColumnsChange) onHiddenColumnsChange(next);
    else setLocalHidden(next);
  };

  const selectedKeys = Object.keys(selected).filter((k) => selected[k]);
  const allSelected = (rows ?? []).length > 0 && selectedKeys.length === (rows ?? []).length;

  // Registry-derived columns: all fields for this objectType that are not already in base columns
  // They are hidden by default and become visible when added via AddFieldMenu
  const registryCols = useMemo<ListColumn<T>[]>(() => {
    if (!objectType) return [];
    const registry = getAvailableFields(objectType);
    const existing = new Set(columns.map((c) => c.id));
    return registry
      .filter((f) => !existing.has(f.id))
      .map((def) => ({
        id: def.id,
        label: def.label as unknown as StringKey,
        icon: def.icon,
        size: 'minmax(9rem, 1.5fr)',
        render: (row: any) => {
          const raw = row?.[def.id] ?? row?.[def.id.toLowerCase()] ?? null;
          if (raw == null || raw === '') return null;
          if (typeof raw === 'string' && (def.id.toLowerCase().includes('at') || def.id.toLowerCase().includes('date'))) {
            const d = new Date(raw);
            if (!isNaN(d.getTime())) return d.toLocaleDateString();
          }
          return String(raw);
        },
      }));
  }, [objectType, columns]);

  const combinedColumns = useMemo(() => [...columns, ...registryCols], [columns, registryCols]);

  const registryIdSet = useMemo(() => new Set(registryCols.map((c: ListColumn<T>) => c.id)), [registryCols]);

  const orderedCombinedColumns = useMemo(() => {
    if (!columnOrder) return combinedColumns;
    const orderMap = new Map(columnOrder.map((id, i) => [id, i] as const));
    return [...combinedColumns].sort((a, b) => {
      const ai = orderMap.get(a.id) ?? 999;
      const bi = orderMap.get(b.id) ?? 999;
      return ai - bi;
    });
  }, [combinedColumns, columnOrder]);

  const columnsMenu = (
    <>
      {onDeleteSelected ? (
        <div className="border-b border-hairline p-1">
          <MenuItem
            danger
            icon={Trash2}
            label={`${t('list.deleteSelected')}${selectedKeys.length > 0 ? ` (${selectedKeys.length})` : ''}`}
            disabled={selectedKeys.length === 0}
            onClick={() => {
              if (selectedKeys.length === 0) return;
              onDeleteSelected(selectedKeys);
              setSelected({});
              if (onSelectionChange) onSelectionChange([]);
            }}
          />
        </div>
      ) : null}
      <div className="px-2.5 pb-1 pt-1.5">
        <p className="fe-eyebrow">{t('list.columns')}</p>
        <button
          type="button"
          onClick={() => updateHidden({})}
          className="mt-1 text-xs font-medium text-signal hover:underline"
        >
          {t('list.reset')}
        </button>
      </div>
      {orderedCombinedColumns.map((col: ListColumn<T>) => {
        const isRegistry = registryIdSet.has(col.id);
        const isVisible = isRegistry ? hidden[col.id] === false : !hidden[col.id];
        return (
          <label key={col.id} className="flex cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-xs text-ink hover:bg-mist">
            <input
              type="checkbox"
              checked={isVisible}
              onChange={() => updateHidden({ ...hidden, [col.id]: isVisible ? true : false })}
              className="h-3.5 w-3.5 accent-signal"
            />
            <col.icon aria-hidden="true" className="h-3.5 w-3.5 text-slate-soft" />
            {(() => {
              const key = col.label as StringKey;
              try {
                return t(key);
              } catch {
                return col.label;
              }
            })()}
          </label>
        );
      })}
    </>
  );

  const visible = useMemo(
    () =>
      orderedCombinedColumns.filter((c: ListColumn<T>) => {
        if (registryIdSet.has(c.id)) return hidden[c.id] === false;
        return !hidden[c.id];
      }),
    [orderedCombinedColumns, hidden, registryIdSet],
  );

  const handleAddField = (fieldId: string) => {
    // Registry columns are already in combinedColumns but hidden; just unhide
    // Base columns that are hidden also just unhide
    updateHidden({ ...hidden, [fieldId]: false });
  };

  const handleMoveLeft = (id: string) => {
    const ids = columnOrder ?? orderedCombinedColumns.map((c) => c.id);
    const idx = ids.indexOf(id);
    if (idx <= 0) return;
    const next = [...ids];
    const tmp = next[idx - 1]!;
    next[idx - 1] = next[idx]!;
    next[idx] = tmp;
    setColumnOrder(next);
    setHeaderMenu(null);
  };

  const handleHide = (id: string) => {
    updateHidden({ ...hidden, [id]: true });
    setHeaderMenu(null);
  };

  const handleHeaderFilter = () => {
    setFilterOpen(true);
    setHeaderMenu(null);
  };

  const handleHeaderSort = (id: string) => {
    if (onSort) onSort(id);
    setHeaderMenu(null);
  };

  const tLabel = (label: StringKey | string) => {
    try {
      return t(label as StringKey);
    } catch {
      return String(label);
    }
  };
  const toggleAll = () => {
    if (!rows) return;
    const next = allSelected ? {} : Object.fromEntries(rows.map((r) => [keyOf(r), true]));
    setSelected(next);
    if (onSelectionChange) onSelectionChange(allSelected ? [] : rows.map(keyOf));
  };

  const toggleOne = (key: string) => {
    setSelected((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      if (onSelectionChange) onSelectionChange(Object.keys(next).filter((k) => next[k]));
      return next;
    });
  };

  const template = `2.75rem ${visible.map((c: ListColumn<T>) => columnSizes[c.id] ?? c.size).join(' ')}${rowActions ? ' auto' : ''}`;

  const grid = { gridTemplateColumns: template };

  useEffect(() => {
    if (!resizing) return;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    const onMove = (e: MouseEvent) => {
      const delta = e.clientX - resizing.startX;
      const next = Math.max(90, Math.min(520, resizing.startWidth + delta));
      setColumnSizes((prev) => ({ ...prev, [resizing.id]: `${next}px` }));
    };
    const onUp = () => {
      setResizing(null);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    };
  }, [resizing]);

  const selectCheck = (checked: boolean) => (
    <span
      aria-hidden="true"
      className={`pointer-events-none inline-flex h-4 w-4 items-center justify-center rounded-sm border ${
        checked ? 'border-signal bg-signal text-white' : 'border-slate-soft text-transparent'
      } transition-colors`}
    >
      <Check aria-hidden="true" className="h-3 w-3" />
    </span>
  );

  const cell = (col: ListColumn<T>, row: T) => {
    const value = col.render(row);
    if (value === null || value === undefined || value === '') {
      return <SkeletonBar />;
    }
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      return <span className="truncate text-xs text-slate">{String(value)}</span>;
    }
    return value;
  };

  return (
    <section className="overflow-hidden rounded-2xl bg-[var(--fe-surface)] border border-[var(--fe-hairline)] shadow-[var(--fe-shadow-panel)]">
      {/* Header: object title + primary action */}
      <div className="flex items-center justify-between gap-3 border-b border-[var(--fe-hairline)] px-5 py-5 bg-[var(--fe-surface)]">
        <div className="min-w-0">
          {eyebrow ? <p className="fe-eyebrow">{eyebrow}</p> : null}
          <h2 className="fe-display truncate text-lg text-ink">{title}</h2>
        </div>
        <Button type="button" size="sm" variant="primary" onClick={onAdd}>
          <Plus aria-hidden="true" className="h-4 w-4" />
          {addLabel}
        </Button>
      </div>

      {/* Toolbar: All {noun} · [n]  +  Filter / Sort / Options */}
      <div className="flex h-11 items-center gap-1 border-b border-black/5 dark:border-white/10 px-3 bg-surface/20">
        <div className="flex min-w-0 flex-1 items-center gap-1.5 text-sm text-ink">
          {viewSwitcher ?? (
            <>
              <ListIcon aria-hidden="true" className="h-4 w-4 shrink-0 text-slate-soft" />
              <span className="truncate font-medium">
                {t('list.footer.all')} {noun}
              </span>
            </>
          )}
          <span className="fe-mono text-xs text-slate-soft">{isPending ? '…' : (rows?.length ?? 0)}</span>
          {selectedKeys.length > 0 && selectable ? (
            <button
              type="button"
              onClick={() => {
                setSelected({});
                if (onSelectionChange) onSelectionChange([]);
              }}
              className="ms-1 text-xs font-medium text-signal hover:underline"
            >
              {t('list.unselect')}
            </button>
          ) : null}
        </div>

        <button
          type="button"
          onClick={() => setFilterOpen((o) => !o)}
          className={`inline-flex items-center gap-1 rounded px-2 py-1 text-xs transition-colors ${
            filterOpen || filterValue ? 'text-ink' : 'text-slate hover:text-ink'
          }`}
        >
          <Filter aria-hidden="true" className="h-3.5 w-3.5" />
          {t('list.filter')}
        </button>
        {sortOptions.length > 0 && (
          <button
            type="button"
            onClick={() => setSortOpen((o) => !o)}
            className={`inline-flex items-center gap-1 rounded px-2 py-1 text-xs transition-colors ${
              sortOpen || sortValue ? 'text-ink' : 'text-slate hover:text-ink'
            }`}
          >
            <ArrowDownNarrowWide aria-hidden="true" className="h-3.5 w-3.5" />
            {t('list.sort')}
          </button>
        )}
        <Menu
          align="end"
          button={
            <span className="inline-flex items-center gap-1 rounded px-2 py-1 text-xs text-slate transition-colors hover:text-ink">
              <MoreHorizontal aria-hidden="true" className="h-3.5 w-3.5" />
              {t('list.options')}
            </span>
          }
        >
          {columnsMenu}
        </Menu>
      </div>

      {/* Inline controls revealed by Filter / Sort */}
      {filterOpen && (
        <div className="border-b border-hairline px-4 py-2">
          <input
            type="search"
            autoFocus
            value={filterValue}
            onChange={(e) => onFilter?.(e.target.value)}
            placeholder={t('list.filter')}
            className="h-7 w-full rounded border border-hairline bg-surface px-2.5 text-xs text-ink placeholder:text-slate-soft focus:border-signal"
          />
        </div>
      )}
      {sortOpen && (
        <div className="border-b border-hairline px-4 py-2">
          <select
            value={sortValue}
            onChange={(e) => onSort?.(e.target.value)}
            className="h-7 w-full rounded border border-hairline bg-surface px-2.5 text-xs text-ink focus:border-signal"
          >
            {sortOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Column header row — wrapped for independent horizontal scroll */}
      <div className="overflow-x-auto">
        <div className="flex h-11 items-center border-b border-black/5 dark:border-white/10 px-2.5 bg-surface/30">
          <div style={grid} className="grid min-w-max items-center">
          <div className="px-2.5">
            {selectable && rows && rows.length > 0 ? (
              <button type="button" onClick={toggleAll} aria-label={t('list.unselect')}>
                {selectCheck(allSelected)}
              </button>
            ) : null}
          </div>
          {visible.map((col: ListColumn<T>) => (
            <div
              key={col.id}
              ref={(el) => {
                colRefs.current[col.id] = el;
              }}
              data-col-header={col.id}
              className="group relative flex min-w-0 items-center"
            >
              <button
                type="button"
                onClick={(e) => {
                  const r = e.currentTarget.getBoundingClientRect();
                  const left = Math.max(8, Math.min(r.left, window.innerWidth - 200 - 8));
                  setHeaderMenu((prev) => (prev?.id === col.id ? null : { id: col.id, top: r.bottom + 6, left }));
                }}
                className="flex min-w-0 flex-1 items-center gap-2 px-3 text-start transition-colors hover:text-signal"
              >
                <col.icon aria-hidden="true" className="h-3.5 w-3.5 shrink-0 text-slate-soft" />
                <span className="fe-eyebrow truncate">{tLabel(col.label)}</span>
              </button>
              <div
                onMouseDown={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setHeaderMenu(null);
                  // measure every visible header in the live DOM now (synchronous),
                  // then store px widths so each column drags independently
                  const frozen: Record<string, string> = {};
                  visible.forEach((c) => {
                    const el = colRefs.current[c.id];
                    if (el) frozen[c.id] = `${Math.round(el.getBoundingClientRect().width)}px`;
                  });
                  setColumnSizes((prev) => ({ ...prev, ...frozen }));
                  const cell = colRefs.current[col.id];
                  setResizing({
                    id: col.id,
                    startX: e.clientX,
                    startWidth: cell ? cell.getBoundingClientRect().width : 160,
                  });
                }}
                className="absolute -right-1 top-0 flex h-full w-3 cursor-col-resize touch-none items-center justify-center"
                aria-hidden="true"
              >
                <div
                  className={`h-6 w-0.5 rounded transition-colors ${resizing?.id === col.id ? 'bg-signal' : 'bg-hairline group-hover:bg-slate-soft'}`}
                />
              </div>
            </div>
          ))}
          <div className="flex items-center justify-end px-1">
            {objectType ? (
              <AddFieldMenu
                objectType={objectType}
                visibleIds={visible.map((c: ListColumn<T>) => c.id)}
                onAddField={handleAddField}
                onCustomize={() => {
                  // open full field management — for now just reset columns menu could be toggled
                  // keep popover open behavior already handled
                }}
              />
            ) : rowActions ? (
              <Menu
                align="end"
                button={
                  <button
                    type="button"
                    aria-label={t('list.columns')}
                    className="flex items-center justify-center text-slate-soft transition-colors hover:text-ink"
                  >
                    <Plus aria-hidden="true" className="h-3.5 w-3.5" />
                  </button>
                }
              >
                {columnsMenu}
              </Menu>
            ) : null}
          </div>
        </div>
      </div>

      {/* Data */}
      {isError ? (
        <p className="px-4 py-4 text-sm text-slate">{t('list.error')}</p>
      ) : isPending || !rows ? (
        <div className="flex flex-col">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} style={grid} className="grid h-12 items-center border-b border-black/5 dark:border-white/10 last:border-b-0 px-2.5">
              <div className="px-2.5">
                <span className="block h-4 w-4 rounded-sm bg-mist" />
              </div>
              {visible.map((col: ListColumn<T>) => (
                <div key={col.id} className="px-2.5">
                  <SkeletonBar />
                </div>
              ))}
            </div>
          ))}
        </div>
      ) : rows.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-3 px-4 py-16 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-signal/10 text-signal mb-2">
            <ListIcon className="h-6 w-6" />
          </div>
          <p className="text-base font-semibold text-ink">{emptyTitle ?? t('list.empty.title')}</p>
          <p className="max-w-sm text-sm text-slate-soft">{emptyBody ?? t('list.empty.body')}</p>
        </div>
      ) : (
        <ul className="flex flex-col">
          {rows.map((row) => {
            const key = keyOf(row);
            const active = selectable && selected[key];
            return (
              <li
                key={key}
                onClick={(e) => {
                  const target = e.target as HTMLElement;
                  if (target.closest('button, select, input, a, label, [role="checkbox"]')) return;
                  if (selectable) toggleOne(key);
                }}
                className={`grid h-12 cursor-default items-center border-b border-black/5 dark:border-white/10 px-2.5 transition-colors duration-200 last:border-b-0 ${
                  active ? 'bg-signal/10' : 'hover:bg-surface/40'
                }`}
                style={grid}
              >
                <div className="px-2.5">
                  {selectable ? (
                    <button type="button" onClick={() => toggleOne(key)} aria-label={t('list.unselect')}>
                      {selectCheck(Boolean(selected[key]))}
                    </button>
                  ) : null}
                </div>
                {visible.map((col: ListColumn<T>) => (
                  <div key={col.id} className="min-w-0 px-2.5">
                    {cell(col, row)}
                  </div>
                ))}
                {rowActions ? <div className="flex items-center justify-end ps-1">{rowActions(row)}</div> : null}
              </li>
            );
          })}
        </ul>
      )}

      {/* Inline Add New row */}
      {!isPending && !isError ? (
        <button
          type="button"
          onClick={onAdd}
          className="grid h-12 w-full items-center border-t border-black/5 dark:border-white/10 text-slate-soft transition-colors hover:bg-surface/50 hover:text-signal"
          style={grid}
        >
          <div className="col-start-2 flex min-w-0 items-center gap-2">
            <CirclePlus aria-hidden="true" className="h-4 w-4 shrink-0" />
            <span className="text-xs">{t('list.addNew')}</span>
          </div>
        </button>
      ) : null}

      {/* Calculate footer */}
      {footer && !isPending && !isError && rows && rows.length > 0 ? (
        <div style={grid} className="grid h-12 items-center border-t border-black/5 dark:border-white/10 bg-surface/20 px-2.5 backdrop-blur-sm">
          <div className="flex min-w-0 items-center gap-1.5 px-2.5 text-slate-soft">
            <Sigma aria-hidden="true" className="h-3.5 w-3.5 shrink-0" />
            <span className="text-xs">{t('list.calculate')}</span>
          </div>
          {visible.map((col: ListColumn<T>) => {
            const cell = footerCells.find((c) => c.col === col.id);
            if (!cell) return <div key={col.id} className="px-2.5" />;
            const value = cell.render(rows);
            if (value === null || value === undefined || value === '') return <div key={col.id} className="px-2.5" />;
            return (
              <div key={col.id} className="fe-mono min-w-0 truncate px-2.5 text-xs text-slate-soft">
                {value}
              </div>
            );
          })}
          {rowActions ? <div className="px-1" /> : null}
        </div>
      ) : null}
      </div>

      {/* Column header dropdown — Filter / Sort / Move left / Hide */}
      {headerMenu
        ? createPortal(
            <>
              <button
                type="button"
                aria-hidden="true"
                tabIndex={-1}
                onClick={() => setHeaderMenu(null)}
                className="fixed inset-0 z-20 cursor-default"
              />
              <div
                role="menu"
                style={{ top: headerMenu.top, left: headerMenu.left, width: 220 }}
                className="fixed z-30 flex flex-col overflow-hidden rounded-xl border border-white/10 bg-[#1a1d23] p-1.5 shadow-[0_16px_40px_rgba(0,0,0,0.5)]"
              >
                <button
                  type="button"
                  role="menuitem"
                  onClick={handleHeaderFilter}
                  className="flex h-10 w-full items-center gap-3 rounded-md px-3 text-start transition-colors hover:bg-white/[0.07] group"
                >
                  <Filter aria-hidden="true" className="h-[18px] w-[18px] shrink-0 text-slate-soft transition-colors group-hover:text-white" />
                  <span className="truncate text-sm text-[#c8cdd6] transition-colors group-hover:text-white">Filter</span>
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => handleHeaderSort(headerMenu.id)}
                  className="flex h-10 w-full items-center gap-3 rounded-md px-3 text-start transition-colors hover:bg-white/[0.07] group"
                >
                  <ArrowUpDown aria-hidden="true" className="h-[18px] w-[18px] shrink-0 text-slate-soft transition-colors group-hover:text-white" />
                  <span className="truncate text-sm text-[#c8cdd6] transition-colors group-hover:text-white">Sort</span>
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => handleMoveLeft(headerMenu.id)}
                  className="flex h-10 w-full items-center gap-3 rounded-md px-3 text-start transition-colors hover:bg-white/[0.07] group"
                >
                  <ArrowLeft aria-hidden="true" className="h-[18px] w-[18px] shrink-0 text-slate-soft transition-colors group-hover:text-white" />
                  <span className="truncate text-sm text-[#c8cdd6] transition-colors group-hover:text-white">Move left</span>
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => handleHide(headerMenu.id)}
                  className="flex h-10 w-full items-center gap-3 rounded-md px-3 text-start transition-colors hover:bg-white/[0.07] group"
                >
                  <EyeOff aria-hidden="true" className="h-[18px] w-[18px] shrink-0 text-slate-soft transition-colors group-hover:text-white" />
                  <span className="truncate text-sm text-[#c8cdd6] transition-colors group-hover:text-white">Hide</span>
                </button>
              </div>
            </>,
            document.body,
          )
        : null}
    </section>
  );
}