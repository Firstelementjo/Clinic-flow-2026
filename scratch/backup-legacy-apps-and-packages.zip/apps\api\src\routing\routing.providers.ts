import { Injectable } from '@nestjs/common';
import { RoutingEngine } from '@firstelement/routing';
import { PrismaService } from '../common/prisma.service';
import { DomainEventBus } from '../events/domain-event-bus';

/**
 * The routing engine, wired for the API. Used by the inline development
 * path; in production the worker routes escalations off the queue.
 */
@Injectable()
export class RoutingEngineProvider extends RoutingEngine {
  constructor(prisma: PrismaService, events: DomainEventBus) {
    super(prisma.client, events);
  }
}
