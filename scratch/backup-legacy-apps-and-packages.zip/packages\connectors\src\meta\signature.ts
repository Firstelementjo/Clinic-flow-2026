import { createHmac, timingSafeEqual } from 'node:crypto';

/**
 * Meta webhook signature verification (plan §8, §12).
 *
 * Meta signs the **raw request body** with the app secret and sends
 * `X-Hub-Signature-256: sha256=<hex>`. Two details decide whether this
 * actually protects anything:
 *
 * 1. It must run against the bytes as received. Verifying a re-serialized
 *    `JSON.parse` result computes a different digest — key order and
 *    whitespace change — so the API keeps the raw body for this check.
 * 2. The comparison is constant-time. A `===` on a digest leaks it one
 *    byte at a time to anyone willing to measure.
 */
export function verifyMetaSignature(params: {
  rawBody: Buffer | string;
  signatureHeader: string | undefined;
  appSecret: string;
}): boolean {
  const { rawBody, signatureHeader, appSecret } = params;
  if (!signatureHeader || !appSecret) return false;

  const [algorithm, provided] = signatureHeader.split('=');
  if (algorithm !== 'sha256' || !provided) return false;

  const expected = createHmac('sha256', appSecret)
    .update(typeof rawBody === 'string' ? Buffer.from(rawBody, 'utf8') : rawBody)
    .digest('hex');

  const providedBuffer = Buffer.from(provided, 'hex');
  const expectedBuffer = Buffer.from(expected, 'hex');

  // Length is checked first because timingSafeEqual throws on a mismatch;
  // digest length is fixed and public anyway.
  if (providedBuffer.length !== expectedBuffer.length) return false;
  return timingSafeEqual(providedBuffer, expectedBuffer);
}

/**
 * The GET handshake Meta performs when a webhook URL is first registered:
 * it echoes `hub.challenge` back only if the verify token matches.
 */
export function resolveVerificationChallenge(params: {
  mode: string | undefined;
  token: string | undefined;
  challenge: string | undefined;
  expectedToken: string;
}): string | null {
  const { mode, token, challenge, expectedToken } = params;
  if (mode !== 'subscribe' || !token || !challenge || !expectedToken) return null;

  const provided = Buffer.from(token, 'utf8');
  const expected = Buffer.from(expectedToken, 'utf8');
  if (provided.length !== expected.length) return null;

  return timingSafeEqual(provided, expected) ? challenge : null;
}
