import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Patch, Post, Query, Req } from '@nestjs/common';
import type { Request } from 'express';
import { Permission } from '@firstelement/auth';
import type { TenantContext } from '@firstelement/database';
import {
  createProjectSchema,
  updateProjectSchema,
  type CreateProjectInput,
  type UpdateProjectInput,
} from '@firstelement/shared';
import { zodBody } from '../common/zod-validation.pipe';
import { RequirePermissions, Tenant } from '../auth/decorators';
import { ProjectsService } from './projects.service';

@Controller('projects')
export class ProjectsController {
  constructor(private readonly projects: ProjectsService) {}

  @Get()
  @RequirePermissions(Permission.PROJECT_READ)
  list(@Tenant() ctx: TenantContext, @Query('includeArchived') includeArchived?: string) {
    return this.projects.list(ctx, { includeArchived: includeArchived === 'true' });
  }

  @Get(':projectId')
  @RequirePermissions(Permission.PROJECT_READ)
  getOne(@Tenant() ctx: TenantContext, @Param('projectId', ParseUUIDPipe) projectId: string) {
    return this.projects.getById(ctx, projectId);
  }

  @Post()
  @RequirePermissions(Permission.PROJECT_CREATE)
  create(
    @Tenant() ctx: TenantContext,
    @Body(zodBody(createProjectSchema)) body: CreateProjectInput,
    @Req() request: Request,
  ) {
    return this.projects.create(ctx, body, request.ip);
  }

  @Patch(':projectId')
  @RequirePermissions(Permission.PROJECT_UPDATE)
  update(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Body(zodBody(updateProjectSchema)) body: UpdateProjectInput,
    @Req() request: Request,
  ) {
    return this.projects.update(ctx, projectId, body, request.ip);
  }

  @Delete(':projectId')
  @RequirePermissions(Permission.PROJECT_DELETE)
  delete(
    @Tenant() ctx: TenantContext,
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Req() request: Request,
  ) {
    return this.projects.delete(ctx, projectId, request.ip);
  }
}
