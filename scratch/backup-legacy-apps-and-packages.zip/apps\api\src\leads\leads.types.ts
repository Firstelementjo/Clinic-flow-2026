export interface Lead {
  id: string;
  projectId: string;
  name: string;
  company?: string;
  source?: string;
  status: string;
  tags: string[];
  owner?: string;
  conversationCount: number;
  createdAt: string;
}

export interface LeadListItem {
  id: string;
  projectId: string;
  name: string;
  company?: string;
  source?: string;
  status: string;
  tags: string[];
  owner: string;
  conversationCount: number;
  createdAt: string;
}