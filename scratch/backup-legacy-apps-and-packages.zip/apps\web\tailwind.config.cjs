/** @type {import('tailwindcss').Config} */
module.exports = {
  presets: [require('@firstelement/ui/tailwind-preset.js')],
  content: [
    './index.html',
    './src/**/*.{ts,tsx}',
    '../../packages/ui/src/**/*.{ts,tsx}',
  ],
};
