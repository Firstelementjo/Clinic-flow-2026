import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { createHash } from 'node:crypto';
import { projectScope, type TenantContext } from '@firstelement/database';
import {
  MAX_UPLOAD_BYTES,
  buildStorageKey,
  isAllowedMimeType,
} from '@firstelement/knowledge-base';
import {
  AuditAction,
  ErrorCode,
  type CreateKnowledgeBaseInput,
  type CreateTextDocumentInput,
  type DocumentView,
  type KnowledgeBaseView,
  type RetrievalPreviewInput,
  type RetrievalPreviewResult,
} from '@firstelement/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../audit/audit.service';
import { KnowledgeRetrieverProvider, StorageDriverHolder } from './knowledge.providers';
import { KnowledgeQueueService } from './knowledge-queue.service';

export interface UploadedFile {
  originalname: string;
  mimetype: string;
  size: number;
  buffer: Buffer;
}

@Injectable()
export class KnowledgeService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly storage: StorageDriverHolder,
    private readonly retriever: KnowledgeRetrieverProvider,
    private readonly queue: KnowledgeQueueService,
  ) {}

  async listBases(ctx: TenantContext, projectId: string): Promise<KnowledgeBaseView[]> {
    const bases = await this.prisma.client.knowledgeBase.findMany({
      where: projectScope(ctx, projectId),
      select: {
        id: true,
        name: true,
        description: true,
        createdAt: true,
        documents: { select: { status: true } },
      },
      orderBy: { createdAt: 'asc' },
    });

    return bases.map((base) => ({
      id: base.id,
      name: base.name,
      description: base.description,
      documentCount: base.documents.length,
      readyCount: base.documents.filter((doc) => doc.status === 'READY').length,
      createdAt: base.createdAt.toISOString(),
    }));
  }

  async createBase(
    ctx: TenantContext,
    projectId: string,
    input: CreateKnowledgeBaseInput,
  ): Promise<KnowledgeBaseView> {
    const scope = projectScope(ctx, projectId);

    const existing = await this.prisma.client.knowledgeBase.findUnique({
      where: { projectId_name: { projectId, name: input.name } },
      select: { id: true },
    });
    if (existing) {
      throw new ConflictException({
        code: ErrorCode.CONFLICT,
        message: 'A knowledge base with this name already exists in the project',
      });
    }

    const created = await this.prisma.client.knowledgeBase.create({
      data: { ...scope, name: input.name, description: input.description },
      select: { id: true, name: true, description: true, createdAt: true },
    });

    return {
      ...created,
      documentCount: 0,
      readyCount: 0,
      createdAt: created.createdAt.toISOString(),
    };
  }

  async listDocuments(
    ctx: TenantContext,
    projectId: string,
    knowledgeBaseId?: string,
  ): Promise<DocumentView[]> {
    const documents = await this.prisma.client.document.findMany({
      where: { ...projectScope(ctx, projectId), ...(knowledgeBaseId ? { knowledgeBaseId } : {}) },
      select: {
        id: true,
        knowledgeBaseId: true,
        title: true,
        sourceType: true,
        mimeType: true,
        sizeBytes: true,
        status: true,
        failureReason: true,
        chunkCount: true,
        processedAt: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return documents.map((document) => ({
      ...document,
      processedAt: document.processedAt?.toISOString() ?? null,
      createdAt: document.createdAt.toISOString(),
    }));
  }

  /**
   * Accepts an upload and hands processing to the worker. The request
   * returns as soon as the bytes are safely stored — parsing and embedding
   * a large PDF is not something an HTTP request should wait on (plan §11).
   */
  async uploadDocument(
    ctx: TenantContext,
    projectId: string,
    knowledgeBaseId: string,
    file: UploadedFile,
    ipAddress?: string,
  ): Promise<DocumentView> {
    const scope = projectScope(ctx, projectId);
    await this.requireBase(ctx, projectId, knowledgeBaseId);

    // Type and size are checked here, before a byte is written (plan §12).
    if (!isAllowedMimeType(file.mimetype)) {
      throw new BadRequestException({
        code: ErrorCode.VALIDATION_FAILED,
        message: `Unsupported file type: ${file.mimetype}`,
      });
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      throw new BadRequestException({
        code: ErrorCode.VALIDATION_FAILED,
        message: `File is larger than the ${Math.round(MAX_UPLOAD_BYTES / 1024 / 1024)}MB limit`,
      });
    }

    const contentHash = createHash('sha256').update(file.buffer).digest('hex');
    // The key is generated, never derived from the uploaded filename —
    // user input on a filesystem path is a traversal bug waiting to happen.
    const storageKey = buildStorageKey(projectId);
    await this.storage.driver.put(storageKey, file.buffer);

    const document = await this.prisma.client.document.create({
      data: {
        ...scope,
        knowledgeBaseId,
        title: file.originalname.slice(0, 200),
        sourceType: 'FILE',
        storageKey,
        mimeType: file.mimetype,
        sizeBytes: file.size,
        contentHash,
        status: 'UPLOADED',
        uploadedByUserId: ctx.userId,
      },
      select: this.documentSelect(),
    });

    await this.queue.enqueue({
      organizationId: ctx.organizationId,
      projectId,
      documentId: document.id,
    });

    await this.audit.record({
      organizationId: ctx.organizationId,
      projectId,
      actorUserId: ctx.userId,
      action: AuditAction.ADMIN_UPLOADED_DOCUMENT,
      resourceType: 'Document',
      resourceId: document.id,
      metadata: { knowledgeBaseId, mimeType: file.mimetype, sizeBytes: file.size },
      ipAddress,
    });

    return this.toDocumentView(document);
  }

  /** Pasted text — the fastest way to seed a policy without a file. */
  async createTextDocument(
    ctx: TenantContext,
    projectId: string,
    knowledgeBaseId: string,
    input: CreateTextDocumentInput,
  ): Promise<DocumentView> {
    const scope = projectScope(ctx, projectId);
    await this.requireBase(ctx, projectId, knowledgeBaseId);

    const buffer = Buffer.from(input.content, 'utf8');
    const storageKey = buildStorageKey(projectId);
    await this.storage.driver.put(storageKey, buffer);

    const document = await this.prisma.client.document.create({
      data: {
        ...scope,
        knowledgeBaseId,
        title: input.title,
        sourceType: 'TEXT',
        storageKey,
        mimeType: 'text/plain',
        sizeBytes: buffer.byteLength,
        contentHash: createHash('sha256').update(buffer).digest('hex'),
        status: 'UPLOADED',
        uploadedByUserId: ctx.userId,
      },
      select: this.documentSelect(),
    });

    await this.queue.enqueue({
      organizationId: ctx.organizationId,
      projectId,
      documentId: document.id,
    });

    return this.toDocumentView(document);
  }

  async deleteDocument(ctx: TenantContext, projectId: string, documentId: string): Promise<void> {
    const scope = projectScope(ctx, projectId);
    const document = await this.prisma.client.document.findFirst({
      where: { id: documentId, ...scope },
      select: { id: true, storageKey: true },
    });
    if (!document) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Document not found' });
    }

    // Chunks cascade with the document row; the stored file does not.
    await this.prisma.client.document.delete({ where: { id: document.id } });
    if (document.storageKey) {
      await this.storage.driver.delete(document.storageKey).catch(() => undefined);
    }
  }

  /** Retry a failed document without re-uploading it. */
  async reprocessDocument(
    ctx: TenantContext,
    projectId: string,
    documentId: string,
  ): Promise<DocumentView> {
    const scope = projectScope(ctx, projectId);
    const document = await this.prisma.client.document.findFirst({
      where: { id: documentId, ...scope },
      select: { id: true },
    });
    if (!document) {
      throw new NotFoundException({ code: ErrorCode.NOT_FOUND, message: 'Document not found' });
    }

    const updated = await this.prisma.client.document.update({
      where: { id: documentId },
      data: { status: 'UPLOADED', failureReason: null },
      select: this.documentSelect(),
    });

    await this.queue.enqueue({
      organizationId: ctx.organizationId,
      projectId,
      documentId,
    });

    return this.toDocumentView(updated);
  }

  /**
   * Retrieval preview: what the agent would find for a question, with
   * scores. This is how an admin checks their knowledge base *before*
   * a customer does.
   */
  async previewRetrieval(
    ctx: TenantContext,
    projectId: string,
    input: RetrievalPreviewInput,
  ): Promise<RetrievalPreviewResult> {
    const scope = projectScope(ctx, projectId);

    const result = await this.retriever.retrieve({
      organizationId: scope.organizationId,
      projectId: scope.projectId,
      query: input.query,
      limit: input.limit,
    });

    return {
      chunks: result.chunks.map((chunk) => ({
        chunkId: chunk.chunkId,
        documentId: chunk.documentId,
        documentTitle: chunk.documentTitle,
        chunkIndex: chunk.chunkIndex,
        content: chunk.content,
        score: Number(chunk.score.toFixed(4)),
      })),
      isGap: result.isGap,
      bestScore: result.bestScore === null ? null : Number(result.bestScore.toFixed(4)),
    };
  }

  private async requireBase(ctx: TenantContext, projectId: string, knowledgeBaseId: string) {
    const base = await this.prisma.client.knowledgeBase.findFirst({
      where: { id: knowledgeBaseId, ...projectScope(ctx, projectId) },
      select: { id: true },
    });
    if (!base) {
      throw new NotFoundException({
        code: ErrorCode.NOT_FOUND,
        message: 'Knowledge base not found',
      });
    }
    return base;
  }

  private documentSelect() {
    return {
      id: true,
      knowledgeBaseId: true,
      title: true,
      sourceType: true,
      mimeType: true,
      sizeBytes: true,
      status: true,
      failureReason: true,
      chunkCount: true,
      processedAt: true,
      createdAt: true,
    } as const;
  }

  private toDocumentView(document: {
    id: string;
    knowledgeBaseId: string;
    title: string;
    sourceType: 'FILE' | 'URL' | 'TEXT';
    mimeType: string | null;
    sizeBytes: number | null;
    status: DocumentView['status'];
    failureReason: string | null;
    chunkCount: number;
    processedAt: Date | null;
    createdAt: Date;
  }): DocumentView {
    return {
      ...document,
      processedAt: document.processedAt?.toISOString() ?? null,
      createdAt: document.createdAt.toISOString(),
    };
  }
}
