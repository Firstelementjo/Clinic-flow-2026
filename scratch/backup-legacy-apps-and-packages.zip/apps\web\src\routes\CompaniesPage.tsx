import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Building2, CalendarPlus, Globe, Link2, MapPin, MoreHorizontal, Trash2, UserRound } from 'lucide-react';
import { useDirection } from '@firstelement/ui';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useT } from '../lib/i18n';
import { api } from '../lib/api';
import { formatDate } from '../lib/format';
import { useAccounts, type AccountRow } from '../lib/accounts';
import { CreateCompanyDrawer } from '../components/company-form';
import { useCrmViews } from '../lib/views';
import {
  ListView,
  Menu,
  MenuItem,
  RecordAvatar,
  type ListColumn,
} from '../components/ListView';

const accountsKey = ['accounts'] as const;

export function CompaniesPage() {
  const t = useT();
  const dir = useDirection();
  const qc = useQueryClient();
  const views = useCrmViews('company', { noun: t('companies.list.title'), defaultSort: 'name' });
  const [createOpen, setCreateOpen] = useState(false);
  const location = useLocation();
  const nav = useNavigate();
  useEffect(() => {
    if (new URLSearchParams(location.search).get('new') === '1') {
      setCreateOpen(true);
      nav(location.pathname, { replace: true });
    }
  }, [location.search, nav]);

  const accounts = useAccounts(views.search);

  const rows = views.sort === 'created'
    ? [...(accounts.data ?? [])].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    : accounts.data;

  const invalidate = () => void qc.invalidateQueries({ queryKey: accountsKey });

  const remove = useMutation({
    mutationFn: (id: string) => api.delete(`/accounts/${id}`),
    onSuccess: invalidate,
  });

  const removeMany = useMutation({
    mutationFn: async (ids: string[]) => {
      await Promise.all(ids.map((id) => api.delete(`/accounts/${id}`)));
    },
    onSuccess: invalidate,
  });

  const nameCell = (acc: AccountRow) => (
    <button
      type="button"
      tabIndex={-1}
      className="flex min-w-0 max-w-full items-center gap-2 text-start"
      title={acc.name}
    >
      <RecordAvatar name={acc.name} />
      <span className="truncate text-sm font-medium text-ink transition-colors hover:text-signal">
        {acc.name || t('list.col.untitled')}
      </span>
    </button>
  );

  const columns: ListColumn<AccountRow>[] = [
    { id: 'name', label: 'list.col.name', icon: Building2, size: 'minmax(12rem, 3fr)', render: nameCell },
    {
      id: 'website',
      label: 'list.col.domain',
      icon: Globe,
      size: 'minmax(9rem, 2fr)',
      render: (acc) => acc.website,
    },
    {
      id: 'createdBy',
      label: 'list.col.createdBy',
      icon: UserRound,
      size: 'minmax(7rem, 1.5fr)',
      render: (acc) => acc.createdBy?.fullName ?? null,
    },
    {
      id: 'owner',
      label: 'list.col.owner',
      icon: UserRound,
      size: 'minmax(7rem, 1.5fr)',
      render: (acc) => acc.owner?.fullName ?? null,
    },
    {
      id: 'createdAt',
      label: 'list.col.created',
      icon: CalendarPlus,
      size: '7rem',
      render: (acc) => formatDate(acc.createdAt, dir.locale),
    },
    { id: 'linkedin', label: 'list.col.linkedin', icon: Link2, size: '9rem', render: (acc) => acc.linkedin },
    { id: 'address', label: 'list.col.address', icon: MapPin, size: 'minmax(10rem, 2fr)', render: (acc) => acc.address },
  ];

  const footerCells = [
    {
      col: 'name',
      render: (list: AccountRow[]) => <span>{list.length}</span>,
    },
    {
      col: 'linkedin',
      render: (list: AccountRow[]) => {
        if (list.length === 0) return null;
        const empty = list.filter((a) => !a.linkedin).length;
        return `${Math.round((empty / list.length) * 100)}% ${t('list.footer.empty')}`;
      },
    },
    {
      col: 'address',
      render: (list: AccountRow[]) => `${list.filter((a) => a.address).length} ${t('list.footer.filledPct')}`,
    },
  ];

  return (
    <>
      <ListView<AccountRow>
        title={t('companies.list.title')}
        eyebrow={t('companies.list.eyebrow')}
        addLabel={t('list.newCompany')}
        onAdd={() => setCreateOpen(true)}
        noun={t('companies.list.title')}
        objectType="companies"
        columns={columns}
        rows={rows}
        isPending={accounts.isPending}
        isError={accounts.isError}
        keyOf={(a) => a.id}
        viewSwitcher={views.switcher}
        filterValue={views.search}
        onFilter={views.setSearch}
        sortValue={views.sort}
        onSort={views.setSort}
        sortOptions={[
          { value: 'name', label: t('list.col.name') },
          { value: 'created', label: t('list.col.created') },
        ]}
        hiddenColumns={views.hidden}
        onHiddenColumnsChange={views.setHidden}
        onDeleteSelected={(ids) => removeMany.mutate(ids)}
        footerCells={footerCells}
        rowActions={(acc) => (
          <Menu
            button={
              <span
                aria-label={t('list.options')}
                role="img"
                className="flex h-6 w-6 items-center justify-center rounded text-slate-soft transition-colors hover:bg-mist hover:text-ink"
              >
                <MoreHorizontal aria-hidden="true" className="h-4 w-4" />
              </span>
            }
          >
            <MenuItem
              danger
              icon={Trash2}
              label={t('companies.delete')}
              onClick={() => remove.mutate(acc.id)}
            />
          </Menu>
        )}
      />
      <CreateCompanyDrawer open={createOpen} onClose={() => setCreateOpen(false)} />
    </>
  );
}