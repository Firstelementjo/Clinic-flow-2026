import { describe, expect, it } from 'vitest';
import {
  DEFAULT_ESCALATION_RULES,
  RuleOperator,
  ScoreSignal,
  describeMatch,
  evaluateRules,
  testCondition,
  type EscalationRuleInput,
  type RuleFacts,
} from './rules';

function facts(overrides: Partial<RuleFacts> = {}): RuleFacts {
  return {
    frustration: 10,
    sentiment: 60,
    urgency: 10,
    risk: 10,
    intentConfidence: 70,
    aiConfidence: null,
    intent: 'delivery',
    evaluator: 'heuristic',
    signals: {},
    aiTurnsWithoutResolution: 0,
    explicitHumanRequest: false,
    ...overrides,
  };
}

function rule(overrides: Partial<EscalationRuleInput> = {}): EscalationRuleInput {
  return {
    id: 'rule-1',
    name: 'Frustration threshold',
    isEnabled: true,
    priority: 100,
    combinator: 'ALL',
    conditions: [{ signal: ScoreSignal.FRUSTRATION, operator: RuleOperator.GTE, value: 70 }],
    ...overrides,
  };
}

describe('conditions', () => {
  it('compares a signal against its threshold', () => {
    const condition = { signal: ScoreSignal.FRUSTRATION, operator: RuleOperator.GTE, value: 70 };
    expect(testCondition(condition, facts({ frustration: 74 }))).toBe(true);
    expect(testCondition(condition, facts({ frustration: 69 }))).toBe(false);
    expect(testCondition(condition, facts({ frustration: 70 }))).toBe(true);
  });

  it('treats a missing signal as not-matching rather than as zero', () => {
    // aiConfidence is null on a customer turn. A "≤ 30" rule must not fire
    // just because nothing was measured.
    const condition = { signal: ScoreSignal.AI_CONFIDENCE, operator: RuleOperator.LTE, value: 30 };
    expect(testCondition(condition, facts({ aiConfidence: null }))).toBe(false);
    expect(testCondition(condition, facts({ aiConfidence: 20 }))).toBe(true);
  });

  it('maps the boolean human-request signal onto 1/0', () => {
    const condition = {
      signal: ScoreSignal.EXPLICIT_HUMAN_REQUEST,
      operator: RuleOperator.EQ,
      value: 1,
    };
    expect(testCondition(condition, facts({ explicitHumanRequest: true }))).toBe(true);
    expect(testCondition(condition, facts({ explicitHumanRequest: false }))).toBe(false);
  });
});

describe('rule evaluation', () => {
  it('returns nothing when no rule matches', () => {
    expect(evaluateRules([rule()], facts({ frustration: 20 }))).toBeNull();
  });

  it('matches when the threshold is crossed', () => {
    const match = evaluateRules([rule()], facts({ frustration: 74 }));
    expect(match?.rule.id).toBe('rule-1');
    expect(match?.matched).toHaveLength(1);
  });

  it('requires every condition under ALL', () => {
    const combined = rule({
      combinator: 'ALL',
      conditions: [
        { signal: ScoreSignal.FRUSTRATION, operator: RuleOperator.GTE, value: 50 },
        { signal: ScoreSignal.SENTIMENT, operator: RuleOperator.LTE, value: 25 },
      ],
    });

    expect(evaluateRules([combined], facts({ frustration: 60, sentiment: 40 }))).toBeNull();
    expect(evaluateRules([combined], facts({ frustration: 60, sentiment: 20 }))).not.toBeNull();
  });

  it('needs only one condition under ANY', () => {
    const either = rule({
      combinator: 'ANY',
      conditions: [
        { signal: ScoreSignal.FRUSTRATION, operator: RuleOperator.GTE, value: 90 },
        { signal: ScoreSignal.RISK, operator: RuleOperator.GTE, value: 60 },
      ],
    });

    expect(evaluateRules([either], facts({ frustration: 10, risk: 70 }))).not.toBeNull();
  });

  it('ignores disabled rules and rules with no conditions', () => {
    expect(evaluateRules([rule({ isEnabled: false })], facts({ frustration: 95 }))).toBeNull();
    expect(evaluateRules([rule({ conditions: [] })], facts({ frustration: 95 }))).toBeNull();
  });

  it('picks the lowest-priority rule first, deterministically', () => {
    const urgent = rule({ id: 'a', name: 'Risk', priority: 10, conditions: [{ signal: ScoreSignal.RISK, operator: RuleOperator.GTE, value: 50 }] });
    const later = rule({ id: 'b', name: 'Frustration', priority: 90 });

    const match = evaluateRules([later, urgent], facts({ frustration: 95, risk: 80 }));
    expect(match?.rule.id).toBe('a');
  });

  it('breaks a priority tie by id, so the same input always escalates the same way', () => {
    const first = rule({ id: 'aaa', priority: 50 });
    const second = rule({ id: 'bbb', priority: 50 });

    expect(evaluateRules([second, first], facts({ frustration: 95 }))?.rule.id).toBe('aaa');
  });
});

describe('default rules', () => {
  const defaults = DEFAULT_ESCALATION_RULES.map((definition, index) => ({
    ...definition,
    id: `default:${index}`,
  }));

  it('escalates immediately when the customer asks for a person', () => {
    const match = evaluateRules(defaults, facts({ explicitHumanRequest: true }));
    expect(match?.rule.name).toBe('Customer asked for a person');
  });

  it('escalates at frustration 70, the threshold from the plan', () => {
    expect(evaluateRules(defaults, facts({ frustration: 69 }))).toBeNull();
    expect(evaluateRules(defaults, facts({ frustration: 74 }))?.rule.name).toBe(
      'Frustration threshold',
    );
  });

  it('escalates a moderately frustrated but very negative customer', () => {
    const match = evaluateRules(defaults, facts({ frustration: 55, sentiment: 20 }));
    expect(match?.rule.name).toBe('Frustrated and negative');
  });

  it('escalates after repeated AI turns even when the wording stays calm', () => {
    const match = evaluateRules(defaults, facts({ aiTurnsWithoutResolution: 5 }));
    expect(match?.rule.name).toBe('Repeated AI attempts');
  });

  it('leaves a calm conversation with the AI', () => {
    expect(evaluateRules(defaults, facts())).toBeNull();
  });
});

describe('explanation', () => {
  it('renders the matched thresholds as a sentence an employee can read', () => {
    const match = evaluateRules([rule()], facts({ frustration: 74 }));
    expect(describeMatch(match!)).toBe('Frustration threshold (frustration ≥ 70)');
  });

  it('joins multiple conditions with the rule combinator', () => {
    const combined = rule({
      name: 'Frustrated and negative',
      conditions: [
        { signal: ScoreSignal.FRUSTRATION, operator: RuleOperator.GTE, value: 50 },
        { signal: ScoreSignal.SENTIMENT, operator: RuleOperator.LTE, value: 25 },
      ],
    });
    const match = evaluateRules([combined], facts({ frustration: 60, sentiment: 20 }));
    expect(describeMatch(match!)).toContain(' and ');
  });
});
