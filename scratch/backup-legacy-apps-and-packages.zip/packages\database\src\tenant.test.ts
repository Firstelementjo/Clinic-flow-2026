import { describe, expect, it } from 'vitest';
import {
  TenantAccessError,
  accessibleProjectsScope,
  canAccessProject,
  organizationScope,
  projectScope,
  type TenantContext,
} from './tenant';

const ctx: TenantContext = {
  organizationId: 'org-1',
  userId: 'user-1',
  role: 'EMPLOYEE',
  projectIds: ['project-a'],
};

describe('projectScope', () => {
  it('pins the query to both tenant columns', () => {
    expect(projectScope(ctx, 'project-a')).toEqual({
      organizationId: 'org-1',
      projectId: 'project-a',
    });
  });

  it('refuses a project the caller has no membership in', () => {
    expect(() => projectScope(ctx, 'project-b')).toThrowError(TenantAccessError);
  });

  it('refuses an unknown project id rather than returning an unscoped filter', () => {
    expect(() => projectScope(ctx, 'does-not-exist')).toThrowError(TenantAccessError);
  });
});

describe('accessibleProjectsScope', () => {
  it('lists only the caller projects', () => {
    expect(accessibleProjectsScope(ctx)).toEqual({
      organizationId: 'org-1',
      projectId: { in: ['project-a'] },
    });
  });

  it('yields an empty set — not an unfiltered query — for a user with no memberships', () => {
    const orphan: TenantContext = { ...ctx, projectIds: [] };
    expect(accessibleProjectsScope(orphan).projectId.in).toEqual([]);
  });
});

describe('organizationScope', () => {
  it('always carries the organization id', () => {
    expect(organizationScope(ctx)).toEqual({ organizationId: 'org-1' });
  });
});

describe('canAccessProject', () => {
  it('is membership, not role', () => {
    expect(canAccessProject(ctx, 'project-a')).toBe(true);
    expect(canAccessProject({ ...ctx, role: 'ADMIN' }, 'project-b')).toBe(false);
  });
});
