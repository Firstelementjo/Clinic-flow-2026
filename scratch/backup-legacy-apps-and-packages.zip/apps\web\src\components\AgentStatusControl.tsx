import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { EmployeeAvailabilityStatus, type AgentStatusView } from '@firstelement/shared';
import { api } from '../lib/api';
import { useT, type StringKey } from '../lib/i18n';

/** Order shown in the picker: working states first, then stated absences. */
const STATUSES: EmployeeAvailabilityStatus[] = [
  EmployeeAvailabilityStatus.ONLINE,
  EmployeeAvailabilityStatus.BUSY,
  EmployeeAvailabilityStatus.BREAK,
  EmployeeAvailabilityStatus.MEAL,
  EmployeeAvailabilityStatus.MEETING,
  EmployeeAvailabilityStatus.TRAINING,
  EmployeeAvailabilityStatus.OFFLINE,
];

/** Dot colour by status — routable states read as "at the desk". */
const TONE: Record<string, string> = {
  ONLINE: 'bg-signal',
  BUSY: 'bg-agent',
  BREAK: 'bg-escalation',
  MEAL: 'bg-escalation',
  MEETING: 'bg-escalation',
  TRAINING: 'bg-escalation',
  OFFLINE: 'bg-slate-soft',
};

/**
 * Agent status with its running timer (V1.2 §8, §9).
 *
 * The timer counts from the server's `since` rather than from a local
 * start: a refresh, a second tab, or a sleeping laptop all show the same
 * elapsed time, and it matches the totals a supervisor reports on.
 */
export function AgentStatusControl() {
  const t = useT();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [now, setNow] = useState(() => Date.now());

  const status = useQuery({
    queryKey: ['my-status'],
    queryFn: () => api.get<AgentStatusView>('/me/status'),
    // A status changed on another device should surface here too.
    refetchInterval: 60_000,
    retry: false,
  });

  const setStatus = useMutation({
    mutationFn: (availabilityStatus: EmployeeAvailabilityStatus) =>
      api.patch<AgentStatusView>('/me/availability', { availabilityStatus }),
    onSuccess: (updated) => {
      queryClient.setQueryData(['my-status'], updated);
      void queryClient.invalidateQueries({ queryKey: ['team'] });
      setOpen(false);
    },
  });

  // One interval for the whole control rather than one per rendered digit.
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Admins without an employee profile have no status to set.
  if (status.isError || !status.data) return null;

  const since = new Date(status.data.since).getTime();
  const elapsed = Math.max(0, Math.floor((now - since) / 1000));

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 rounded border border-hairline bg-surface px-2 py-1 hover:bg-mist"
        aria-label={t('status.change')}
      >
        <span className={`h-2 w-2 rounded-full ${TONE[status.data.status] ?? 'bg-slate-soft'}`} />
        <span className="text-xs text-ink">
          {t(`availability.${status.data.status}` as StringKey)}
        </span>
        {status.data.status !== EmployeeAvailabilityStatus.OFFLINE && (
          <span className="fe-mono text-2xs text-slate" dir="ltr">
            {formatDuration(elapsed)}
          </span>
        )}
      </button>

      {open && (
        <ul className="absolute start-0 top-full z-20 mt-1 w-44 rounded border border-hairline bg-surface py-1 shadow-panel">
          {STATUSES.map((option) => (
            <li key={option}>
              <button
                type="button"
                onClick={() => setStatus.mutate(option)}
                disabled={setStatus.isPending}
                className={[
                  'flex w-full items-center gap-2 px-3 py-1.5 text-start text-xs hover:bg-mist',
                  option === status.data.status ? 'font-medium text-ink' : 'text-slate',
                ].join(' ')}
              >
                <span className={`h-2 w-2 rounded-full ${TONE[option]}`} />
                {t(`availability.${option}` as StringKey)}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/** `HH:MM:SS`, because a shift is measured in hours (V1.2 §9). */
function formatDuration(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const rest = seconds % 60;
  return [hours, minutes, rest].map((value) => String(value).padStart(2, '0')).join(':');
}
