/**
 * Document parsers (plan §9).
 *
 * A parser's job is to produce text and to fail clearly when it cannot. An
 * unreadable file must surface as FAILED with a reason an admin can act on
 * — "This PDF has no extractable text; it looks like a scan" — rather than
 * being indexed as an empty document that quietly answers nothing.
 */

export interface ParsedDocument {
  text: string;
  /** Anything the format exposes that is worth keeping (page count, title). */
  metadata: Record<string, unknown>;
}

export class UnsupportedFormatError extends Error {
  constructor(readonly mimeType: string) {
    super(`Unsupported file type: ${mimeType}`);
    this.name = 'UnsupportedFormatError';
  }
}

export class EmptyDocumentError extends Error {
  constructor(message = 'No readable text found in this file') {
    super(message);
    this.name = 'EmptyDocumentError';
  }
}

/** Upload validation (plan §12: validated file uploads, type and size). */
export const ALLOWED_MIME_TYPES = [
  'text/plain',
  'text/markdown',
  'text/csv',
  'application/json',
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
] as const;

export const MAX_UPLOAD_BYTES = 20 * 1024 * 1024;

export function isAllowedMimeType(mimeType: string): boolean {
  return (ALLOWED_MIME_TYPES as readonly string[]).includes(mimeType);
}

export async function parseDocument(
  buffer: Buffer,
  mimeType: string,
  fileName?: string,
): Promise<ParsedDocument> {
  const parsed = await runParser(buffer, mimeType, fileName);

  if (!parsed.text.trim()) {
    throw new EmptyDocumentError(
      mimeType === 'application/pdf'
        ? 'This PDF contains no extractable text. If it is a scan, it needs OCR before upload.'
        : 'No readable text found in this file',
    );
  }

  return parsed;
}

async function runParser(
  buffer: Buffer,
  mimeType: string,
  fileName?: string,
): Promise<ParsedDocument> {
  switch (mimeType) {
    case 'text/plain':
    case 'text/markdown':
      return { text: buffer.toString('utf8'), metadata: { fileName } };

    case 'text/csv':
      return { text: parseCsv(buffer.toString('utf8')), metadata: { fileName } };

    case 'application/json':
      return { text: parseJson(buffer.toString('utf8')), metadata: { fileName } };

    case 'application/pdf':
      return parsePdf(buffer, fileName);

    case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
      return parseDocx(buffer, fileName);

    default:
      throw new UnsupportedFormatError(mimeType);
  }
}

/**
 * CSV becomes one line per row with its header labels attached. A bare
 * grid of values embeds as noise; "Plan: Pro, Price: 49 SAR" retrieves.
 */
function parseCsv(raw: string): string {
  const rows = raw
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map(splitCsvLine);

  const [header, ...body] = rows;
  if (!header) return '';
  if (body.length === 0) return header.join(', ');

  return body
    .map((row) => header.map((column, i) => `${column}: ${row[i] ?? ''}`).join(', '))
    .join('\n');
}

function splitCsvLine(line: string): string[] {
  const values: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      values.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  values.push(current.trim());
  return values;
}

/** Flattens JSON to `path: value` lines so structure survives embedding. */
function parseJson(raw: string): string {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new EmptyDocumentError('This file is not valid JSON');
  }

  const lines: string[] = [];
  const walk = (value: unknown, path: string): void => {
    if (value === null || value === undefined) return;
    if (Array.isArray(value)) {
      value.forEach((item, index) => walk(item, `${path}[${index}]`));
      return;
    }
    if (typeof value === 'object') {
      for (const [key, child] of Object.entries(value)) {
        walk(child, path ? `${path}.${key}` : key);
      }
      return;
    }
    lines.push(`${path}: ${String(value)}`);
  };

  walk(parsed, '');
  return lines.join('\n');
}

async function parsePdf(buffer: Buffer, fileName?: string): Promise<ParsedDocument> {
  const pdfParse = await loadOptional<(data: Buffer) => Promise<{ text: string; numpages: number }>>(
    'pdf-parse',
    'PDF support',
  );
  const result = await pdfParse(buffer);
  return { text: result.text, metadata: { fileName, pageCount: result.numpages } };
}

async function parseDocx(buffer: Buffer, fileName?: string): Promise<ParsedDocument> {
  const mammoth = await loadOptional<{
    extractRawText(input: { buffer: Buffer }): Promise<{ value: string }>;
  }>('mammoth', 'Word document support');
  const result = await mammoth.extractRawText({ buffer });
  return { text: result.value, metadata: { fileName } };
}

/**
 * Loaded on demand so a deployment that never uploads PDFs does not pay
 * for the parser at boot — and so a missing optional dependency reports
 * itself as a document-level failure rather than crashing the worker.
 */
async function loadOptional<T>(moduleName: string, feature: string): Promise<T> {
  try {
    const loaded = (await import(moduleName)) as T & { default?: T };
    return loaded.default ?? loaded;
  } catch {
    throw new UnsupportedFormatError(`${feature} is not installed (missing ${moduleName})`);
  }
}
