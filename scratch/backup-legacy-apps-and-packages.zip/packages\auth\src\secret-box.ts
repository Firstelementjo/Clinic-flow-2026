import { createCipheriv, createDecipheriv, randomBytes, timingSafeEqual } from 'node:crypto';

/**
 * Encryption for connector credentials at rest (plan §8, §12).
 *
 * AES-256-GCM, so the ciphertext is authenticated: a tampered blob fails
 * to decrypt rather than yielding plausible garbage that gets sent to
 * Meta as an access token. The envelope carries a version prefix so the
 * key or algorithm can be rotated without guessing at old rows.
 *
 * Envelope: `v1.<iv>.<authTag>.<ciphertext>`, each part base64url.
 */

const VERSION = 'v1';
const IV_BYTES = 12; // GCM standard nonce length
const KEY_BYTES = 32;

export class SecretBoxError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SecretBoxError';
  }
}

function toKey(hexKey: string): Buffer {
  if (!/^[0-9a-fA-F]{64}$/.test(hexKey)) {
    throw new SecretBoxError('ENCRYPTION_KEY must be 64 hex characters (32 bytes)');
  }
  const key = Buffer.from(hexKey, 'hex');
  if (key.length !== KEY_BYTES) throw new SecretBoxError('ENCRYPTION_KEY has the wrong length');
  return key;
}

export function encryptSecret(plaintext: string, hexKey: string): string {
  const key = toKey(hexKey);
  const iv = randomBytes(IV_BYTES);
  const cipher = createCipheriv('aes-256-gcm', key, iv);

  const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();

  return [VERSION, b64(iv), b64(authTag), b64(ciphertext)].join('.');
}

export function decryptSecret(envelope: string, hexKey: string): string {
  const key = toKey(hexKey);
  const parts = envelope.split('.');

  if (parts.length !== 4 || parts[0] !== VERSION) {
    throw new SecretBoxError('Unrecognized secret envelope');
  }

  try {
    const decipher = createDecipheriv('aes-256-gcm', key, unb64(parts[1]!));
    decipher.setAuthTag(unb64(parts[2]!));
    return Buffer.concat([decipher.update(unb64(parts[3]!)), decipher.final()]).toString('utf8');
  } catch {
    // Wrong key or tampered ciphertext — indistinguishable on purpose.
    throw new SecretBoxError('Could not decrypt this secret');
  }
}

/** Encrypts a credential bundle as one blob rather than field by field. */
export function encryptJson(value: Record<string, unknown>, hexKey: string): string {
  return encryptSecret(JSON.stringify(value), hexKey);
}

export function decryptJson<T = Record<string, unknown>>(envelope: string, hexKey: string): T {
  return JSON.parse(decryptSecret(envelope, hexKey)) as T;
}

/**
 * Constant-time comparison for shared secrets (Telegram's webhook token,
 * Meta's verify token). `===` on a secret leaks its prefix through timing.
 */
export function secretsMatch(a: string, b: string): boolean {
  const left = Buffer.from(a, 'utf8');
  const right = Buffer.from(b, 'utf8');
  // Length is compared separately because timingSafeEqual throws on a
  // mismatch; the length of a token is not the part worth hiding.
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

function b64(buffer: Buffer): string {
  return buffer.toString('base64url');
}

function unb64(value: string): Buffer {
  return Buffer.from(value, 'base64url');
}
